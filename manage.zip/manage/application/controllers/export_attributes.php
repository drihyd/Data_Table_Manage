<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Export_attributes extends CI_Controller {
    
	function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
	
	function index() {
		
		require APPPATH . 'controllers/class/PHPExcel.php';
		require_once APPPATH . 'controllers/class/PHPExcel/IOFactory.php';
		
		$excel_data = array();
		$excel_headings = array(
			'attribute_id',
			'product_id',
			'link',
			'product_name',
			'attribute_name',
			'attribute_value',
		);
		array_push($excel_data, $excel_headings);
		
		$products = array();
		$this->db->select('product_id');
		$this->db->where('stock >', 0);
		$this->db->group_by('product_id');
		$check = $this->db->get('skus');
		if($check->num_rows() > 0) {
			$products = $check->result();
		}
		
		$product_ids = array();
		foreach($products as $product) {
			array_push($product_ids, $product->product_id);
		}
		
		if(count($product_ids) == 0) {
			echo 'no products in stock';
			exit();
		}
		
		$product_attributes = array();
		$this->db->where_in('product_id', $product_ids);
		$check = $this->db->get('product_attrs');
		if($check->num_rows() > 0) {
			$product_attributes = $check->result();
		}
		
		$product_index = array();
		$products = array();
		$this->db->where_in('id', $product_ids);
		$check = $this->db->get('products');
		if($check->num_rows() > 0) {
			$products = $check->result();
		}
		
		foreach($products as $product) {
			$product_index[$product->id] = $product;
		}
		
		foreach($product_attributes as $attribute) {
			$attribute_id = $attribute->id;
			$product_id = $attribute->product_id;
			$product_name = ucwords($product_index[$product_id]->name);
			$product_link = "http://taruni.in/product/view/" . $product_index[$product_id]->slug;
			$attribute_name = ucwords($attribute->attribute_name);
			$attribute_value = ucwords($attribute->attribute_value);
			
			$row = array(
				$attribute_id,
				$product_id,
				$product_link,
				$product_name,
				$attribute_name,
				$attribute_value,
			);
			
			array_push($excel_data, $row);
		}
		
		$title = 'taruni-attribute-correction-'.date('d-M-Y', time());
		
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->getProperties()->setCreator("Taruni");
		$objPHPExcel->getProperties()->setLastModifiedBy("Taruni");
		$objPHPExcel->getProperties()->setTitle("{$title}");
		$objPHPExcel->getProperties()->setSubject("{$title}");
		$objPHPExcel->getProperties()->setDescription("{$title}");
		
		$objPHPExcel->getActiveSheet()->fromArray($excel_data, null, 'A1');
		
		$date = date('M-d-Y', time());
		
		header("Content-Type: application/xlsx");
		header("Content-Disposition: attachment; filename={$title}.xlsx");
		header("Pragma: no-cache");
		header("Expires: 0");
		
		$highestColumn = $objPHPExcel->getActiveSheet()->getHighestDataColumn();
		$nCols = PHPExcel_Cell::columnIndexFromString($highestColumn);
		
		foreach (range(0, $nCols) as $col) {
			$objPHPExcel->getActiveSheet()->getColumnDimensionByColumn($col)->setWidth(30);                
		}
		
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
		$objWriter->save('php://output');
	}
		
}
