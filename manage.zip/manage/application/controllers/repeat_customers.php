<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Repeat_customers extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'form',
			'email_helper',
            'page_initiater_helper',
        );
        $models = array(
            'model_carts' => 'carts',
            'model_categories' => 'categories',
            'model_customers' => 'customers',
            'model_orders' => 'orders',
            'model_order_items' => 'order_items',
            'model_products' => 'products',
            'model_skus' => 'skus',
            'model_users' => 'users',
            'model_reorder_thresholds' => 'reorder_thresholds',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
	function index() {
		
		$data = initiate_page();
        $data['page_name'] = 'Repeat Customers';
        $data['page_title'] = 'Repeat Customers';
        
        $data['sidebar_element'] = 'side-customers';
        $data['sidebar_subelement'] = 'side-repeat-customers';
        
        $data['seo_title'] = 'Repeat Customers';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
		
		$orders = array();
		$filters = array(
			'customer_id !=' => 0,
			'total_items >' => 0,
			'total_amount >' => 0,
		);
		$check = $this->orders->get_true_orders($filters);
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$repeat_customers = array();
		$repeat_customer_count = array();
		
		foreach($orders as $order) {
			
			$filters = array(
				'customer_id' => $order->customer_id,
			);
			$check = $this->orders->get_where_array($filters);
			if($check->num_rows() > 1) {
				$customer_id = $order->customer_id;
				if( ! isset($repeat_customers[$customer_id]) ) {
					$check = $this->customers->get($customer_id);
					if($check->num_rows() == 0) {
						CONTINUE;
					}
					$repeat_customers[$customer_id] = $check->row();
					$repeat_customer_count[$customer_id] = 0;
				}
				$repeat_customer_count[$customer_id] += 1;
			}
		}
		
		$data['repeat_customers'] = $repeat_customers;
		$data['repeat_customer_count'] = $repeat_customer_count;
		
		$this->load->view('header', $data);
		$this->load->view('repeat_customers_view', $data);
		$this->load->view('footer', $data);
		
	}
	
	
	
	
}
