<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Newsletter_leads extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('mdl_newsletter_leads', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'newsletter_leads';
      
      $newsletter_leads = array();
      $query = $this->db->query("select * from leads where `for` = 'newsletter'");
      if($query) :
        foreach($query->result() as $newsletter_lead) {
          foreach($newsletter_lead as $key => $value) {
            $newsletter_leads[$newsletter_lead->id][$key] = $value;
          }
        }
      endif;
      $data['newsletter_leads'] = $newsletter_leads;
      $this->load->view('header', $data);
      $this->load->view('newsletter_leads_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function delete($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $this->mdl_newsletter_leads->_delete($id);
      
      
      redirect('newsletter_leads');
    }
    else {
      redirect('login', 'refresh');
    }
  }
    
  function get($order_by) {
  $this->load->model('mdl_newsletter_leads');
  $query = $this->mdl_newsletter_leads->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_newsletter_leads');
  $query = $this->mdl_newsletter_leads->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_newsletter_leads');
  $query = $this->mdl_newsletter_leads->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_newsletter_leads');
  $query = $this->mdl_newsletter_leads->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_newsletter_leads');
  $this->mdl_newsletter_leads->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_newsletter_leads');
  $this->mdl_newsletter_leads->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_newsletter_leads');
  $this->mdl_newsletter_leads->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_newsletter_leads');
  $count = $this->mdl_newsletter_leads->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_newsletter_leads');
  $max_id = $this->mdl_newsletter_leads->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_newsletter_leads');
  $query = $this->mdl_newsletter_leads->_custom_query($mysql_query);
  return $query;
  }

}
