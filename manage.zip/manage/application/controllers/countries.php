<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Countries extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_countries', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Countries';
            $data['page_title'] = 'All Countries';
            
            $data['sidebar_element'] = 'side-master-data';
            $data['sidebar_subelement'] = 'side-countries-view';
            
            $this->load->model('mdl_shipping_rates');
            $this->load->model('mdl_shipping_times');
            
            $check = $this->mdl_countries->get('id');
            if($check->num_rows() > 0) {
              $countries = $check->result();
            }
            else {
              $countries = array();
            }
            
            $check = $this->mdl_shipping_rates->get('id');
            if($check->num_rows() > 0) {
              $shipping_rates_info = array();
              foreach($check->result() as $shipping_rate) {
                $shipping_rates_info[$shipping_rate->id] = $shipping_rate;
              }
            }
            else {
              $shipping_rates_info = array();
            }
            
            $check = $this->mdl_shipping_times->get('id');
            if($check->num_rows() > 0) {
              $shipping_times_info = array();
              foreach($check->result() as $shipping_time) {
                $shipping_times_info[$shipping_time->id] = $shipping_time;
              }
            }
            else {
              $shipping_times_info = array();
            }
            
            $data['shipping_rates_info'] = $shipping_rates_info;
            $data['shipping_times_info'] = $shipping_times_info;
            $data['countries'] = $countries;
            
            $this->load->view('header', $data);
            $this->load->view('countries_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Add Shipping Rate';
            $data['page_title'] = 'Add Shipping Rate';
            
            $data['sidebar_element'] = 'side-countries';
            $data['sidebar_subelement'] = 'side-add-country';
            
            $this->load->model('mdl_shipping_rates');
            $this->load->model('mdl_shipping_times');
            
            $check = $this->mdl_shipping_rates->get('id');
            if($check->num_rows() > 0) {
              $shipping_rates = $check->result();
            }
            else {
              $shipping_rates = array();
            }
            
            $check = $this->mdl_shipping_times->get('id');
            if($check->num_rows() > 0) {
              $shipping_times = $check->result();
            }
            else {
              $shipping_times = array();
            }
            
            $data['shipping_rates'] = $shipping_rates;
            $data['shipping_times'] = $shipping_times;
            
            $this->load->view('header', $data);
            $this->load->view('country_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function delete() {
      if ($this->session->userdata('logged_in')) {
          $session_data = $this->session->userdata('logged_in');
          $data['username'] = $session_data['username'];
          $data['user_type'] = $session_data['type'];
          $data['user_email'] = $session_data['email'];
          
          $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Sorry! You are not auhtorised to delete Countries. Please contact DB Administrator.</strong></div>");
          redirect("countries");
            
      }
      else {
          redirect('login', 'refresh');
      }
    }
    
    
    function edit($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = 'Edit Shipping Rate';
            
            $data['sidebar_element'] = 'side-countries';
            $data['sidebar_subelement'] = 'side-countries-view';
            
            $check = $this->mdl_countries->get_where($id);
            if($check->num_rows() > 0) {
              $country_details = $check->row();
            }
            else {
              $country_details->array();
            }
            
            $data['country_details'] = $country_details;
            
            $this->load->model('mdl_shipping_rates');
            $this->load->model('mdl_shipping_times');
            
            $check = $this->mdl_shipping_rates->get('id');
            if($check->num_rows() > 0) {
              $shipping_rates = $check->result();
            }
            else {
              $shipping_rates = array();
            }
            
            $check = $this->mdl_shipping_times->get('id');
            if($check->num_rows() > 0) {
              $shipping_times = $check->result();
            }
            else {
              $shipping_times = array();
            }
            
            $data['shipping_rates'] = $shipping_rates;
            $data['shipping_times'] = $shipping_times;
            
            $this->load->view('header', $data);
            $this->load->view('country_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function save($id=null) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = '';
            
            $data['sidebar_element'] = 'side-countries';
            $data['sidebar_subelement'] = 'side-countries-view';
            
            $this->load->model('mdl_shipping_rates');
            $this->load->model('mdl_shipping_times');
            
            if($id) {
              $check = $this->mdl_countries->get_where($id);
              if($check->num_rows() > 0) {
                $country_details = $check->row();
              }
              else {
                redirect('404', 'refresh');
              }
              
              $countryName = $this->input->post('countryName', true);
              $countryCode = $this->input->post('countryCode', true);
              $countryShippingRateID = (int) $this->input->post('countryShippingRateID', true);
              $countryShippingTimeID = (int) $this->input->post('countryShippingTimeID', true);
              $countryTax = $this->input->post('countryTax', true);
              $countryCOD = (int) $this->input->post('countryCOD', true);
              
              if( (trim($countryName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              if( (trim($countryCode) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Country Code cannot be empty.</strong></div>");
                redirect("countries/edit/{$id}");
              }
            
              if( (trim($countryShippingRateID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Rate cannot be empty.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              if( (trim($countryShippingTimeID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Time cannot be empty.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              if( (trim($countryTax) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Tax cannot be empty.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              if( (trim($countryCOD) == '') || ( ! in_array($countryCOD, array(0,1)) ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid COD Availability.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_rates->get_where($countryShippingRateID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Rate ID.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_times->get_where($countryShippingTimeID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Time ID.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              $new_data = array(
                'country_name' => $countryName,
                'country_code' => $countryCode,
                'shipping_rate_id' => $countryShippingRateID,
                'shipping_time_id' => $countryShippingTimeID,
                'tax_percentage' => $countryTax,
                'cod_available' => $countryCOD
              );
              
              $this->mdl_countries->_update($id, $new_data);
              
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully updated!</strong></div>");
              redirect("countries/edit/{$id}");
            
            }
            else {
              
              $countryName = $this->input->post('countryName', true);
              $countryCode = $this->input->post('countryCode', true);
              $countryShippingRateID = (int) $this->input->post('countryShippingRateID', true);
              $countryShippingTimeID = (int) $this->input->post('countryShippingTimeID', true);
              $countryTax = $this->input->post('countryTax', true);
              $countryCOD = (int) $this->input->post('countryCOD', true);
              
              if( (trim($countryName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              if( (trim($countryCode) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Country Code cannot be empty.</strong></div>");
                redirect("countries/edit/{$id}");
              }
            
              if( (trim($countryShippingRateID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Rate cannot be empty.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              if( (trim($countryShippingTimeID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Time cannot be empty.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              if( (trim($countryTax) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Tax cannot be empty.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              if( (trim($countryCOD) == '') || ( ! in_array($countryCOD, array(0,1)) ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid COD Availability.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_rates->get_where($countryShippingRateID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Rate ID.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_times->get_where($countryShippingTimeID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Time ID.</strong></div>");
                redirect("countries/edit/{$id}");
              }
              
              $new_data = array(
                'country_name' => $countryName,
                'country_code' => $countryCode,
                'shipping_rate_id' => $countryShippingRateID,
                'shipping_time_id' => $countryShippingTimeID,
                'tax_percentage' => $countryTax,
                'cod_available' => $countryCOD
              );
              
              $this->mdl_countries->_insert($new_data);
              $id = $this->db->insert_id();
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully added!</strong></div>");
              redirect("countries/edit/{$id}");
            
            }

        }
        else {
            redirect('login', 'refresh');
        }
    }

}
