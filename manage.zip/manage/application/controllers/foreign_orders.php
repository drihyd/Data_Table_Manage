<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Foreign_orders extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'email_helper',
            'page_initiater_helper',
        );
        $models = array(
            'model_carts' => 'carts',
            'model_categories' => 'categories',
            'model_customers' => 'customers',
            'model_orders' => 'orders',
            'model_order_items' => 'order_items',
            'model_products' => 'products',
            'model_skus' => 'skus',
            'model_users' => 'users',
            'model_reorder_thresholds' => 'reorder_thresholds',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function index() {
		$data = initiate_page();
		
		$data['page_name']  = 'foreign orders';
		$data['page_title'] = 'Foreign orders';

		$data['sidebar_element']    = 'side-orders';
		$data['sidebar_subelement'] = 'side-foreign-orders-view';
		
		$data['seo_title'] = 'Orders';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
		
		if( ! $this->input->get('month', TRUE)) {
			$month = date('M', strtotime('first day of last month'));
			$year = date('Y', strtotime('first day of last month'));
		} else {
			$monthYear = strtolower(trim($this->input->get('monthYear', TRUE)));
			$monthYear = explode('-', $monthYear);
			$month = (int) $this->input->get('month', TRUE);
			$year = (int) $this->input->get('year', TRUE);
			
			if( ($month > 12) OR ($month < 1)) {
				$month = date('M', time());
			}
			
			$phrase = "01-" . $month . "-" . $year;
			$month = date('M', strtotime($phrase));			
		}
		$from_phrase = "first day of " . $month . " " . $year;
		$to_phrase   = "last day of " . $month . " " . $year;
		
		$from_date = date('Y-m-d', strtotime($from_phrase));
		$to_date = date('Y-m-d', strtotime($to_phrase));
		
		$data['from_date'] = $from_date;
		$data['to_date'] = $to_date;
		
		#---------------------------------------------------------------
		# Get Month
		$current_month = date('m', strtotime($from_date));
		$current_year  = date('Y', strtotime($from_date));
		
		$orders = array();
		$orders_this_month = 0;
		$check = $this->orders->get_month_foreign($current_month, $current_year);
		if($check->num_rows() > 0) {
			$orders = $check->result();
			$orders_this_month = $check->num_rows();
		}
		$data['orders_this_month'] = $orders_this_month;
		$data['orders'] = $orders;
		
		$customer_index = array();
		$shipping_index = array();
		$payment_details_index = array();
		
		$this->load->model('model_payments');
        $this->load->model('model_customers');
        $this->load->model('model_order_items');
		
		$total_revenue = 0;
		$total_weight = 0;
		
		foreach($orders as $order) {
			
			$payment_details = '';
			$payment_type = 'COD';
			
			if($order->payment_mode != 'cod') {
				$check = $this->model_payments->get($order->payment_id);
				if($check->num_rows() > 0) {
					$payment_details = $check->row();
					$payment_type = 'EBS';
					if($payment_details->paypal_payer_id != NULL) {
						$payment_type = 'PayPal';
					}
				}
			}
			
			$total_revenue += $order->grand_total;
			$total_weight += $order->total_shipping_weight;
			
			$payment_details_index[$order->id] = $payment_type;
			
			if( ! isset($order_nums[$order->order_status])) {
				$order_nums[$order->order_status] = 0;
			}
			$order_nums[$order->order_status] += 1;
			
			$shipping_index[$order->id] = 'domestic';
			if($order->ship_to_country_id != 99) {
				$shipping_index[$order->id] = 'foreign';
			}
			
			if( ! isset($customer_index[$order->customer_id])) {
				$customer_details = array();
				$check = $this->model_customers->get($order->customer_id);
				if($check->num_rows() > 0) {
					$customer_details = $check->row();
				}
				$customer_index[$order->customer_id] = $customer_details;
			}
			
			$filters = array(
				'order_id' => $order->id,
				'alterations !=' => '',
			);
			$check = $this->model_order_items->get_where_array($filters);
			if($check->num_rows() > 0) {
				$alterations_index[$order->id] = 1;
			}
		}
		$data['total_revenue'] = $total_revenue;
		$data['total_weight'] = $total_weight;
		$data['shipping_index'] = $shipping_index;
		$data['customer_index'] = $customer_index;
		$data['payment_details_index'] = $payment_details_index;
		
		$this->load->view('header', $data);
		$this->load->view('foreign_orders_view', $data);
		$this->load->view('footer', $data);
		
		//$this->load->view('monthly_report', $data);
		
	}
	
	// get category size stock
	function get_category_size_stock($cat_id, $size) {
		$filters = array(
			'stock >' => 0,
			'size' => $size,
			'cat_id' => $cat_id,
		);
		$check = $this->skus->get_where_array($filters);
		$skus = array();
		$stock = 0;
		if($check->num_rows() > 0) {
			$skus = $check->result();
		}
		foreach($skus as $sku) {
			$stock += $sku->stock;
		}	
		return $stock;
	}
	
}
