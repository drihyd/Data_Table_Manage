<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Attribute_values extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_attribute_values', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        redirect('attributes', 'refresh');
    }
    
    function add() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'attributes';
            $data['page_title'] = 'Add New Attribute';
            
            $data['sidebar_element'] = 'side-attributes';
            $data['sidebar_subelement'] = 'side-attributes-view';            
            
            $this->load->model('mdl_attributes');
            
            $query = $this->mdl_attributes->get('id');
            if($query->num_rows() > 0) {
              $attributes = $query->result();
            }
            else {
              $attributes = array();
            }
            
            $data['attributes'] = $attributes;
            
            
            $this->load->view('header', $data);
            $this->load->view('attribute_value_add_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add_child_attr_value($parent_attr_id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'attributes';
            $data['page_title'] = 'Add New Attribute';
            
            $data['sidebar_element'] = 'side-attributes';
            $data['sidebar_subelement'] = 'side-attributes-view';            
            
            $this->load->model('mdl_attributes');
            
            
            $query = $this->mdl_attributes->get_where($parent_attr_id);
            if($query->num_rows() > 0) {
              $attributes = $query->result();
            }
            else {
              redirect('404', 'refresh');
            }
            
            $data['attributes'] = $attributes;
            
            
            $this->load->view('header', $data);
            $this->load->view('attribute_value_add_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function edit($attribute_value_id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'attributes';
            $data['page_title'] = 'Add New Attribute';
            
            $data['sidebar_element'] = 'side-attributes';
            $data['sidebar_subelement'] = 'side-attributes-view';            
            
            $this->load->model('mdl_attributes');
            
            $attribute_value_id = (int) $attribute_value_id;
            $query_check = $this->mdl_attribute_values->get_where($attribute_value_id);
            if( $query_check->num_rows() > 0 ) {
              $attribute_value_details = $query_check->row();
            }
            else {
              redirect('404', 'refresh');
            }
            
            $data['attribute_value_details'] = $attribute_value_details;
            
            $query = $this->mdl_attributes->get_where($attribute_value_details->attr_id);
            if( $query->num_rows() > 0 ) {
              $attribute_details = $query->row();
            }
            
            $data['attribute_details'] = $attribute_details;
            
            $this->load->view('header', $data);
            $this->load->view('attribute_value_edit_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function delete($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'attributes';
            $data['page_title'] = 'Add New Attribute';
            
            $data['sidebar_element'] = 'side-attributes';
            $data['sidebar_subelement'] = 'side-attributes-view';            
            
            $query = $this->mdl_attribute_values->get_where($id);
            if($query->num_rows() > 0) {
              $attribute_value_details = $query->row();
            }
            else {
              redirect('404', 'refresh');
            }
            
            //now delete the attribute
            $this->mdl_attribute_values->_delete($attribute_value_details->id);
            
            $this->session->set_flashdata('message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Deleted Successfully</strong></div>");
            redirect('attributes', 'refresh');
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function save($attribute_value_id = FALSE) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'attributes';
            $data['page_title'] = 'All Attributes';
            
            $data['sidebar_element'] = 'side-attributes';
            $data['sidebar_subelement'] = 'side-attributes-view';
            
            $this->load->model('mdl_attributes');
            
            $attributeID = $this->input->post('attributeID', true);
            $attributeValue = $this->input->post('attributeValue', true);
            
            if ($attribute_value_id) {
                
                $attribute_value_id = (int) $attribute_value_id;
                $query_check = $this->mdl_attribute_values->get_where($attribute_value_id);
                if( ! $query_check->num_rows() > 0) {
                  $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Attribute Value.</strong></div>");
                  redirect("attribute_values/add", 'refresh');
                }
                
                $attribute_value_details = $query_check->row();
                
                $attributeValue = trim(strtolower($attributeValue));
                if($attributeValue == '') {
                  $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Value cannot be empty.</strong></div>");
                  redirect("attribute_values/edit/{$attribute_value_details->id}", 'refresh');
                }
                
                //check whether this value already exists for this attribute
                $this->db->where_not_in('id', array($attribute_value_details->id));
                $this->db->where('attr_id', $attribute_value_details->attr_id);
                $this->db->where('attr_value', $attributeValue);
                $query = $this->mdl_attribute_values->get('id');
                if( $query->num_rows() > 0 ) {
                  $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! This value already exists.</strong></div>");
                  redirect("attribute_values/edit/{$attribute_value_details->id}", 'refresh');
                }
                
                $new_data = array(
                  'attr_value' => $attributeValue
                );
                
                $this->mdl_attribute_values->_update($attribute_value_details->id, $new_data);
                
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully Updated!</strong></div>");
                redirect("attribute_values/edit/{$attribute_value_details->id}", 'refresh');
            }
            else {
                
                $attributeID = (int) $attributeID;
                $query_check = $this->mdl_attributes->get_where($attributeID);
                if( ! $query_check->num_rows() > 0) {
                  $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Parent Attribute.</strong></div>");
                  redirect("attribute_values/add", 'refresh');
                }
                
                $attribute_details = $query_check->row();
                
                $attributeValue = trim(strtolower($attributeValue));
                if($attributeValue == '') {
                  $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Value cannot be empty.</strong></div>");
                  redirect("attribute_values/add", 'refresh');
                }
                
                //check whether this value already exists for this attribute
                $this->db->where('attr_id', $attribute_details->id);
                $this->db->where('attr_value', $attributeValue);
                $query_check = $this->mdl_attribute_values->get('id');
                if( $query_check->num_rows() > 0 ) {
                  $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! This value already exists for this attribute.</strong></div>");
                  redirect("attribute_values/add", 'refresh');
                }
                
                $new_data = array(
                  'attr_id' => $attribute_details->id,
                  'attr_value' => $attributeValue
                );
                
                $this->mdl_attribute_values->_insert($new_data);
                
                $id = mysql_insert_id();
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Attribute Value successfully added!</strong></div>");
                redirect("attribute_values/edit/{$id}", 'refresh');
            }
            
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
}
