<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Projects extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('mdl_projects', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'projects';
      
      $projects = array();
      $query = $this->mdl_projects->get('id');
      if($query) :
        foreach($query->result() as $project) {
          $projects[$project->id] = array(
            'id' => $project->id,
            'name' => $project->name,
            'slug' => $project->slug,
            'desc' => $project->desc,
            'main_img' => $project->main_img
          );
        }
      endif;
      $data['projects'] = $projects;
      $this->load->view('header', $data);
      $this->load->view('projects_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function edit($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'projects';
      
      $project_details = array();
      $query = $this->mdl_projects->get_where($id);
      foreach($query->result() as $project) {
        
        $project_details = array (
          'id' => $project->id,
          'name' => $project->name,
          'slug' => $project->slug,
          'desc' => $project->desc,
          'main_img' => $project->main_img,
          'seo_title' => $project->seo_title,
          'seo_desc' => $project->seo_desc,
          'seo_keywords' => $project->seo_keywords
        );
      }
      $data['project_details'] = $project_details;
      
      $query = $this->db->query("select * from gallery where project_id = {$id}");
      $galleryimgs = array();
      if($query->result()) {
        foreach($query->result() as $galleryimg) {
          $galleryimgs[$galleryimg->id] = array(
            'id' => $galleryimg->id,
            'project_id' => $galleryimg->project_id,
            'caption' => $galleryimg->caption,
            'image' => $galleryimg->img_path
          );
        }
      }
      else {
        $galleryimgs = '';
      }
      
      $data['galleryimgs'] = $galleryimgs;
      
      $data['tinyMC'] = TRUE;
      
      $this->load->view('header', $data);
      $this->load->view('project_edit', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function save($id=FALSE) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'projects';
      
      $projectName = $this->input->post('projectName');
      $projectSlug = $this->input->post('projectSlug');
      $projectDesc = $this->input->post('projectDesc');
      
      if($id) {
        
        if($_FILES['projectDPChange']['name']) {

          $config['upload_path']='../assets/uploads/files/';
          $config['allowed_types']='gif|png|jpg|jpeg';
          $this->load->library('upload',$config);
          
          if(!$this->upload->do_upload('projectDPChange')) {
            $data['uploadErrors'] = $this->upload->display_errors();
            echo $data['uploadErrors'].'<br>';
            echo "<a href='{$this->config->base_url()}projects/edit/{$id}'>Please try again</a>"; 
          }
          else {
            $res = $this->upload->data();
            $DPname = $res['file_name'];
            $data = array(
              'name' => $projectName,
              'slug' => $projectSlug,
              'desc' => $projectDesc,
              'main_img' => $DPname
            );
            
            $current_image = $this->db->query("select * from projects where id = {$id}");
            if(!($current_image->row()->main_img == '')) :
              unlink('../assets/uploads/files/'.$current_image->row()->main_img);
            endif;
            
            $query = $this->db->query("select * from projects where id not in('{$id}') and slug = '{$projectSlug}'");
            if($query->num_rows() > 0) {
              echo "Slug already exists. <a href='{$this->config->base_url()}projects/edit/{$id}'>Enter a unique slug.</a>";
            }
            else {            
              $this->mdl_projects->_update($id, $data);
              $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
              redirect("projects/edit/{$id}");
            }
          }
        }
        else {
          $data = array(
            'name' => $projectName,
            'slug' => $projectSlug,
            'desc' => $projectDesc
          );
          
          $query = $this->db->query("select * from projects where id not in('{$id}') and slug = '{$projectSlug}'");
          if($query->num_rows() > 0) {
            echo "Slug already exists. <a href='{$this->config->base_url()}projects/edit/{$id}'>Enter a unique slug.</a>";
          }
          else {          
            $this->mdl_projects->_update($id, $data);
            $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
            redirect("projects/edit/{$id}");
          }
        }
        
      }
      else {
        if($_FILES['projectDPChange']['name']) {

          $config['upload_path']='../assets/uploads/files/';
          $config['allowed_types']='gif|png|jpg|jpeg';
          $this->load->library('upload',$config);
          
          if(!$this->upload->do_upload('projectDPChange')) {
            $data['uploadErrors'] = $this->upload->display_errors();
            echo $data['uploadErrors'].'<br>';
            echo "<a href='{$this->config->base_url()}projects/add'>Please try again</a>"; 
          }
          else {
            $res = $this->upload->data();
            $DPname = $res['file_name'];
            $data = array(
              'name' => $projectName,
              'slug' => $projectSlug,
              'desc' => $projectDesc,
              'main_img' =>$DPname
            );
            
            $query = $this->db->query("select * from projects where slug = '{$projectSlug}'");
            if($query->num_rows() > 0) {
              echo "Slug already exists. <a href='{$this->config->base_url()}projects/add'>Enter a unique slug.</a>";
            }
            else {
              $this->mdl_projects->_insert($data);
              $id = mysql_insert_id();
              $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
              redirect("projects/edit/{$id}");
            }
          }
        }
        else {
          $data = array(
            'name' => $projectName,
            'slug' => $projectSlug,
            'desc' => $projectDesc
          );
          
          $query = $this->db->query("select * from projects where slug = '{$projectSlug}'");
          if($query->num_rows() > 0) {
            echo "Slug already exists. <a href='{$this->config->base_url()}projects/add'>Enter a unique slug.</a>";
          }
          else {
            $this->mdl_projects->_insert($data);
            $id = mysql_insert_id();
            $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
            redirect("projects/edit/{$id}");
          }
        }
      }
      
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  
  function seosave($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'projects';
      
      $seoTitle = $this->input->post('projectSeoTitle');
      $seoDesc = $this->input->post('projectSeoDesc');
      $seoKeys = $this->input->post('projectSeoKeys');
      
      $data = array(
        'seo_title' => $seoTitle,
        'seo_desc' => $seoDesc,
        'seo_keywords' => $seoKeys
      );
      print_r($data);
      $this->mdl_projects->_update($id, $data);
      $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
      redirect('projects');
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  
  function add() {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'projects';
      
      $data['tinyMC'] = TRUE;
      //$data['products'] = $products;
      $this->load->view('header', $data);
      $this->load->view('project_add', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function delete($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $current_image = $this->db->query("select * from projects where id = {$id}");
      if(!($current_image->row()->main_img == '')) :
        unlink('../assets/uploads/files/'.$current_image->row()->main_img);
      endif;
      
      $this->mdl_projects->_delete($id);
      
      
      redirect('projects');
    }
    else {
      redirect('login', 'refresh');
    }
  }
    
  function get($order_by) {
  $this->load->model('mdl_projects');
  $query = $this->mdl_projects->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_projects');
  $query = $this->mdl_projects->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_projects');
  $query = $this->mdl_projects->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_projects');
  $query = $this->mdl_projects->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_projects');
  $this->mdl_projects->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_projects');
  $this->mdl_projects->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_projects');
  $this->mdl_projects->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_projects');
  $count = $this->mdl_projects->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_projects');
  $max_id = $this->mdl_projects->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_projects');
  $query = $this->mdl_projects->_custom_query($mysql_query);
  return $query;
  }

}
