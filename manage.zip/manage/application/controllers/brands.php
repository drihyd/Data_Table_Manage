<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Brands extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('mdl_brands', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'brands';
      $brands = array();
      $query = $this->mdl_brands->get('id');
      if($query) :
        foreach($query->result() as $brand) {
          $brands[$brand->id] = array(
            'id' => $brand->id,
            'name' => $brand->name,
            'slug' => $brand->slug,
            'logo' => $brand->logo,
            'seo_title' => $brand->seo_title,
            'seo_desc' => $brand->seo_desc,
            'seo_keywords' => $brand->seo_keywords
          );
        }
      endif;
      $data['brands'] = $brands;
      $this->load->view('header', $data);
      $this->load->view('brands_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function edit($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'brands';
      
      $brand_details = array();
      $query = $this->mdl_brands->get_where($id);
      foreach($query->result() as $brand) {
        
        $brand_details = array (
          'id' => $brand->id,
          'name' => $brand->name,
          'slug' => $brand->slug,
          'logo' => $brand->logo,
          'seo_title' => $brand->seo_title,
          'seo_desc' => $brand->seo_desc,
          'seo_keywords' => $brand->seo_keywords
        );
      }
      $data['brand_details'] = $brand_details;
      
      $data['tinyMC'] = TRUE;
      
      $this->load->view('header', $data);
      $this->load->view('brand_edit', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function save($id=FALSE) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'brands';
      
      $brandName = $this->input->post('brandName');
      $brandSlug = $this->input->post('brandSlug');
      
      if($id) {
        
        if($_FILES['brandLogoChange']['name']) {
          
          $config['upload_path']='../assets/uploads/files/';
          $config['allowed_types']='gif|png|jpg|jpeg';
          $this->load->library('upload',$config);
          
          if(!$this->upload->do_upload('brandLogoChange')) {
            $data['uploadErrors'] = $this->upload->display_errors();
            echo $data['uploadErrors'].'<br>';
            echo "<a href='{$this->config->base_url()}brands/edit/{$id}'>Please try again</a>"; 
          }
          else {
            $res = $this->upload->data();
            $DPname = $res['file_name'];
            $data = array(
              'name' => $brandName,
              'slug' => $brandSlug,
              'logo' => $DPname
            );
            
            $query = $this->db->query("select * from brands where id not in('{$id}') and slug = '{$brandSlug}'");
            if($query->num_rows() > 0) {
              echo "Slug already exists. <a href='{$this->config->base_url()}brands/edit/{$id}'>Enter a unique slug.</a>";
            }
            else {
              
              $current_image = $this->db->query("select * from brands where id = {$id}");
              if(!($current_image->row()->logo == '')) :
                unlink('../assets/uploads/files/'.$current_image->row()->logo); 
              endif;
              
              $this->mdl_brands->_update($id, $data);
              $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
              redirect("brands/edit/{$id}");
              //$this->index();
            }
          }
        }
        else {
          $data = array(
            'name' => $brandName,
            'slug' => $brandSlug
          );
          
          $query = $this->db->query("select * from brands where id not in('{$id}') and slug = '{$brandSlug}'");
          if($query->num_rows() > 0) {
            echo "Slug already exists. <a href='{$this->config->base_url()}brands/edit/{$id}'>Enter a unique slug.</a>";
          }
          else {          
            $this->mdl_brands->_update($id, $data);
            $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
            redirect("brands/edit/{$id}");
            //$this->index();
          }
        }
      }
      else {
        
        if($_FILES['brandLogoChange']['name']) {
          
          $config['upload_path']='../assets/uploads/files/';
          $config['allowed_types']='gif|png|jpg|jpeg';
          $this->load->library('upload',$config);
          
          if(!$this->upload->do_upload('brandLogoChange')) {
            $data['uploadErrors'] = $this->upload->display_errors();
            echo $data['uploadErrors'].'<br>';
            echo "<a href='{$this->config->base_url()}brands/edit/{$id}'>Please try again</a>"; 
          }
          else {
            $res = $this->upload->data();
            $DPname = $res['file_name'];
            $data = array(
              'name' => $brandName,
              'slug' => $brandSlug,
              'logo' => $DPname
            );
            
            $query = $this->db->query("select * from brands where slug = '{$brandSlug}'");
            if($query->num_rows() > 0) {
              echo "Slug already exists. <a href='{$this->config->base_url()}brands/add'>Enter a unique slug.</a>";
            }
            else {
              $this->mdl_brands->_insert($data);
              $id = mysql_insert_id();
              $data['success'] = "<div class='alert alert-success'>Record Created Successfully!</div>";
              redirect("brands/edit/{$id}");
            }
          }
        }
        else {
          $data = array(
            'name' => $brandName,
            'slug' => $brandSlug
          );
          
          $query = $this->db->query("select * from brands where slug = '{$brandSlug}'");
          if($query->num_rows() > 0) {
            echo "Slug already exists. <a href='{$this->config->base_url()}brands/add'>Enter a unique slug.</a>";
          }
          else {
            $this->mdl_brands->_insert($data);
            $id = mysql_insert_id();
            $data['success'] = "<div class='alert alert-success'>Record Created Successfully!</div>";
            redirect("brands/edit/{$id}");
          }
        }
      }
      
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function seosave($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'brands';
      
      $seoTitle = $this->input->post('brandSeoTitle');
      $seoDesc = $this->input->post('brandSeoDesc');
      $seoKeys = $this->input->post('brandSeoKeys');
      
      $data = array(
        'seo_title' => $seoTitle,
        'seo_desc' => $seoDesc,
        'seo_keywords' => $seoKeys
      );
      
      $this->mdl_brands->_update($id, $data);
      $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
      redirect('brands');
      //$this->index();
      
      
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function add() {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'brands';
      
      $data['tinyMC'] = TRUE;
      //$data['products'] = $products;
      $this->load->view('header', $data);
      $this->load->view('brand_add', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function delete($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $current_image = $this->db->query("select * from brands where id = {$id}");
      if(!($current_image->row()->logo == '')) :
        unlink('../assets/uploads/files/'.$current_image->row()->logo); 
      endif;
      
      $this->mdl_brands->_delete($id);
      
      $products = $this->db->query("select * from products where brnd_id='{$id}'");
      foreach($products->result() as $product) {
        //echo 'ill delete product- '. $product->name.'<br>';
        $query = $this->db->query("select * from images where product_id = {$product->id}");
        if($query->num_rows() > 0) :
          foreach($query->result() as $image) {
            if(!($image->path == '')) :
              unlink('../assets/uploads/files/'.$image->path);
              $this->db->delete('images', array('id' => $image->id)); 
            endif;
          }
        endif;
        $this->db->delete('products', array('id' => $product->id));
        
      }
      
      redirect('brands');
    }
    else {
      redirect('login', 'refresh');
    }
  }
    
  function get($order_by) {
  $this->load->model('mdl_brands');
  $query = $this->mdl_brands->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_brands');
  $query = $this->mdl_brands->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_brands');
  $query = $this->mdl_brands->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_brands');
  $query = $this->mdl_brands->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_brands');
  $this->mdl_brands->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_brands');
  $this->mdl_brands->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_brands');
  $this->mdl_brands->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_brands');
  $count = $this->mdl_brands->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_brands');
  $max_id = $this->mdl_brands->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_brands');
  $query = $this->mdl_brands->_custom_query($mysql_query);
  return $query;
  }

}
