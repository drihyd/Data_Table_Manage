<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Testimonials extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('mdl_testimonials', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'testimonials';
      
      $testimonials = array();
      $query = $this->mdl_testimonials->get('id');
      if($query) :
        foreach($query->result() as $testimonial) {
          $testimonials[$testimonial->id] = array(
            'id' => $testimonial->id,
            'testimonial_content' => $testimonial->testimonial_content,
            'name' => $testimonial->name,
            'dp_image' => $testimonial->dp_image,
            'slug' => $testimonial->slug,
            'seo_title' => $testimonial->seo_title,
            'seo_desc' => $testimonial->seo_desc,
            'seo_keywords' => $testimonial->seo_keywords
          );
        }
      endif;
      $data['testimonials'] = $testimonials;
      $this->load->view('header', $data);
      $this->load->view('testimonials_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function edit($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'testimonials';
      
      $testimonial_details = array();
      $query = $this->mdl_testimonials->get_where($id);
      foreach($query->result() as $testimonial) {
        
        $testimonial_details = array (
          'id' => $testimonial->id,
          'testimonial_content' => $testimonial->testimonial_content,
          'name' => $testimonial->name,
          'dp_image' => $testimonial->dp_image,
          'slug' => $testimonial->slug,
          'seo_title' => $testimonial->seo_title,
          'seo_desc' => $testimonial->seo_desc,
          'seo_keywords' => $testimonial->seo_keywords
        );
      }
      $data['testimonial_details'] = $testimonial_details;
      
      $data['tinyMC'] = TRUE;
      
      $this->load->view('header', $data);
      $this->load->view('testimonial_edit', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function save($id=FALSE) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'testimonials';
      
      $testimonialName = $this->input->post('testimonialName');
      $testimonialSlug = $this->input->post('testimonialSlug');
      $testimonialContent = $this->input->post('testimonialContent');
      
      if($id) {
        $data = array(
          'name' => $testimonialName,
          'slug' => $testimonialSlug,
          'testimonial_content' => $testimonialContent
        );
        
        $query = $this->db->query("select * from testimonials where id not in('{$id}') and slug = '{$testimonialSlug}'");
        if($query->num_rows() > 0) {
          echo "Slug already exists. <a href='{$this->config->base_url()}testimonials/edit/{$id}'>Enter a unique slug.</a>";
        }
        else {
          $this->mdl_testimonials->_update($id, $data);
          $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
          //echo $data['success'];
          redirect('testimonials');
        }
      }
      else {
        $data = array(
          'name' => $testimonialName,
          'slug' => $testimonialSlug,
          'testimonial_content' => $testimonialContent
        );
        
        $query = $this->db->query("select * from testimonials where slug = '{$testimonialSlug}'");
        if($query->num_rows() > 0) {
          echo "Slug already exists. <a href='{$this->config->base_url()}testimonials/add'>Enter a unique slug.</a>";
        }
        else {        
          $this->mdl_testimonials->_insert($data);
          $data['success'] = "<div class='alert alert-success'>Record Added Successfully!</div>";
          //echo $data['success'];
          redirect('testimonials');
        }
      }
      
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function seosave($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'testimonials';
      
      $seoTitle = $this->input->post('testimonialSeoTitle');
      $seoDesc = $this->input->post('testimonialSeoDesc');
      $seoKeys = $this->input->post('testimonialSeoKeys');
      
      $data = array(
        'seo_title' => $seoTitle,
        'seo_desc' => $seoDesc,
        'seo_keywords' => $seoKeys
      );
      print_r($data);
      $this->mdl_testimonials->_update($id, $data);
      $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
      redirect('testimonials');
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function add() {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'testimonials';
      
      $data['tinyMC'] = TRUE;
      //$data['products'] = $products;
      $this->load->view('header', $data);
      $this->load->view('testimonial_add', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function delete($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $this->mdl_testimonials->_delete($id);
      
      
      redirect('testimonials');
    }
    else {
      redirect('login', 'refresh');
    }
  }
    
  function get($order_by) {
  $this->load->model('mdl_testimonials');
  $query = $this->mdl_testimonials->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_testimonials');
  $query = $this->mdl_testimonials->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_testimonials');
  $query = $this->mdl_testimonials->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_testimonials');
  $query = $this->mdl_testimonials->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_testimonials');
  $this->mdl_testimonials->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_testimonials');
  $this->mdl_testimonials->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_testimonials');
  $this->mdl_testimonials->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_testimonials');
  $count = $this->mdl_testimonials->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_testimonials');
  $max_id = $this->mdl_testimonials->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_testimonials');
  $query = $this->mdl_testimonials->_custom_query($mysql_query);
  return $query;
  }

}
