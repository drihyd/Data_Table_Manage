<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('users_model', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['user_id'] = $session_data['id'];
      $data['user_email'] = $session_data['email'];
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $data['page_name'] = 'profile';
      
      $query = $this->db->get_where('users', array('id' => $data['user_id']));
      if($query->num_rows == 1) {
        $user_details = $query->row();
      }
      else {
        redirect('login', 'refresh');
      }
    
      $data['user_details'] = $user_details;
      
      $this->load->view('header', $data);
      $this->load->view('profile_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function change_pass() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['user_id'] = $session_data['id'];
      $data['user_email'] = $session_data['email'];
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $data['page_name'] = 'profile';
      
      $query = $this->db->get_where('users', array('id' => $data['user_id']));
      if($query->num_rows == 1) {
        $user_details = $query->row();
      }
      else {
        redirect('login', 'refresh');
      }
    
      $data['user_details'] = $user_details;
      
      $this->load->view('header', $data);
      $this->load->view('change_pass_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function change_pass_save() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['user_id'] = $session_data['id'];
      $data['user_email'] = $session_data['email'];
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      if( !($this->input->post('oldpass', true)) || !($this->input->post('newpass', true)) || !($this->input->post('newpass_confirm', true)) ) {
        echo "Invalid Input. Please <a href=\"{$this->config->base_url()}profile/change_pass\">try again</a>";
      }
      else {
        $data['page_name'] = 'profile';
              
        $query = $this->db->get_where('users', array('id' => $data['user_id']));
        if($query->num_rows == 1) {
          $user_details = $query->row();
        }
        else {
          redirect('login', 'refresh');
        }
        
        $data['user_details'] = $user_details;
        
        $oldpass = $this->input->post('oldpass', true);
        $newpass = $this->input->post('newpass', true);
        $newpass_confirm = $this->input->post('newpass_confirm', true);
        
        if($newpass != $newpass_confirm) {
          echo "Invalid Input. Please <a href=\"{$this->config->base_url()}profile/change_pass\">try again</a>";
        }
        else {
          
          $orig_pass = $user_details->password;
          $oldpass = md5($oldpass);
          
          if($oldpass != $orig_pass) {
            echo "The current password is incorrect. Please <a href=\"{$this->config->base_url()}profile/change_pass\">try again</a>";
          }
          else {
            $new_data = array (
              'password' => md5($newpass)
            );
            
            $this->db->where('id', $user_details->id);
            $this->db->update('users', $new_data);
            
            $data['success'] = 'Password changed successfully';
            $this->load->view('header', $data);
            $this->load->view('profile_view', $data);
            $this->load->view('footer', $data);
          }
        }
      }
      
      
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function forgot_pass() {
      
    $data['page_name'] = 'profile';
    
    if(!($this->input->post('email', true))) {
      echo "Please entre your registered Email";
      exit();
    }
    else{
      $email = $this->input->post('email', true);
      
      $query = $this->db->get_where('users', array('email' => $email));
      if($query->num_rows() != 1) {
        echo "The email address entered is not registered.";
        exit();
      }
      else {
        $user_details = $query->row();
        
        $new_pass = '';
        
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        for ($i = 0; $i < 8; $i++) {
          $new_pass .= $characters[rand(0, strlen($characters)-1)];
        }
        
        $new_data = array (
          'password' => md5($new_pass)
        );
        
        $this->db->where('id', $user_details->id);
        $this->db->update('users', $new_data);
        
        $this->load->helper('email_new_helper');
        
        $from = 'admin@taruni.in';
        $from_name = 'Taruni Admin';
        $to = $user_details->email;
        $to_name = $user_details->username;
        $subject = "Your new password";
        
        ob_start();
?>
<p style="font-family:monospace, sans-serif;font-size: 12px;color:#333;">
	Hi <?php echo $to_name; ?>,<br>
	Your new password: <?php echo $new_pass; ?>
	<br><br>
	Thanks,<br>
	Taruni Admin.
</p>

<?php
		$message = ob_get_clean();
		$plain_text_message = '';
		
        send_email($from, $from_name, $to, $to_name, $subject, $message, $plain_text_message);
        echo "A new password has been sent to your email. <a href='" . $this->config->base_url() . "login'>Retry Login</a>";
      }  
    }
    
  }

  
  function forgot_pass_page() {
      
    $data['page_name'] = 'profile';
    
    $this->load->view('forgot_pass_view', $data);
    $this->load->view('footer', $data);
    
  }
  
  function get($order_by) {
  $this->load->model('mdl_products');
  $query = $this->mdl_products->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_products');
  $query = $this->mdl_products->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_products');
  $query = $this->mdl_products->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_products');
  $query = $this->mdl_products->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_products');
  $this->mdl_products->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_products');
  $this->mdl_products->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_products');
  $this->mdl_products->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_products');
  $count = $this->mdl_products->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_products');
  $max_id = $this->mdl_products->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_products');
  $query = $this->mdl_products->_custom_query($mysql_query);
  return $query;
  }

}
