<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Vanakkam extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'email_helper',
            'page_initiater_helper',
        );
        $models = array(
            'model_carts' => 'carts',
            'model_categories' => 'categories',
            'model_customers' => 'customers',
            'model_orders' => 'orders',
            'model_order_items' => 'order_items',
            'model_products' => 'products',
            'model_skus' => 'skus',
            'model_users' => 'users',
            'model_reorder_thresholds' => 'reorder_thresholds',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function index() {
		echo "<style>.pure-table td, .pure-table th { white-space: nowrap; }</style>";
		$registrations = array();
		
		$this->db->order_by('vanakkam_id', 'DESC');
		$check = $this->db->get('vanakkam');
		
		if($check->num_rows() > 0) {
			$registrations = $check->result();
		}
		echo "<link rel='stylesheet' type='text/css' href='https://cdnjs.cloudflare.com/ajax/libs/pure/1.0.0/pure-min.css'>";
		echo "<style>body, table { font-family: monospace, sans-serif; font-size: 12px; line-height: 1.5; color: #333333;}</style>";
		echo "<table class='pure-table pure-table-horizontal'>";
		echo "<thead><tr><th>S.no</th><th>Name</th><th>Email</th><th>Phone</th><th>Coupon Code</th><th>Location</th><th>Source</th><th>Medium</th><th>Campaign</th><th>Content</th><th>Term</th><th>Date</th></tr></thead>";
		echo "<tbody>";
		
		$i = $check->num_rows();
		
		foreach($registrations as $registration) {
			echo "<tr>";
			echo "<td>" . $i . "</td>";
			echo "<td>" . ucwords($registration->vanakkam_name) . "</td>";
			echo "<td>" . $registration->vanakkam_email . "</td>";
			echo "<td>" . $registration->vanakkam_phone . "</td>";
			echo "<td>" . $registration->vanakkam_coupon_code . "</td>";
			echo "<td>" . ucwords($registration->vanakkam_location) . "</td>";
			echo "<td>" . $registration->utm_source . "</td>";
			echo "<td>" . $registration->utm_medium . "</td>";
			echo "<td>" . $registration->utm_campaign . "</td>";
			echo "<td>" . $registration->utm_content . "</td>";
			echo "<td>" . $registration->utm_term . "</td>";
			echo "<td>" . date('d M, Y', strtotime($registration->vanakkam_date_captured)) . "</td>";
			echo "</tr>";
			
			$i -= 1;
		}
		
		echo "</tbody>";
		echo "</table>";
	}
	
	function generate_report_excel($rows, $title, $bold_rows) {
		
		require APPPATH . 'controllers/class/PHPExcel.php';
		require_once APPPATH . 'controllers/class/PHPExcel/IOFactory.php';
		
		if(count($rows) == 0) {
			echo "Empty";
			return;
		}
		
		$excel_data = array();
		$excel_headings = array(
			'Date',
			'Order/Invoice Number',
			'State',
			'Tax Amount',
			'Grand Total',
			'Pieces',
		);
		array_push($excel_data, $excel_headings);
		
		$email_record = array();
		foreach($rows as $row) {
			array_push($excel_data, $row);
		}
		
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->getProperties()->setCreator("Taruni");
		$objPHPExcel->getProperties()->setLastModifiedBy("Taruni");
		$objPHPExcel->getProperties()->setTitle("{$title}");
		$objPHPExcel->getProperties()->setSubject("{$title}");
		$objPHPExcel->getProperties()->setDescription("{$title}");
		
		$objPHPExcel->getActiveSheet()->fromArray($excel_data, null, 'A1');
		
		$date = date('M-d-Y', time());
		
		header("Content-Type: application/xlsx");
		header("Content-Disposition: attachment; filename={$title}.xlsx");
		header("Pragma: no-cache");
		header("Expires: 0");
		
		$highestColumn = $objPHPExcel->getActiveSheet()->getHighestDataColumn();
		$nCols = PHPExcel_Cell::columnIndexFromString($highestColumn);
		
		foreach (range(0, $nCols) as $col) {
			$objPHPExcel->getActiveSheet()->getColumnDimensionByColumn($col)->setWidth(18);                
		}
		
		$from = "A1"; // or any value
		$to = "F1"; // or any value
		$objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold( true );
		
		foreach($bold_rows as $row_num) {
			$from = "A{$row_num}"; // or any value
			$to = "F{$row_num}"; // or any value
			
			$bgcolor = "95B3D7";
			
			$objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold( true );
			$objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFill()->applyFromArray(array(
				'type' => PHPExcel_Style_Fill::FILL_SOLID,
				'startcolor' => array(
					 'rgb' => $bgcolor,
				)
			));
		}
		
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
		$objWriter->save('php://output');
	}
	
	function currency_convertor($from_currency, $to_currency, $amount) {
		$from_currency = strtoupper($from_currency);
		$to_currency = strtoupper($to_currency);
		$get = file_get_contents("http://data.fixer.io/api/latest?access_key=d31268aae6ff8c6e1cfbf0df3729eb53&symbols={$from_currency},{$to_currency}&format=1");
		$get = json_decode($get);
		$rates = (array) $get->rates;
		$from_rate = $rates[$from_currency];
		$to_rate = $rates[$to_currency];
		$output = ($to_rate/$from_rate) * $amount;
		$output = round($output, 2);
		return $output;
	}
	
}
