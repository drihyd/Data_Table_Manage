<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');
	
class Abandoned_carts extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'page_initiater_helper'
		);
		$models  = array(
			'model_carts' => 'carts',
			'model_customers' => 'customers',
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
	
	function index() {
		
		$data               = initiate_page();
		$data['page_name']  = 'Abandoned Carts';
		$data['page_title'] = 'Abandoned Carts';
		
		$data['sidebar_element'] = 'side-orders';
		$data['sidebar_subelement'] = 'side-abandoned-carts';
		
		$data['seo_title']       = 'Abandoned Carts';
		$data['seo_description'] = '';
		$data['seo_keywords']    = '';
		
		$get_from = $this->input->get('from');
		$data['get_from'] = $get_from;
		$get_to = $this->input->get('to');
		$data['get_to'] = $get_to;
		
		$filters = array(
			'checked_out' 		=> 0,
			'total_items >' 	=> 0,
			'total_amount >' 	=> 0,
		);
		
		if($get_from == '') {
			$get_from = date('Y-m-d', strtotime('-7 days'));
		}
		$data['get_from'] = $get_from;;
		$filters["DATE(`date`) >="] = $get_from;
		
		if($get_to == '') {
			$get_to = date('Y-m-d', time());
		}
		$data['get_to'] = $get_to;
		$filters["DATE(`date`) <="] = $get_to;
		
		$ab_carts = array();
		
		$check = $this->carts->get_where_array($filters);
		if($check->num_rows() > 0) {
			$ab_carts = $check->result();
		}
		$data['ab_carts'] = $ab_carts; 
		
		$customer_index = array();
		foreach($ab_carts as $cart) {
			$customer = $this->customers->get($cart->user_id)->row();
			$customer_index[$cart->user_id] = $customer;
		}
		$data['customer_index'] = $customer_index;
		
		$this->load->view('header', $data);
		$this->load->view('abandoned_carts_view', $data);
		$this->load->view('footer', $data);
	}
	
	function logout() {
		$this->users->logout();
		redirect('login', 'refresh');
	}
	
	/**
	 * Get filtered orders based on filters array
	 * --
	 * @param array $filters_array
	 * --
	 * @return array $result
	 */
	function get_filtered_orders($filters_array) {
		$from                                    = $filters_array['get_from'];
		$to                                      = $filters_array['get_to'];
		$order_date_field                        = $this->orders->get_field_name('order_placed_date');
		$order_status_field                      = $this->orders->get_field_name('order_status');
		$grand_total_field                       = $this->orders->get_field_name('order_grand_total');
		$total_items_field                       = $this->orders->get_field_name('order_total_items');
		$filters                                 = array();
		$filters["DATE({$order_date_field}) >="] = $from;
		$filters["DATE({$order_date_field}) <="] = $to;
		if (strtotime($from) == strtotime($to)) {
			$filters                                = array(); // empty the filters array
			$filters["DATE({$order_date_field}) ="] = $from;
		}
		$filters["{$order_status_field} !="] = 'cancelled';
		$filters["{$grand_total_field} >"]   = 0;
		$filters["{$total_items_field} >"]   = 0;
		$orders                              = $this->orders->get_where_array($filters);
		return $orders;
	}
	
	/**
	 * Filter error generator and redirector
	 * --
	 * @param string $error
	 * --
	 * @return bool
	 * --
	 */
	function filter_error($error_message) {
		$this->load->library('user_agent');
		$this->session->set_flashdata('form_errors', "<div class='alert alert-danger'>{$error_message}</div>");
		if ($this->agent->is_referral()) {
			redirect($this->agent->referrer(), 'refresh');
		}
	}
	
	/**
	 * Get today's orders
	 * --
	 * @param bool $only_num <returns only number if set to true>
	 * --
	 * @return bool/array $result
	 * --
	 */
	function get_todays_orders($num = FALSE) {
		$today              = date('Y-m-d', time());
		$order_date_field   = $this->orders->get_field_name('order_placed_date');
		$order_date_field   = $this->orders->get_field_name('order_placed_date');
		$order_status_field = $this->orders->get_field_name('order_status');
		$grand_total_field  = $this->orders->get_field_name('order_grand_total');
		$total_items_field  = $this->orders->get_field_name('order_total_items');
		$filter_arrays      = array(
			"DATE({$order_date_field}) =" => $today,
			"{$grand_total_field} >" => 0,
			"{$total_items_field} >" => 0
		);
		$result             = $this->orders->get_where_array($filter_arrays);
		if ($num) {
			return $result->num_rows();
		}
		return $result;
	}
	
	/**
	 * Get total order worth revenue
	 * --
	 * @param object $orders
	 * --
	 * @return int $worth
	 * --
	 */
	function get_orders_worth($orders) {
		$total = 0;
		foreach ($orders as $order) {
			$total += $order->grand_total;
		}
		return $total;
	}
	
	/**
	 * Get today's registrations
	 * --
	 * @return int $num;
	 */
	function get_todays_registrations() {
		$today          = date('Y-m-d', time());
		$reg_date_field = $this->customers->get_field_name('customer_registration_date');
		$filters        = array(
			"DATE({$reg_date_field}) =" => $today
		);
		return $this->customers->get_where_array($filters)->num_rows();
	}
	
	/**
	 * Sort orders date wise
	 * --
	 * @param array $orders
	 * --
	 * @return array $result
	 * --
	 */
	function sort_orders_date($orders, $get_from, $get_to) {
		$sorted    = array();
		$from_time = strtotime($get_from);
		$to_time   = strtotime($get_to);
		foreach ($orders->result() as $order) {
			$order_time = strtotime($order->ordered_on);
			while ($from_time < $order_time) {
				$date  = date('Y-m-d', $from_time);
				// google charts month starts with 0 -> jan, 11 -> dec
				$date  = explode('-', $date);
				$month = $date[1] - 1;
				$date  = $date[0] . '-' . $month . '-' . $date[2];
				if (!isset($sorted[$date])) {
					$sorted[$date] = 0;
				}
				$from_time = strtotime('+1 day', $from_time);
			}
			$date  = date('Y-m-d', strtotime($order->ordered_on));
			// google charts month starts with 0 -> jan, 11 -> dec
			$date  = explode('-', $date);
			$month = $date[1] - 1;
			$date  = $date[0] . '-' . $month . '-' . $date[2];
			
			if (!isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$sorted[$date] += 1;
		}
		while ($from_time <= $to_time) {
			$date  = date('Y-m-d', $from_time);
			$date  = explode('-', $date);
			$month = $date[1] - 1;
			$date  = $date[0] . '-' . $month . '-' . $date[2];
			if (!isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$from_time = strtotime('+1 day', $from_time);
		}
		return $sorted;
	}
	
	/**
	 * Sort revenues date wise
	 * --
	 * @param array $orders
	 * --
	 * @return array $result
	 * --
	 */
	function sort_revenues_date($orders, $get_from, $get_to) {
		$sorted    = array();
		$from_time = strtotime($get_from);
		$to_time   = strtotime($get_to);
		foreach ($orders->result() as $order) {
			$order_time = strtotime($order->ordered_on);
			while ($from_time < $order_time) {
				$date  = date('Y-m-d', $from_time);
				// google charts month starts with 0 -> jan, 11 -> dec
				$date  = explode('-', $date);
				$month = $date[1] - 1;
				$date  = $date[0] . '-' . $month . '-' . $date[2];
				if (!isset($sorted[$date])) {
					$sorted[$date] = 0;
				}
				$from_time = strtotime('+1 day', $from_time);
			}
			$date  = date('Y-m-d', strtotime($order->ordered_on));
			// google charts month starts with 0 -> jan, 11 -> dec
			$date  = explode('-', $date);
			$month = $date[1] - 1;
			$date  = $date[0] . '-' . $month . '-' . $date[2];
			
			if (!isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$sorted[$date] += $order->grand_total;
		}
		while ($from_time <= $to_time) {
			$date  = date('Y-m-d', $from_time);
			$date  = explode('-', $date);
			$month = $date[1] - 1;
			$date  = $date[0] . '-' . $month . '-' . $date[2];
			if (!isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$from_time = strtotime('+1 day', $from_time);
		}
		return $sorted;
	}
}
