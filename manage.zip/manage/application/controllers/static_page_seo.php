<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class static_page_seo extends CI_Controller {
    
    function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		$models = array(
			'static_page_seo_model' => 'static_page_seo_model',
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
    }
    
    public function index() {
		$data = initiate_page();
		$data['page_name'] = 'Static Pages';
		$data['page_title'] = 'Static Pages';

		$data['sidebar_element'] = 'side-content';
		$data['sidebar_subelement'] = 'side-static-page-seo';

		$data['seo_title'] = 'Static Pages';
		$data['seo_description'] = '';
		$data['seo_keywords'] = '';
		
		$static_pages = $this->static_page_seo_model->get_all();
		if( ! $static_pages) {
			$static_pages = array();
		}
		$data['static_pages'] = $static_pages;
		
		$this->load->view('header', $data);
		$this->load->view('static_pages_view', $data);
		$this->load->view('footer', $data);
	}
	
	public function edit($id) {
		$data = initiate_page();
		$data['page_name'] = 'Static Pages';
		$data['page_title'] = 'Static Pages';

		$data['sidebar_element'] = 'side-content-dropmenu';
		$data['sidebar_subelement'] = 'side-static-page-seo';

		$data['seo_title'] = 'Static Pages';
		$data['seo_description'] = '';
		$data['seo_keywords'] = '';
		
		if( ! $id) {
			redirect('404', 'refresh');
		}
		
		$seo_details = $this->static_page_seo_model->get_page_by_id($id);
		if( ! $seo_details) {
			redirect('404', 'refresh');
		}
		$data['seo_details'] = $seo_details;
		
		$this->load->view('header', $data);
		$this->load->view('static_page_seo_edit_view', $data);
		$this->load->view('footer', $data);
	}
	
	public function save($id) {
		
		$data = initiate_page();
		if( ( ! $id) OR ((int)$id == '') ) {
			$this->session->set_flashdata('message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please try again.</strong></div>");
			redirect("static_page_seo", 'refresh');
		}
		
		$seo_details = $this->static_page_seo_model->get_page_by_id($id);
		if( ! $seo_details) {
			$this->session->set_flashdata('message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please try again.</strong></div>");
			redirect("static_page_seo", 'refresh');
		}
		
		$seo_title = $this->input->post('seo_title', true);
		$seo_desc = $this->input->post('seo_desc', true);
		$seo_keywords = $this->input->post('seo_keywords', true);
		
		if( ( ! $seo_title) OR (trim($seo_title) == '')) {
			$this->session->set_flashdata('message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Seo title is required.</strong></div>");
			redirect("static_page_seo/edit/{$id}", 'refresh');
		}
		
		if( ( ! $seo_desc) OR (trim($seo_desc) == '')) {
			$this->session->set_flashdata('message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Seo description is required.</strong></div>");
			redirect("static_page_seo/edit/{$id}", 'refresh');
		}
		
		if( ( ! $seo_keywords) OR (trim($seo_keywords) == '')) {
			$this->session->set_flashdata('message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Seo keywords are required.</strong></div>");
			redirect("static_page_seo/edit/{$id}", 'refresh');
		}
		
		$new_data = array(
			'seo_title' => $seo_title,
			'seo_desc' => $seo_desc,
			'seo_keywords' => $seo_keywords,
		);
		
		$filters = array(
			'id' => $id,
		);
		
		$result = $this->static_page_seo_model->update_page($filters, $new_data);
		if( ! $result) {
			$this->session->set_flashdata('message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Changes could not be saved. Please try again.</strong></div>");
			redirect("static_page_seo/edit/{$id}", 'refresh');
		}
		
		$this->session->set_flashdata('message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully modified Meta Tags.</strong></div>");
			redirect("static_page_seo", 'refresh');
	}
}
