<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class order_averages extends CI_Controller {
    
    function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		$models = array(
			'Order_model',
		);
		foreach ($models as $file) {
			$this->load->model($file);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
    }
    
    public function index() {
		
		$data = initiate_page();
		$data['page_name'] = 'Stock Logs';
		$data['page_title'] = 'Stock Logs';
		
		$data['sidebar_element'] = 'side-monitor';
		$data['sidebar_subelement'] = 'side-stock-logs';
		
		$data['seo_title'] = 'Stock Logs Report';
		$data['seo_desc'] = '';
		$data['seo_keywords'] = '';
		
		$orders = $this->Order_model->get_billable_orders();
		
		$total_orders = 0;
		$total_revenue = 0;
		$avg_order_value = 0;
		
		foreach($orders as $order) {
			$total_orders += 1;
			$total_revenue += $order->grand_total;
		}
		
		$avg_order_value = $total_revenue / $total_orders;
		
		$this->load->model('Order_averages_model');
		$this->Order_averages_model->update_averages($total_orders, $total_revenue, $avg_order_value);
		
		echo "Total Orders: {$total_orders}<br>";
		echo "Total Revenue: {$total_revenue}<br>";
		echo "Avg. Order Value: {$avg_order_value}<br>";
		
		exit();
		
	}
	
}
