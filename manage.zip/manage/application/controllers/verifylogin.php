<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Verifylogin extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('users_model', '', TRUE);
  }
  
  function index() {
    $this->load->library('form_validation');

    // echo '<pre>'; print_r($this->input->post); exit();
    // echo '<pre>'; print_r($_POST); exit();
    // DIE
   
    $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
    $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_check_database');
    
    if($this->form_validation->run() == FALSE) {
      $this->load->view('login_view');
    }
    else {
      redirect('dashboard');
    }
  }
  
  function check_database($password) {
    $username = $this->input->post('username');
   $result = $this->users_model->login($username, $password);
    if($result) {
      $sess_array = array();
      foreach($result as $row) {
        $sess_array = array(
          'id' => $row->id,
          'username' => $row->username,
          'email' => $row->email,
          'type' => $row->type
        );
        $this->session->set_userdata('logged_in', $sess_array);
        
        $time = date('M-d-Y H:i:s', time());
        $ip = $this->input->ip_address();
        
        $this->load->library('user_agent');
        $useragent = $this->agent->agent_string();
    		$message = "New Login | session_id: {$session_id} | user: {$row->username} | time: {$time} | ip: {$ip} | useragent: {$useragent}" . "\n\n";
    		
    		$path = APPPATH . 'logs/' . date('M-Y', time()) . '_logs';
    		if( ! file_exists($path)) {
    			mkdir($path, 0755, true);
    		}
    		$log_file = $path . '/login_logs.log';
    		error_log($message, 3, $log_file);
        
      }

      return TRUE;
    }
    else {
      $this->form_validation->set_message('check_database', 'Invalid username or password');
      return FALSE;
    }
  }
          
  
}
