<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pages extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('mdl_pages', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $data['page_name'] = 'pages';
      $data['sidebar_element'] = 'side-content';
      $data['sidebar_subelement'] = 'side-pages-view';
      
      $pages = array();
      $query = $this->mdl_pages->get('id');
      if($query->num_rows() > 0) {
        $pages = $query->result();
      }
      else {
        $pages = array();
      }
      
      $data['pages'] = $pages;
      $this->load->view('header', $data);
      $this->load->view('pages_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function edit($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $data['page_name'] = 'pages';
      $data['sidebar_element'] = 'side-content';
      $data['sidebar_subelement'] = 'side-pages-view';

      $query = $this->mdl_pages->get_where($id);
      if($query->num_rows() > 0) {
        $page_details = $query->row();
      }
      else {
        $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Page does not exist.</strong></div>");
        redirect("pages/edit/{$id}");
      }
      
      $data['page_details'] = $page_details;
      
      $data['tinyMC'] = TRUE;
      
      $this->load->view('header', $data);
      $this->load->view('page_edit', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function save($id=FALSE) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'pages';
      
      $pageName = $this->input->post('pageName');
      $pageSlug = $this->input->post('pageSlug');
      $pageTitle = $this->input->post('pageTitle');
      $pageExcerpt= $this->input->post('pageExcerpt');
      $pageContent = $this->input->post('pageContent');
      $pageKeywords = $this->input->post('pageKeywords');
      
      if($id) {
        
        $query = $this->mdl_pages->get_where($id);
        if($query->num_rows() > 0) {
          $page_details = $query->row();
        }
        else {
          $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Page does not exist.</strong></div>");
          redirect("pages/edit/{$id}");
        }
        
        $data = array(
          'name' => $pageName,
          'slug' => $pageSlug,
          'title' => $pageTitle,
          'excerpt' => $pageExcerpt,
          'content' => $pageContent,
          'keywords' => $pageKeywords
        );
        
        $id_array = array($id);
        $this->db->where_not_in('id', $id_array); 
        //$query = $this->db->query("select * from pages where id not in('{$id}') and slug = '{$pageSlug}'");
        $this->db->where('slug', $pageSlug);
        $query = $this->mdl_pages->get('id');
        
        if($query->num_rows() > 0) {
          $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Slug already exists. Please enter a unique slug.</strong></div>");
          redirect("pages/edit/{$id}");
        }
        else {
          $this->mdl_pages->_update($id, $data);
          $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully Updated!</strong></div>");
          redirect("pages/edit/{$id}");
        }
      }
      else {
        $data = array(
          'name' => $pageName,
          'slug' => $pageSlug,
          'title' => $pageTitle,
          'excerpt' => $pageExcerpt,
          'content' => $pageContent,
          'keywords' => $pageKeywords
        );
        $this->db->where('slug', $pageSlug);
        $query = $this->mdl_pages->get_where_custom('slug', $pageSlug);
        if($query->num_rows() > 0) {
          $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Slug already exists. Please enter a unique slug.</strong></div>");
          redirect("pages/add");
        }
        else {        
          $this->mdl_pages->_insert($data);
          $id = mysql_insert_id();
          $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Page successfully added!</strong></div>");
          redirect("pages/edit/{$id}");
        }
      }
      
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function seosave($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'pages';
      
      $seoTitle = $this->input->post('pageSeoTitle');
      $seoDesc = $this->input->post('pageSeoDesc');
      $seoKeys = $this->input->post('pageSeoKeys');
      
      $data = array(
        'seo_title' => $seoTitle,
        'seo_desc' => $seoDesc,
        'seo_keywords' => $seoKeys
      );
      print_r($data);
      $this->mdl_pages->_update($id, $data);
      $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
      redirect('pages');
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function add() {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $data['page_name'] = 'pages';
      $data['sidebar_element'] = 'side-content';
      $data['sidebar_subelement'] = 'side-add-page';
      
      $data['tinyMC'] = TRUE;
      //$data['products'] = $products;
      $this->load->view('header', $data);
      $this->load->view('page_add', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function delete($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $this->mdl_pages->_delete($id);
      
      
      redirect('pages');
    }
    else {
      redirect('login', 'refresh');
    }
  }
    
  function get($order_by) {
  $this->load->model('mdl_pages');
  $query = $this->mdl_pages->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_pages');
  $query = $this->mdl_pages->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_pages');
  $query = $this->mdl_pages->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_pages');
  $query = $this->mdl_pages->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_pages');
  $this->mdl_pages->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_pages');
  $this->mdl_pages->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_pages');
  $this->mdl_pages->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_pages');
  $count = $this->mdl_pages->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_pages');
  $max_id = $this->mdl_pages->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_pages');
  $query = $this->mdl_pages->_custom_query($mysql_query);
  return $query;
  }

}
