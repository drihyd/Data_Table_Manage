<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Statewise_monthly_report extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'email_helper',
            'page_initiater_helper',
        );
        $models = array(
            'model_carts' => 'carts',
            'model_categories' => 'categories',
            'model_customers' => 'customers',
            'model_orders' => 'orders',
            'model_order_items' => 'order_items',
            'model_products' => 'products',
            'model_skus' => 'skus',
            'model_users' => 'users',
            'model_reorder_thresholds' => 'reorder_thresholds',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function index($justsee=TRUE) {
		
		$data['justsee'] = $justsee;
		$usd_conversion_rate = $this->currency_convertor('usd', 'inr', 1);
		
		if( ! $this->input->get('month', TRUE)) {
			$month = date('M', strtotime('last month'));
			$year = date('Y', time());
		} else {
			$monthYear = strtolower(trim($this->input->get('monthYear', TRUE)));
			$monthYear = explode('-', $monthYear);
			$month = (int) $this->input->get('month', TRUE);
			$year = (int) $this->input->get('year', TRUE);
			
			if( ($month > 12) OR ($month < 1)) {
				$month = date('M', time());
			}
			
			$phrase = "01-" . $month . "-" . $year;
			$month = date('M', strtotime($phrase));			
		}
		$from_phrase = "first day of " . $month . " " . $year;
		$to_phrase   = "last day of " . $month . " " . $year;
		
		$from_date = date('Y-m-d', strtotime($from_phrase));
		$to_date = date('Y-m-d', strtotime($to_phrase));
		
		//$from_date = date('Y-m-d', strtotime('2016-01-01'));
		//$to_date = date('Y-m-d', strtotime('2016-01-07'));
		
		$data['from_date'] = $from_date;
		$data['to_date'] = $to_date;
		
		#---------------------------------------------------------------
		# Get Month
		$current_month = date('m', strtotime($from_date));
		$current_year  = date('Y', strtotime($from_date));
		
		$orders_this_month = 0;
		$check = $this->orders->get_month($current_month, $current_year);
		if($check->num_rows() > 0) {
			$orders_this_month = $check->num_rows();
		}
		$data['orders_this_month'] = $orders_this_month;
		
		#---------------------------------------------------------------
		# Get all orders in date range
		$all_orders = array();
		
		$this->db->where("DATE(ordered_on) >=", $from_date);
		$this->db->where("DATE(ordered_on) <=", $to_date);
		$this->db->where_not_in("order_status", array('cancelled', 'cancelled-refunded', 'cancelled-refund-pending'));
		$this->db->where("grand_total >", 0);
		$this->db->where("total_items >", 0);
		
		$check = $this->db->get('orders');
		
		if($check->num_rows() > 0) {
			$all_orders = $check->result();
		}
		
		$all_total_orders = $check->num_rows();
		$all_total_revenue = 0;
		$all_total_tax = 0;
		$all_total_pieces = 0;
		
		$state_index = array();
		$state_totals_index = array();
		
		foreach($all_orders as $order) {
			
			if(trim(strtolower($order->ship_to_country)) != 'india') {
				CONTINUE;
			}
			
			$ship_to_state = trim(strtolower($order->ship_to_state));
			$ship_to_country = trim(strtolower($order->ship_to_country));
			
			if($ship_to_country != 'india') {
				$ship_to_state = $ship_to_country;
			}
			
			if( ! isset($state_index[$ship_to_state])) {
				$state_index[$ship_to_state] = array();
			}
			$temp = $state_index[$ship_to_state];
			array_push($temp, $order);
			$state_index[$ship_to_state] = $temp;
			
			$grand_total = $order->grand_total;
			if($order->currency == 'usd') {
				$grand_total = $grand_total * $usd_conversion_rate;
			}
			
			$all_total_revenue += $grand_total;
			$all_total_tax += 0;
			$all_total_pieces += $order->total_items;
		}
		
		foreach($all_orders as $order) {
			
			if(trim(strtolower($order->ship_to_country)) == 'india') {
				CONTINUE;
			}
			
			$ship_to_state = trim(strtolower($order->ship_to_state));
			$ship_to_country = trim(strtolower($order->ship_to_country));
			
			if($ship_to_country != 'india') {
				$ship_to_state = $ship_to_country;
			}
			
			if( ! isset($state_index[$ship_to_state])) {
				$state_index[$ship_to_state] = array();
			}
			$temp = $state_index[$ship_to_state];
			array_push($temp, $order);
			$state_index[$ship_to_state] = $temp;
			
			$grand_total = $order->grand_total;
			if($order->currency == 'usd') {
				$grand_total = $grand_total * $usd_conversion_rate;
			}
			
			$all_total_revenue += $grand_total;
			$all_total_tax += 0;
			$all_total_pieces += $order->total_items;
		}
		
		foreach($state_index as $state => $orders) {
			if( ! isset($state_totals_index[$state])) {
				$state_totals_index[$state] = array(
					'total_orders' => 0,
					'total_revenue' => 0,
					'total_tax' => 0,
					'total_pieces' => 0,
				);
			}
			
			$temp = $state_totals_index[$state];
			
			$total_orders = $temp['total_orders'];
			$total_revenue = $temp['total_revenue'];
			$total_tax = $temp['total_tax'];
			$total_pieces = $temp['total_pieces'];
			
			foreach($orders as $order) {
				$ship_to_state = trim(strtolower($order->ship_to_state));
				$ship_to_country = trim(strtolower($order->ship_to_country));
				
				if($ship_to_country != 'india') {
					$ship_to_state = $ship_to_country;
				}
				
				$grand_total = $order->grand_total;
				if($order->currency == 'usd') {
					$grand_total = $grand_total * $usd_conversion_rate;
				}
				$total_orders += 1;
				$total_revenue += $grand_total;
				$total_tax += 0;
				$total_pieces += $order->total_items;
			}
			
			$temp['total_orders'] = $total_orders;
			$temp['total_revenue'] = $total_revenue;
			$temp['total_tax'] = $total_tax;
			$temp['total_pieces'] = $total_pieces;
			$state_totals_index[$state] = $temp;
		}
		
		$rows = array();
		$rows_count = 1;
		$bold_rows = array();
		
		foreach($state_index as $state => $orders) {
			foreach($orders as $order) {
				$grand_total = $order->grand_total;
				if($order->currency == 'usd') {
					$grand_total = $grand_total * $usd_conversion_rate;
				}
				
				$row = array(
					date('d-m-Y', strtotime($order->ordered_on)),
					$order->id,
					ucwords($state),
					0,
					(round($grand_total * 2, 0) / 2),
					$order->total_items,
				);
				
				array_push($rows, $row);
				$rows_count += 1;
			}
			$state_totals = $state_totals_index[$state];
			$state_totals_row = array(
				'',
				ucwords($state),
				$state_totals['total_orders'],
				0,
				(round($state_totals['total_revenue'] * 2, 0) / 2),
				$state_totals['total_pieces'],
			);
			$rows_count += 1;
			array_push($rows, $state_totals_row);
			array_push($bold_rows, $rows_count);
			
			$empty_row = array(
				'',
				'',
				'',
				'',
				'',
				'',
			);
			$rows_count += 1;
			array_push($rows, $empty_row);
		}
		
		$all_totals_row = array(
			'',
			'Totals',
			$all_total_orders,
			0,
			(round($all_total_revenue * 2, 0) / 2),
			$all_total_pieces,
		);
		$rows_count += 1;
		array_push($rows, $all_totals_row);
		array_push($bold_rows, $rows_count);
		
		$conversion_row = array(
			'',
			'',
			'',
			'',
			'',
			"1 USD = {$usd_conversion_rate} INR",
		);
		$rows_count += 1;
		array_push($rows, $conversion_row);
		
		//echo "<pre>";
		//print_r($rows);
		//echo "</pre>";
		
		$month = date('F', strtotime($from_date));
		$this->generate_report_excel($rows, "Statewise Report for {$month}", $bold_rows);
	}
	
	// get category size stock
	function get_category_size_stock($cat_id, $size) {
		$filters = array(
			'stock >' => 0,
			'size' => $size,
			'cat_id' => $cat_id,
		);
		$check = $this->skus->get_where_array($filters);
		$skus = array();
		$stock = 0;
		if($check->num_rows() > 0) {
			$skus = $check->result();
		}
		foreach($skus as $sku) {
			$stock += $sku->stock;
		}	
		return $stock;
	}
	
	function generate_report_excel($rows, $title, $bold_rows) {
		
		require APPPATH . 'controllers/class/PHPExcel.php';
		require_once APPPATH . 'controllers/class/PHPExcel/IOFactory.php';
		
		if(count($rows) == 0) {
			echo "Empty";
			return;
		}
		
		$excel_data = array();
		$excel_headings = array(
			'Date',
			'Order/Invoice Number',
			'State',
			'Tax Amount',
			'Grand Total',
			'Pieces',
		);
		array_push($excel_data, $excel_headings);
		
		$email_record = array();
		foreach($rows as $row) {
			array_push($excel_data, $row);
		}
		
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->getProperties()->setCreator("Taruni");
		$objPHPExcel->getProperties()->setLastModifiedBy("Taruni");
		$objPHPExcel->getProperties()->setTitle("{$title}");
		$objPHPExcel->getProperties()->setSubject("{$title}");
		$objPHPExcel->getProperties()->setDescription("{$title}");
		
		$objPHPExcel->getActiveSheet()->fromArray($excel_data, null, 'A1');
		
		$date = date('M-d-Y', time());
		
		header("Content-Type: application/xlsx");
		header("Content-Disposition: attachment; filename={$title}.xlsx");
		header("Pragma: no-cache");
		header("Expires: 0");
		
		$highestColumn = $objPHPExcel->getActiveSheet()->getHighestDataColumn();
		$nCols = PHPExcel_Cell::columnIndexFromString($highestColumn);
		
		foreach (range(0, $nCols) as $col) {
			$objPHPExcel->getActiveSheet()->getColumnDimensionByColumn($col)->setWidth(18);                
		}
		
		$from = "A1"; // or any value
		$to = "F1"; // or any value
		$objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold( true );
		
		foreach($bold_rows as $row_num) {
			$from = "A{$row_num}"; // or any value
			$to = "F{$row_num}"; // or any value
			
			$bgcolor = "95B3D7";
			
			$objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold( true );
			$objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFill()->applyFromArray(array(
				'type' => PHPExcel_Style_Fill::FILL_SOLID,
				'startcolor' => array(
					 'rgb' => $bgcolor,
				)
			));
		}
		
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
		$objWriter->save('php://output');
	}
	
	function currency_convertor($from_currency, $to_currency, $amount) {
		$from_currency = strtoupper($from_currency);
		$to_currency = strtoupper($to_currency);
		$get = file_get_contents("http://data.fixer.io/api/latest?access_key=d31268aae6ff8c6e1cfbf0df3729eb53&symbols={$from_currency},{$to_currency}&format=1");
		$get = json_decode($get);
		$rates = (array) $get->rates;
		$from_rate = $rates[$from_currency];
		$to_rate = $rates[$to_currency];
		$output = ($to_rate/$from_rate) * $amount;
		$output = round($output, 2);
		return $output;
	}
	
}
