<?php
date_default_timezone_set("Asia/Kolkata");

if(!defined('BASEPATH'))
	exit('No direct script access allowed');
class Friendship_contest extends CI_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model('mdl_contests', '', TRUE);
		$this->load->helper(array(
			'form',
			'page_initiater_helper',
		));
	}
	
	function index() {
		$data = initiate_page();
		
		$data['page_name']  = 'Friendship Day Stats';
		$data['page_title'] = 'All Participants';

		$data['page_name']  = 'contest';
		$data['page_title'] = 'All participants';
		
		$data['sidebar_element']    = 'side-promos';
		$data['sidebar_subelement'] = 'side-contest';
		
		$data['seo_title'] = 'Friendship Day Stats';
		$data['seo_description'] = '';
		$data['seo_keywords'] = '';
		
		$participants = array();
		$check = $this->db->get('friendship');
		if($check->num_rows() > 0) {
			$participants = $check->result();
		}
		$data['participants'] = $participants;
		
		$total_participants = 0;
		$new_regs = 0;
		$orders_from_new_regs = 0;
		$revenue_from_new_regs = 0;
		$completed = 0;
		
		$total_coupons_given = 0;
		$total_coupon_value = 0;
		$total_coupons_claimed = 0;
		$total_claimed_value = 0;
		$claim_revenue = 0;
		
		$new_orders = array();
		$claim_orders = array();
		$claim_order_number = 0;
		
		$customer_index = array();
        foreach($participants as $participant) {
			$this->db->where('email', $participant->first_email);
			$this->db->or_where('guest_email', $participant->first_email);
			$check = $this->db->get('customers');
			if($check->num_rows() > 0) {
				$total_participants += 1;
				$customer = $check->row();
				$email = $customer->email;
				if($customer->is_guest == 1) {
					$email = $customer->guest_email;
				}
				
				if( strtotime($customer->date) >= strtotime('5 August 2016')) {
					$new_regs += 1;
					
					$this->db->where('email', $customer->email);
					$this->db->or_where('guest_email', $customer->email);
					$check = $this->db->get('customers');
					if($check->num_rows() > 0) {
						foreach($check->result as $id) {
							$this->db->where('customer_id', $id->id);
							$this->db->where('grand_total >', 0);
							$this->db->where('total_items >', 0);
							$this->db->where_not_in('order_status', array('cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'on-hold'));
							$check = $this->db->get('orders');
							if($check->num_rows() > 0) {
								$orders_from_new_regs += $check->num_rows();
								array_push($new_orders, $check->result());
								foreach($check->result() as $order) {
									$revenue_from_new_regs += $order->grand_total;
								}
							}
						}
					}
				}
				$customer_index[$email] = $customer;
			}
			
			$this->db->where('email', $participant->second_email);
			$this->db->or_where('guest_email', $participant->second_email);
			$check = $this->db->get('customers');
			if($check->num_rows() > 0) {
				$total_participants += 1;
				$customer = $check->row();
				$email = $customer->email;
				if($customer->is_guest == 1) {
					$email = $customer->guest_email;
				}
				if( strtotime($customer->date) >= strtotime('5 August 2016')) {
					$new_regs += 1;
					
					$this->db->where('email', $customer->email);
					$this->db->or_where('guest_email', $customer->email);
					$check = $this->db->get('customers');
					if($check->num_rows() > 0) {
						foreach($check->result as $id) {
							$this->db->where('customer_id', $id->id);
							$this->db->where('grand_total >', 0);
							$this->db->where('total_items >', 0);
							$this->db->where_not_in('order_status', array('cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'on-hold'));
							$check = $this->db->get('orders');
							if($check->num_rows() > 0) {
								$orders_from_new_regs += $check->num_rows();
								array_push($new_orders, $check->result());
								foreach($check->result() as $order) {
									$revenue_from_new_regs += $order->grand_total;
								}
							}
						}
					}
				}
				$customer_index[$email] = $customer;
			}
			
			if( ($participant->challenge_date != '') AND ($participant->second_answers != '') ) {
				$completed += 1;
				$total_coupon_value += ($participant->discount_amount * 2);
				
				$first_coupon_id = $participant->first_coupon_id;
				$second_coupon_id = $participant->second_coupon_id;
				
				$total_coupons_given += 2;
				
				$this->db->where('coupon_id', $first_coupon_id);
				$check = $this->db->get('coupon_usage_log');
				if($check->num_rows() > 0) {
					
					$usage = $check->row();
					$order_id = $usage->order_id;
					
					$this->db->where('id', $order_id);
					$check = $this->db->get('orders');
					if($check->num_rows() > 0) {
						array_push($claim_orders, $check->row());
						$claim_order_number += 1;
						$order_details = $check->row();
						if( ! in_array($order_details->order_status, array('cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'on-hold'))) {
							$total_coupons_claimed += 1;
							$total_claimed_value += $participant->discount_amount;
							$claim_revenue += $order_details->grand_total;
						}
					}
				}
				
				$this->db->where('coupon_id', $second_coupon_id);
				$check = $this->db->get('coupon_usage_log');
				if($check->num_rows() > 0) {
					
					$usage = $check->row();
					$order_id = $usage->order_id;
					
					$this->db->where('id', $order_id);
					$check = $this->db->get('orders');
					if($check->num_rows() > 0) {
						array_push($claim_orders, $check->row());
						$claim_order_number += 1;
						$order_details = $check->row();
						if( ! in_array($order_details->order_status, array('cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'on-hold'))) {
							$total_coupons_claimed += 1;
							$total_claimed_value += $participant->discount_amount;
							$claim_revenue += $order_details->grand_total;
						}
					}
				}	
			}
		}
		
		$data['customer_index'] = $customer_index;
		$data['total_participants'] = $total_participants;
		$data['completed'] = $completed;
		
		$data['new_regs'] = $new_regs;
		$data['orders_from_new_regs'] = $orders_from_new_regs;
		$data['revenue_from_new_regs'] = $revenue_from_new_regs;
		
		$data['total_coupons_given'] = $total_coupons_given;
		$data['total_coupon_value'] = $total_coupon_value;
		$data['total_coupons_claimed'] = $total_coupons_claimed;
		$data['total_claimed_value'] = $total_claimed_value;
		$data['claim_revenue'] = $claim_revenue;
		
		$data['new_orders'] = $new_orders;
		$data['claim_orders'] = $claim_orders;
		$data['claim_order_number'] = $claim_order_number;
		
		$this->load->view('header', $data);
		$this->load->view('friendship_view', $data);
		$this->load->view('footer', $data);
	}
	
}
