<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title><?php echo $seo_title; ?></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
  
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/style.css">
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>js/jquery-ui/jquery-ui.min.css">
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>js/jquery-ui/dataTables.jqueryui.css">

  <!--[if lt IE 9]>
  <script src="js/vendor/html5-3.6-respond-1.1.0.min.js"></script>
  <![endif]-->
</head>
<body>
  <!--[if lt IE 7]>
  <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
  <![endif]-->
  
  <!-- Sidebar -->
  <div id="sidebar-wrapper">
    <ul class="sidebar-nav">
      <li class="sidebar-brand">
        <a href="<?php echo $this->config->base_url(); ?>"><img src="<?php echo $this->config->base_url(); ?>img/logo.png" class="img-responsive" alt="Seating-world Logo" title="Seating-world"></a>
      </li>
      <!-- li><a href="<?php echo $this->config->base_url().'getting_started'; ?>">Getting Started</a></li -->
      <li id="side-dashboard"><a href="<?php echo $this->config->base_url().'dashboard'; ?>">Dashboard</a></li>
      <li id="side-analytics"><a href="<?php echo $this->config->base_url().'analytics'; ?>">Analytics</a></li>
      <li id="side-cart-analytics"><a href="<?php echo $this->config->base_url().'cart_analytics'; ?>">Cart Analytics</a></li>
      <li id="side-repeat-customers"><a href="<?php echo $this->config->base_url().'repeat_customers'; ?>">Repeat Customers</a></li>
      <li id="side-wishlists"><a href="<?php echo $this->config->base_url().'wishlists'; ?>">Wishlists</a></li>
      <li id="side-categories">
        <a href="#" data-toggle="collapse" data-target="#side-categories-dropmenu">Categories</a>
        <ul class="nav nav-list collapse" id="side-categories-dropmenu">
          <li id="side-categories-view"><a href="<?php echo $this->config->base_url().'categories'; ?>">View</a></li>
          <li id="side-add-parentcat"><a href="<?php echo $this->config->base_url().'categories/parentadd'; ?>">Add Parent Category</a></li>
          <li id="side-add-childcat"><a href="<?php echo $this->config->base_url().'categories/add'; ?>">Add Child Category</a></li>
          <li id="side-edit-reorder"><a href="<?php echo $this->config->base_url().'reorder'; ?>">Edit Re-order Values</a></li>
        </ul>
      </li>
      <li id="side-products">
        <a href="#" data-toggle="collapse" data-target="#side-products-dropmenu">Products</a>
        <ul class="nav nav-list collapse" id="side-products-dropmenu">
          <li id="side-products-view"><a href="<?php echo $this->config->base_url().'products'; ?>">View</a></li>
          <li id="side-add-product"><a href="<?php echo $this->config->base_url().'products/add'; ?>">Add Product</a></li>
        </ul>
      </li>
      <li id="side-orders">
        <a href="#" data-toggle="collapse" data-target="#side-orders-dropmenu">Orders</a>
        <ul class="nav nav-list collapse" id="side-orders-dropmenu">
          <li id="side-orders-view"><a href="<?php echo $this->config->base_url().'orders'; ?>">View All</a></li>
        </ul>
      </li>
      <li id="side-reports">
        <a href="#" data-toggle="collapse" data-target="#side-reports-dropmenu">Reports</a>
        <ul class="nav nav-list collapse" id="side-reports-dropmenu">
          <li id="side-reports-view"><a href="<?php echo $this->config->base_url().'reports'; ?>">View All</a></li>
        </ul>
      </li>
      <li id="side-pages">
        <a href="#" data-toggle="collapse" data-target="#side-pages-dropmenu">Pages</a>
        <ul class="nav nav-list collapse" id="side-pages-dropmenu">
          <li id="side-pages-view"><a href="<?php echo $this->config->base_url().'pages'; ?>">View All</a></li>
          <li id="side-add-page"><a href="<?php echo $this->config->base_url().'pages/add'; ?>">Add New Page</a></li>
        </ul>
      </li>
      <li id="side-customers">
        <a href="#" data-toggle="collapse" data-target="#side-customers-dropmenu">Customers</a>
        <ul class="nav nav-list collapse" id="side-customers-dropmenu">
          <li id="side-customers-view"><a href="<?php echo $this->config->base_url().'customers'; ?>">View All</a></li>
        </ul>
      </li>
      <li id="side-attributes">
        <a href="#" data-toggle="collapse" data-target="#side-attributes-dropmenu">Attributes</a>
        <ul class="nav nav-list collapse" id="side-attributes-dropmenu">
          <li id="side-attributes-view"><a href="<?php echo $this->config->base_url().'attributes'; ?>">View All</a></li>
        </ul>
      </li>
      <li id="side-homepage-featured">
        <a href="<?php echo $this->config->base_url().'homepage_featured'; ?>">Homepage Featured</a>
      </li>
      <li id="side-shipping-rates">
        <a href="#" data-toggle="collapse" data-target="#side-shipping-rates-dropmenu">Shipping Rates</a>
        <ul class="nav nav-list collapse" id="side-shipping-rates-dropmenu">
          <li id="side-shipping-rates-view"><a href="<?php echo $this->config->base_url().'shipping_rates/'; ?>">View All</a></li>
          <li id="side-add-shipping-rate"><a href="<?php echo $this->config->base_url().'shipping_rates/add'; ?>">Add New</a></li>
        </ul>
      </li>
      <li id="side-shipping-times">
        <a href="#" data-toggle="collapse" data-target="#side-shipping-times-dropmenu">Shipping Times</a>
        <ul class="nav nav-list collapse" id="side-shipping-times-dropmenu">
          <li id="side-shipping-times-view"><a href="<?php echo $this->config->base_url().'shipping_times/'; ?>">View All</a></li>
          <li id="side-add-shipping-time"><a href="<?php echo $this->config->base_url().'shipping_times/add'; ?>">Add New</a></li>
        </ul>
      </li>
      <li id="side-discounts">
        <a href="#" data-toggle="collapse" data-target="#side-discounts-dropmenu">Discounts</a>
        <ul class="nav nav-list collapse" id="side-discounts-dropmenu">
          <li id="side-discounts-view"><a href="<?php echo $this->config->base_url().'discounts/'; ?>">View All</a></li>
          <li id="side-add-discount"><a href="<?php echo $this->config->base_url().'discounts/add'; ?>">Add New</a></li>
        </ul>
      </li>
      <li id="side-coupons">
        <a href="#" data-toggle="collapse" data-target="#side-coupons-dropmenu">Coupons</a>
        <ul class="nav nav-list collapse" id="side-coupons-dropmenu">
          <li id="side-coupons-view"><a href="<?php echo $this->config->base_url().'coupons/'; ?>">View All</a></li>
          <li id="side-add-coupons"><a href="<?php echo $this->config->base_url().'coupons/add'; ?>">Add New</a></li>
        </ul>
      </li>
      <li id="side-tags">
        <a href="#" data-toggle="collapse" data-target="#side-tags-dropmenu">Tags</a>
        <ul class="nav nav-list collapse" id="side-tags-dropmenu">
          <li id="side-tags-view"><a href="<?php echo $this->config->base_url().'tags/'; ?>">View All</a></li>
          <li id="side-add-tag"><a href="<?php echo $this->config->base_url().'tags/add'; ?>">Add New</a></li>
        </ul>
      </li>
      <li id="side-countries">
        <a href="#" data-toggle="collapse" data-target="#side-countries-dropmenu">Countries</a>
        <ul class="nav nav-list collapse" id="side-countries-dropmenu">
          <li id="side-countries-view"><a href="<?php echo $this->config->base_url().'countries/'; ?>">View All</a></li>
          <li id="side-add-country"><a href="<?php echo $this->config->base_url().'countries/add'; ?>">Add New</a></li>
        </ul>
      </li>
      <li id="side-states">
        <a href="<?php echo $this->config->base_url().'states'; ?>">States</a>
      </li>
      <li id="side-cities">
        <a href="<?php echo $this->config->base_url().'cities'; ?>">Cities</a>
      </li>
      <li id="side-contest">
        <a href="<?php echo $this->config->base_url().'contest'; ?>">Contest</a>
      </li>
      <li id="side-abandoned-carts">
        <a href="<?php echo $this->config->base_url().'abandoned_carts'; ?>">Abandoned Carts</a>
      </li>
      <li id="side-paypal-outbox">
        <a href="<?php echo $this->config->base_url().'paypal_outbox'; ?>">Paypal Outbox</a>
      </li>
      <li id="side-bulk-upload">
        <a href="#" data-toggle="collapse" data-target="#side-bulk-upload-dropmenu">Bulk Upload</a>
        <ul class="nav nav-list collapse" id="side-bulk-upload-dropmenu">
          <li id="side-bulk-upload-download"><a href="<?php echo $this->config->base_url().'bulk_upload/download'; ?>">Download XLSX File</a></li>
          <li id="side-bulk-upload-upload"><a href="<?php echo $this->config->base_url().'bulk_upload/upload'; ?>">Upload Bulk Data</a></li>
          <li id="side-bulk-images-upload"><a href="<?php echo $this->config->base_url().'bulk_images_upload'; ?>">Bulk Image Upload</a></li>
        </ul>
      </li>
      <li id="side-monitor-stock">
        <a href="<?php echo $this->config->base_url().'monitor_stock'; ?>">Monitor Stock</a>
      </li>
    </ul>
  </div>
  <!-- /#sidebar-wrapper -->
  <div id="main-content">
    <header>
      <a href="#menu-toggle" class="btn btn-default btn-edit btn-xs" id="menu-toggle"><span class="glyphicon glyphicon-chevron-left"></span> Menu</a>
<?php
if(isset($page_title)) { ?>
      <div class="header-page-title"><?php echo ucwords($page_title); ?></div>
<?php
} else { ?>
      <div class="header-page-title"><?php echo ucfirst($user_type); ?></div>
<?php
} ?>
      <div class="dropdown pull-right header-user-dropdown" style="display: inline-block;">
        <button class="btn btn-brand dropdown-toggle" type="button" id="userDropMenu" data-toggle="dropdown">
          <?php echo $username; ?>
          <span class="caret"></span>
        </button>
        <ul class="dropdown-menu" role="menu" aria-labelledby="userDropMenu">
          <!-- li role="presentation"><a role="menuitem" tabindex="-1" href="#">Change Password</a></li -->
          <!-- li role="presentation"><a role="menuitem" tabindex="-1" href="#">Change Email</a></li -->
          <!-- li role="presentation" class="divider"></li -->
          <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo $this->config->base_url().'profile'; ?>">Profile</a></li>
          <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo $this->config->base_url().'dashboard/logout'; ?>">Logout</a></li>
        </ul>
      </div>
    </header>
    
