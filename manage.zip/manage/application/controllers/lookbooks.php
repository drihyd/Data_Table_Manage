<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Lookbooks extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_products', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }
    public function index()
    {
        echo 'Welcome to Lookbooks';
    }

    public function add()
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Lookbooks';
            $data['page_title'] = 'Add New Lookbook';

            $this->load->view('header', $data);
            $this->load->view('lookbook_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }


}