<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Update_price extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_products', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index($id=NULL) //
    {
        $this->load->view('header', $data);
        $this->load->view('update_price_view', $data);
        $this->load->view('footer', $data);
    }

    public function update()
    {
       if (!$this->input->is_ajax_request()) {
            $factor = $this->getINRPerDollar();
            if (!$factor) {
               die('Failed to update Dollar prices');
           }
        }else{
            $factor = $this->input->post('factor', TRUE);
            if (!$factor) {
                die('Failed to update Dollar prices');
            }
        }    
        $this->update_price($factor);       
    }

    public function api_update()
    {
       // if (!$this->input->is_ajax_request()) {
       //      die('You are awesome, please go to home page');
       //  }
       $factor = $this->getINRPerDollar();

       if (!$factor) {
           die('Failed to update Dollar prices');
       }

        $this->update_price($factor);

    }

    public function update_price($factor)
    {
        $sql = "UPDATE skus s SET s.price_usd = IF( MOD(s.price_inr/{$factor}, 1) > 0.5, FLOOR(s.price_inr/{$factor})+0.5, FLOOR(s.price_inr/{$factor}))";
        if ($this->db->query($sql)) {
           echo '<div class="alert alert-success" role="alert">Successfully updated</div>';
           exit();
        }
        echo '<div class="alert alert-danger" role="alert">Failed to update</div>';
        exit();
    }

    public function getINRPerDollar(){
       // Fetching JSON
        $req_url = 'https://api.exchangerate-api.com/v4/latest/USD';
        $response_json = file_get_contents($req_url);

        // Continuing if we got a result
        if(false !== $response_json) {
            $response_object = json_decode( $response_json);
           return $response_object->rates->INR;
        }

        return false;
    }
}