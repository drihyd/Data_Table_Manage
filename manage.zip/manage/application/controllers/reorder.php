<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Reorder extends CI_Controller {
	
    function __construct() {
        parent::__construct();
        $helpers = array(
            'form',
            'page_initiater_helper',
        );
        
        $models = array(
            'model_categories' => 'categories',
            'model_reorder_thresholds' => 'reorder_thresholds',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function index() {
        $data = initiate_page();
        $data['page_name'] = 'Reorder Values';
        $data['page_title'] = 'Reorder Values';
        
        $data['sidebar_element'] = 'side-categories';
        $data['sidebar_subelement'] = 'side-edit-reorder';
        
        $data['seo_title'] = 'Reorder Values';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
        
        $reorder_values = array();
        $check = $this->reorder_thresholds->get_all();
        if($check->num_rows() > 0) {
			$reorder_values = $check->result();
		}
		
		$data['reorder_values'] = $reorder_values;
		
		$category_index = array();
		$categories = array();
		$check = $this->categories->get_all();
		if($check->num_rows() > 0) {
			$categories = $check->result();
		}
		
		foreach($categories as $category) {
			$category_index[$category->id] = $category;
		}
		$data['category_index'] = $category_index;
		
        $this->load->view('header/header', $data);
        $this->load->view('reorder_view', $data);
        $this->load->view('footer/footer', $data);
    }
    
    function edit($id) {
		$data = initiate_page();
        $data['page_name'] = 'Reorder Values';
        $data['page_title'] = 'Edit Reorder Values';
        
        $data['sidebar_element'] = 'side-categories';
        $data['sidebar_subelement'] = 'side-edit-reorder';
        
        $data['seo_title'] = 'Reorder Values';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
        
        $check = $this->reorder_thresholds->get($id);
        if($check->num_rows() == 0) {
			show_404();
		}
		
		$reorder_values = $check->row();
		$data['reorder_values'] = $reorder_values;
		
		$category_details = $this->categories->get($reorder_values->cat_id)->row();
		$data['category_details'] = $category_details;
        
        $this->load->view('header/header', $data);
        $this->load->view('reorder_edit', $data);
        $this->load->view('footer/footer', $data);
    }
    
    function save($id) {
		
		$check = $this->reorder_thresholds->get($id);
		if($check->num_rows() == 0) {
			show_404();
		}
		
		$s = $this->input->post('s', true);
		$m = $this->input->post('m', true);
		$l = $this->input->post('l', true);
		$xl = $this->input->post('xl', true);
		$xxl = $this->input->post('xxl', true);
		$unstitched = $this->input->post('unstitched', true);
		
		$new_data = array(
			's' => $s,
			'm' => $m,
			'l' => $l,
			'xl' => $xl,
			'xxl' => $xxl,
			'unstitched' => $unstitched,
		);
		
		$this->reorder_thresholds->update($id, $new_data);
		$this->session->set_flashdata('form_errors', '<div class="alert alert-success">Successfully Updated</div>');
		
		redirect('reorder/edit/'.$id, refresh);
	}
		
		
    
}
