<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Shipping_times extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_shipping_times', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Shipping Times';
            $data['page_title'] = 'All Shipping Times';
            
            $data['sidebar_element'] = 'side-master-data';
            $data['sidebar_subelement'] = 'side-shipping-times-view';
            
            $check = $this->mdl_shipping_times->get('id');
            if($check->num_rows() > 0) {
              $shipping_times = $check->result();
            }
            else {
              $shipping_times = array();
            }
            
            $data['shipping_times'] = $shipping_times;
            
            $this->load->view('header', $data);
            $this->load->view('shipping_times_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Add Shipping Rate';
            $data['page_title'] = 'Add Shipping Rate';
            
            $data['sidebar_element'] = 'side-shipping-times';
            $data['sidebar_subelement'] = 'side-add-shipping-time';
            
            $this->load->view('header', $data);
            $this->load->view('shipping_time_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function delete($id) {
      if ($this->session->userdata('logged_in')) {
          $session_data = $this->session->userdata('logged_in');
          $data['username'] = $session_data['username'];
          $data['user_type'] = $session_data['type'];
          $data['user_email'] = $session_data['email'];
          
          $check = $this->mdl_shipping_times->get_where($id);
          if($check->num_rows() > 0) {
            $shipping_time_details = $check->row();
          }
          else {
            $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid ID.</strong></div>");
            redirect("shipping_times");
          }
          
          $this->load->model('mdl_countries');
          $this->load->model('mdl_states');
          $this->load->model('mdl_cities');
          
          //check if any countries, states or cities are referencing this time
          $check = $this->mdl_countries->get_where_custom('shipping_time_id', $shipping_time_details->id);
          if($check->num_rows() > 0) {
            $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Sorry! Cannot delete this shipping time. It is being referenced in {$check->num_rows()} countries. First change those countries to a default shipping rate.</strong></div>");
            redirect("shipping_times");
          }
          
          $check = $this->mdl_states->get_where_custom('shipping_time_id', $shipping_time_details->id);
          if($check->num_rows() > 0) {
            $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Sorry! Cannot delete this shipping time. It is being referenced in {$check->num_rows()} states. First change those states to a default shipping time.</strong></div>");
            redirect("shipping_times");
          }
          
          $check = $this->mdl_cities->get_where_custom('shipping_time_id', $shipping_time_details->id);
          if($check->num_rows() > 0) {
            $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Sorry! Cannot delete this shipping time. It is being referenced in {$check->num_rows()} cities. First change those cities to a default shipping time.</strong></div>");
            redirect("shipping_times");
          }
          
          $this->mdl_shipping_times->_delete($id);
          $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Deleted successfully.</strong></div>");
          redirect("shipping_times");
      }
      else {
          redirect('login', 'refresh');
      }
    }
    
    
    function edit($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = 'Edit Shipping Rate';
            
            $data['sidebar_element'] = 'side-shipping-times';
            $data['sidebar_subelement'] = 'side-shipping-times-view';
            
            $check = $this->mdl_shipping_times->get_where($id);
            if($check->num_rows() > 0) {
              $shipping_time_details = $check->row();
            }
            else {
              $shipping_time_details->array();
            }
            
            $data['shipping_time_details'] = $shipping_time_details;
            
            $this->load->view('header', $data);
            $this->load->view('shipping_time_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function save($id=null) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = '';
            
            $data['sidebar_element'] = 'side-shipping-times';
            $data['sidebar_subelement'] = 'side-shipping-times-view';
            
            if($id) {
              $check = $this->mdl_shipping_times->get_where($id);
              if($check->num_rows() > 0) {
                $shipping_time_details = $check->row();
              }
              else {
                redirect('404', 'refresh');
              }
              
              $timeName = $this->input->post('timeName', true);
              $timeMin = (int) $this->input->post('timeMin', true);
              $timeMax = (int) $this->input->post('timeMax', true);
              $timePhrase = $this->input->post('timePhrase', true);
              
              if( (trim($timeName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("shipping_times/edit/{$id}");
              }
              
              if( ( trim( $timeMin ) == '' ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Minimum days must be greater than equal to one.</strong></div>");
                redirect("shipping_times/edit/{$id}");
              }
              
              if( ( trim( $timeMax ) == '' ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Maximum days must be greater than equal to one.</strong></div>");
                redirect("shipping_times/edit/{$id}");
              }
              
              $new_data = array(
                'name' => $timeName,
                'min_days' => $timeMin,
                'max_days' => $timeMax,
                'phrase' => $timePhrase
              );
              
              $this->mdl_shipping_times->_update($id, $new_data);
              
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully updated!</strong></div>");
              redirect("shipping_times/edit/{$id}");
            
            }
            else {
              
              $timeName = $this->input->post('timeName', true);
              $timeMin = (int) $this->input->post('timeMin', true);
              $timeMax = (int) $this->input->post('timeMax', true);
              $timePhrase = $this->input->post('timePhrase', true);
              
              if( (trim($timeName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("shipping_times/edit/{$id}");
              }
              
              if( ( trim( $timeMin ) == '' ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Minimum days must be greater than equal to one.</strong></div>");
                redirect("shipping_times/edit/{$id}");
              }
              
              if( ( trim( $timeMax ) == '' ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Maximum days must be greater than equal to one.</strong></div>");
                redirect("shipping_times/edit/{$id}");
              }
              
              $new_data = array(
                'name' => $timeName,
                'min_days' => $timeMin,
                'max_days' => $timeMax,
                'phrase' => $timePhrase
              );
              
              $this->mdl_shipping_times->_insert($new_data);
              $id = $this->db->insert_id();
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully added!</strong></div>");
              redirect("shipping_times/edit/{$id}");
            
            }

        }
        else {
            redirect('login', 'refresh');
        }
    }

}
