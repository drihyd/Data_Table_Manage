<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Color_report extends CI_Controller {
    
    function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		$models = array(
			'model_categories' => 'categories',
			'model_orders' => 'orders',
			'model_order_items' => 'order_items',
			'model_products' => 'products',
			'model_skus' => 'skus',
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
    }
    
    function index() {
		
		$data = initiate_page();
		$data['page_name'] = 'Color Report';
		$data['page_title'] = 'Color Report';

		$data['sidebar_element'] = 'side-monitor';
		$data['sidebar_subelement'] = 'side-color-report';

		$data['seo_title'] = 'Color Report';
		$data['seo_description'] = '';
		$data['seo_keywords'] = '';

		$from = date('Y-m-d', strtotime('today - 7 days'));
		$to = date('Y-m-d', time());

		$from_date = $from;
		$to_date = $to;

		if($this->input->get('from')) {
			$from_date = $this->input->get('from');
		}
		if($this->input->get('to')) {
			$to_date = $this->input->get('to');
		}
		
		if(strtotime($from_date) > strtotime($to_date)) {
			$get_from = $from;
			$data['from_date'] = $from;
			$this->session->set_flashdata('form_errors', "FROM DATE cannot be later than TO DATE.");
			redirect('color-report', 'refresh');
		}

		$data['get_from_date'] 	= $from_date;
		$data['get_to_date'] 	= $to_date;

		$filters = array(
			'DATE(ordered_on) >=' => $from_date,
			'DATE(ordered_on) <=' => $to_date,
		);
		
		$product_ids = array();
		
		$top_stock_colors = array();
		$top_order_colors = array();
		
		$orders = array();
		$check = $this->orders->get_true_orders($filters);
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$order_products = array();
		$order_items = array();
		
		foreach ($orders as $order) {
			
			$order_items = array();
			$check = $this->db->get_where('order_items', array('order_id' => $order->id));
			if($check->num_rows() > 0) {
				$order_items = $check->result();
			}
			
			foreach($order_items as $item) {
				$product_id = $item->product_id;
				$this->db->where('attribute_name', 'color');
				$this->db->where('product_id', $product_id);
				$check = $this->db->get('product_attrs');
				if($check->num_rows() > 0) {
					$attr = $check->row();
					$color = $attr->attribute_value;
					
					if( ! isset($top_order_colors[$color])) {
						$top_order_colors[$color] = 0;
					}
					
					$top_order_colors[$color] += 1;
				}
			}
		}
		
		arsort($top_order_colors);
		$data['top_order_colors'] = $top_order_colors;
		
		
		$skus = array();
		$filters = array(
			'stock >' => 0,
			'price >' => 0,
		);
		
		$check = $this->skus->get_where_array($filters);
		if($check->num_rows() > 0) {
			$skus = $check->result();
		}
		
		foreach($skus as $item) {
			$product_id = $item->product_id;
			$this->db->where('attribute_name', 'color');
			$this->db->where('product_id', $product_id);
			$check = $this->db->get('product_attrs');
			if($check->num_rows() > 0) {
				$attr = $check->row();
				$color = $attr->attribute_value;
				
				if( ! isset($top_stock_colors[$color])) {
					$top_stock_colors[$color] = 0;
				}
				
				$top_stock_colors[$color] += 1;
			}
		}
		
		arsort($top_stock_colors);
		$data['top_stock_colors'] = $top_stock_colors;
		
		$this->load->view('header', $data);
		$this->load->view('color_report_view', $data);
		$this->load->view('footer', $data);	
	}
}
