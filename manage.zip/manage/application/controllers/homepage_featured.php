<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Homepage_featured extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->helper(array(
            'form'
        ));
    }

    function index()
    {
        if ($this->session->userdata('logged_in')) 
        {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Homepage Featured';
            $data['page_title'] = 'Homepage Featured';
            
            $data['sidebar_element'] = 'side-content';
            $data['sidebar_subelement'] = 'side-homepage-featured';
            
            
            $this->load->view('header', $data);
            $this->load->view('homepage_featured_view', $data);
            $this->load->view('footer', $data);
        }
        else 
        {
            redirect('login', 'refresh');
        }
    }

    function discountImageSave()
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $path = $_FILES['discountImage']['name'];
            $ext = pathinfo($path, PATHINFO_EXTENSION);
            
            $config['upload_path'] = '../assets/uploads/homepage_featured';
            $config['allowed_types'] = 'png|jpg';
            $config['file_name'] = 'discount_dp';
            $config['overwrite'] = TRUE;
            
            $images = glob(APPPATH . '../../assets/uploads/homepage_featured/'.'discount'.'_*');
            foreach($images as $image) {
              unlink($image);
            }
            
            $this->load->library('upload', $config);
            if($_FILES['discountImage']['size'] == 0) :
                //redirect('404', 'refresh');
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please upload a file.</strong></div>");
                redirect("homepage_featured?tab=discountimage");
            endif;
            
            if (!$this->upload->do_upload('discountImage')) {
                $data['uploadErrors'] = $this->upload->display_errors();
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>{$this->upload->display_errors()}</strong></div>");
                redirect("homepage_featured?tab=discountimage");
            }
            else {
              $res = $this->upload->data();
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Image uploaded successfully.</strong></div>");
              redirect("homepage_featured?tab=discountimage");
            }            
            
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function arrivalImageSave()
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $path = $_FILES['arrivalImage']['name'];
            $ext = pathinfo($path, PATHINFO_EXTENSION);
            
            $config['upload_path'] = '../assets/uploads/homepage_featured';
            $config['allowed_types'] = 'png|jpg';
            $config['file_name'] = 'arrival_dp';
            $config['overwrite'] = TRUE;
            
            $images = glob(APPPATH . '../../assets/uploads/homepage_featured/'.'arrival'.'_*');
            foreach($images as $image) {
              unlink($image);
            }
            
            $this->load->library('upload', $config);
            if($_FILES['arrivalImage']['size'] == 0) :
                //redirect('404', 'refresh');
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please upload a file.</strong></div>");
                redirect("homepage_featured?tab=arrivalimage");
            endif;
            
            if (!$this->upload->do_upload('arrivalImage')) {
                $data['uploadErrors'] = $this->upload->display_errors();
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>{$this->upload->display_errors()}</strong></div>");
                redirect("homepage_featured?tab=arrivalimage");
            }
            else {
              $res = $this->upload->data();
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Image uploaded successfully.</strong></div>");
              redirect("homepage_featured?tab=arrivalimage");
            }            
            
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function dealzoneImageSave()
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $path = $_FILES['dealzoneImage']['name'];
            $ext = pathinfo($path, PATHINFO_EXTENSION);
            
            $config['upload_path'] = '../assets/uploads/homepage_featured';
            $config['allowed_types'] = 'png|jpg';
            $config['file_name'] = 'dealzone_dp';
            $config['overwrite'] = TRUE;
            
            $images = glob(APPPATH . '../../assets/uploads/homepage_featured/'.'dealzone'.'_*');
            foreach($images as $image) {
              unlink($image);
            }
            
            $this->load->library('upload', $config);
            if($_FILES['dealzoneImage']['size'] == 0) :
                //redirect('404', 'refresh');
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please upload a file.</strong></div>");
                redirect("homepage_featured?tab=dealzoneimage");
            endif;
            
            if (!$this->upload->do_upload('dealzoneImage')) {
                $data['uploadErrors'] = $this->upload->display_errors();
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>{$this->upload->display_errors()}</strong></div>");
                redirect("homepage_featured?tab=dealzoneimage");
            }
            else {
              $res = $this->upload->data();
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Image uploaded successfully.</strong></div>");
              redirect("homepage_featured?tab=dealzoneimage");
            }            
            
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function add()
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-add-childcat';
            
            $parent_categories_list = $this->mdl_categories->get_where_custom('parent_id', 0);
            $data['parent_categories_list'] = $parent_categories_list->result();
            
            $data['tinyMC'] = TRUE;

            $this->load->view('header', $data);
            $this->load->view('category_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add_child($parent_id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $check = $this->mdl_categories->get_where($parent_id);
            if($check->num_rows() == 0) :
                redirect('404', 'refresh');
            endif;
            
            $data['page_name'] = 'categories';
            
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-add-childcat';
            
            $parent_category_details = $this->mdl_categories->get_where($parent_id);
            $data['parent_category_details'] = $parent_category_details->row();
            
            $data['tinyMC'] = TRUE;

            $this->load->view('header', $data);
            $this->load->view('category_add_child', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function parentadd()
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-add-parentcat';
            
            $data['tinyMC'] = TRUE;

            $this->load->view('header', $data);
            $this->load->view('category_parentadd', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function delete($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $check = $this->mdl_categories->get_where($id);
            if($check->num_rows() == 0) :
                redirect('404', 'refresh');
            endif;
            
            $data['page_name'] = 'categories';
            $data['page_title'] = 'All Categories';
            
            $this->load->model('mdl_products');
            $this->load->model('mdl_product_images');
            
            //delete products listed directly under this category
            $products = $this->mdl_products->get_where('cat_id', $id);
            foreach($products->result() as $product) {
                
                $product_code = implode('_', explode(' ',$product->code));
                $product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
                foreach($product_images as $image) {
                    unlink($image);
                }
                
                //delete all SKUs listed under this product
                $this->load->model('mdl_skus');
                $skus = $this->mdl_skus->get_where_custom('product_id', $product->id);
                foreach($skus->result() as $sku) {
                    $this->mdl_skus->_delete($sku->id);
                }
                
                //delete all product_attributes listed under this product
                $this->load->model('mdl_product_attributes');
                $product_attribute_entries = $this->mdl_product_attributes->get_where_custom('product_id', $product->id);
                if($product_attribute_entries->num_rows() > 0) {
                    foreach($product_attribute_entries->result() as $product_attribute_entries) {
                        $this->mdl_product_attributes->_delete($product_attribute_entries->id);
                    }
                }
                
                // finally delete the product
                $this->mdl_products->_delete($product->id);
                
            }

            //delete Sub-categories listed under this Category
            $sub_categories = $this->mdl_categories->get_where_custom('parent_id', $id);
            foreach($sub_categories->result() as $sub_category) {
                
                // first delete all products listed under this sub-category
                $products = $this->mdl_products->get_where_custom('cat_id', $sub_category->id);
                foreach($products->result() as $product) {
                    
                    $product_code = implode('_', explode(' ',$product->code));
                    $product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
                    foreach($product_images as $image) {
                        unlink($image);
                    }
                    
                    //delete all SKUs listed under this product
                    $this->load->model('mdl_skus');
                    $skus = $this->mdl_skus->get_where_custom('product_id', $product->id);
                    foreach($skus->result() as $sku) {
                        $this->mdl_skus->_delete($sku->id);
                    }
                    
                    //delete all product_attributes listed under this product
                    $this->load->model('mdl_product_attributes');
                    $product_attribute_entries = $this->mdl_product_attributes->get_where_custom('product_id', $product->id);
                    if($product_attribute_entries->num_rows() > 0) {
                        foreach($product_attribute_entries->result() as $product_attribute_entries) {
                            $this->mdl_product_attributes->_delete($product_attribute_entries->id);
                        }
                    }
                    
                    // finally delete the product
                    $this->mdl_products->_delete($product->id);
                    
                }
                
                // finally delete the sub-category
                $this->mdl_categories->_delete($sub_category->id);
            }
            
            // finally delete the category
            $this->mdl_categories->_delete($id);
            
            redirect('categories');
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function parentdelete($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $check = $this->mdl_categories->get_where($id);
            if($check->num_rows() == 0) :
                redirect('404', 'refresh');
            endif;
            
            $data['page_name'] = 'categories';
            $data['page_title'] = 'All Categories';
            
            $this->load->model('mdl_products');
            $this->load->model('mdl_product_images');
            
            //delete products listed directly under this category
            $products = $this->mdl_products->get_where_custom('cat_id', $id);
            foreach($products->result() as $product) {
                
                $product_code = implode('_', explode(' ',$product->code));
                $product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
                foreach($product_images as $image) {
                    unlink($image);
                }
                
                //delete all SKUs listed under this product
                $this->load->model('mdl_skus');
                $skus = $this->mdl_skus->get_where_custom('product_id', $product->id);
                foreach($skus->result() as $sku) {
                    $this->mdl_skus->_delete($sku->id);
                }
                
                //delete all product_attributes listed under this product
                $this->load->model('mdl_product_attributes');
                $product_attribute_entries = $this->mdl_product_attributes->get_where_custom('product_id', $product->id);
                if($product_attribute_entries->num_rows() > 0) {
                    foreach($product_attribute_entries->result() as $product_attribute_entries) {
                        $this->mdl_product_attributes->_delete($product_attribute_entries->id);
                    }
                }
                
                // finally delete the product
                $this->mdl_products->_delete($product->id);
                
            }

            //delete Sub-categories listed under this Category
            $sub_categories = $this->mdl_categories->get_where_custom('parent_id', $id);
            foreach($sub_categories->result() as $sub_category) {
                
                // first delete all products listed under this sub-category
                $products = $this->mdl_products->get_where_custom('cat_id', $sub_category->id);
                foreach($products->result() as $product) {
                    
                    $product_code = implode('_', explode(' ',$product->code));
                    $product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
                    foreach($product_images as $image) {
                        unlink($image);
                    }
                    
                    //delete all SKUs listed under this product
                    $this->load->model('mdl_skus');
                    $skus = $this->mdl_skus->get_where_custom('product_id', $product->id);
                    foreach($skus->result() as $sku) {
                        $this->mdl_skus->_delete($sku->id);
                    }
                    
                    //delete all product_attributes listed under this product
                    $this->load->model('mdl_product_attributes');
                    $product_attribute_entries = $this->mdl_product_attributes->get_where_custom('product_id', $product->id);
                    if($product_attribute_entries->num_rows() > 0) {
                        foreach($product_attribute_entries->result() as $product_attribute_entries) {
                            $this->mdl_product_attributes->_delete($product_attribute_entries->id);
                        }
                    }
                    
                    // finally delete the product
                    $this->mdl_products->_delete($product->id);
                    
                }
                
                // finally delete the sub-category
                $this->mdl_categories->_delete($sub_category->id);
            }
            
            // finally delete the category
            $this->mdl_categories->_delete($id);
            
            redirect('categories');
        }
        else {
            redirect('login', 'refresh');
        }
    }

}
