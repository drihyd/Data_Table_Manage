<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class bulk_images_upload extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('mdl_tags', '', TRUE);
    $this->load->model('mdl_tagged_products', '', TRUE);
    $this->load->helper(array(
        'form'
    ));
  }
    
  function index()
	{
    if ($this->session->userdata('logged_in')) {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['user_email'] = $session_data['email'];
      
      $data['page_name'] = 'Bulk Images Upload';
      $data['page_title'] = 'Bulk Image Upload';
      
      $data['sidebar_element'] = 'side-bulk-upload';
      $data['sidebar_subelement'] = 'side-bulk-images-upload';
      
      $this->load->view('header', $data);
      $this->load->view('bulk_images_upload_view', $data);
      $this->load->view('footer', $data);
    }
    else {
        redirect('login', 'refresh');
    }
  }
  
	function doupload() {
    //system("cp /usr/local/lib/php.ini  /home/deepred/public_html/demos/taruni/manage/php.ini");
    //echo phpinfo();
		if ($this->session->userdata('logged_in')) {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['user_email'] = $session_data['email'];
      
      $data['page_name'] = 'Bulk Images Upload';
      $data['page_title'] = 'Bulk Image Upload';
      
      $data['sidebar_element'] = 'side-bulk-upload';
      $data['sidebar_subelement'] = 'side-bulk-images-upload';
      
      $error_names = array();
      $name_array = array();
      $count = count($_FILES['userfile']['size']);
      foreach($_FILES as $key=>$value) {
        for($s=0; $s<=$count-1; $s++) {
          $_FILES['userfile']['name']=$value['name'][$s];
          $_FILES['userfile']['type']    = $value['type'][$s];
          $_FILES['userfile']['tmp_name'] = $value['tmp_name'][$s];
          $_FILES['userfile']['error']       = $value['error'][$s];
          $_FILES['userfile']['size']    = $value['size'][$s];   
          $config['upload_path'] = '../assets/uploads/';
          $config['allowed_types'] = 'jpg';
          $config['max_size']	= '300';
          $config['max_width']  = '1000';
          $config['max_height']  = '1000';
          $config['overwrite']  = TRUE;
          
          if ( preg_match('/\s/',$value['name'][$s]) ) {
			  array_push($error_names, $value['name'][$s]);
              continue;
          }
          
          $this->load->library('upload', $config);
          //echo phpinfo();
          if( ! $this->upload->do_upload()) {
            //$data['uploadErrors'] = $this->upload->display_errors();
            //$this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Following error(s) occured. {$data['uploadErrors']}. Please make sure all the uploaded files are .jpg and 500px X 500px dimension.</strong></div>");
            array_push($error_names, $value['name'][$s]);
            continue;
            //redirect('bulk_images_upload', 'refresh');
          }
          else {
            $imgdata = $this->upload->data();
            $name_array[] = $imgdata['file_name'];
          }
        }
        //$names= implode(',', $name_array);
        //print_r($names);
      }
      
      $data['names'] = $name_array;
      $data['error_names'] = $error_names;
      $this->load->view('header', $data);
      $this->load->view('bulk_images_done_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
	}
    
    

}
