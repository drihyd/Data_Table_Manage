<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Skus extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_skus', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            redirect('products', 'refresh');
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function sku_info($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
                        
            $sku_details = $this->mdl_skus->get_where($id);
            if($sku_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $sku_details = $sku_details->row();
            }
            
            $data['sku_details'] = $sku_details;
            
            
            $this->load->model('mdl_products');
            $parent_product_details = $this->mdl_products->get_where($sku_details->product_id);
            if($parent_product_details->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $parent_product_details = $parent_product_details->row();
            }
            $data['parent_product_details'] = $parent_product_details;
            
            $data['page_title'] = $sku_details->sku_code;
             
            $this->load->view('header', $data);
            $this->load->view('sku_info_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function edit($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $this->load->model('mdl_products');
            
            $sku_details = $this->mdl_skus->get_where($id);
            if($sku_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $sku_details = $sku_details->row();
            }
            $data['sku_details'] = $sku_details;
            
            $parent_product_details = $this->mdl_products->get_where($sku_details->product_id);
            if($parent_product_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $parent_product_details = $parent_product_details->row();
            }
            $data['parent_product_details'] = $parent_product_details;
            
            $data['page_title'] = 'Edit '.$sku_details->sku_code;

            $this->load->view('header', $data);
            $this->load->view('sku_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function add($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'Add New Product';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-add-product';
            
            $this->load->model('mdl_products');
            
            $product_details = $this->mdl_products->get_where($id);
            if($product_details->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $product_details = $product_details->row();
            }
            $data['product_details'] = $product_details;
            
            $data['page_title'] = 'Add SKU in '.$product_details->name;

            $this->load->view('header', $data);
            $this->load->view('sku_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add_child($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'Add New Product';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-add-product';
            
            $this->load->model('mdl_products');
            
            $product_details = $this->mdl_products->get_where($id);
            if($product_details->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $product_details = $product_details->row();
            }
            $data['product_details'] = $product_details;
            
            $data['page_title'] = 'Add SKU in '.$product_details->name;

            $this->load->view('header', $data);
            $this->load->view('sku_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function delete($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'Add New Product';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-add-product';
            
            $check = $this->mdl_skus->get_where($id);
            if($check->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $sku = $check->row();
            }
            
            $this->load->model('mdl_products');
            $product = $this->mdl_products->get_where($sku->product_id)->row();
            
            $this->mdl_skus->_delete($sku->id);
            
            redirect("products/product_info/{$product->id}#sub-skus-section");
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function save($id = FALSE) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'All Products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $skuCode = $this->input->post('skuCode');            
            $skuSize = $this->input->post('skuSize', true);
            $skuPriceINR = $this->input->post('skuPrice_inr', true);
            $skuPriceUSD = $this->input->post('skuPrice_usd', true);
            ///$skuStrikedPrice = $this->input->post('skuStrikedPrice', true);
            $skuStock = (int) $this->input->post('skuStock', true);
            $productId = (int) $this->input->post('productId',true);
            $catId = (int) $this->input->post('catId',true);

            $this->load->model('mdl_products');
            
            if ($id) {
                
                $sku_details_query = $this->mdl_skus->get_where($id);
                if($sku_details_query->num_rows() > 0) {
                    $sku_details = $sku_details_query->row();
                }
                else {
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Invalid SKU ID.</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                }
                
                if(!$productId || !$catId) :
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Product ID not found. Please try again</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                $product = $this->mdl_products->get_where($productId);
                if($product->num_rows() != 1) {
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Invalid parent Product ID.</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                }
                else {
                    $product = $product->row();
                }
                if($catId != $product->cat_id) :
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid parent product</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                
                if (!$skuCode):
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please enter an SKU Code</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                
                if ( (!$skuPriceINR) || ($skuPriceINR <= 0) ):
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please enter a valid INR Price.</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                
                if ( (!$skuPriceUSD) || ($skuPriceUSD <= 0) ):
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please enter a valid USD Price.</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                
                //if ( ($skuStrikedPrice < 0) ):
                    //$this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please enter a valid Striked Price.</strong></div>");
                    //redirect("skus/edit/{$id}", 'refresh');
                //endif;

                $all_sizes = array('s', 'm', 'l', 'xl', 'xxl', 'xxxl', 'unstitched');
                for ($i=24; $i < 42; $i+=2) { 
                    $all_sizes [] = 'kid_'.$i;               
                }
                
                if( !$skuSize || !(in_array($skuSize, $all_sizes)) ) :
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please specify a valid size.</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                
                $skuSize = strtolower($skuSize);
                
                if($skuStock < 0) :
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Stock must be a number greater than or equal to zero.</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                
                
                
                $data = array(
                    'sku_code' => $skuCode,
                    'size' => $skuSize,
                    'price_inr' => $skuPriceINR,
                    'price_usd' => $skuPriceUSD,
                    //'striked_price' => $skuStrikedPrice,
                    'stock' => $skuStock
                );
                
                $this->mdl_skus->_update($id, $data);
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully Updated!</strong></div>");
                redirect("skus/edit/{$id}", 'refresh');
            }
            else {
              
                if(!$productId || !$catId) :
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Product ID not found. Please try again</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                $product = $this->mdl_products->get_where($productId);
                if($product->num_rows() != 1) {
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Invalid parent Product ID.</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                }
                else {
                    $product = $product->row();
                }
                if($catId != $product->cat_id) :
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid parent product</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                
                if (!$skuCode):
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please enter an SKU Code</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                
                if (!$skuPriceINR):
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please enter a valid INR Price.</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                
                if (!$skuPriceUSD):
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please enter a valid USD Price.</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;

                
                if( !$skuSize || !(in_array($skuSize, array('s', 'm', 'l', 'xl', 'xxl', 'xxxl', 'unstitched'))) ) :
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please specify a valid size.</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                
                $skuSize = strtolower($skuSize);
                
                if($skuStock < 0) :
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Stock must be a number greater than or equal to zero.</strong></div>");
                    redirect("skus/edit/{$id}", 'refresh');
                endif;
                
                $data = array(
                    'product_id' => $productId,
                    'cat_id' => $catId,
                    'sku_code' => $skuCode,
                    'size' => $skuSize,
                    'price_inr' => $skuPriceINR,
                    'price_usd' => $skuPriceUSD,
                    'stock' => $skuStock
                );
                
                $this->mdl_skus->_insert($data);
                $id = mysql_insert_id();
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>SKU successfully created!</strong></div>");
                redirect("skus/edit/{$id}", 'refresh');
            }
            
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function update_stock($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'All Products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $this->load->model('mdl_products');
            
            $check = $this->mdl_skus->get_where($id);
            if($check->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $sku_details = $check->row();
            }
            
            
            $sku_stock = (int) $this->input->post('sku_stock');
            if ($sku_stock < 0):
                echo "Error! Stock must be greater than or equal to Zero";
                exit();
            endif;
            
            $data = array(
                'stock' => $sku_stock
            );
            
            $this->mdl_skus->_update($sku_details->id, $data);
            $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
            redirect("products/product_info/{$sku_details->product_id}#sub-skus-section");

        }
        else {
            redirect('login', 'refresh');
        }
    }

}
