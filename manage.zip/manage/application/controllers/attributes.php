<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Attributes extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_attributes', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'attributes';
            $data['page_title'] = 'All Attributes';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-attributes-view';
            
            $this->load->model('mdl_attribute_values');
            
            
            $attributes = $this->mdl_attributes->get('id');
            if($attributes->num_rows() > 0) {
              $attributes = $attributes->result();
            }
            else {
              $attributes = array();
            }
            
            $attribute_values = $this->mdl_attribute_values->get('id');
            if($attribute_values->num_rows() > 0) {
              $attribute_values = $attribute_values->result();
            }
            else {
              $attribute_values = array();
            }
                      
            $data['attributes'] = $attributes;
            $data['attribute_values'] = $attribute_values;
            
            $this->load->view('header', $data);
            $this->load->view('attributes_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function attribute_info($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'attributes';
            
            $data['sidebar_element'] = 'side-attributes';
            $data['sidebar_subelement'] = 'side-attributes-view';
            
            $this->load->model('mdl_attribute_values');
            
            
            $attribute = $this->mdl_attributes->get_where($id);
            if($attribute->num_rows() > 0) {
              $attribute_details = $attribute->row();
            }
            else {
              redirect('404', 'refresh');
            }
            
            
            $attribute_values = $this->mdl_attribute_values->get_where_custom('attr_id', $attribute_details->id);
            if($attribute_values->num_rows() > 0) {
              $attribute_values = $attribute_values->result();
            }
            else {
              $attribute_values = array();
            }
            
            
            $data['page_title'] = 'Manage '. $attribute_details->attr_name . 'attributes';
                      
            $data['attribute_details'] = $attribute_details;
            $data['attribute_values'] = $attribute_values;
            
            $this->load->view('header', $data);
            $this->load->view('attribute_info_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'attributes';
            $data['page_title'] = 'Add New Attribute';
            
            $data['sidebar_element'] = 'side-attributes';
            $data['sidebar_subelement'] = 'side-attributes-view';            
            
            $this->load->view('header', $data);
            $this->load->view('attribute_add_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function edit($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'attributes';
            $data['page_title'] = 'Add New Attribute';
            
            $data['sidebar_element'] = 'side-attributes';
            $data['sidebar_subelement'] = 'side-attributes-view';            
            
            $query = $this->mdl_attributes->get_where($id);
            if($query->num_rows() > 0) {
              $attribute_details = $query->row();
            }
            else {
              redirect('404', 'refresh');
            }
            
            $data['attribute_details'] = $attribute_details;
            
            $this->load->view('header', $data);
            $this->load->view('attribute_edit_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function delete($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'attributes';
            $data['page_title'] = 'Add New Attribute';
            
            $data['sidebar_element'] = 'side-attributes';
            $data['sidebar_subelement'] = 'side-attributes-view';            
            
            $query = $this->mdl_attributes->get_where($id);
            if($query->num_rows() > 0) {
              $attribute_details = $query->row();
            }
            else {
              redirect('404', 'refresh');
            }
            
            //delete all the attribute Values with this attribute as the parent
            $this->load->model('mdl_attribute_values');
            $attribute_values = $this->mdl_attribute_values->get_where_custom('attr_id', $attribute_details->id);
            if($attribute_values->num_rows() > 0) {
              foreach($attribute_values->result() as $attribute_value) {
                $this->mdl_attribute_values->_delete($attribute->id);
              }
            }
            
            //now delete the attribute
            $this->mdl_attributes->_delete($attribute_details->id);
            
            $this->session->set_flashdata('message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Deleted Successfully</strong></div>");
            redirect('attributes', 'refresh');
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function save($id = FALSE) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'attributes';
            $data['page_title'] = 'All Attributes';
            
            $data['sidebar_element'] = 'side-attributes';
            $data['sidebar_subelement'] = 'side-attributes-view';
            
            $attributeName = $this->input->post('attributeName', true);
            
            if ($id) {
                
                $attributeName = trim(strtolower($attributeName));
                if($attributeName == '') {
                  $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                  redirect("attributes/edit/{$id}", 'refresh');
                }
                
                $attribute_details_query = $this->mdl_attributes->get_where($id);
                if($attribute_details_query->num_rows() > 0) {
                    $attribute_details = $attribute_details_query->row();
                }
                else {
                    $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Atrribute ID.</strong></div>");
                    redirect("attributes/edit/{$id}", 'refresh');
                }
                
                
                
                $this->db->where_not_in('id', array($id));
                $query = $this->mdl_attributes->get_where_custom('attr_name', $attributeName);
                if($query->num_rows() > 0) {
                  $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! This name already exists. Enter a unique name.</strong></div>");
                  redirect("attributes/edit/{$id}", 'refresh');
                }
                
                $new_data = array(
                  'attr_name' => $attributeName
                );
                
                $this->mdl_attributes->_update($id, $new_data);
                
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully Updated!</strong></div>");
                redirect("attributes/edit/{$id}", 'refresh');
            }
            else {
                
                $attributeName = trim(strtolower($attributeName));
                if($attributeName == '') {
                  $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                  redirect("attributes/add", 'refresh');
                }
                
                $query = $this->mdl_attributes->get_where_custom('attr_name', $attributeName);
                if($query->num_rows() > 0) {
                  $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! This name already exists. Enter a unique name.</strong></div>");
                  redirect("attributes/add", 'refresh');
                }
                
                $new_data = array(
                  'attr_name' => $attributeName
                );
                
                $this->mdl_attributes->_insert($new_data);
                
                $id = mysql_insert_id();
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Attribute successfully created!</strong></div>");
                redirect("attributes/edit/{$id}", 'refresh');
            }
            
        }
        else {
            redirect('login', 'refresh');
        }
    }
    

}
