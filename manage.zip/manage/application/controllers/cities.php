<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Cities extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_cities', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'States';
            $data['page_title'] = 'All States';
            
            $data['sidebar_element'] = 'side-master-data';
            $data['sidebar_subelement'] = 'side-cities';
            
            $this->load->model('mdl_states');
            $this->load->model('mdl_shipping_rates');
            $this->load->model('mdl_shipping_times');
            
            $check = $this->mdl_cities->get('id');
            if($check->num_rows() > 0) {
              $cities = $check->result();
            }
            else {
              $cities = array();
            }
            
            $check = $this->mdl_shipping_rates->get('id');
            if($check->num_rows() > 0) {
              $shipping_rates_info = array();
              foreach($check->result() as $shipping_rate) {
                $shipping_rates_info[$shipping_rate->id] = $shipping_rate;
              }
            }
            else {
              $shipping_rates_info = array();
            }
            
            $check = $this->mdl_shipping_times->get('id');
            if($check->num_rows() > 0) {
              $shipping_times_info = array();
              foreach($check->result() as $shipping_time) {
                $shipping_times_info[$shipping_time->id] = $shipping_time;
              }
            }
            else {
              $shipping_times_info = array();
            }
            
            $check = $this->mdl_states->get('id');
            if($check->num_rows() > 0) {
              $states_info = array();
              foreach($check->result() as $state) {
                $states_info[$state->id] = $state;
              }
            }
            else {
              $states_info = array();
            }
            
            $data['shipping_rates_info'] = $shipping_rates_info;
            $data['shipping_times_info'] = $shipping_times_info;
            $data['states_info'] = $states_info;
            $data['cities'] = $cities;
            
            $this->load->view('header', $data);
            $this->load->view('cities_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function delete() {
      if ($this->session->userdata('logged_in')) {
          $session_data = $this->session->userdata('logged_in');
          $data['username'] = $session_data['username'];
          $data['user_type'] = $session_data['type'];
          $data['user_email'] = $session_data['email'];
          
          $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Sorry! You are not auhtorised to delete Cities. Please contact DB Administrator.</strong></div>");
          redirect("cities");
            
      }
      else {
          redirect('login', 'refresh');
      }
    }
    
    
    function edit($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = 'Edit Shipping Rate';
            
            $data['sidebar_element'] = 'side-cities';
            $data['sidebar_subelement'] = 'side-cities-view';
            
            if( ! $id ) {
              redirect('404', 'refresh');
            }
            
            $check = $this->mdl_cities->get_where($id);
            if($check->num_rows() > 0) {
              $city_details = $check->row();
            }
            else {
              $city_details->array();
            }
            
            $data['city_details'] = $city_details;
            
            $this->load->model('mdl_states');
            $this->load->model('mdl_shipping_rates');
            $this->load->model('mdl_shipping_times');
            
            $check = $this->mdl_shipping_rates->get('id');
            if($check->num_rows() > 0) {
              $shipping_rates = $check->result();
            }
            else {
              $shipping_rates = array();
            }
            
            $check = $this->mdl_shipping_times->get('id');
            if($check->num_rows() > 0) {
              $shipping_times = $check->result();
            }
            else {
              $shipping_times = array();
            }
            
            $check = $this->mdl_states->get_where($city_details->state_id);
            if($check->num_rows() > 0) {
              $parent_state = $check->row();
            }
            else {
              $parent_state = array();
            }
            
            $data['parent_state'] = $parent_state;
            
            $data['shipping_rates'] = $shipping_rates;
            $data['shipping_times'] = $shipping_times;
            
            $this->load->view('header', $data);
            $this->load->view('city_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function save($id=null) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = '';
            
            $data['sidebar_element'] = 'side-cities';
            $data['sidebar_subelement'] = 'side-cities-view';
            
            $this->load->model('mdl_shipping_rates');
            $this->load->model('mdl_shipping_times');
            
            if($id) {
              $check = $this->mdl_cities->get_where($id);
              if($check->num_rows() > 0) {
                $state_details = $check->row();
              }
              else {
                redirect('404', 'refresh');
              }
              
              $cityName = $this->input->post('cityName', true);
              $cityShippingRateID = (int) $this->input->post('cityShippingRateID', true);
              $cityShippingTimeID = (int) $this->input->post('cityShippingTimeID', true);
              $cityTax = $this->input->post('cityTax', true);
              $cityCOD = (int) $this->input->post('cityCOD', true);
              
              if( (trim($cityName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("cities/edit/{$id}");
              }
            
              if( (trim($cityShippingRateID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Rate cannot be empty.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              if( (trim($cityShippingTimeID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Time cannot be empty.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              if( (trim($cityTax) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Tax cannot be empty.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              if( (trim($cityCOD) == '') || ( ! in_array($cityCOD, array(0,1)) ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid COD Availability.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_rates->get_where($cityShippingRateID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Rate ID.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_times->get_where($cityShippingTimeID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Time ID.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              $new_data = array(
                'city_name' => $cityName,
                'shipping_rate_id' => $cityShippingRateID,
                'shipping_time_id' => $cityShippingTimeID,
                'tax_percentage' => $cityTax,
                'cod_available' => $cityCOD
              );
              
              $this->mdl_cities->_update($id, $new_data);
              
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully updated!</strong></div>");
              redirect("cities/edit/{$id}");
            
            }
            else {
              
              $cityName = $this->input->post('cityName', true);
              $cityShippingRateID = (int) $this->input->post('cityShippingRateID', true);
              $cityShippingTimeID = (int) $this->input->post('cityShippingTimeID', true);
              $cityTax = $this->input->post('cityTax', true);
              $cityCOD = (int) $this->input->post('cityCOD', true);
              
              if( (trim($cityName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              if( (trim($cityCODe) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Country Code cannot be empty.</strong></div>");
                redirect("cities/edit/{$id}");
              }
            
              if( (trim($cityShippingRateID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Rate cannot be empty.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              if( (trim($cityShippingTimeID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Time cannot be empty.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              if( (trim($cityTax) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Tax cannot be empty.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              if( (trim($cityCOD) == '') || ( ! in_array($cityCOD, array(0,1)) ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid COD Availability.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_rates->get_where($cityShippingRateID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Rate ID.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_times->get_where($cityShippingTimeID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Time ID.</strong></div>");
                redirect("cities/edit/{$id}");
              }
              
              $new_data = array(
                'city_name' => $cityName,
                'shipping_rate_id' => $cityShippingRateID,
                'shipping_time_id' => $cityShippingTimeID,
                'tax_percentage' => $cityTax,
                'cod_available' => $cityCOD
              );
              
              $this->mdl_cities->_insert($new_data);
              $id = $this->db->insert_id();
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully added!</strong></div>");
              redirect("cities/edit/{$id}");
            
            }

        }
        else {
            redirect('login', 'refresh');
        }
    }

}
