<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Enquiry_leads extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('mdl_enquiry_leads', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'enquiry_leads';
      
      $enquiry_leads = array();
      $query = $this->db->query("select * from leads where `for` = 'enquiry'");
      if($query) :
        foreach($query->result() as $enquiry_lead) {
          foreach($enquiry_lead as $key => $value) {
            $enquiry_leads[$enquiry_lead->id][$key] = $value;
          }
        }
      endif;
      $data['enquiry_leads'] = $enquiry_leads;
      $this->load->view('header', $data);
      $this->load->view('enquiry_leads_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function delete($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $this->mdl_enquiry_leads->_delete($id);
      
      
      redirect('enquiry_leads');
    }
    else {
      redirect('login', 'refresh');
    }
  }
    
  function get($order_by) {
  $this->load->model('mdl_enquiry_leads');
  $query = $this->mdl_enquiry_leads->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_enquiry_leads');
  $query = $this->mdl_enquiry_leads->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_enquiry_leads');
  $query = $this->mdl_enquiry_leads->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_enquiry_leads');
  $query = $this->mdl_enquiry_leads->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_enquiry_leads');
  $this->mdl_enquiry_leads->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_enquiry_leads');
  $this->mdl_enquiry_leads->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_enquiry_leads');
  $this->mdl_enquiry_leads->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_enquiry_leads');
  $count = $this->mdl_enquiry_leads->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_enquiry_leads');
  $max_id = $this->mdl_enquiry_leads->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_enquiry_leads');
  $query = $this->mdl_enquiry_leads->_custom_query($mysql_query);
  return $query;
  }

}
