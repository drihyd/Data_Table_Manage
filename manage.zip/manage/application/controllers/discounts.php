<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Discounts extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_discounts', '', TRUE);
        $this->load->model('mdl_discounted_products', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Discounts';
            $data['page_title'] = 'All Discounts';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-discounts-view';
            
            $this->db->order_by('id', 'desc');
            $check = $this->mdl_discounts->get('id');
            if($check->num_rows() > 0) {
              $discounts = $check->result();
            }
            else {
              $discounts = array();
            }
            
            $discount_num_products = array();
            foreach($discounts as $discount) {
              $this->db->where('discount_id', $discount->id);
              $this->db->from('discounted_products');
              $discount_num_products[$discount->id] = $this->db->count_all_results();
            }
            
            $data['discounts'] = $discounts;
            $data['discount_num_products'] = $discount_num_products;
            
            $this->load->view('header', $data);
            $this->load->view('discounts_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function delete($id) {
      if ($this->session->userdata('logged_in')) {
          $session_data = $this->session->userdata('logged_in');
          $data['username'] = $session_data['username'];
          $data['user_type'] = $session_data['type'];
          $data['user_email'] = $session_data['email'];
          
          $check = $this->mdl_discounts->get_where($id);
          if($check->num_rows() > 0) {
            $discount = $check->row();
          }
          else {
            redirect('404', 'refresh');
          }
          
          //delete discounted products table entries first
          $this->db->where('discount_id', $discount->id);
          $this->db->delete('discounted_products');
          
          //now delete actual discount
          $this->mdl_discounts->_delete($discount->id);
          
          redirect($this->config->base_url().'discounts');
      }
      else {
          redirect('login', 'refresh');  
      }
    }
    
    
    function edit($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Discount';
            $data['page_title'] = 'Edit Discount';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-discounts-view';
            
            if( ! $id ) {
              redirect('404', 'refresh');
            }
            
            $check = $this->mdl_discounts->get_where($id);
            if($check->num_rows() > 0) {
              $discount_details = $check->row();
            }
            else {
              $discount_details->array();
            }
            $data['discount_details'] = $discount_details;
            
            $this->load->model('mdl_discounted_products');
            $this->load->model('mdl_products');
            $this->load->model('mdl_categories');
            
            $discounted_products = array();
            $check = $this->mdl_discounted_products->get_where_custom('discount_id', $discount_details->id);
            if($check->num_rows() > 0) {
              $discounted_products = $check->result();
            }
            $data['discounted_products'] = $discounted_products;
            
            $products_info = array();
            foreach($discounted_products as $product) {
              $check = $this->mdl_products->get_where($product->product_id);
              if($check->num_rows() > 0) {
                $products_info[$product->product_id] = $check->row();
              }
            }
            $data['products_info'] = $products_info;
            
            $categories_info = array();
            foreach($products_info as $product) {
              $check = $this->mdl_categories->get_where($product->cat_id);
              if($check->num_rows() > 0) {
                $categories_info[$product->cat_id] = $check->row();
              }
            }
            $data['categories_info'] = $categories_info;
            
            $discounted_product_codes = array();
            //print_r($discounted_products);
            foreach($discounted_products as $product) {
              if(isset($products_info[$product->product_id])) {
                array_push($discounted_product_codes, $products_info[$product->product_id]->code);
              }
            }
            $data['discounted_product_codes'] = $discounted_product_codes;
            
            $this->load->view('header', $data);
            $this->load->view('discount_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Add Discount';
            $data['page_title'] = 'Add Discount';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-discounts-view';
            
            $this->load->view('header', $data);
            $this->load->view('discount_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function seosave($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-discounts-view';
            
            $check = $this->mdl_discounts->get_where($id);
            if($check->num_rows() == 0) :
                redirect('404', 'refresh');
            endif;
            
            $seoTitle = $this->input->post('discountSeoTitle', true);
            $seoDesc = $this->input->post('discountSeoDesc', true);
            $seoKeys = $this->input->post('discountSeoKeys', true);
            
            $data = array(
                'seo_title' => $seoTitle,
                'seo_desc' => $seoDesc,
                'seo_keywords' => $seoKeys
            );
            $this->mdl_discounts->_update($id, $data);
            
            
            $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Upadated successfully.</strong></div>");
            redirect("discounts/edit/{$id}?tab=seotags");

        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function save($id=null) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = '';
            
            $data['sidebar_element'] = 'side-cities';
            $data['sidebar_subelement'] = 'side-cities-view';
            
            $this->load->model('mdl_products');
            
            if($id) {
              $check = $this->mdl_discounts->get_where($id);
              if($check->num_rows() > 0) {
                $discount_details = $check->row();
              }
              else {
                redirect('404', 'refresh');
              }
              
              $discountName = $this->input->post('discountName', true);
              $discountSlug = $this->input->post('discountSlug', true);
              $discountDesc = $this->input->post('discountDesc', true);
              $discountPercentage = $this->input->post('discountPercentage', true);
              $discountProductsList = $this->input->post('discountProductsList', true);
              $discountValidFrom = $this->input->post('discountValidFrom', true);
              $discountValidTill = $this->input->post('discountValidTill', true);
              $discountValidFromTime = $this->input->post('discountValidFromTime', true);
              $discountValidTillTime = $this->input->post('discountValidTillTime', true);
              
              
              
              if( (trim($discountName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("discounts/edit/{$id}");
              }
              
              if( (trim($discountSlug) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Slug cannot be empty.</strong></div>");
                redirect("discounts/edit/{$id}");
              }
              
              $this->db->where('id !=', $id);
              $check = $this->mdl_discounts->get_where_custom('slug', $discountSlug);
              if($check->num_rows() > 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Slug already exists. Enter a unique slug.</strong></div>");
                redirect("discounts/edit/{$id}");
              }
              
              if( (trim($discountPercentage) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Discount Percentage cannot be empty.</strong></div>");
                redirect("discounts/edit/{$id}");
              }
              
              if( (trim($discountValidFrom) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Valid From Date cannot be empty.</strong></div>");
                redirect("discounts/edit/{$id}");
              }
              
              if( (trim($discountValidTill) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Valid Till Date cannot be empty.</strong></div>");
                redirect("discounts/edit/{$id}");
              }
              
              $discountedProductCodes = array();
              $discountedProducts = array();
              $invalidProductCodes = array();
              
              //print_r($discountProductsList);
              $discountProductsList = str_replace(' ', '', $discountProductsList);
              $discountedProductCodes = explode(',', $discountProductsList);
              
              foreach($discountedProductCodes as $productCode) {
                $check = $this->mdl_products->get_where_custom('code', $productCode);
                if($check->num_rows() > 0) {
                  array_push($discountedProducts, $check->row()->id);
                }
                else {
                  array_push($invalidProductCodes, $productCode);
                }
              }
              
              $this->db->where('discount_id', $discount_details->id);
              $this->db->delete('discounted_products');
              
              
			  foreach($discountedProducts as $product) {
				
				$new_data = array(
				  'discount_id' => $discount_details->id,
				  'product_id' => $product
				);
				
				$this->mdl_discounted_products->_insert($new_data);
			  }

              $new_data = array(
                'name' => $discountName,
                'slug' => $discountSlug,
                'desc' => $discountDesc,
                'discount_percentage' => $discountPercentage,
                'valid_from' => date('Y-m-d H:i:s', strtotime($discountValidFrom.' '.$discountValidFromTime)),
                'valid_till' => date('Y-m-d H:i:s', strtotime($discountValidTill.' '.$discountValidTillTime))
              );
              
              
              $this->mdl_discounts->_update($discount_details->id, $new_data);
              
              //$this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully updated!</strong></div>");
              
              
              if(count($discountedProducts) > 0) {
                $add_count = count($discountedProducts);
                $this->session->set_flashdata('discount-success-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully addded {$add_count} product(s).</strong></div>");
              }
              
              if(count($invalidProductCodes) > 0) {
                $invalid_codes = implode(', ', $invalidProductCodes);
                $this->session->set_flashdata('discount-success-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button>The following products were invalid, and hence were not added:<br><strong>{$invalid_codes}.</strong></div>");
              }
              
              redirect("discounts/edit/{$id}");
            
            }
            else {
              
              $discountName = $this->input->post('discountName', true);
              $discountSlug = $this->input->post('discountSlug', true);
              $discountDesc = $this->input->post('discountDesc', true);
              $discountPercentage = $this->input->post('discountPercentage', true);
              $discountValidFrom = $this->input->post('discountValidFrom', true);
              $discountValidTill = $this->input->post('discountValidTill', true);
              $discountValidFromTime = $this->input->post('discountValidFromTime', true);
              $discountValidTillTime = $this->input->post('discountValidTillTime', true);              
              
              if( (trim($discountName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("discounts/add");
              }
              
              if( (trim($discountSlug) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Slug cannot be empty.</strong></div>");
                redirect("discounts/add");
              }
              
              $check = $this->mdl_discounts->get_where_custom('slug', $discountSlug);
              if($check->num_rows() > 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Slug already exists. Enter a unique slug.</strong></div>");
                redirect("discounts/add");
              }
              
              if( (trim($discountPercentage) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Discount Percentage cannot be empty.</strong></div>");
                redirect("discounts/add");
              }
              
              if( (trim($discountValidFrom) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Valid From Date cannot be empty.</strong></div>");
                redirect("discounts/add");
              }
              
              if( (trim($discountValidTill) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Valid Till Date cannot be empty.</strong></div>");
                redirect("discounts/add");
              }
              
              $new_data = array(
                'name' => $discountName,
                'slug' => $discountSlug,
                'desc' => $discountDesc,
                'discount_percentage' => $discountPercentage,
                'valid_from' => date('Y-m-d H:i:s', strtotime($discountValidFrom.' '.$discountValidFromTime.':00')),
                'valid_till' => date('Y-m-d H:i:s', strtotime($discountValidTill.' '.$discountValidTillTime.':00'))
              );

              $this->mdl_discounts->_insert($new_data);
              $id = $this->db->insert_id();
              
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully added!</strong></div>");
              
              redirect("discounts/edit/{$id}");
            
            }

        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function DPimageSave($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];

            if ($id) {
                
                $check = $this->mdl_discounts->get_where($id);
                if($check->num_rows() == 0) :
                    redirect('404', 'refresh');
                endif;
                
                if ($_FILES['discountDPChange']['name']) {
                    $config['upload_path'] = '../assets/uploads/discounts';
                    $config['allowed_types'] = 'png|jpg|jpeg';
                    $this->load->library('upload', $config);
                    if (!$this->upload->do_upload('discountDPChange')) {
                        $data['uploadErrors'] = $this->upload->display_errors();
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! {$data['uploadErrors']}</strong></div>");
                        redirect("discounts/edit/{$id}?tab=displaypic");
                    }
                    else {
                        $res = $this->upload->data();
                        $DPname = 'discounts/'.$res['file_name'];
                        $data = array(
                            'dp_image' => $DPname
                        );
                        $current_image = $this->mdl_discounts->get_where($id);
                        if (!($current_image->row()->dp_image == '')):
                            unlink('../assets/uploads/' . $current_image->row()->dp_image);
                        endif;
                        $this->mdl_discounts->_update($id, $data);
                        redirect("discounts/edit/{$id}?tab=displaypic");
                    }
                }
                else {
                    echo "<h1>Error!</h1>";
                    echo "<a href='{$this->config->base_url() }discounts/edit/{$id}'>Please try again</a>";
                }

            }
            else {
                redirect('404', 'refresh');
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }

}
