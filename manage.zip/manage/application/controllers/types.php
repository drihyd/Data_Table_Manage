<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Types extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('mdl_types', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'types';
      $types = array();
      $query = $this->mdl_types->get('id');
      if($query) :
        foreach($query->result() as $type) {
          
          $cat_name = $this->db->query("select * from categories where id = '{$type->cat_id}'");
          $cat_name = $cat_name->row()->name;
          
          $types[$type->id] = array(
            'id' => $type->id,
            'name' => $type->name,
            'cat_id' => $type->cat_id,
            'cat_name' => $cat_name
          );
        }
      endif;
      $data['types'] = $types;
      $this->load->view('header', $data);
      $this->load->view('types_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function edit($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'types';
      
      $type_details = array();
      $query = $this->mdl_types->get_where($id);
      
      foreach($query->result() as $type) {
        
        $type_details = array (
          'id' => $type->id,
          'name' => $type->name,
          'cat_id' => $type->cat_id
        );
      }
      $data['type_details'] = $type_details;
      
      $query = $this->db->query("select * from categories where id = '{$type_details['cat_id']}'");
      $category = array();
      $category = array(
        'id' => $query->row()->id,
        'name' => $query->row()->name,
        'parent_id' => $query->row()->parent_id
      );
      $data['category'] = $category;
      
      $data['tinyMC'] = FALSE;
      
      $this->load->view('header', $data);
      $this->load->view('type_edit', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function save($id=FALSE) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'types';
      
      $typeName = $this->input->post('typeName');
      $typeParentCat = $this->input->post('typeParentCat');
      echo $typeParentCat;
      if($id) {
        $data = array(
          'name' => $typeName,
          'cat_id' => $typeParentCat
        );
        
        $this->mdl_types->_update($id, $data);
        $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
        //echo $data['success'];
        redirect("categories/edit/{$typeParentCat}");
        
      }
      else {
        $data = array(
          'name' => $typeName,
          'cat_id' => $typeParentCat
        );
        
        $this->mdl_types->_insert($data);
        $data['success'] = "<div class='alert alert-success'>Record Added Successfully!</div>";
        redirect("categories/edit/{$typeParentCat}");
        
      }
      
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function add($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'types';
      
      $query = $this->db->query("select * from categories where id = '{$id}'");
      $category = array();
      $category = array(
        'id' => $query->row()->id,
        'name' => $query->row()->name,
        'parent_id' => $query->row()->parent_id
      );
      
      $data['category'] = $category;
      
      $data['tinyMC'] = FALSE;
      
      $this->load->view('header', $data);
      $this->load->view('type_add', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }

  function delete($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $type_details = array();
      $query = $this->mdl_types->get_where($id);
      
      foreach($query->result() as $type) {
        
        $type_details = array (
          'id' => $type->id,
          'name' => $type->name,
          'cat_id' => $type->cat_id
        );
      }
      
      $this->mdl_types->_delete($id);
      
      redirect("categories/edit/{$type_details['cat_id']}");
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  
    
  function get($order_by) {
  $this->load->model('mdl_types');
  $query = $this->mdl_types->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_types');
  $query = $this->mdl_types->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_types');
  $query = $this->mdl_types->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_types');
  $query = $this->mdl_types->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_types');
  $this->mdl_types->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_types');
  $this->mdl_types->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_types');
  $this->mdl_types->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_types');
  $count = $this->mdl_types->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_types');
  $max_id = $this->mdl_types->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_types');
  $query = $this->mdl_types->_custom_query($mysql_query);
  return $query;
  }

}
