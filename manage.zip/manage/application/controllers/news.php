<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class News extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('mdl_news', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'news';
      $news = array();
      $query = $this->mdl_news->get('id');
      if($query->num_rows() > 0) :
        foreach($query->result() as $news_item) {
          
          $news[$news_item->id] = array(
            'id' => $news_item->id,
            'title' => $news_item->title,
            'slug' => $news_item->slug,
            'content' => $news_item->content,
            'date' => $news_item->date,
            'seo_title' => $news_item->seo_title,
            'seo_desc' => $news_item->seo_desc,
            'seo_keywords' => $news_item->seo_keywords
          );
        }
      endif;
      $data['news'] = $news;
      $this->load->view('header', $data);
      
      $this->load->view('news_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function edit($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'news';
      
      $news_details = array();
      $query = $this->mdl_news->get_where($id);
      $news_item = $query->row();
      foreach($news_item as $key => $value) {
        $news_details[$key] = $value;
      }
      $data['news_details'] = $news_details;
      
      $data['tinyMC'] = TRUE;
      
      $this->load->view('header', $data);
      $this->load->view('news_edit', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function save($id=FALSE) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'news';
      
      $newsTitle = $this->input->post('newsTitle');
      $newsSlug = $this->input->post('newsSlug');
      $newsContent = $this->input->post('newsContent');
      $newsDate = $this->input->post('newsDate');      
      if($id) {
        $data = array(
          'title' => $newsTitle,
          'slug' => $newsSlug,
          'content' => $newsContent,
          'date' => $newsDate
        );
        
        $query = $this->db->query("select * from news where id not in('{$id}') and slug = '{$newsSlug}'");
        if($query->num_rows() > 0) {
          echo "Slug already exists. <a href='{$this->config->base_url()}news/edit/{$id}'>Enter a unique slug.</a>";
        }
        else {
          $this->mdl_news->_update($id, $data);
          $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
          //echo $data['success'];
          redirect("news/edit/{$id}");
        }
      }
      else {
        $data = array(
          'title' => $newsTitle,
          'slug' => $newsSlug,
          'content' => $newsContent,
          'date' => $newsDate
        );
        
        $query = $this->db->query("select * from news where slug = '{$newsSlug}'");
        if($query->num_rows() > 0) {
          echo "Slug already exists. <a href='{$this->config->base_url()}news/add'>Enter a unique slug.</a>";
        }
        else {        
          $this->mdl_news->_insert($data);
          $id = mysql_insert_id();
          $data['success'] = "<div class='alert alert-success'>Record Added Successfully!</div>";
          //echo $data['success'];
          redirect("news/edit/{$id}");
        }
      }
      
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function seosave($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'news';
      
      $seoTitle = $this->input->post('newsSeoTitle');
      $seoDesc = $this->input->post('newsSeoDesc');
      $seoKeys = $this->input->post('newsSeoKeys');
      
      $data = array(
        'seo_title' => $seoTitle,
        'seo_desc' => $seoDesc,
        'seo_keywords' => $seoKeys
      );
      print_r($data);
      $this->mdl_news->_update($id, $data);
      $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
      redirect('news');
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function add() {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'news';
      
      $data['tinyMC'] = TRUE;
      //$data['products'] = $products;
      $this->load->view('header', $data);
      $this->load->view('news_add', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function delete($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $this->mdl_news->_delete($id);
      
      
      redirect('news');
    }
    else {
      redirect('login', 'refresh');
    }
  }
    
  function get($order_by) {
  $this->load->model('mdl_news');
  $query = $this->mdl_news->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_news');
  $query = $this->mdl_news->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_news');
  $query = $this->mdl_news->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_news');
  $query = $this->mdl_news->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_news');
  $this->mdl_news->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_news');
  $this->mdl_news->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_news');
  $this->mdl_news->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_news');
  $count = $this->mdl_news->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_news');
  $max_id = $this->mdl_news->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_news');
  $query = $this->mdl_news->_custom_query($mysql_query);
  return $query;
  }

}
