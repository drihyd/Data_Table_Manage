<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Weekly_report extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'email_helper',
            'page_initiater_helper',
        );
        $models = array(
            'model_carts' => 'carts',
            'model_categories' => 'categories',
            'model_customers' => 'customers',
            'model_orders' => 'orders',
            'model_order_items' => 'order_items',
            'model_products' => 'products',
            'model_skus' => 'skus',
            'model_users' => 'users',
            'model_reorder_thresholds' => 'reorder_thresholds',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function index($justsee=null) {
		
		$data['justsee'] = $justsee;
		
		//$from_date = date('Y-m-d', strtotime("last Sunday", strtotime("Monday previous week")));
		//$to_date = date('Y-m-d', strtotime("Saturday previous week"));
		
		$from_date = date('Y-m-d', strtotime("last Sunday"));
		$to_date = date('Y-m-d', strtotime("last Saturday"));
		
		//$from_date = date('Y-m-d', strtotime('2016-01-01'));
		//$to_date = date('Y-m-d', strtotime('2016-01-07'));
		
		$data['from_date'] = $from_date;
		$data['to_date'] = $to_date;
		
		#---------------------------------------------------------------
		# Get Month
		$current_month = date('m', strtotime($from_date));
		$current_year  = date('Y', strtotime($from_date));
		
		$orders_this_month = 0;
		$check = $this->orders->get_month($current_month, $current_year);
		if($check->num_rows() > 0) {
			$orders_this_month = $check->num_rows();
		}
		$data['orders_this_month'] = $orders_this_month;
		
		#---------------------------------------------------------------
		# Get all orders this week
		$all_orders = array();
		$filters = array(
			"DATE(ordered_on) >=" => $from_date,
			"DATE(ordered_on) <=" => $to_date,
			'order_status !=' => 'cancelled',
			'grand_total >' => 0,
			'total_items >' => 0,
		);
		$check = $this->orders->get_where_array($filters);
		if($check->num_rows() > 0) {
			$all_orders = $check->result();
		}
		$total_orders = $check->num_rows();
		$order_ids = array();
		$total_order_value = 0;
		$total_domestic_orders = 0;
		$total_foreign_orders = 0;
		$order_country_index = array();
		$order_city_index = array();
		$customer_ids_who_ordered = array();
		$total_repeat_orders = 0;
		$total_first_time_orders = 0;
		
		foreach($all_orders as $order) {
			array_push($order_ids, $order->id);
			if($order->currency == 'inr') {
				$total_order_value += $order->grand_total;
			} else {
				$total_order_value += ($order->grand_total * 65);
			}
			$total_domestic_orders += 1; // add 1 by default. Reduce 1 if foregin check passes
			
			// foreign check
			$ship_country = trim(strtolower($order->ship_to_country));
			$ship_city = trim(strtolower($order->ship_to_city));
			$bill_country = trim(strtolower($order->bill_to_country));
			
			if( ($ship_country != 'india') OR ($bill_country != 'india') ) {
				$total_foreign_orders += 1;
				$total_domestic_orders -= 1; // reduce 1. It was increased by default before.
			}
			
			if( ! isset($order_country_index[$ship_country])) {
				$order_country_index[$ship_country] = array(
					'number' => 0,
					'value' => 0,
				);
			}
			$a = $order_country_index[$ship_country];
			$a['number'] += 1;
			if($order->currency == 'inr') {
				$a['value'] += $order->grand_total;
			} else {
				$a['value'] += ($order->grand_total * 65);
			}
			$order_country_index[$ship_country] = $a;
			
			# --
			
			if( ! isset($order_city_index[$ship_city])) {
				$order_city_index[$ship_city] = array(
					'value' => 0,
					'number' => 0,
					'country' => $ship_country,
				);
			}
			$a = $order_city_index[$ship_city];
			$a['number'] += 1;
			if($order->currency == 'inr') {
				$a['value'] += $order->grand_total;
			} else {
				$a['value'] += ($order->grand_total * 65);
			}
			
			$order_city_index[$ship_city] = $a;
			
			
			array_push($customer_ids_who_ordered, $order->customer_id);
			
			$total_first_time_orders += 1; // add 1 by default;
			$filters = array(
				'DATE(ordered_on) <' => $from_date,
				'customer_id' => $order->customer_id,
			);
			$check = $this->orders->get_where_array($filters);
			if($check->num_rows() > 0) {
				$total_repeat_orders += 1;
				$total_first_time_orders -= 1; // reduce 1. added 1 by default before.
			}
			
		}
		
		#---------------------------------------------------------------
		# Get all new customers this week
		$all_customers = array();
		$filters = array(
			"DATE(date) >=" => $from_date,
			"DATE(date) <=" => $to_date,
		);
		$check = $this->customers->get_where_array($filters);
		if($check->num_rows() > 0) {
			$all_customers = $check->result();
		}
		
		$total_new_customers = $check->num_rows();
		
		$new_customer_ids = array();
		$total_guest_customers = 0;
		$total_new_customer_orders = 0;
		$total_guest_customer_orders = 0;
		
		foreach($all_customers as $customer) {
			array_push($new_customer_ids, $customer->id);
			if($customer->is_guest == 1) {
				$total_guest_customers += 1;
			}
			if( in_array($customer->id, $customer_ids_who_ordered)) {
				$total_new_customer_orders += 1;
				if($customer->is_guest == 1) {
					$total_guest_customer_orders += 1;
				}
			}
		}
		
		#---------------------------------------------------------------
		# Get all order items
		$order_items = array();
		if(count($order_ids) > 0) {
			$check = $this->order_items->get_where_in('order_id', $order_ids);
			if($check->num_rows() > 0) {
				$order_items = $check->result();
			}
		}
		$item_category_index = array();
		
		foreach($order_items as $item) {
			if( ! isset($item_category_index[$item->cat_id])) {
				$item_category_index[$item->cat_id] = array(
					'value' => 0,
					'number' => 0,
				);
			}
			$a = $item_category_index[$item->cat_id];
			$a['number'] += 1;
			$a['value'] += $item->net_price;
			$item_category_index[$item->cat_id] = $a;
			
		}
		
		#---------------------------------------------------------------
		# Abandoned Carts
		$abandoned_carts = 0;
		$filters = array(
			'DATE(date) >=' 	=> $from_date,
			'DATE(date) <=' 	=> $to_date,
			'checked_out' 		=> 0,
			'total_items >' 	=> 0,
			'total_amount >' 	=> 0,
			 
		);
		$check = $this->carts->get_where_array($filters);
		if($check->num_rows() > 0) {
			$abandoned_carts = $check->num_rows();
		}
		
		$data['abandoned_carts'] = $abandoned_carts;
		
		#---------------------------------------------------------------
		# Get category wise details
		$categories = array();
		$ignored_categories = array('1', '12');
		$check = $this->categories->get_where_not_in('id', $ignored_categories);
		if($check->num_rows() > 0) {
			$categories = $check->result();
		}
		
		$category_index = array();
		$reorder_index = array();
		foreach($categories as $category) {
			$category_index[$category->id] = array(
				'details' => $category,
			);
			$a = $category_index[$category->id];
			$sizes = array('s', 'm', 'l', 'xl', 'xxl', 'xxxl', 'unstitched');
			foreach($sizes as $size) {
				$stock = $this->get_category_size_stock($category->id, $size);
				$a[$size] = $stock;
			}
			$category_index[$category->id] = $a;
			$reorder_index[$category->id] = $this->reorder_thresholds->get_where('cat_id', $category->id)->result();
		}
				
		$data['total_orders'] = $total_orders;
		$data['total_order_value'] = $total_order_value;
		$data['total_domestic_orders'] = $total_domestic_orders;
		$data['total_foreign_orders'] = $total_foreign_orders;
		$data['order_country_index'] = $order_country_index;
		$data['order_city_index'] = $order_city_index;
		$data['total_first_time_orders'] = $total_first_time_orders;
		$data['total_repeat_orders'] = $total_repeat_orders;
		
		$data['total_new_customers'] = $total_new_customers;
		$data['total_guest_customers'] = $total_guest_customers;
		$data['total_new_customer_orders'] = $total_new_customer_orders;
		$data['total_guest_customer_orders'] = $total_guest_customer_orders;
		
		$data['item_category_index'] = $item_category_index;
		
		$data['category_index'] = $category_index;
		$data['reorder_index'] = $reorder_index;
		
		$this->load->view('weekly_report', $data);
		
	}
	
	// get category size stock
	function get_category_size_stock($cat_id, $size) {
		$filters = array(
			'stock >' => 0,
			'size' => $size,
			'cat_id' => $cat_id,
		);
		$check = $this->skus->get_where_array($filters);
		$skus = array();
		$stock = 0;
		if($check->num_rows() > 0) {
			$skus = $check->result();
		}
		foreach($skus as $sku) {
			$stock += $sku->stock;
		}	
		return $stock;
	}
	
}
