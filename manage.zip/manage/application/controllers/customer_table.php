<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Customer_table extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'form',
			'email_helper',
            'page_initiater_helper',
        );
        $models = array(
            'model_carts' => 'carts',
            'model_categories' => 'categories',
            'model_customers' => 'customers',
            'model_orders' => 'orders',
            'model_order_items' => 'order_items',
            'model_products' => 'products',
            'model_skus' => 'skus',
            'model_users' => 'users',
            'model_reorder_thresholds' => 'reorder_thresholds',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
	
	function index() {
		
		$data = initiate_page();
        $data['page_name'] = 'Analytics';
        $data['page_title'] = 'Analytics';
        
        $data['sidebar_element'] = 'side-analytics';
        
        $data['seo_title'] = 'Analytics';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
		
		$customers = array();
		$check = $this->customers->get_all();
		if($check->num_rows() > 0) {
			$customers = $check->result();
		}
		$data['customers'] = $customers;
		
		//$this->load->view('header', $data);
		$this->load->view('customer_table_view', $data);
		//$this->load->view('footer', $data);
	}
	
}
