<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Payments extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_payments', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        redirect('orders', 'refresh');
    }
    
    function payment_info($id) //
    {
        redirect('orders', 'refresh');
    }

    function edit($id) //
    {
        redirect('orders', 'refresh');
    }

    function add()
    {
        redirect('orders', 'refresh');
    }
    
    function add_child($id)
    {
        redirect('orders', 'refresh');
    }

    function delete($id)
    {
        redirect('orders', 'refresh');
    }

    function save($id = FALSE) //
    {
        redirect('orders', 'refresh');
    }
    
    function status_update($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'orders';
            $data['page_title'] = 'Update Orders';
            
            $data['sidebar_element'] = 'side-orders';
            $data['sidebar_subelement'] = 'side-orders-view';
            
            $order_check = $this->mdl_payments->get_where($id);
            if($order_check->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $order_details = $order_check->row();
            }
            
            $orderStatus = $this->input->post('orderStatus', true);
            if (!$orderStatus):
                redirect("orders/order_info/{$id}");
            endif;
            
            $order_status_possibilities = array('placed', 'processing', 'dispatched', 'on-hold', 'cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'delivered');
            
            if(!in_array(strtolower($orderStatus), $order_status_possibilities)) :
                redirect('404', 'refresh');
            endif;
            
            $new_data = array (
                'order_status' => $orderStatus
            );
            
            $this->mdl_payments->_update($order_details->id, $new_data);
            redirect("orders/order_info/{$order_details->id}", 'refresh');
            
        }
        else {
            redirect('login', 'refresh');
        }
    }

    

}
