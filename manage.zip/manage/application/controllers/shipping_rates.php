<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Shipping_rates extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_shipping_rates', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Shipping Rates';
            $data['page_title'] = 'All Shipping Rates';
            
            $data['sidebar_element'] = 'side-master-data';
            $data['sidebar_subelement'] = 'side-shipping-rates-view';
            
            $check = $this->mdl_shipping_rates->get('id');
            if($check->num_rows() > 0) {
              $shipping_rates = $check->result();
            }
            else {
              $shipping_rates = array();
            }
            
            $data['shipping_rates'] = $shipping_rates;
            
            $this->load->view('header', $data);
            $this->load->view('shipping_rates_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Add Shipping Rate';
            $data['page_title'] = 'Add Shipping Rate';
            
            $data['sidebar_element'] = 'side-shipping-rates';
            $data['sidebar_subelement'] = 'side-add-shipping-rate';
            
            $this->load->view('header', $data);
            $this->load->view('shipping_rate_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function delete($id) {
      if ($this->session->userdata('logged_in')) {
          $session_data = $this->session->userdata('logged_in');
          $data['username'] = $session_data['username'];
          $data['user_type'] = $session_data['type'];
          $data['user_email'] = $session_data['email'];
          
          $check = $this->mdl_shipping_rates->get_where($id);
          if($check->num_rows() > 0) {
            $shipping_rate_details = $check->row();
          }
          else {
            $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid ID.</strong></div>");
            redirect("shipping_rates");
          }
          
          $this->load->model('mdl_countries');
          $this->load->model('mdl_states');
          $this->load->model('mdl_cities');
          
          //check if any countries, states or cities are referencing this rate
          $check = $this->mdl_countries->get_where_custom('shipping_rate_id', $shipping_rate_details->id);
          if($check->num_rows() > 0) {
            $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Sorry! Cannot delete this shipping rate. It is being referenced in {$check->num_rows()} countries. First change those countries to a default shipping rate.</strong></div>");
            redirect("shipping_rates");
          }
          
          $check = $this->mdl_states->get_where_custom('shipping_rate_id', $shipping_rate_details->id);
          if($check->num_rows() > 0) {
            $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Sorry! Cannot delete this shipping rate. It is being referenced in {$check->num_rows()} states. First change those states to a default shipping rate.</strong></div>");
            redirect("shipping_rates");
          }
          
          $check = $this->mdl_cities->get_where_custom('shipping_rate_id', $shipping_rate_details->id);
          if($check->num_rows() > 0) {
            $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Sorry! Cannot delete this shipping rate. It is being referenced in {$check->num_rows()} cities. First change those cities to a default shipping rate.</strong></div>");
            redirect("shipping_rates");
          }
          
          $this->mdl_shipping_rates->_delete($id);
          $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Deleted successfully.</strong></div>");
          redirect("shipping_rates");
      }
      else {
          redirect('login', 'refresh');
      }
    }
    
    
    function edit($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = 'Edit Shipping Rate';
            
            $data['sidebar_element'] = 'side-shipping-rates';
            $data['sidebar_subelement'] = 'side-shipping-rates-view';
            
            $check = $this->mdl_shipping_rates->get_where($id);
            if($check->num_rows() > 0) {
              $shipping_rate_details = $check->row();
            }
            else {
              $shipping_rate_details->array();
            }
            
            $data['shipping_rate_details'] = $shipping_rate_details;
            
            $this->load->view('header', $data);
            $this->load->view('shipping_rate_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function save($id=null) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = '';
            
            $data['sidebar_element'] = 'side-shipping-rates';
            $data['sidebar_subelement'] = 'side-shipping-rates-view';
            
            if($id) {
              $check = $this->mdl_shipping_rates->get_where($id);
              if($check->num_rows() > 0) {
                $shipping_rate_details = $check->row();
              }
              else {
                redirect('404', 'refresh');
              }
              
              $rateName = $this->input->post('rateName', true);
              $rateRate = $this->input->post('rateRate', true);
              
              if( (trim($rateName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("shipping_rates/edit/{$id}");
              }
              
              if( ( trim( floatval($rateRate) ) == '' ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Rate cannot be empty.</strong></div>");
                redirect("shipping_rates/edit/{$id}");
              }
              
              $new_data = array(
                'name' => $rateName,
                'inr_rate' => $rateRate
              );
              
              $this->mdl_shipping_rates->_update($id, $new_data);
              
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully updated!</strong></div>");
              redirect("shipping_rates/edit/{$id}");
            
            }
            else {
              
              $rateName = $this->input->post('rateName', true);
              $rateRate = $this->input->post('rateRate', true);
              
              if( (trim($rateName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("shipping_rates/add");
              }
              
              if( ( trim( floatval($rateRate) ) == '' ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Rate cannot be empty.</strong></div>");
                redirect("shipping_rates/add");
              }
              
              $new_data = array(
                'name' => $rateName,
                'inr_rate' => $rateRate
              );
              
              $this->mdl_shipping_rates->_insert($new_data);
              $id = $this->db->insert_id();
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully added!</strong></div>");
              redirect("shipping_rates/edit/{$id}");
            
            }

        }
        else {
            redirect('login', 'refresh');
        }
    }

}
