<?php
defined('BASEPATH') OR exit();

class Stock_reports extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$this->load->helper(array(
			'form',
			'email_improved_helper',
			'page_initiater_helper'
		));
	}
	
	function index($email=NULL) {
		
		redirect('stock_logs', 'refresh');
		
		$data                    		= initiate_page();
		$data['page_name']       		= 'Stock Report';
		$data['page_title']      		= 'Stock Report';
		$data['sidebar_element'] 		= 'side-monitor';
		$data['sidebar_subelement'] 	= 'side-stock-reports';
		$data['seo_title']       		= 'Stock Reports';
		$data['seo_description'] 		= '';
		$data['seo_keywords']    		= '';
		
		if($email) {
			$email = 1;
		}
		
		$data['email_report'] = $email;
		
		$stock_index = array();
		$in_stock_product_ids = array();
		$skus = array();
		
		$this->db->where('stock >', 0);
		$this->db->group_by('product_id');
		$check = $this->db->get('skus');
		if($check->num_rows() > 0) {
			$skus = $check->result();
		}
		
		foreach($skus as $sku) {
			if( ! isset($stock_index[$sku->product_id])) {
				$stock_index[$sku->product_id] = 0;
			}
			$stock_index[$sku->product_id] += $sku->stock;
			array_push($in_stock_product_ids, $sku->product_id);
		}
		
		$in_stock_product_ids = array_unique($in_stock_product_ids);
		
		$products = array();
		$this->db->where_in('id', $in_stock_product_ids);
		$check = $this->db->get('products');
		if($check->num_rows() > 0) {
			$products = $check->result();
		}
		
		$stock_log_index = array();
		$total_sold_index = array();
		$last_sale_index = array();
		
		foreach($in_stock_product_ids as $product_id) {
			
			$this->db->where('product_id', $product_id);
			$check = $this->db->get('stock_logs');
			if($check->num_rows() > 0) {
				$stock_log_index[$product_id] = $check->row();
			}
			
			$this->db->order_by('id', 'desc');
			$this->db->where('product_id', $product_id);
			$check = $this->db->get('order_items');
			if($check->num_rows() > 0) {
				
				$all_order_items = $check->result();
				$last_order_item = $check->row();
				$last_order_id = $last_order_item->order_id;
				$this->db->where('id', $last_order_id);
				$check = $this->db->get('orders');
				if($check->num_rows() > 0) {
					$order_details = $check->row();
					$last_sale_index[$product_id] = $order_details->ordered_on;
				}
				
				$total_pieces = 0;
				foreach($all_order_items as $order_item) {
					$total_pieces += $order_item->qty;
				}
				
				$total_sold_index[$product_id] = $total_pieces;
			} else {
				$total_sold_index[$product_id] = 0;
			}
			
		}
		
		$data['products'] = $products;
		$data['stock_index'] = $stock_index;
		$data['stock_log_index'] = $stock_log_index;
		$data['sale_index'] = $total_sold_index;
		$data['last_sale_index'] = $last_sale_index;
		
		$this->load->view('header', $data);
		$this->load->view('stock_report_view', $data);
		$this->load->view('footer', $data);
		
	}
	
}
