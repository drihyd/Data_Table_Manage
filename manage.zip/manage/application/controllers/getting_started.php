<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Getting_started extends CI_Controller {
  function __construct() {
    parent::__construct();
  }
  
  function index() {
    $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
    $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
    $this->output->set_header('Pragma: no-cache');
    $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'getting_started';
      $this->load->view('header', $data);
      $this->load->view('getting_started', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
}
