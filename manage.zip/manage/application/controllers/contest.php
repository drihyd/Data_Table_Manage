<?php
date_default_timezone_set("Asia/Kolkata");

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Contest extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_contests', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'ocntest';
            $data['page_title'] = 'All participants';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-contest';
            
            $this->db->order_by('id', 'desc');
            $participants = $this->db->get('contest_participants');
            
            if($participants->num_rows() > 0) {
              $participants = $participants->result();
            } else {
              $participants = array();
            }
            $data['participants'] = $participants;
            
            $new_regs = 0;
            $customer_index = array();
            foreach($participants as $participant) {
                $cust_id = $participant->cust_id;
                $customer_details = $this->db->get_where('customers', array('id' => $cust_id))->row();
                $customer_index[$customer_details->id] = $customer_details;
                if(strtotime($customer_details->date) >= strtotime('25 August 2015')) {
                    $new_regs += 1;
                }
            }
            
            $data['customer_index'] = $customer_index;
            $data['new_regs'] = $new_regs;
            
            $this->db->where('coupon_id !=', 0);
            $completed = $this->db->get_where('contest_participants');
            if($completed->num_rows() > 0) {
                $completed_participants = $completed->result();
                $completed = $completed->num_rows();
            } else {
                $completed_participants = array();
                $completed = 0;
            }
            
            $data['completed'] = $completed;
            
            $winnings = 0;
            $coupon_ids = array();
            foreach($completed_participants as $participant) {
                $winnings += $participant->score;
                array_push($coupon_ids, $participant->coupon_id);
            }
            
            $data['winnings'] = $winnings;
            
            $claimed = 0;
            $spent = 0;
            $claimed_coupons = array();
            foreach($coupon_ids as $coupon_id) {
                $coupon_details = $this->db->get_where('coupons', array('id' => $coupon_id))->row();
                $coupon_used = $this->db->get_where('coupon_usage_log', array('coupon_id' => $coupon_details->id));
                if($coupon_used->num_rows() > 0) {
                    $claimed += $coupon_details->value;
                    $coupon_used = $coupon_used->row();
                    $order_id = $coupon_used->order_id;
                    $order_details = $this->db->get_where('orders', array('id' => $order_id))->row();
                    $grand_total = $order_details->grand_total;
                    $spent += $grand_total;
                    $claimed_coupons[$coupon_details->id] = $order_details->id;
                }
            }
            
            $data['claimed'] = $claimed;
            $data['spent'] = $spent;
            $data['claimed_coupons'] = $claimed_coupons;
            
            $this->load->view('header', $data);
            $this->load->view('participants_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

}
