<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Stock_reminder extends CI_Controller {

	function __construct() {
		parent::__construct();
	}

	function index() {		
		$from      = "webmaster@taruni.in";
		$from_name = "Taruni Webmaster";
		
		//$to        = "sathyendra@deepredink.com";
		$to        = "ranjith@deepredink.com";
		$to_name   = "Ranjith";
		
		$subject   = "Reminder | Stock Updates for New Collections";
		
		ob_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Taruni | Stock Reminder</title>
</head>
<body>
	<p>Hi Team,</p>
	<p>Checkout the recently added stock here: <?php echo $this->config->base_url() . 'product_viewer?time_frame=10'; ?>.</p>
	<p>Thanks,<br>Webmaster</p>
</body>
</html>
<?php
		$message = ob_get_clean();
		$plain_text_message = "";
		$cc_emails = array(
			//'shreya@deepredink.com',
			//'hari@deepredink.com',
			//'rohit@deepredink.com',
			'ranjith@deepredink.com',
			// 'satish@deepredink.com',
			'rajkumar@deepredink.com',
		);
		$this->send_new_email($from, $from_name, $to, $to_name, $subject, $message, $plain_text_message, $cc_emails);
	}
	
	function send_new_email($from, $from_name, $to, $to_name, $subject, $message, $plain_text_message='', $cc_emails=null, $bcc_emails=null) {
		
		$to = array($to);
		
		if($cc_emails != NULL) {
			$to = array_merge($to, $cc_emails);
		} else {
			$cc_emails = array();
		}
		
		if($bcc_emails != NULL) {
			$to = array_merge($to, $bcc_emails);
		} else {
			$bcc_emails = array();
		}
		
		$mailstatus = $this->_send_api($from, $from_name, $to, $to_name, $subject, $message, $plain_text_message, $cc_emails, $bcc_emails);
		$mailstatus = json_decode($mailstatus, TRUE);
		
		if($mailstatus['success'] != 1) {
			
			$cc_string = '';
			if(count($cc_array > 0)) {
				$cc_string  = 'Cc: ';
				$cc_string .= implode(',', $cc_array);
			}
			$bcc_string = '';
			if(count($bcc_array > 0)) {
				$bcc_string  = 'Bcc: ';
				$bcc_string .= implode(',', $bcc_array);
			}
			$headers = array("MIME-Version: 1.0",	"Content-type: text/html", "From: {$from}", "Reply-To: {$from}");
			if($cc_string != '') {
				array_push($headers, $cc_string);
			}
			if($bcc_string != '') {
				array_push($headers, $bcc_string);
			}
			array_push($headers, "X-mailer: PHP/" . PHP_VERSION);
			$headers = implode("\r\n", $headers);
			mail($to , $subject , $message, $headers);
			return TRUE;
		}
	}

	function _send_api($from, $from_name, $to, $to_name, $subject, $message, $plain_text_message, $cc_emails=null, $bcc_emails=null, $isTransactional=TRUE) {
		
		$url = 'https://api.elasticemail.com/v2/email/send';
		
		try {
			
			$post = array(
				'from'            => $from,
				'fromName'        => $from_name,
				'apikey'          => '7349bdd3-b388-4821-bb02-eef05f24f98f',
				'subject'         => $subject,
				'to'              => implode(',', $to),
				'msgTo'           => $to[0],
				'msgCC'           => implode(',', $cc_emails),
				'msgBcc'          => implode(',', $bcc_emails),
				'bodyHtml'        => $message,
				'bodyText'        => $plain_text_message,
				'isTransactional' => $isTransactional,
			);
			
			$ch = curl_init();
			curl_setopt_array($ch, array(
				CURLOPT_URL            => $url,
				CURLOPT_POST           => true,
				CURLOPT_POSTFIELDS     => $post,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HEADER         => false,
				CURLOPT_SSL_VERIFYPEER => false,
			));
			
			$result = curl_exec($ch);
			curl_close($ch);
			return $result;
		}
		catch(Exception $ex){
			return $ex->getMessage();
		}
	}
	
}
