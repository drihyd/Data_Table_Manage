<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Homepage_sliders extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('mdl_homepage_sliders', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'types';
      $sliders = array();
      $query = $this->db->get('homepage_sliders');
      if($query->num_rows() > 0) {
        $homepage_sliders = $query->result();
      }
      else {
        $homepage_sliders = array();
      }
      $data['homepage_sliders'] = $homepage_sliders;
      $this->load->view('header', $data);
      $this->load->view('homepage_sliders_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function edit($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'types';
      
      $homepage_slider_details = array();
      $query = $this->db->get_where('homepage_sliders', array('id' => $id));
      
      foreach($query->result() as $homepage_slider) {
        
        $homepage_slider_details = array (
          'id' => $homepage_slider->id,
          'url' => $homepage_slider->url,
          'caption' => $homepage_slider->caption,
          'image' => $homepage_slider->image
        );
      }
      $data['homepage_slider_details'] = $homepage_slider_details;
      
      $data['tinyMC'] = FALSE;
      
      $this->load->view('header', $data);
      $this->load->view('homepage_slider_edit', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function save($id=FALSE) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'homepage_sliders';
      
      $homepage_sliderUrl = $this->input->post('homepage_sliderUrl');
      $homepage_sliderCaption = $this->input->post('homepage_sliderCaption');
      
      
      if($id) {
        if($_FILES['homepage_sliderImage']['name']) {
          
          $config['upload_path']='../assets/uploads/files/';
          $config['allowed_types']='gif|png|jpg|jpeg';
          $this->load->library('upload',$config);
          
          if(!$this->upload->do_upload('homepage_sliderImage')) {
            $data['uploadErrors'] = $this->upload->display_errors();
            echo $data['uploadErrors'].'<br>';
            echo "<a href='{$this->config->base_url()}homepage_sliders/edit/{$id}'>Please try again</a>"; 
          }
          else {
            $res = $this->upload->data();
            $DPname = $res['file_name'];
            $data = array(
              'url' => $homepage_sliderUrl,
              'caption' => $homepage_sliderCaption,
              'image' => $DPname
            );
            $current_image = $this->db->query("select * from homepage_sliders where id = {$id}");
            if(!($current_image->row()->image == '')) :
              unlink('../assets/uploads/files/'.$current_image->row()->image);
            endif;
            $this->mdl_homepage_sliders->_update($id, $data);
            $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
            //echo $data['success'];
            redirect("homepage_sliders/edit/{$id}");
          }
        }
        else {
          $data = array(
            'url' => $homepage_sliderUrl,
            'caption' => $homepage_sliderCaption
          );
      
          $this->mdl_homepage_sliders->_update($id, $data);
          $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
          redirect("homepage_sliders/edit/{$id}");
        }
      }
      else {
        
        if($_FILES['homepage_sliderImage']['name']) {
          
          $config['upload_path']='../assets/uploads/files/';
          $config['allowed_types']='gif|png|jpg|jpeg';
          $this->load->library('upload',$config);
          
          if(!$this->upload->do_upload('homepage_sliderImage')) {
            $data['uploadErrors'] = $this->upload->display_errors();
            echo $data['uploadErrors'].'<br>';
            echo "<a href='{$this->config->base_url()}homepage_sliders/add'>Please try again</a>"; 
          }
          else {
            $res = $this->upload->data();
            $DPname = $res['file_name'];
            $data = array(
              'url' => $homepage_sliderUrl,
              'caption' => $homepage_sliderCaption,
              'image' => $DPname
            );
            
            $this->mdl_homepage_sliders->_insert($data);
            $id = mysql_insert_id();
            $data['success'] = "<div class='alert alert-success'>Record Added Successfully!</div>";
            redirect("homepage_sliders/edit/{$id}");
          }
          
        }
        else {
          echo "<h1>Error!</h1>";
          echo "<a href='{$this->config->base_url()}homepage_sliders/add'>Please try again</a>"; 
        }
      }
      
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function add() {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'sliders';
           
      $data['tinyMC'] = FALSE;
      
      $this->load->view('header', $data);
      $this->load->view('homepage_slider_add', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }

  function delete($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $slider_details = array();
      $query = $this->mdl_homepage_sliders->get_where($id);
      
      $current_image = $this->db->query("select * from sliders where id = {$id}");
      if(!($current_image->row()->image == '')) :
        unlink('../assets/uploads/files/'.$current_image->row()->image);
      endif;
      
      $this->mdl_homepage_sliders->_delete($id);
      
      redirect("homepage_sliders");
    }
    else {
      redirect('login', 'refresh');
    }
  }  
    
  function get($order_by) {
  $this->load->model('mdl_homepage_sliders');
  $query = $this->mdl_homepage_sliders->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_homepage_sliders');
  $query = $this->mdl_homepage_sliders->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_homepage_sliders');
  $query = $this->mdl_homepage_sliders->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_homepage_sliders');
  $query = $this->mdl_homepage_sliders->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_homepage_sliders');
  $this->mdl_homepage_sliders->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_homepage_sliders');
  $this->mdl_homepage_sliders->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_homepage_sliders');
  $this->mdl_homepage_sliders->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_homepage_sliders');
  $count = $this->mdl_homepage_sliders->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_homepage_sliders');
  $max_id = $this->mdl_homepage_sliders->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_homepage_sliders');
  $query = $this->mdl_homepage_sliders->_custom_query($mysql_query);
  return $query;
  }

}
