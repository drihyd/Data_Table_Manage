<?php
defined('BASEPATH') or exit();

class monitor_stock extends CI_Controller
{
	
	function __construct() {
		parent::__construct();
		$this->load->helper('page_initiater_helper');
		$this->load->helper('db_utility_helper');
	}
	
	function index() {
		$data = initiate_page();
		
		$data['page_name'] = 'Monitor Stock';
		$data['page_title'] = 'Stock Details';
		$data['sidebar_element'] = 'side-monitor';
		$data['sidebar_subelement'] = 'side-monitor-stock';
		
		$ranges = array(
			50000 => array('title' => '>50K'),
			20000 => array('title' => '20K1 - 50K'),
			10000 => array('title' => '10001 - 20000'),
			9000  => array('title' => '9001 - 10000'),
			8000  => array('title' => '8001 - 9000'),
			7000  => array('title' => '7001 - 8000'),
			6000  => array('title' => '6001 - 7000'),
			5000  => array('title' => '5001 - 6000'),
			4000  => array('title' => '4001 - 5000'),
			3000  => array('title' => '3001 - 4000'),
			2000  => array('title' => '2001 - 3000'),
			1000  => array('title' => '1001 - 2000'),
			1     => array('title' => '1 - 1000'),
		);
		
		$data['ranges'] = array_reverse($ranges, TRUE); # ** #
		$stock_range = array();
		foreach($ranges as $range => $meta) {
			$stock_range[$range] = array('total' => 0, 'title' => '>' . $range);
		}
		
		$category_index = get_category_index();
		$data['category_index'] = $category_index; # ** #
		
		foreach($category_index as $id => $category) {
			$category_name = strtolower($category->name);
			foreach($ranges as $range => $meta) {
				$temp = $stock_range[$range];
				if( ! isset($temp[$category_name])) {
					$temp[$category_name] = 0;
				}
				$stock_range[$range] = $temp;
			}
		}
		
		$skus = get_in_stock_skus();
		foreach($skus as $sku) {
			$price = $sku->price_inr;
			if( ! isset($category_index[$sku->cat_id])) {
				CONTINUE;
			}
			$category = strtolower($category_index[$sku->cat_id]->name);
			foreach($ranges as $range => $meta) {
				if($price > $range) {
					$temp = $stock_range[$range];
					$temp[$category] += 1;
					$temp['total'] += 1;
					$stock_range[$range] = $temp;
					BREAK;
				}
			}
		}
		$data['stock_range'] = $stock_range;
		
		$this->load->view('header', $data);
		$this->load->view('monitor_stock_view', $data);
		$this->load->view('footer', $data);
	}
}
