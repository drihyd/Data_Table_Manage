<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');
class Cart_analytics extends CI_Controller {
	function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper'
		);
		$models  = array(
			'model_carts' => 'carts',
			'model_categories' => 'categories',
			'model_customers' => 'customers',
			'model_orders' => 'orders',
			'model_cart_items' => 'cart_items',
			'model_products' => 'products',
			'model_skus' => 'skus',
			'model_users' => 'users',
			'model_reorder_thresholds' => 'reorder_thresholds'
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
	function index() {
		$data                    = initiate_page();
		$data['page_name']       = 'Cart Analytics';
		$data['page_title']      = 'Cart Analytics';
		$data['sidebar_element'] = 'side-monitor';
		$data['sidebar_subelement'] = 'side-cart-analytics';
		$data['seo_title']       = 'Cart Analytics';
		$data['seo_description'] = '';
		$data['seo_keywords']    = '';
		$from                    = date('Y-m-d', strtotime('today - 7 days'));
		$to                      = date('Y-m-d', time());
		$from_date               = $from;
		$to_date                 = $to;
		if ($this->input->get('from')) {
			$from_date = $this->input->get('from');
		}
		if ($this->input->get('to')) {
			$to_date = $this->input->get('to');
		}
		if (strtotime($from_date) > strtotime($to_date)) {
			$get_from          = $from;
			$data['from_date'] = $from;
			$this->session->set_flashdata('form_errors', "FROM DATE cannot be later than TO DATE.");
			redirect('analytics', 'refresh');
		}
		$data['get_from_date']    = $from_date;
		$data['get_to_date']      = $to_date;
		$data['get_utm_source']   = '';
		$data['get_utm_medium']   = '';
		$data['get_utm_campaign'] = '';
		$data['get_utm_term']     = '';
		$data['get_utm_content']  = '';
		$filters                  = array(
			'DATE(date) >=' => $from_date,
			'DATE(date) <=' => $to_date,
			'total_items >' => 0,
			'total_amount >' => 0,
			'checked_out =' => 0
		);
		if ($this->input->get('utm_source') != '') {
			$filters['utm_source']  = $this->input->get('utm_source');
			$data['get_utm_source'] = $this->input->get('utm_source');
		}
		if ($this->input->get('utm_medium') != '') {
			$filters['utm_medium']  = $this->input->get('utm_medium');
			$data['get_utm_medium'] = $this->input->get('utm_medium');
		}
		if ($this->input->get('utm_campaign') != '') {
			$filters['utm_campaign']  = $this->input->get('utm_campaign');
			$data['get_utm_campaign'] = $this->input->get('utm_campaign');
		}
		if ($this->input->get('utm_term') != '') {
			$filters['utm_term']  = $this->input->get('utm_term');
			$data['get_utm_term'] = $this->input->get('utm_term');
		}
		if ($this->input->get('utm_content') != '') {
			$filters['utm_content']  = $this->input->get('utm_content');
			$data['get_utm_content'] = $this->input->get('utm_content');
		}
		$all_utm_sources   = array();
		$all_utm_mediums   = array();
		$all_utm_campaigns = array();
		$all_utm_terms     = array();
		$all_utm_contents  = array();
		$carts             = array();
		$check             = $this->carts->get_all();
		if ($check->num_rows() > 0) {
			$carts = $check->result();
		}
		foreach ($carts as $cart) {
			if ((trim($cart->utm_source) != '') AND (!in_array(trim($cart->utm_source), $all_utm_sources))) {
				array_push($all_utm_sources, $cart->utm_source);
			}
			if ((trim($cart->utm_medium) != '') AND (!in_array(trim($cart->utm_medium), $all_utm_mediums))) {
				array_push($all_utm_mediums, $cart->utm_medium);
			}
			if ((trim($cart->utm_campaign) != '') AND (!in_array(trim($cart->utm_campaign), $all_utm_campaigns))) {
				array_push($all_utm_campaigns, $cart->utm_campaign);
			}
			if ((trim($cart->utm_term) != '') AND (!in_array(trim($cart->utm_term), $all_utm_terms))) {
				array_push($all_utm_terms, $cart->utm_term);
			}
			if ((trim($cart->utm_content) != '') AND (!in_array(trim($cart->utm_content), $all_utm_contents))) {
				array_push($all_utm_contents, $cart->utm_content);
			}
		}
		$data['all_utm_sources']   = $all_utm_sources;
		$data['all_utm_mediums']   = $all_utm_mediums;
		$data['all_utm_campaigns'] = $all_utm_campaigns;
		$data['all_utm_terms']     = $all_utm_terms;
		$data['all_utm_content']   = $all_utm_contents;
		$all_carts                 = array();
		$check                     = $this->carts->get_where_array($filters);
		if ($check->num_rows() > 0) {
			$all_carts = $check->result();
		}
		$data['carts']                  = $all_carts;
		$cart_ids                       = array();
		$sorted                         = array();
		$guest_customer_ids             = array();
		$activity                       = array();
		$total_carts                    = 0;
		$total_carts_revenue            = 0;
		$total_unreg_carts              = 0;
		$total_unreg_revenue            = 0;
		$total_reg_carts                = 0;
		$total_reg_revenue              = 0;
		$total_guest_carts              = 0;
		$total_guest_revenue            = 0;
		$total_domestic_carts           = 0;
		$total_domestic_revenue         = 0;
		$total_foreign_carts            = 0;
		$total_foreign_revenue          = 0;
		$total_repeat_carts             = 0;
		$total_repeat_revenue           = 0;
		$total_actionable_carts         = 0;
		$total_actionable_carts_revenue = 0;
		//$top_categories 				= array();
		//$top_products 				= array();
		//$top_sizes 					= array();
		$top_cities                     = array();
		$top_states                     = array();
		$top_countries                  = array();
		$utm_sources_index              = array();
		$utm_mediums_index              = array();
		$utm_campaigns_index            = array();
		$utm_terms_index                = array();
		$utm_contents_index             = array();
		
		$actionable_index 				= array(); 
		
		foreach ($all_carts as $cart) {
			$total_carts += 1;
			$total_carts_revenue += $cart->grand_total;
			
			$top_cities    = $this->add_to_index('ship_to_city', $cart, $top_cities);
			$top_states    = $this->add_to_index('ship_to_state', $cart, $top_states);
			$top_countries = $this->add_to_index('ship_to_country', $cart, $top_countries);

			
			$from_d    = strtotime($from_date);
			$to_d      = strtotime($to_date);
			$cart_time = strtotime($cart->date);
			while ($from_d < $cart_time) { # when no carts on this day
				$date  = date('Y-m-d', $from_d);
				$date  = explode('-', $date);
				$month = $date[1] - 1; # decrement by 1 so 0 -> jan, 11 -> dec
				$date  = $date[0] . '-' . $month . '-' . $date[2];
				if (!isset($sorted[$date])) {
					$sorted[$date]                   = array();
					$sorted[$date]['cart_num']       = 0;
					$sorted[$date]['revenue']        = 0;
					
					$sorted[$date]['unreg_num']      = 0;
					$sorted[$date]['unreg_rev']      = 0;
					
					$sorted[$date]['reg_num']        = 0;
					$sorted[$date]['reg_rev']        = 0;
					
					$sorted[$date]['domestic_num']   = 0;
					$sorted[$date]['domestic_rev']   = 0;
					
					$sorted[$date]['foreign_num']    = 0;
					$sorted[$date]['foreign_rev']    = 0;
					
					$sorted[$date]['repeat_num']     = 0;
					$sorted[$date]['repeat_rev']     = 0;
					
					$sorted[$date]['actionable_num'] = 0;
					$sorted[$date]['actionable_rev'] = 0;
					
					$sorted[$date]['s'] 							= 0;
					$sorted[$date]['m'] 							= 0;
					$sorted[$date]['l'] 							= 0;
					$sorted[$date]['xl'] 							= 0;
					$sorted[$date]['xxl'] 							= 0;
					$sorted[$date]['xxxl'] 							= 0;
					$sorted[$date]['unstitched'] 					= 0;
					
				}
				$from_d = strtotime('+1 day', $from_d);
			}
			$date  = date('Y-m-d', strtotime($cart->date));
			$date  = explode('-', $date);
			$month = $date[1] - 1; # decrement by 1 so 0 -> jan, 11 -> dec
			$date  = $date[0] . '-' . $month . '-' . $date[2];
			if (!isset($sorted[$date])) { # cart is there on this day
				$sorted[$date]                   = array();
				$sorted[$date]['cart_num']       = 0;
				$sorted[$date]['revenue']        = 0;
				
				$sorted[$date]['unreg_num']      = 0;
				$sorted[$date]['unreg_rev']      = 0;
				
				$sorted[$date]['reg_num']        = 0;
				$sorted[$date]['reg_rev']        = 0;
				
				$sorted[$date]['domestic_num']   = 0;
				$sorted[$date]['domestic_rev']   = 0;
				
				$sorted[$date]['foreign_num']    = 0;
				$sorted[$date]['foreign_rev']    = 0;
				
				$sorted[$date]['repeat_num']     = 0;
				$sorted[$date]['repeat_rev']     = 0;
				
				$sorted[$date]['actionable_num'] = 0;
				$sorted[$date]['actionable_rev'] = 0;
				
				$sorted[$date]['s'] 							= 0;
				$sorted[$date]['m'] 							= 0;
				$sorted[$date]['l'] 							= 0;
				$sorted[$date]['xl'] 							= 0;
				$sorted[$date]['xxl'] 							= 0;
				$sorted[$date]['xxxl'] 							= 0;
				$sorted[$date]['unstitched'] 					= 0;
				
			}
			
			$sorted[$date]['cart_num'] += 1;
			$sorted[$date]['revenue'] += $cart->total_amount;
			
			$cart_items = array();
			$check = $this->db->get_where('cart_items', array('cart_id' => $cart->id));
			if($check->num_rows() > 0) {
				$cart_items = $check->result();
			}
			
			foreach($cart_items as $item) {
				$sku_id = $item->sku_id;
				$sku_details = $this->db->get_where('skus', array('id' => $sku_id));
				if($sku_details->num_rows() == 0) {
					CONTINUE;
				}
				$sku_details = $sku_details->row();
				$sorted[$date][strtolower($sku_details->size)] += $item->qty;
			}
			
			$customer_id = $cart->user_id;
			$check       = $this->customers->get($customer_id);
			if ($check->num_rows() == 0) {
				$total_unreg_carts += 1;
				$sorted[$date]['unreg_num'] += 1;
				$total_unreg_revenue += $cart->total_amount;
				$sorted[$date]['unreg_rev'] += $cart->total_amount;
			} else {
				$customer_details = $check->row();
				$check            = $this->orders->get_where('customer_id', $customer_details->id);
				if ($check->num_rows() > 0) {
					$total_repeat_carts += 1;
					$sorted[$date]['repeat_num'] += 1;
					$total_repeat_revenue += $cart->total_amount;
					$sorted[$date]['repeat_rev'] += $cart->total_amount;
				}
				if ($customer_details->is_guest == 1) {
					$total_guest_carts += 1;
					$total_guest_revenue += $cart->total_amount;
				} else {
					$total_reg_carts += 1;
					$sorted[$date]['reg_num'] += 1;
					$total_reg_revenue += $cart->total_amount;
					$sorted[$date]['reg_rev'] += $cart->total_amount;
				}
			}
			
			if (($cart->user_id != 0) OR ($cart->ship_to_email != '') OR ($cart->bill_to_email != '')) {
				$total_actionable_carts += 1;
				$sorted[$date]['actionable_num'] += 1;
				$total_actionable_carts_revenue += $cart->total_amount;
				$sorted[$date]['actionable_rev'] += $cart->total_amount;
				
				if($cart->user_id != 0) {
					$email = $this->customers->get_customer_email($cart->user_id);
					$name = $this->customers->get_customer_name($cart->user_id);
				} else if($cart->ship_to_email != '') {
					$email = $cart->ship_to_email;
					$name = $cart->ship_to_name;
				} else {
					$email = $cart->bill_to_email;
					$name = $cart->bill_to_name;
				}
				
				$actionable_index[$cart->id] = array(
					'name' => $name,
					'email' => $email,
					'total_amount' => $cart->total_amount,
				);
				
			}
			
			$total_domestic_carts += 1;
			$sorted[$date]['domestic_num'] += 1;
			$total_domestic_revenue += $cart->total_amount;
			$sorted[$date]['domestic_rev'] += $cart->total_amount;
			
			if ((strtolower(trim($cart->ship_to_country)) != '' AND strtolower(trim($cart->ship_to_country)) != 'india') OR (strtolower(trim($cart->bill_to_country)) != '' AND strtolower(trim($cart->bill_to_country)) != 'india')) {
				$total_domestic_carts -= 1;
				$sorted[$date]['domestic_num'] -= 1;
				$total_domestic_revenue -= $cart->total_amount;
				$sorted[$date]['domestic_rev'] -= $cart->total_amount;
				
				$total_foreign_carts += 1;
				$sorted[$date]['foreign_num'] += 1;
				$total_foreign_revenue += $cart->total_amount;
				$sorted[$date]['foreign_rev'] += $cart->total_amount;
				
			}
			
			
			if (trim($cart->utm_source) != '') {
				if (!isset($utm_sources_index[$cart->utm_source])) {
					$utm_sources_index[$cart->utm_source] = 0;
				}
				$utm_sources_index[$cart->utm_source] += 1;
			}
			if (trim($cart->utm_medium) != '') {
				if (!isset($utm_mediums_index[$cart->utm_medium])) {
					$utm_mediums_index[$cart->utm_medium] = 0;
				}
				$utm_mediums_index[$cart->utm_medium] += 1;
			}
			if (trim($cart->utm_campaign) != '') {
				if (!isset($utm_campaigns_index[$cart->utm_campaign])) {
					$utm_campaigns_index[$cart->utm_campaign] = 0;
				}
				$utm_campaigns_index[$cart->utm_campaign] += 1;
			}
			if (trim($cart->utm_term) != '') {
				if (!isset($utm_terms_index[$cart->utm_term])) {
					$utm_terms_index[$cart->utm_term] = 0;
				}
				$utm_terms_index[$cart->utm_term] += 1;
			}
			if (trim($cart->utm_content) != '') {
				if (!isset($utm_contents_index[$cart->utm_content])) {
					$utm_contents_index[$cart->utm_content] = 0;
				}
				$utm_contents_index[$cart->utm_content] += 1;
			}
		}
		while ($from_d <= $to_d) { # fill the remaining days with no carts
			$date  = date('Y-m-d', $from_d);
			$date  = explode('-', $date);
			$month = $date[1] - 1;
			$date  = $date[0] . '-' . $month . '-' . $date[2];
			if (!isset($sorted[$date])) {
				$sorted[$date]                   = array();
				$sorted[$date]['cart_num']       = 0;
				$sorted[$date]['revenue']        = 0;
				
				$sorted[$date]['unreg_num']      = 0;
				$sorted[$date]['unreg_rev']      = 0;
				
				$sorted[$date]['reg_num']        = 0;
				$sorted[$date]['reg_rev']        = 0;
				
				$sorted[$date]['domestic_num']   = 0;
				$sorted[$date]['domestic_rev']   = 0;
				
				$sorted[$date]['foreign_num']    = 0;
				$sorted[$date]['foreign_rev']    = 0;
				
				$sorted[$date]['repeat_num']     = 0;
				$sorted[$date]['repeat_rev']     = 0;
				
				$sorted[$date]['actionable_num'] = 0;
				$sorted[$date]['actionable_num'] = 0;
				
				$sorted[$date]['s'] 							= 0;
				$sorted[$date]['m'] 							= 0;
				$sorted[$date]['l'] 							= 0;
				$sorted[$date]['xl'] 							= 0;
				$sorted[$date]['xxl'] 							= 0;
				$sorted[$date]['xxxl'] 							= 0;
				$sorted[$date]['unstitched'] 					= 0;
				
			}
			$from_d = strtotime('+1 day', $from_d);
		}
		$data['sorted']                         = $sorted;
		$data['total_carts']                    = $total_carts;
		$data['total_carts_revenue']            = $total_carts_revenue;
		$data['total_guest_carts']              = $total_guest_carts;
		$data['total_guest_revenue']            = $total_guest_revenue;
		$data['total_domestic_carts']           = $total_domestic_carts;
		$data['total_domestic_revenue']         = $total_domestic_revenue;
		$data['total_foreign_carts']            = $total_foreign_carts;
		$data['total_foreign_revenue']          = $total_foreign_revenue;
		$data['total_repeat_carts']             = $total_repeat_carts;
		$data['total_repeat_revenue']           = $total_repeat_revenue;
		$data['total_actionable_carts']         = $total_actionable_carts;
		$data['total_actionable_carts_revenue'] = $total_actionable_carts_revenue;
		$data['top_cities']                     = $top_cities;
		$data['top_states']                     = $top_states;
		$data['top_countries']                  = $top_countries;
		$data['utm_sources_index']              = $utm_sources_index;
		$data['utm_mediums_index']              = $utm_mediums_index;
		$data['utm_campaigns_index']            = $utm_campaigns_index;
		$data['utm_terms_index']                = $utm_terms_index;
		$data['utm_contents_index']             = $utm_contents_index;
		$data['actionable_index'] 				= $actionable_index; 
		$this->load->view('header', $data);
		$this->load->view('cart_analytics_view', $data);
		$this->load->view('footer', $data);
	}
	public function add_to_index($field, $array, $index) {
		if ($array->$field != '') {
			$key = strtolower(trim($array->$field));
			if ($key == '') {
				$key = 'NA';
			}
			if (!isset($index[$key])) {
				$index[$key] = array(
					'number' => 0,
					'revenue' => 0
				);
			}
			$index[$key]['number'] += 1;
			$index[$key]['revenue'] += 1;
		}
		return $index;
	}
}
