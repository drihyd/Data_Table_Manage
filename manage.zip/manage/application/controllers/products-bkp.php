<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Products extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_products', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index($id=NULL) //
    {
        // redirect('product_reports','refresh');
        
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'All Products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_product_images');
            
            if($id) {
                $parent_category = $this->mdl_categories->get_where($id);
                if($parent_category->num_rows() == 0) {
                    redirect('404', 'refresh');
                }
                else {
                    $parent_category = $parent_category->row();
                }
                $products = $this->mdl_products->get_where_custom('cat_id', $parent_category->id);
                $data['parent_category'] = $parent_category;
                $data['page_title'] = 'Products within '.$parent_category->name;
            }
            else {
                $products = $this->mdl_products->get('id');
            }
            
            if($products->num_rows() > 0) {
                $products = $products->result();
                $data['products'] = $products;
                foreach($products as $product) {
                    $category_index[$product->cat_id] = $this->mdl_categories->get_where($product->cat_id)->row();
                    $image = $this->mdl_product_images->get_where_custom('product_id', $product->id);
                    if($image->num_rows() == 0) {
                        if(file_exists("../assets/uploads/{$product->code}_front.jpg")) {
                            $product_images[$product->id] = $this->config->base_url().'../assets/uploads/'.$product->code.'_front.jpg';
                        }
                        else {
                            $product_images[$product->id] = $this->config->base_url().'img/Not_Available.jpg';
                        }
                    }
                    else {
                        $product_images[$product->id] = $this->config->base_url().'../assets/uploads/'.$image->row()->url;
                    }
                }
                $data['category_index'] = $category_index;
                $data['product_images'] = $product_images;
            }
            else {
            
                $data['products'] = array();
                $data['category_index'] = array();
                $data['product_images'] = array();
            }

            $this->load->view('header', $data);
            $this->load->view('products_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function product_info($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_skus');
            $this->load->model('mdl_product_images');
            
            $product_details = $this->mdl_products->get_where($id);
            if($product_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $product_details = $product_details->row();
            }
            
            $data['product_details'] = $product_details;
            
            //$applicable_attributes = $this->db->get_where('categories', array('id' => $product_details->cat_id))->row();
            //if(trim($applicable_attributes->applicable_attributes) != '') {
                //$applicable_attributes = explode(',', $applicable_attributes->applicable_attributes);
            //}
            //else {
                //$applicable_attributes = array();
            //}
            
            $query = $this->db->get('attributes');
            if($query->num_rows() > 0) {
              $applicable_attributes = array();
              foreach($query->result() as $attribute) {
                array_push($applicable_attributes, $attribute->id);
              }
            }
            else {
              $applicable_attributes = array();
            }
            
            
            if(count($applicable_attributes) > 0) {
              $this->db->where_in('id', $applicable_attributes);
              $attributes = $this->db->get('attributes');
              if($attributes->num_rows() > 0) {
                  $attribute_names = array();
                  foreach($attributes->result() as $attribute) {
                      $attribute_names[$attribute->id] = $attribute;
                  }
              }
              else {
                  $attribute_names = array();
              }
            }
            else {
              $attribute_names = array();
            }
            
            $data['attribute_names'] = $attribute_names;
            
            $attribute_values_list = $this->db->get('attribute_values');
            if($attribute_values_list->num_rows() > 0) {
                $attribute_values = array();
                foreach($attribute_values_list->result() as $attribute_value) {
                    $attribute_values[$attribute_value->id] = $attribute_value;
                }
            }
            else {
                $attribute_values = array();
            }
            
            $data['attribute_values'] = $attribute_values;
        
			$product_attributes = array();
            $check = $this->db->get_where('product_attrs', array('product_id' => $product_details->id));
            if($check->num_rows() > 0) {
				$product_attributes = $check->result();
            }
            
            $data['product_attributes'] = $product_attributes;
            
            $parent_category_details = $this->mdl_categories->get_where($product_details->cat_id)->row();
            $data['parent_category_details'] = $parent_category_details;
            
            $product_images = $this->mdl_product_images->get_product_images($product_details->id);
            $data['product_images'] = $product_images;        
            
            $skus_list = $this->mdl_skus->get_where_custom('product_id', $product_details->id);
            $data['skus_list'] = $skus_list->result();
            
            $data['page_title'] = $product_details->name;
             
            $this->load->view('header', $data);
            $this->load->view('product_info_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function edit($id) 
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_product_images');
            
            $product_details = $this->mdl_products->get_where($id);
            if($product_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $product_details = $product_details->row();
            }
            $data['product_details'] = $product_details;
            
            $parent_category_details = $this->mdl_categories->get_where($product_details->cat_id);
            if($parent_category_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $parent_category_details = $parent_category_details->row();
            }
            $data['parent_category_details'] = $parent_category_details;
            
            $applicable_attributes_list = $parent_category_details->applicable_attributes;
            if(trim($applicable_attributes_list) != '') {
                $applicable_attributes = explode(',', $applicable_attributes_list);
            }
            else {
                $applicable_attributes = array();
            }
            
            $data['applicable_attributes'] = $applicable_attributes;
            
            $this->db->where_in($applicable_attributes);
            $attribute_names_query = $this->db->get('attributes');
            if($attribute_names_query->num_rows() > 0) {
                $attribute_names = array();
                foreach($attribute_names_query->result() as $attribute_name) {
                    $attribute_names[$attribute_name->id] = $attribute_name->attr_name;
                }
            }
            else {
                $attribute_names = array();
            }
            
            $data['attribute_names'] = $attribute_names;
            
            $attribute_values_array = array();
            foreach($attribute_names as $key => $value) {
                $attribute_values_array[$key] = $this->db->get_where('attribute_values', array('attr_id' => $key))->result();
            }
            
            $data['attribute_values_array'] = $attribute_values_array;
            
            
            $product_attributes = array();
            $check = $this->db->get_where('product_attrs', array('product_id' => $product_details->id));
            if($check->num_rows() > 0) {
                $product_attributes = $check->result();
            }
            $data['product_attributes'] = $product_attributes;
            
            $categories_list = $this->mdl_categories->get('id')->result();
            $data['categories_list'] = $categories_list;
            
            $product_images = $this->mdl_product_images->get_product_images($product_details->id);
            $data['product_images'] = $product_images;
            
            $data['tinyMC'] = TRUE;
            
            $data['page_title'] = 'Edit '.$product_details->name;

            $this->load->view('header', $data);
            $this->load->view('product_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function add()
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'Add New Product';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-add-product';
            
            $this->load->model('mdl_categories');
            
            $categories_list = $this->mdl_categories->get('id')->result();
            $data['categories_list'] = $categories_list;
            
            
            //$data['tinyMC'] = FALSE;

            $this->load->view('header', $data);
            $this->load->view('product_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add_child($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'Add New Product';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-add-product';
            
            $this->load->model('mdl_categories');
            
            $parent_category = $this->mdl_categories->get_where($id);
            if($parent_category->num_rows() > 0) {
              $parent_category_details = $parent_category->row();
            }
            else {
              redirect('404', 'refresh');
            }
            
            $data['categories_list'] = $parent_category->result();
            
            //$data['tinyMC'] = FALSE;

            $this->load->view('header', $data);
            $this->load->view('product_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function delete($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'Add New Product';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-add-product';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_product_images');
            
            $product = $this->mdl_products->get_where($id);
            
            if($product->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $product = $product->row();
            }
            
            //$product->code = implode('_', explode(' ',$product->code));
            
            $product_code = implode('_', explode(' ',$product->code));
            $product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
            foreach($product_images as $image) {
                unlink($image);
            }
            
            //delete all SKUs listed under this product
            $this->load->model('mdl_skus');
            $skus = $this->mdl_skus->get_where_custom('product_id', $product->id);
            foreach($skus->result() as $sku) {
                $this->mdl_skus->_delete($sku->id);
            }
            
            //delete all product_attributes listed under this product
            $this->load->model('mdl_product_attributes');
            $product_attribute_entries = $this->mdl_product_attributes->get_where_custom('product_id', $product->id);
            if($product_attribute_entries->num_rows() > 0) {
                foreach($product_attribute_entries->result() as $product_attribute_entries) {
                    $this->mdl_product_attributes->_delete($product_attribute_entries->id);
                }
            }
            
            // finally delete the product
            $this->mdl_products->_delete($product->id);
            
            redirect('products');
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function save($id = FALSE) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'All Products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $productName = $this->input->post('productName');
            if (!$productName):
                redirect('products');
            endif;
            $productCode = $this->input->post('productCode', true);
            $productSlug = $this->input->post('productSlug', true);
            $productCategory = $this->input->post('productCategory', true);
            $productDesc = $this->input->post('productDesc', true);
            $productPosScore = (int)$this->input->post('productPosScore', true);
            $product_attributes = $this->input->post('productAttributes', true);
            $productUnstitched = $this->input->post('productUnstitched', true);
            
            if((int) $productUnstitched == 1) {
                $productUnstitched = 1;
            }
            else {
                $productUnstitched = null;
            }
            
            $productPriceINR = (float) $this->input->post('productPriceINR', true);
            $productPriceUSD = (float) $this->input->post('productPriceUSD', true);
            
            if($productPriceINR <= 0) {
            	$this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Please enter a valid INR price.</strong></div>");
                redirect("products/edit/{$id}");
            }
            
            if($productPriceUSD <= 0) {
            	$this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Please enter a valid USD price.</strong></div>");
                redirect("products/edit/{$id}");
            }
            
            if (is_int($productPosScore) && ($productPosScore >= 0) && ($productPosScore <= 1000)) {
                if ($id) {
                    
                    $data = array(
                        'name' => $productName,
                        'code' => $productCode,
                        'slug' => $productSlug,
                        'cat_id' => $productCategory,
                        'desc' => $productDesc,
                        'unstitched' => $productUnstitched,
                        'position_score' => $productPosScore,
                        'price_inr' => $productPriceINR,
                        'price_usd' => $productPriceUSD,
                    );
                    
                    $this->db->where('id !=', $id);
                    $slug_exists = $this->mdl_products->get_where_custom('slug', $productSlug);
                    
                    if ($slug_exists->num_rows() > 0) {
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Slug already exists. Please enter a unique slug</strong></div>");
                        redirect("products/edit/{$id}");
                    }
                    else {
                        $this->mdl_products->_update($id, $data);
                        
                        //delete any existing product attributes
                        $this->db->where('product_id', $id);
                        $this->db->delete('product_attributes');
                        
                        if(is_array($product_attributes)) { 
							foreach($product_attributes as $product_attribute) {
								$new_data = array(
								  'product_id' => $id,
								  'attribute_id' => $product_attribute
								);
								$this->db->insert('product_attributes', $new_data);
							}
                        }
                        
                        //update SKU category ID to match product cat ID
                        $new_data = array(
                          'cat_id' => $productCategory
                        );
                        
                        $this->db->where('product_id', $id);
                        $this->db->update('skus', $new_data);
                        
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Updated successfully.</strong></div>");
                        redirect("products/edit/{$id}");
                    }
                    
                }
                else {
                    $data = array(
                        'name' => $productName,
                        'code' => $productCode,
                        'slug' => $productSlug,
                        'cat_id' => $productCategory,
                        'desc' => $productDesc,
                        'unstitched' => $productUnstitched,
                        'position_score' => $productPosScore
                    );
                    $slug_exists = $this->mdl_products->get_where_custom('slug', $productSlug);
                    if ($slug_exists->num_rows() > 0) {
                        echo "Slug already exists. <a href='{$this->config->base_url() }products/add'>Enter a unique slug.</a>";
                    }
                    else {
                        $this->mdl_products->_insert($data);
                        $id = mysql_insert_id();
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Product added successfully. Please add attributes and images.</strong></div>");
                        redirect("products/edit/{$id}");
                    }
                }
            }
            else {
                echo "Invalid Input. Please <a href='{$this->config->base_url() }products/edit/{$id}'>try again.</a>";
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function seosave($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'All Products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_product_images');
            
            $seoTitle = $this->input->post('productSeoTitle');
            $seoDesc = $this->input->post('productSeoDesc');
            $seoKeys = $this->input->post('productSeoKeys');
            $data = array(
                'seo_title' => $seoTitle,
                'seo_desc' => $seoDesc,
                'seo_keywords' => $seoKeys
            );
            $this->mdl_products->_update($id, $data);
            $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
            redirect("products/edit/{$id}?tab=seotags");

        }
        else {
            redirect('login', 'refresh');
        }
    }

    function DPimageSave($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'All Products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_product_images');
            
            $check = $this->mdl_products->get_where($id);
            if($check->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $product_details = $check->row();
            }
            
            //$view = $this->input->post('view', true);
            //if( !( in_array( strtolower($view), array('front', 'back', 'left', 'right', 'closeup') ) ) ) :
                //redirect('404', 'refresh');
            //endif;
            
            
            $config['upload_path'] = '../assets/uploads/';
            $config['allowed_types'] = 'jpg|jpeg';
            $config['file_name'] = implode('_', explode(' ', $product_details->code)).'_'.'.jpg';
            $config['overwrite'] = FALSE;
            
            $this->load->library('upload', $config);
            if($_FILES['productDPChange']['size'] == 0) :
                //redirect('404', 'refresh');
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please upload a file.</strong></div>");
                redirect("products/edit/{$product_details->id}?tab=productspics");
            endif;
            
            if (!$this->upload->do_upload('productDPChange')) {
                $data['uploadErrors'] = $this->upload->display_errors();
                echo $data['uploadErrors'] . '<br />';
                
                echo "<a href='{$this->config->base_url() }products/edit/{$id}?tab=productpics'>Please try again</a>";
            }
            else {
                $res = $this->upload->data();
                $DPname = implode('_', explode(' ',$product_details->code)).'_'.$view.'.jpg';
                $data = array(
                    'url' => $DPname,
                    'product_id' => $product_details->id,
                    'view' => $view,
                    'alt' => ucfirst($product_details->name).' '.$view.' view',
                    'title' => ucfirst($product_details->name).' '.$view.' view'
                );
                
                $current_image = $this->db->get_where('product_images', array('product_id' => $product_details->id, 'view' => $view));
                if($current_image->num_rows() > 0) {
                    $this->mdl_product_images->_update($current_image->row()->id, $data);
                    redirect("products/edit/{$product_details->id}?tab=productspics");
                }
                else {
                    $this->mdl_product_images->_insert($data);
                    redirect("products/edit/{$product_details->id}?tab=productspics");
                }
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function imageSave($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'Edit Product';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $check = $this->mdl_products->get_where($id);
            if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invald product ID.</strong></div>");
                redirect("products/edit/{$id}?tab=productpics");
            }
            else {
                $product_details = $check->row();
            }
                        
            $config['upload_path'] = '../assets/uploads/';
            $config['allowed_types'] = 'jpg|jpeg';
            
            if( ! ($_FILES['productImage']['name'] == $product_details->code.'_dp.jpg') ) {
              $config['file_name'] = implode('_', explode(' ', $product_details->code)).'_'.'.jpg';
            }
            else {
              $config['file_name'] = $_FILES['productImage']['name'];
            }
            $config['overwrite'] = FALSE;
            
            $this->load->library('upload', $config);
            if($_FILES['productImage']['size'] == 0) :
                //redirect('404', 'refresh');
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Please upload a file.</strong></div>");
                redirect("products/edit/{$product_details->id}?tab=productpics");
            endif;
            
            if (!$this->upload->do_upload('productImage')) {
                $data['uploadErrors'] = $this->upload->display_errors();
                //echo $data['uploadErrors'] . '<br />';
                
                //echo "<a href='{$this->config->base_url() }products/edit/{$id}?tab=productpics'>Please try again</a>";
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>{$this->upload->display_errors()}.</strong></div>");
                redirect("products/edit/{$product_details->id}?tab=productpics");
            }
            else {
                $res = $this->upload->data();
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Image uploaded successfully.</strong></div>");
                redirect("products/edit/{$product_details->id}?tab=productpics");
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function imageDelete($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'Edit Products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $filename = $this->input->post('filename', true);
            
            $this->load->helper('encode_helper');
            
            $filename = filename_decode($filename);
            
            if(file_exists($filename)) {
                unlink($filename);
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Image deleted successfully</strong></div>");
                redirect("products/edit/{$id}?tab=productpics");
            }
            else {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! File does not exist.</strong></div>");
                redirect("products/edit/{$id}?tab=productpics");
            }
        }    
    }

}
