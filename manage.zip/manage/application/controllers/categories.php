<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Categories extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_categories', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index()
    {
        if ($this->session->userdata('logged_in')) 
        {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            $data['page_title'] = 'All Categories';
            
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-categories-view';
            
            $categories = $this->mdl_categories->get('id');
            if( $categories->num_rows() == 0 ) 
            {
                redirect('404', 'refresh');
            }
            else
            {
                $categories = $categories->result();
            }
            
            $data['categories'] = $categories;
            
            $this->load->view('header', $data);
            $this->load->view('categories_view', $data);
            $this->load->view('footer', $data);
        }
        else 
        {
            redirect('login', 'refresh');
        }
    }
    
    function category_info($id)
    {
        if ($this->session->userdata('logged_in')) 
        {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-categories-view';
            
            $category_details = $this->mdl_categories->get_where($id);
            
            if($category_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $category_details = $category_details->row();
            }
            
            $data['category_details'] = $category_details;
            
            if($category_details->parent_id != 0) :
                $parent_category_details = $this->mdl_categories->get_where($category_details->parent_id)->row();
                $data['parent_category_details'] = $parent_category_details;
            endif;
            
            $this->db->where('parent_id', $category_details->id);
            $sub_categories_list = $this->mdl_categories->get('id')->result();
            $data['sub_categories_list'] = $sub_categories_list;
            
            if(trim($category_details->applicable_attributes) != '') {
                $applicable_attributes = explode(',', $category_details->applicable_attributes);
                if(sizeof($applicable_attributes) > 0) {
                    foreach($applicable_attributes as $attribute) {
                        $query = $this->db->get_where('attributes', array('id' => $attribute));
                        if($query->num_rows() == 0) {
                          continue;
                        }
                        else {
                          $attribute_names[$attribute] = $query->row()->attr_name;
                          $attribute_values_list[$attribute] = $this->db->get_where('attribute_values', array('attr_id' => $attribute))->result();
                        }
                    }
                }
                else {
                    $applicable_attributes = array();
                    $attribute_names = array();
                    $attribute_values_list = array();
                }
            }
            else {
                $applicable_attributes = array();
                $attribute_names = array();
                $attribute_values_list = array();
            }
            
            $data['applicable_attributes'] = $applicable_attributes;
            $data['attribute_names'] = $attribute_names;
            $data['attribute_values_list'] = $attribute_values_list;
            
            $this->db->where('cat_id', $category_details->id);
            $this->load->model('mdl_products');
            $sub_products_list = $this->mdl_products->get('id')->result();
            $data['sub_products_list'] = $sub_products_list;
            
            $product_index = array();
            foreach($sub_products_list as $product) 
            {
                $product_index[$product->id] = $product;
            }
            
            $data['product_index'] = $product_index;
            
            $category_product_count = array();
            foreach($sub_categories_list as $category)
            {
                $category_product_count[$category->id] = $this->mdl_products->get_where_custom('cat_id', $category->id)->num_rows();
            }
            
            $data['category_product_count'] = $category_product_count;
            
            $category_index = array();
            foreach($sub_categories_list as $category) 
            {
                $category_index[$category->id] = $category;
            }
            $category_index[$category_details->id] = $category_details;
            
            $data['category_index'] = $category_index;
            
            $this->load->model('mdl_product_images');
            $product_images = array();
            
            foreach($sub_products_list as $product)
            {
                $image = $this->mdl_product_images->get_where_custom('product_id', $product->id);
                if($image->num_rows() == 0) {
                    if(file_exists("../assets/uploads/{$product->code}_front.jpg")) {
                        $product_images[$product->id] = $this->config->base_url().'../assets/uploads/'.$product->code.'_front.jpg';
                    }
                    else {
                        $product_images[$product->id] = $this->config->base_url().'img/Not_Available.jpg';
                    }
                }
                else {
                    $product_images[$product->id] = $this->config->base_url().'../assets/uploads/'.$image->row()->url;
                }
                    
            }
            
            $data['product_images'] = $product_images;
            
            $data['page_title'] = $category_details->name;
            $this->load->view('header', $data);
            $this->load->view('category_info_view', $data);
            $this->load->view('footer', $data);
        }
        else 
        {
            redirect('login', 'refresh');
        }
    }

    function edit($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-categories-view';
            
            $category_details = $this->mdl_categories->get_where($id);
            if($category_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $category_details = $category_details->row();
            }
            
            $data['category_details'] = $category_details;
            
            $parent_category_details = $this->mdl_categories->get_where($category_details->parent_id)->row();
            $data['parent_category_details'] = $parent_category_details;
            
            $parent_categories_list = $this->mdl_categories->get_where_custom('parent_id', '0')->result();
            $data['parent_categories'] = $parent_categories_list;
            
            $attributes = $this->db->get('attributes')->result();
            $selected_attributes = $category_details->applicable_attributes;
            if(trim($selected_attributes) != '') {
                $selected_attributes = explode(',', $selected_attributes);
            }
            else {
                $selected_attributes = array();
            }
            
            $data['selected_attributes'] = $selected_attributes;
            $data['attributes'] = $attributes;
            
            $this->load->model('mdl_designer_tips');
            $query_check = $this->mdl_designer_tips->get_where_custom('cat_id', $category_details->id);
            if($query_check->num_rows() > 0) {
              $designerTip = $query_check->row();
            }
            else {
              $designerTip = array();
            }
            
            $data['designerTip'] = $designerTip;
            
            $data['tinyMC'] = TRUE;
            
            $data['page_title'] = 'Edit '.$category_details->name;
            $this->load->view('header', $data);
            $this->load->view('category_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function parentedit($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-categories-view';
            
            $category_details = $this->mdl_categories->get_where($id);
            
            if($category_details->num_rows() == 0) 
            {
                redirect('404', 'refresh');
            }
            else 
            {
                $category_details = $category_details->row();
            }
            

            $data['category_details'] = $category_details;
            
            $attributes = $this->db->get('attributes')->result();
            
            $selected_attributes = $category_details->applicable_attributes;
            if(trim($selected_attributes) != '') {
                $selected_attributes = explode(',', $selected_attributes);
            }
            else {
                $selected_attributes = array();
            }
            
            $data['selected_attributes'] = $selected_attributes;
            $data['attributes'] = $attributes;
            
            $this->load->model('mdl_designer_tips');
            $query_check = $this->mdl_designer_tips->get_where_custom('cat_id', $category_details->id);
            if($query_check->num_rows() > 0) {
              $designerTip = $query_check->row();
            }
            else {
              $designerTip = array();
            }
            
            $data['designerTip'] = $designerTip;
            
            $data['tinyMC'] = TRUE;
            
            $data['page_title'] = 'Edit '.$category_details->name;
            $this->load->view('header', $data);
            $this->load->view('category_parentedit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function save($id = FALSE)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-categories-view';
            
            $categoryName = $this->input->post('categoryName', true);
            $categorySlug = $this->input->post('categorySlug', true);
            $categoryParent = $this->input->post('categoryParent', true);
            $categoryPosScore = (int)$this->input->post('categoryPosScore', true);
            $categoryDesc = $this->input->post('categoryDesc', true);
            $categoryShippingWeight = $this->input->post('categoryShippingWeight', true);
            $applicable_attributes = $this->input->post('applicableAttributes', true);
            
            if(is_array($applicable_attributes)) {
				if(count(array_filter($applicable_attributes)) > 0) {
					$applicable_attributes_string = implode(',', $applicable_attributes);
				}
			}
            else {
                $applicable_attributes_string = '';
            }
            
            if (is_int($categoryPosScore) && ($categoryPosScore >= 0) && ($categoryPosScore <= 1000)) {
                if ($id) {
                    
                    if($categoryShippingWeight < 0) {
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Shipping must a value greater than or equal to zero.</strong></div>");
                        redirect("categories/edit/{$id}");
                    }
                    
                    $check = $this->mdl_categories->get_where($id);
                    if($check->num_rows() == 0) :
                        redirect('404', 'refresh');
                    endif;
                    
                    $data = array(
                        'name' => $categoryName,
                        'slug' => $categorySlug,
                        'parent_id' => $categoryParent,
                        'applicable_attributes' => $applicable_attributes_string,
                        'shipping_weight' => $categoryShippingWeight,
                        'position_score' => $categoryPosScore,
                        'desc' => $categoryDesc
                    );
                    $this->db->where('id !=', $id);
                    $slug_exists = $this->mdl_categories->get_where_custom('slug', $categorySlug);
                    if ($slug_exists->num_rows() > 0) {
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Slug already exists. Please enter a unique slug</strong></div>");
                        redirect("categories/edit/{$id}");
                    }
                    else {
                        $this->mdl_categories->_update($id, $data);
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Updated successfully.</strong></div>");
                        redirect("categories/edit/{$id}");
                    }
                }
                else {
                    $data = array(
                        'name' => $categoryName,
                        'slug' => $categorySlug,
                        'parent_id' => $categoryParent
                    );
                    
                    $slug_exists = $this->mdl_categories->get_where_custom('slug', $categorySlug);
                    if ($slug_exists->num_rows() > 0) {
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Slug already exists. Please enter a unique slug</strong></div>");
                        redirect('categories/add');
                    }
                    else {
                        $this->mdl_categories->_insert($data);
                        $id = mysql_insert_id();
                        $new_data = array(
							'cat_id' 		=> $id,
							's' 			=> 0,
							'm' 			=> 0,
							'l' 			=> 0,
							'xl' 			=> 0,
							'xxl' 			=> 0,
							'unstitched' 	=> 0,
						);
						$this->db->insert('reorder_thresholds', $new_data);
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Created successfully.</strong></div>");
                        redirect("categories/edit/{$id}");
                    }
                }
            }
            else {
                echo "Invalid Input. Please <a href='{$this->config->base_url() }categories/edit/{$id}'>try again.</a>";
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function seosave($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-categories-view';
            
            $check = $this->mdl_categories->get_where($id);
            if($check->num_rows() == 0) :
                redirect('404', 'refresh');
            endif;
            
            $seoTitle = $this->input->post('categorySeoTitle', true);
            $seoDesc = $this->input->post('categorySeoDesc', true);
            $seoKeys = $this->input->post('categorySeoKeys', true);
            
            $data = array(
                'seo_title' => $seoTitle,
                'seo_desc' => $seoDesc,
                'seo_keywords' => $seoKeys
            );
            $this->mdl_categories->_update($id, $data);
            
            $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
            
            $category_details = $this->mdl_categories->get_where($id)->row();
            if($category_details->parent_id == 0) {
                redirect("categories/parentedit/{$id}?tab=seotags");
            }
            else {
                redirect("categories/edit/{$id}?tab=seotags");
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function designertip_save($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-categories-view';
            
            $check = $this->mdl_categories->get_where($id);
            if($check->num_rows() == 0) :
                redirect('404', 'refresh');
            endif;
            
            $designerName = $this->input->post('designerName', true);
            $designerDesignation = $this->input->post('designerDesignation', true);
            $designerTip = $this->input->post('designerTip', true);
            
            $query_check = $this->db->get_where('designer_tips', array('cat_id' => $id));
            if($query_check->num_rows() > 0) {
              $designer_tip_details = $query_check->row();

              $new_data = array(
                  'designer_name' => $designerName,
                  'designer_designation' => $designerDesignation,
                  'designer_tip' => $designerTip
              );

              $this->db->where('id', $designer_tip_details->id);
              $this->db->update('designer_tips', $new_data);
              
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Designer Tip updated sucessfully.</strong></div>");
              
            }
            else {
              $new_data = array(
                  'cat_id' => $id,
                  'designer_name' => $designerName,
                  'designer_designation' => $designerDesignation,
                  'designer_tip' => $designerTip
              );
              
              $this->db->insert('designer_tips', $new_data);
              
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Designer Tip added sucessfully.</strong></div>");
            }

            $category_details = $this->mdl_categories->get_where($id)->row();
            if($category_details->parent_id == 0) {
                redirect("categories/parentedit/{$id}?tab=designertip");
            }
            else {
                redirect("categories/edit/{$id}?tab=designertip");
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function parentsave($id = FALSE)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-categories-view';
            
            $categoryName = $this->input->post('categoryName', true);
            $categorySlug = $this->input->post('categorySlug', true);
            $categoryPosScore = (int)$this->input->post('categoryPosScore', true);
            $categoryDesc = $this->input->post('categoryDesc', true);
            $categoryShippingWeight = $this->input->post('categoryShippingWeight', true);
            $applicable_attributes = $this->input->post('applicableAttributes', true);
            
            if(count(array_filter($applicable_attributes)) > 0) {
                $applicable_attributes_string = implode(',', $applicable_attributes);
            }
            else {
                $applicable_attributes_string = '';
            }
            
            if (is_int($categoryPosScore) && ($categoryPosScore >= 0) && ($categoryPosScore <= 1000)) {
                if ($id) {
                    
                    if($categoryShippingWeight < 0) {
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Shipping must a value greater than or equal to zero.</strong></div>");
                        redirect("categories/edit/{$id}");
                    }
                    
                    $check = $this->mdl_categories->get_where($id);
                    if($check->num_rows() == 0) :
                        redirect('404', 'refresh');
                    endif;
                    
                    $data = array(
                        'name' => $categoryName,
                        'slug' => $categorySlug,
                        'applicable_attributes' => $applicable_attributes_string,
                        'shipping_weight' => $categoryShippingWeight,
                        'position_score' => $categoryPosScore,
                        'desc' => $categoryDesc
                    );
                    
                    $this->db->where('id !=', $id);
                    $slug_exists = $this->mdl_categories->get_where_custom('slug', $categorySlug);
                    if ($slug_exists->num_rows() > 0) {
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Slug already exists. Please enter a unique slug</strong></div>");
                        redirect("categories/parentedit/{$id}");
                    }
                    else {
                        $this->mdl_categories->_update($id, $data);
                        $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Updated successfully!</strong></div>");
                        redirect("categories/parentedit/{$id}");
                    }
                }
                else {
                    $data = array(
                        'name' => $categoryName,
                        'slug' => $categorySlug
                    );
                    $slug_exists = $this->mdl_categories->get_where_custom('slug', $categorySlug);
                    if ($slug_exists->num_rows() > 0) {
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Slug already exists. Please enter a unique slug</strong></div>");
                        redirect('categories/parentadd');
                    }
                    else {
                        $this->mdl_categories->_insert($data);
                        $id = mysql_insert_id();
                        $data['success'] = "<div class='alert alert-success'>Record Added Successfully!</div>";
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Created successfully!</strong></div>");
                        redirect("categories/parentedit/{$id}");
                    }
                }
            }
            else {
                echo "Invalid Input. Please <a href='{$this->config->base_url() }categories/parentedit/{$id}'>try again.</a>";
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function parentDPimageSave($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];

            // $productDPChange = $_FILES['productDPChange']['name'];
            // print_r($_FILES['productDPChange']);

            if ($id) {
                
                $check = $this->mdl_categories->get_where($id);
                if($check->num_rows() == 0) :
                    redirect('404', 'refresh');
                endif;
                
                if ($_FILES['categoryDPChange']['name']) {
                    $config['upload_path'] = '../assets/uploads/category_dps';
                    $config['allowed_types'] = 'jpg|jpeg';
                    $this->load->library('upload', $config);
                    if (!$this->upload->do_upload('categoryDPChange')) {
                        $data['uploadErrors'] = $this->upload->display_errors();
                        echo $data['uploadErrors'] . '<br />';
                        echo "<a href='{$this->config->base_url() }categories/parentedit/{$id}'>Please try again</a>";
                    }
                    else {
                        $res = $this->upload->data();
                        $DPname = $res['file_name'];
                        $data = array(
                            'cat_image' => $DPname
                        );
                        $current_image = $this->mdl_categories->get_where($id);
                        if (!($current_image->row()->cat_image == '')):
                            unlink('../assets/uploads/category_dps/' . $current_image->row()->cat_image);
                        endif;
                        $this->mdl_categories->_update($id, $data);
                        redirect("categories/parentedit/{$id}?tab=displaypic");
                    }
                }
                else {
                    echo "<h1>Error!</h1>";
                    echo "<a href='{$this->config->base_url() }categories/parentedit/{$id}'>Please try again</a>";
                }

            }
            else {
                echo "<h1>Error!</h1>";
                echo "<a href='{$this->config->base_url() }categories{$id}'>Go Back</a>";
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function DPimageSave($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];

            if ($id) {
                
                $check = $this->mdl_categories->get_where($id);
                if($check->num_rows() == 0) :
                    redirect('404', 'refresh');
                endif;
                
                if ($_FILES['categoryDPChange']['name']) {
                    $config['upload_path'] = '../assets/uploads/category_dps';
                    $config['allowed_types'] = 'jpg|jpeg';
                    $this->load->library('upload', $config);
                    if (!$this->upload->do_upload('categoryDPChange')) {
                        $data['uploadErrors'] = $this->upload->display_errors();
                        echo $data['uploadErrors'] . '<br />';
                        echo "<a href='{$this->config->base_url() }categories/edit/{$id}'>Please try again</a>";
                    }
                    else {
                        $res = $this->upload->data();
                        $DPname = $res['file_name'];
                        $data = array(
                            'cat_image' => $DPname
                        );
                        $current_image = $this->mdl_categories->get_where($id);
                        if (!($current_image->row()->cat_image == '')):
                            unlink('../assets/uploads/category_dps/' . $current_image->row()->cat_image);
                        endif;
                        $this->mdl_categories->_update($id, $data);
                        redirect("categories/edit/{$id}?tab=displaypic");
                    }
                }
                else {
                    echo "<h1>Error!</h1>";
                    echo "<a href='{$this->config->base_url() }categories/edit/{$id}'>Please try again</a>";
                }

            }
            else {
                echo 'error';
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function add()
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-add-childcat';
            
            $parent_categories_list = $this->mdl_categories->get_where_custom('parent_id', 0);
            $data['parent_categories_list'] = $parent_categories_list->result();
            
            $data['tinyMC'] = TRUE;

            $this->load->view('header', $data);
            $this->load->view('category_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add_child($parent_id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $check = $this->mdl_categories->get_where($parent_id);
            if($check->num_rows() == 0) :
                redirect('404', 'refresh');
            endif;
            
            $data['page_name'] = 'categories';
            
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-add-childcat';
            
            $parent_category_details = $this->mdl_categories->get_where($parent_id);
            $data['parent_category_details'] = $parent_category_details->row();
            
            $data['tinyMC'] = TRUE;

            $this->load->view('header', $data);
            $this->load->view('category_add_child', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function parentadd()
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            $data['sidebar_element'] = 'side-categories';
            $data['sidebar_subelement'] = 'side-add-parentcat';
            
            $data['tinyMC'] = TRUE;

            $this->load->view('header', $data);
            $this->load->view('category_parentadd', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function delete($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $check = $this->mdl_categories->get_where($id);
            if($check->num_rows() == 0) :
                redirect('404', 'refresh');
            endif;
            
            $data['page_name'] = 'categories';
            $data['page_title'] = 'All Categories';
            
            $this->load->model('mdl_products');
            $this->load->model('mdl_product_images');
            
            //delete products listed directly under this category
            $products = $this->mdl_products->get_where_custom('cat_id', $id);
            foreach($products->result() as $product) {
                
                $product_code = implode('_', explode(' ',$product->code));
                $product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
                foreach($product_images as $image) {
                    unlink($image);
                }
                
                //delete all SKUs listed under this product
                $this->load->model('mdl_skus');
                $skus = $this->mdl_skus->get_where_custom('product_id', $product->id);
                foreach($skus->result() as $sku) {
                    $this->mdl_skus->_delete($sku->id);
                }
                
                //delete all product_attributes listed under this product
                $this->load->model('mdl_product_attributes');
                $product_attribute_entries = $this->mdl_product_attributes->get_where_custom('product_id', $product->id);
                if($product_attribute_entries->num_rows() > 0) {
                    foreach($product_attribute_entries->result() as $product_attribute_entries) {
                        $this->mdl_product_attributes->_delete($product_attribute_entries->id);
                    }
                }
                
                // finally delete the product
                $this->mdl_products->_delete($product->id);
                
            }

            //delete Sub-categories listed under this Category
            $sub_categories = $this->mdl_categories->get_where_custom('parent_id', $id);
            foreach($sub_categories->result() as $sub_category) {
                
                // first delete all products listed under this sub-category
                $products = $this->mdl_products->get_where_custom('cat_id', $sub_category->id);
                foreach($products->result() as $product) {
                    
                    $product_code = implode('_', explode(' ',$product->code));
                    $product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
                    foreach($product_images as $image) {
                        unlink($image);
                    }
                    
                    //delete all SKUs listed under this product
                    $this->load->model('mdl_skus');
                    $skus = $this->mdl_skus->get_where_custom('product_id', $product->id);
                    foreach($skus->result() as $sku) {
                        $this->mdl_skus->_delete($sku->id);
                    }
                    
                    //delete all product_attributes listed under this product
                    $this->load->model('mdl_product_attributes');
                    $product_attribute_entries = $this->mdl_product_attributes->get_where_custom('product_id', $product->id);
                    if($product_attribute_entries->num_rows() > 0) {
                        foreach($product_attribute_entries->result() as $product_attribute_entries) {
                            $this->mdl_product_attributes->_delete($product_attribute_entries->id);
                        }
                    }
                    
                    // finally delete the product
                    $this->mdl_products->_delete($product->id);
                    
                }
                
                // finally delete the sub-category
                $this->mdl_categories->_delete($sub_category->id);
            }
            
            // finally delete the category
            $this->mdl_categories->_delete($id);
            
            redirect('categories');
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function parentdelete($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $check = $this->mdl_categories->get_where($id);
            if($check->num_rows() == 0) :
                redirect('404', 'refresh');
            endif;
            
            $data['page_name'] = 'categories';
            $data['page_title'] = 'All Categories';
            
            $this->load->model('mdl_products');
            $this->load->model('mdl_product_images');
            
            //delete products listed directly under this category
            $products = $this->mdl_products->get_where_custom('cat_id', $id);
            foreach($products->result() as $product) {
                
                $product_code = implode('_', explode(' ',$product->code));
                $product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
                foreach($product_images as $image) {
                    unlink($image);
                }
                
                //delete all SKUs listed under this product
                $this->load->model('mdl_skus');
                $skus = $this->mdl_skus->get_where_custom('product_id', $product->id);
                foreach($skus->result() as $sku) {
                    $this->mdl_skus->_delete($sku->id);
                }
                
                //delete all product_attributes listed under this product
                $this->load->model('mdl_product_attributes');
                $product_attribute_entries = $this->mdl_product_attributes->get_where_custom('product_id', $product->id);
                if($product_attribute_entries->num_rows() > 0) {
                    foreach($product_attribute_entries->result() as $product_attribute_entries) {
                        $this->mdl_product_attributes->_delete($product_attribute_entries->id);
                    }
                }
                
                // finally delete the product
                $this->mdl_products->_delete($product->id);
                
            }

            //delete Sub-categories listed under this Category
            $sub_categories = $this->mdl_categories->get_where_custom('parent_id', $id);
            foreach($sub_categories->result() as $sub_category) {
                
                // first delete all products listed under this sub-category
                $products = $this->mdl_products->get_where_custom('cat_id', $sub_category->id);
                foreach($products->result() as $product) {
                    
                    $product_code = implode('_', explode(' ',$product->code));
                    $product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
                    foreach($product_images as $image) {
                        unlink($image);
                    }
                    
                    //delete all SKUs listed under this product
                    $this->load->model('mdl_skus');
                    $skus = $this->mdl_skus->get_where_custom('product_id', $product->id);
                    foreach($skus->result() as $sku) {
                        $this->mdl_skus->_delete($sku->id);
                    }
                    
                    //delete all product_attributes listed under this product
                    $this->load->model('mdl_product_attributes');
                    $product_attribute_entries = $this->mdl_product_attributes->get_where_custom('product_id', $product->id);
                    if($product_attribute_entries->num_rows() > 0) {
                        foreach($product_attribute_entries->result() as $product_attribute_entries) {
                            $this->mdl_product_attributes->_delete($product_attribute_entries->id);
                        }
                    }
                    
                    // finally delete the product
                    $this->mdl_products->_delete($product->id);
                    
                }
                
                // finally delete the sub-category
                $this->mdl_categories->_delete($sub_category->id);
            }
            
            // finally delete the category
            $this->mdl_categories->_delete($id);
            
            redirect('categories');
        }
        else {
            redirect('login', 'refresh');
        }
    }

}
