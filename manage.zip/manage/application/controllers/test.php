<?php
date_default_timezone_set("Asia/Kolkata");
if (!defined('BASEPATH'))
	exit('No direct script access allowed');
	
class Test extends CI_Controller {
	
	function __construct() {
		parent::__construct();
	}
	
	function index() {
		
		$this->db->where_in('id', array(5321,5322,5323,5324,5325,5326,5327,5328,5329,5330,5331,5332,5333,5334,5335,5336,5337,5338,5339,5340,5341,5345,5346,5347));
		$check = $this->db->get('orders');
		if($check->num_rows() > 0) {
			$orders = $check->result();
			
			echo "<pre>";
			print_r($orders);
			print_r($orders);
			echo "</pre>";
			
			$revenue = 0;
			foreach($orders as $order) {
				$grand_total = $order->grand_total;
				if($order->currency == 'usd') {
					$grand_total = $grand_total * 70;
				}
				$revenue += $grand_total;
				echo "<br>";
				echo "currency: " . $order->currency;
				echo "<br>";
				echo "grand_total: " . $order->grand_total;
				if($order->currency == 'usd') {
				echo "<br>grand_total_inr: " . ($order->grand_total * 65);
				}
				echo "<br>";
				echo $revenue;
				echo "<hr>";
			}
		}
		
		echo $revenue;
	}
}
