<?php
defined('BASEPATH') OR exit();

class Product_viewer extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$this->load->helper(array(
			'form',
			'email_improved_helper',
			'page_initiater_helper'
		));
	}
	
	function index() {
		
		$data                    		= initiate_page();
		$data['page_name']       		= 'Product Filter';
		$data['page_title']      		= 'Product Filter';
		$data['sidebar_element'] 		= 'side-products';
		$data['sidebar_subelement'] 	= 'side-products-filter';
		$data['seo_title']       		= 'New Stock';
		$data['seo_description'] 		= '';
		$data['seo_keywords']    		= '';
		
		$product_ids = array();
		
		$time_frame = 0;
		if($this->input->get('time_frame')) {
			$time_frame = (int) $this->input->get('time_frame');
		}
		
		if($time_frame > 0) {
			$start_date = date('Y-m-d', strtotime("today - {$time_frame} days"));
			$this->db->where('DATE(`added_date`) >=', $start_date);
		}
		
		$this->db->order_by('added_date', 'desc');
		$this->db->where('in_stock', 1);
		$this->db->select('product_id');
		$check = $this->db->get('stock_logs');
		
		if($check->num_rows() > 0) {
			foreach($check->result() as $product) {
				array_push($product_ids, $product->product_id);
			}
		}
		
		$product_ids = $product_ids;
		$filtered_product_ids = $this->get_filtered_products('get', array());
		
		//echo "<pre>";
		//print_r($filtered_product_ids);
		//echo "</pre>";
		
		//echo "<pre>";
		//print_r($product_ids);
		//echo "</pre>";
		
		$valid_product_ids = $product_ids;
		if(count($filtered_product_ids) > 0) {
			$valid_product_ids = array_intersect($product_ids, $filtered_product_ids);
		} else {
			//$valid_product_ids = array();
			$valid_product_ids = $product_ids;
			//if( ($this->input->get('categories', TRUE)) OR ($this->input->get('colors', TRUE)) OR ($this->input->get('time_frame', TRUE)) ) {
				
			//} else {
				//$valid_product_ids = array();
			//}
		}
		
		$products = array();
		
		
		if(count($valid_product_ids) > 0) {
			$check = $this->db->order_by('id', 'desc');
			$this->db->where_in('id', $valid_product_ids);
			$check = $this->db->get('products');
			if($check->num_rows() > 0) {
				$products = $check->result();
			}
		}
		
		$filters['categories'] = array();
		$filters['colors'] = array();
		$filters['time_frame'] = $time_frame;
		
		if($filter_categories = $this->input->get('categories', TRUE)) {
			if(trim($filter_categories) != '') {
				$filters['categories'] = explode(',', trim($filter_categories));
			}
		}
		
		if($filter_colors = $this->input->get('colors', TRUE)) {
			if(trim($filter_colors) != '') {
				$filters['colors'] = explode(',', trim($filter_colors));
			}
		}
		
		$categories = array();
		$check = $this->db->get('categories');
		if($check->num_rows() > 0) {
			$categories = $check->result();
		}
		
		$data['products'] = $products;
		$data['filters'] = $filters;
		$data['categories'] = $categories;
		
		$this->load->view('header', $data);
		$this->load->view('product_viewer_view', $data);
		$this->load->view('footer', $data);
		
	}
	
	
	function get_filtered_products($method, $discounted_prods_list) {
		
		$filtered_product_ids = array();
		$filters = array();
		$non_empty_arrays = array();
		
		if($filter_categories = $this->input->$method('categories', TRUE)) {
			
			if($method == 'get') {				
				if(trim($filter_categories) != '') {
					$filters['categories'] = explode(',', trim($filter_categories));
				}
			} else {
				if( (count($filter_categories) > 0) AND ( ! empty($filter_categories)) ) {
					$filters['categories'] = $filter_categories;
				}
			}
		}
		
		if(isset($filters['categories'])) {
			foreach($filters['categories'] as $cat_id) {
				$this->db->where('parent_id', $cat_id);
				$check = $this->db->get('categories');
				if($check->num_rows() > 0) {
					foreach($check->result() as $item) {
						array_push($filters['categories'], $item->id);
					}
				}
			}
		}
		
		//if($filter_sizes = $this->input->$method('sizes', TRUE)) {
			
			//if($method == 'get') {				
				//if(trim($filter_sizes) != '') {
					//$filters['sizes'] = explode(',', trim($filter_sizes));
				//}
			//} else {
				//if( (count($filter_sizes) > 0) AND ( ! empty($filter_sizes)) ) {
					//$filters['sizes'] = $filter_sizes;
				//}
			//}
			
		//}
		if($filter_colors = $this->input->$method('colors', TRUE)) {
			
			if($method == 'get') {				
				if(trim($filter_colors) != '') {
					$filters['colors'] = explode(',', trim($filter_colors));
				}
			} else {
				if( (count($filter_colors) > 0) AND ( ! empty($filter_colors)) ) {
					$filters['colors'] = $filter_colors;
				}
			}
			
		}
		//if($filter_fabrics = $this->input->$method('fabrics', TRUE)) {
			//if($method == 'get') {
				//if(trim($filter_fabrics) != '') {
					//$filters['fabrics'] = explode(',', trim($filter_fabrics));
				//}
			//} else {
				//if( (count($filter_fabrics) > 0) AND ( ! empty($filter_fabrics)) ) {
					//$filters['fabrics'] = $filter_fabrics;
				//}
			//}
		//}
		//if($filter_cuts = $this->input->$method('cuts', TRUE)) {
			//if($method == 'get') {				
				//if(trim($filter_cuts) != '') {
					//$filters['cuts'] = explode(',', trim($filter_cuts));
				//}
			//} else {
				//if( (count($filter_cuts) > 0) AND ( ! empty($filter_cuts)) ) {
					//$filters['cuts'] = $filter_cuts;
				//}
			//}
		//}
		//if($filter_minprice = $this->input->$method('minprice', TRUE)) {
			//if($method == 'get') {				
				//if(trim($filter_minprice) != '') {
					//$filters['minprice'] = trim($filter_minprice);
				//}
			//} else {
				//if( (count($filter_minprice) > 0) AND ( ! empty($filter_minprice)) ) {
					//$filters['minprice'] = $filter_minprice;
				//}
			//}
		//}
		//if($filter_maxprice = $this->input->$method('maxprice', TRUE)) {
			//if($method == 'get') {
				//if(trim($filter_maxprice) != '') {
					//$filters['maxprice'] = trim($filter_maxprice);
				//}
			//} else {
				//if( (count($filter_maxprice) > 0) AND ( ! empty($filter_maxprice)) ) {
					//$filters['maxprice'] = $filter_maxprice;
				//}
			//}
		//}
		
		if(count($filters) == 0) {
			return $filtered_product_ids;
		}
		
		if(isset($filters['categories'])) {
			$matched_categories = array();
			$categories = $filters['categories'];
			$this->db->select('product_id');
			$this->db->where_in('cat_id', $categories);
			$this->db->where('stock >', 0);
			$check = $this->db->get('skus');
			if($check->num_rows() > 0) {
				foreach($check->result() as $sku) {
					array_push($matched_categories, $sku->product_id);
				}
			}
			array_push($non_empty_arrays, $matched_categories);
		}
		
		//if(isset($filters['sizes'])) {
			//$matched_sizes = array();
			//$sizes = $filters['sizes'];
			//$this->db->select('product_id');
			//$this->db->where_in('size', $sizes);
			//$this->db->where('stock >', 0);
			//$check = $this->db->get('skus');
			//if($check->num_rows() > 0) {
				//foreach($check->result() as $sku) {
					//array_push($matched_sizes, $sku->product_id);
				//}
			//}
			//array_push($non_empty_arrays, $matched_sizes);
		//}
		
		if(isset($filters['colors'])) {
			$matched_colors = array();
			$colors = $filters['colors'];
			$colors = implode('|', $colors);
			$this->db->select('product_id');
			$this->db->where('attribute_name', 'color');
			$this->db->where('attribute_value REGEXP', $colors);
			$check = $this->db->get('product_attrs');
			if($check->num_rows() > 0) {
				foreach($check->result() as $attr) {
					array_push($matched_colors, $attr->product_id);
				}
			}
			array_push($non_empty_arrays, $matched_colors);
		}
		
		//echo "<pre>";
		//print_r($non_empty_arrays);
		//echo "</pre>";
		
		//if(isset($filters['fabrics'])) {
			//$matched_fabrics = array();
			//$fabrics = $filters['fabrics'];
			//$fabrics = implode('|', $fabrics);
			//$this->db->select('product_id');
			//$this->db->where('attribute_name', 'fabric');
			//$this->db->where('attribute_value REGEXP', $fabrics);
			//$check = $this->db->get('product_attrs');
			//if($check->num_rows() > 0) {
				//foreach($check->result() as $attr) {
					//array_push($matched_fabrics, $attr->product_id);
				//}
			//}
			//array_push($non_empty_arrays, $matched_fabrics);
		//}
		
		//if(isset($filters['cuts'])) {
			//$matched_cuts = array();
			//$cuts = $filters['cuts'];
			//$this->db->select('product_id');
			//$this->db->where('attribute_name', 'cut');
			//$this->db->where_in('attribute_value', $cuts);
			//$check = $this->db->get('product_attrs');
			//if($check->num_rows() > 0) {
				//foreach($check->result() as $attr) {
					//array_push($matched_cuts, $attr->product_id);
				//}
			//}
			//array_push($non_empty_arrays, $matched_cuts);
		//}
		
		//if( isset($filters['minprice']) ) {
			//$matched_prices = array();
			//$minprice = $filters['minprice'];
			//if(isset($filters['maxprice'])) {
				//$maxprice = $filters['maxprice'];
			//} else {
				//$maxprice = 10000000000;
			//}
			//$this->db->select('product_id');
			//$this->db->where('price >=', $minprice);
			//$this->db->where('price <=', $maxprice);
			//$this->db->where('stock >', 0);
			//$check = $this->db->get('skus');
			//if($check->num_rows() > 0) {
				//foreach($check->result() as $sku) {
					//array_push($matched_prices, $sku->product_id);
				//}
			//}
			
			//$matched_discounts = array();
			//$discounted_prod_ids = array();
			//foreach($discounted_prods_list as $key => $value) {
				//array_push($discounted_prod_ids, $key);
			//}
			
			//if(count($discounted_prod_ids) > 0) {
				
				//$this->db->where_in('product_id', $discounted_prod_ids);
				//$this->db->where('stock >', 0);
				//$check = $this->db->get('skus');
				//if($check->num_rows() > 0) {
					//foreach($check->result() as $sku) {
						//$price = $sku->price;
						//$percentage = $discounted_prods_list[$sku->product_id];
						//$discounted_price = $price * (1 - ($percentage/100));
						//if( ($discounted_price >= $minprice) AND ($discounted_price <= $maxprice) ) {
							//array_push($matched_prices, $sku->product_id);
						//}
					//}
				//}
				
			//}
			
			//array_push($non_empty_arrays, $matched_prices);
		//}
		
		
		if(count($non_empty_arrays) > 1) {
			$filtered_product_ids = array_intersect($non_empty_arrays[0], $non_empty_arrays[1]);
		} else {
			$filtered_product_ids = $non_empty_arrays[0];
		}
		
		//echo "<pre>";
		//print_r($non_empty_arrays);
		//echo "</pre>";
		
		$filtered_product_ids = array_unique($filtered_product_ids);
		return $filtered_product_ids;
		
	}
	
}
