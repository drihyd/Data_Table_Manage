<?php

defined('BASEPATH') or exit('no direct script access allowed');

class Names_filter extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		$models = array(
			// add models
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
    }
	
	function index() {
		
		$data = initiate_page();
		
		$query = "SELECT * FROM `customers` where `name` like 'ali%' or `name` like '% ali' or `name` like '%moham%' or `name` like '%muham%' or `name` like '%shaik%' or `name` like '%sheik%' or `name` like '%sheik%' or `name` like '%hus%' or `name` like '%aisha%' or `name` like '%ayesha%' or `name` like '%riz%' or `name` like '%sye%' or `name` like '%saye%' or `name` like '%abdu%' or `name` like '%hasee%' or `name` like '%khan' or `name` like '%hee%' or `name` like '%heen%' or `name` like '%din' or `name` like '%sult%' or `name` like '%beg%' or `name` like '%shah%' or `name` like '%sum' or `name` like 'sana%' or `name` like '%zib%' or `name` like '%z%' or `name` like '%sina' or `name` like '%shee%' or `name` like '%eeb%' or `name` like '%banu%' or `name` like '%bdul%' or `name` like '%uddin%' or `name` like '%bbas%' or `name` like '%eem%' or `name` like '%mirz%' or `name` like '%fee%' or `name` like '%raf%' or `name` like '%q%' or `name` like '%arkh%' or `name` like '%lil%' or `name` like '%fathi%' or `name` like '%neesa%' or `name` like '%nisa%' or `name` like '%fati%' or `name` like '%mumt%' or `name` like '%musk%' or `name` like '%khu%' or `name` like '%bee%' or `name` like '%ahmad%' or `name` like '%wah%'";
		
		$customers = array();
		
		$check = $this->db->query($query);
		if($check->num_rows() > 0) {
			$customers = $check->result();
		}
		
		$filtered = array();
		$record = array();
		
		
		foreach($customers as $customer) {
			$email = $customer->email;
			if($customer->is_guest == 1) {
				$email = $customer->guest_email;
			}
			
			if( ! in_array($email, $record)) {
				array_push($record, $email);
				array_push($filtered, array('name' => $customer->name, 'email' => $email));
			}
		}
		
		echo "<table>";
		foreach($filtered as $a) {
			echo "<tr>";
			echo "<td>" . ucwords(strtolower($a['name'])) . "</td>";
			echo "<td>" . $a['email'] . "</td>";
			echo "</tr>";
		}
		echo "</table>";
		
	}
	
}
