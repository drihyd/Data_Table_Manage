<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');
class Wishlists extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper'
		);
		$models  = array(
			'model_wishlists' => 'wishlists',
			'model_categories' => 'categories',
			'model_customers' => 'customers',
			'model_products' => 'products',
			'model_skus' => 'skus',
			'model_users' => 'users'
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
	
	function index() {
		
		$data = initiate_page();
		$data['page_name']       = 'Wishlists';
		$data['page_title']      = 'Wishlists';
		
		$data['sidebar_element'] = 'side-customers';
		$data['sidebar_subelement'] = 'side-wishlists';
		
		$data['seo_title']       = 'Wishlists';
		$data['seo_description'] = '';
		$data['seo_keywords']    = '';
		
		$wishlists = array();
		$wishlist_products = array();
		$product_index = array();
		
		$check = $this->wishlists->get_all();
		if($check->num_rows() > 0) {
			$wishlists = $check->result();
		}
		$data['wishlists'] = $wishlists;
		
		foreach($wishlists as $wishlist) {
			$products = trim($wishlist->products_list);
			if($products == '') {
				CONTINUE;
			}
			$products = explode(',', $products);
			foreach($products as $product) {
				if( ! isset($wishlist_products["{$product}"])) {
					$wishlist_products["{$product}"] = 0;
				}
				$wishlist_products["{$product}"] += 1;
			}
		}
		arsort($wishlist_products, SORT_NUMERIC);
		$data['wishlist_products'] = $wishlist_products;
		
		foreach($wishlist_products as $key => $value) {
			$product_id = $key;
			if(isset($product_index[$key])) {
				CONTINUE;
			}
			$check = $this->products->get($product_id);
			if($check->num_rows() == 0) {
				$product_index[$key] = 'unknown';
				CONTINUE;
			}
			$product_index[$key] = $check->row();
		}
		$data['product_index'] = $product_index;
		
		$this->load->view('header', $data);
		$this->load->view('wishlists_view', $data);
		$this->load->view('footer', $data);
	}
}
