<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Upload_postalcodes extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'form',
            'page_initiater_helper',
        );
        $models = array(
            'model_postalcodes' => 'pincodes',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function index() {
		
		$data = initiate_page();
        $data['page_name'] = 'Upload Pincodes';
        $data['page_title'] = 'Upload Pincodes';
        
        $data['sidebar_element'] = 'side-bulk-upload';
        $data['sidebar_subelement'] = 'side-postalcodes-upload';
        
        $data['seo_title'] = 'Upload Pincodes';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';		
		
		$this->load->view('header', $data);
		$this->load->view('postalcodes_upload_view', $data);
		$this->load->view('footer', $data);
	}
	
	function upload() {
		
		$data = initiate_page();
        $data['page_name'] = 'Upload Pincodes';
        $data['page_title'] = 'Upload Pincodes';
        
        $data['sidebar_element'] = 'side-bulk-upload';
        $data['sidebar_subelement'] = 'side-postalcodes-upload';
        
        $data['seo_title'] = 'Upload Pincodes';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
		
		echo 
		
		$this->load->helper('file_upload_helper');
		$path = '../assets/uploads/postalcodes_upload';
		$allowed_types = '*';
		$file_name = 'postalcodes_upload.xlsx';
		$overwrite = TRUE;
		
		echo "<div style='display:block;margin: 0 auto;width:240px;text-align:center;'><img src='{$this->config->base_url()}img/loader.gif'><p style='text-align:center;'>Please Wait...</p></div>";
		
		$result = upload_file('postalcodesFile', $path, $allowed_types, $file_name, $overwrite);
		if($result['failure'] == TRUE) {
			$this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>{$result['message']}</strong></div>");
			redirect('upload_postalcodes', 'refresh');
		}
		if($result['success'] == TRUE) {
			//$this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>{$result['message']}</strong></div>");
			redirect('upload_postalcodes/import_postalcodes', 'refresh');
		}
		
		
	}
	
	function import_postalcodes() {
		
		$data = initiate_page();
        $data['page_name'] = 'Upload Pincodes';
        $data['page_title'] = 'Upload Pincodes';
        
        $data['sidebar_element'] = 'side-bulk-upload';
        $data['sidebar_subelement'] = 'side-postalcodes-upload';
        
        $data['seo_title'] = 'Upload Pincodes';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
		
		require APPPATH . 'controllers/class/PHPExcel.php';
		require_once APPPATH . 'controllers/class/PHPExcel/IOFactory.php';
		
		$path     = '../assets/uploads/postalcodes_upload/postalcodes_upload.xlsx';
		$path_csv = '../assets/uploads/postalcodes_upload/postalcodes_upload.csv';
		
		$objPHPExcel = PHPExcel_IOFactory::load($path);
		$writer = PHPExcel_IOFactory::createWriter($objPHPExcel, 'CSV');
		$writer->save($path_csv);
		
		$file  = $path_csv;
		ini_set('auto_detect_line_endings', TRUE);
		$handle = fopen($file, 'r');
		
		if (($csv_data = fgetcsv($handle)) === FALSE) {
			echo "Cannot read from csv {$file}";
			die();
		}
		
		$headers = array();
		$header_count = 0;
		
		for ($i = 0; $i < count($csv_data); $i++) {
			$f = strtolower(trim($csv_data[$i]));
			if ($f) {
				$f = trim(strtolower($f));
				$f = preg_replace('/[^0-9a-z]/', ' ', $f);
				$f = trim($f);
				$f = preg_replace('/[^0-9a-z]\s*/', ' ', $f);
				$f = preg_replace('/[^0-9a-z]/', '_', $f);
				$header_count++;
				$headers[] = preg_replace('/[^0-9a-z]/', '_', $f);
			}
		}
		
		$rows = array();
		while (($csv_data = fgetcsv($handle)) !== FALSE) {
			$temp_array = array();
			for ($i = 0; $i < $header_count; $i++) {
				$temp_array[$headers[$i]] = trim(strtolower($csv_data[$i]));
			}
			$rows[] = $temp_array;
		}
		
		$row_count = 0;
		foreach($rows as $row) {
			
			$row_count += 1+1;
			$valid_cod_states = array(
				'cod',
				'no cod',
			);
			
			$postal_code = $row['postal_code'];
			$city_name = $row['city_name'];
			$cod_info = $row['cod_serviceable_domestic_only'];
			
			if( ! in_array($cod_info, $valid_cod_states)) {
				$this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid COD status on row {$row_count}.</strong></div>");
				redirect('upload_postalcodes', 'refresh');
			}
		}
		
		$row_count = 0;
		foreach($rows as $row) {
			
			$postal_code = $row['postal_code'];
			$city_name = $row['city_name'];
			$cod_info = $row['cod_serviceable_domestic_only'];
			
			if($cod_info == 'no cod') {
				$cod_available = 0;
			}
			
			if($cod_info == 'cod') {
				$cod_available = 1;
			}
			
			$new_data = array(
				'postalcode' => $postal_code,
				'city' => $city_name,
				'cod_available' => $cod_available,
			);
			
			$check = $this->db->get_where('postalcodes', array('postalcode' => $postal_code));
			if($check->num_rows() > 0) {
				$id = $check->row()->id;
				$orig_cod_available = $check->row()->cod_available;
				if($orig_cod_available != $cod_available) {
					$this->db->where('id', $id);
					$this->db->update('postalcodes', $new_data);
				}
			} else {
				$this->db->insert('postalcodes', $new_data);
			}
			
		}
		
		$this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Postal codes successfully updated!</strong></div>");
		redirect('upload_postalcodes', 'refresh');
		
	}
}
