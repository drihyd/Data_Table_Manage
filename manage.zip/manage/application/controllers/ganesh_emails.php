<?php

defined('BASEPATH') or exit('no direct script access allowed');

class Ganesh_emails extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		$models = array(
			// add models
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
	
	function index() {
		
		$data = initiate_page();
		
		$ganesh_emails = array();
		
		$this->db->where('coupon_id !=', 0);
		$check = $this->db->get('ganesh_game');
		foreach($check->result() as $game) {
			
			
			$this->db->where('id', $game->user_id);
			$check = $this->db->get('customers');
			
			if($check->num_rows() > 0) {
				$customer = $check->row();
				
				$email = $customer->email;
				if($customer->is_guest == 1) {
					$email = $customer->guest_email;
				}
				
				$name = ucwords($customer->name);
				
				array_push($ganesh_emails, array('name' => $name, 'email' => $email));
			}
		}
		
		echo "<table>";
		foreach($ganesh_emails as $a) {
			echo "<tr>";
			echo "<td>" . ucwords(strtolower($a['name'])) . "</td>";
			echo "<td>" . $a['email'] . "</td>";
			echo "</tr>";
		}
		echo "</table>";
			
	}
	
}
