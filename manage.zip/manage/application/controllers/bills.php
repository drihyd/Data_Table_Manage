<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class bills extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
            'page_initiater_helper',
        );
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function index() {
		$data = initiate_page();
		
		$all_orders = array();
		
		$from_date = '2017-04-01';
		$to_date = '2018-03-31';
		
		$this->db->where("DATE(ordered_on) >=", $from_date);
		$this->db->where("DATE(ordered_on) <=", $to_date);
		$this->db->where_not_in("order_status", array('cancelled', 'cancelled-refunded', 'cancelled-refund-pending'));
		$this->db->where("grand_total >", 0);
		$this->db->where("total_items >", 0);
		$check = $this->db->get('orders');
		
		if($check->num_rows() > 0) {
			$all_orders = $check->result();
		}
		
		
		$order_rows = array();
		foreach($all_orders as $order) {
			
			$row = array();
			
			$products = array();
			$this->db->where('order_id', $order->id);
			$check = $this->db->get('order_items');
			if($check->num_rows() > 0) {
				foreach($check->result() as $product) {
					$id = $product->product_id;
					$this->db->where('id', $id);
					$product_details = $this->db->get('products');
					array_push($products, $product_details->row()->name . '(' . $product->sku_code .')');
				}
			}
			
			$row['order_id']           = $order->id;
			$row['customer_id']        = $order->customer_id;
			$row['products']           = $products;
			$row['shipped_to_name']    = $order->ship_to_name;
			$row['shipped_to_email']   = $order->ship_to_email;
			$row['shipped_to_country'] = $order->ship_to_country;
			$row['shipped_to_state']   = $order->ship_to_state;
			$row['shipped_to_city']    = $order->ship_to_city;
			$row['shipped_to_pincode'] = $order->ship_to_postalcode;
			$row['shipped_to_address'] = $order->ship_to_address;
			$row['currency']           = $order->currency;
			$row['shipping_charges']   = $order->shipping_cost;
			$row['grand_total']        = $order->grand_total;
			$row['ordered_on_date']    = $order->ordered_on;
			
			array_push($order_rows, $row);
		}
		
		//echo "<pre>";
		//print_r($order_rows);
		//echo "</pre>";
?>
		<table>
			<thead>
				<tr>
					<th>Order ID</th>
					<th>Customer ID</th>
					<th>Products Ordered</th>
					<th>Shipped to Name</th>
					<th>Shipped to Country</th>
					<th>Shipped to State</th>
					<th>Shipped to City</th>
					<th>Shipped to Pincode</th>
					<th>Shipped to Address</th>
					<th>Currency</th>
					<th>Shipping Charges</th>
					<th>Grand Total</th>
					<th>Date</th>
				</tr>
			</thead>
			
			<tbody>
<?php
foreach($order_rows as $order) { ?>
				<tr>
					<td><?php echo $order['order_id']; ?></td>
					<td><?php echo $order['customer_id']; ?></td>
					<td>
						<?php
							foreach($order['products'] as $product) {
								echo ucwords($product) . '<br>';
							}
						?>
					</td>
					<td><?php echo ucwords($order['shipped_to_name']) . ' (' . $order['shipped_to_email'] . ')'; ?></td>
					<td><?php echo ucwords($order['shipped_to_country']); ?></td>
					<td><?php echo ucwords($order['shipped_to_state']); ?></td>
					<td><?php echo ucwords($order['shipped_to_city']); ?></td>
					<td><?php echo ucwords($order['shipped_to_pincode']); ?></td>
					<td><?php echo ucfirst($order['shipped_to_address']); ?></td>
					<td><?php echo strtoupper($order['currency']); ?></td>
					<td><?php echo $order['shipping_charges']; ?></td>
					<td><?php echo $order['grand_total']; ?></td>
					<td><?php echo date('d M, Y', strtotime($order['ordered_on_date'])); ?></td>
				</tr>
<?php
} ?>
			</tbody>
		</table>

<?php

	}
	
	
	function pays() {
		$data = initiate_page();
		
		$all_orders = array();
		
		$from_date = '2017-04-01';
		$to_date = '2018-03-31';
		
		$this->db->where("DATE(ordered_on) >=", $from_date);
		$this->db->where("DATE(ordered_on) <=", $to_date);
		$this->db->where_not_in("order_status", array('cancelled', 'cancelled-refunded', 'cancelled-refund-pending'));
		$this->db->where("grand_total >", 0);
		$this->db->where("total_items >", 0);
		$check = $this->db->get('orders');
		
		if($check->num_rows() > 0) {
			$all_orders = $check->result();
		}
		
		$total_orders = $check->num_rows();
		$cod = 0;
		$paypal = 0;
		$ebs = 0;
		$ebs_abroad = 0;
		$ebs_india = 0;
		
		foreach($all_orders as $order) {
			if($order->payment_mode == 'cod') {
				$cod += 1;
			} else {
				$payment_id = $order->payment_id;
				$this->db->where('id', $payment_id);
				$check = $this->db->get('payments');
				if($check->num_rows() > 0) {
					if($check->row()->paypal_payment == 1) {
						$paypal += 1;
					} else {
						$ebs += 1;
						
						if(strtolower($order->ship_to_country) != 'india') {
							$ebs_abroad += 1;
						} else {
							$ebs_india += 1;
						}
					}
				}
			}
		}
		
		echo "total orders: " . $total_orders . '<br>';
		echo "total CODs: " . $cod . " (" . round(($cod/$total_orders) * 100, 2) . "%)" . '<br>';
		echo "total Paypal: " . $paypal . " (" . round(($paypal/$total_orders) * 100, 2) . "%)" . '<br>';
		echo "total EBS: " . $ebs . " (" . round(($ebs/$total_orders) * 100, 2) . "%)" . '<br>';
		echo "<hr>";
		echo "EBS Abroad: " . $ebs_abroad . " (" . round(($ebs_abroad/$ebs) * 100, 2) . "%)" . '<br>';
		echo "EBS India: " . $ebs_india . " (" . round(($ebs_india/$ebs) * 100, 2) . "%)" . '<br>';
	}
}
