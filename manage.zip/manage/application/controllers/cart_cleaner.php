<?php

defined('BASEPATH') OR exit();

class Cart_cleaner extends CI_Controller {
	
	function __construct() {
		parent::__construct();
	}
	
	function index() {
		$this->delete_old_empty_carts();
	}
	
	private function delete_old_empty_carts() {
		//$this->db->where('total_items', 0);
		$this->db->where('checked_out', 0);
		$this->db->where("DATE(`date`) <", date('Y-m-d', strtotime('-30 days')));
		$this->db->where("DATE(`last_modified`) <", date('Y-m-d', strtotime('-30 days')));
		$this->db->or_where("DATE(`last_modified`)", NULL);
		
		$carts = $this->db->delete('carts');
		
		echo "<pre>";
		//print_r($carts->result());
		echo "</pre>";
	}
	
	private function delete_unused_customer_carts() {
		
		$tracker = array();
		$i = 0;
		
		do {
			
			//$this->db->limit('500');
			$this->db->order_by('id', 'desc');
			$this->db->where('user_id >', 0);
			$this->db->where('checked_out', 0);
			
			if(count($tracker) > 0) {
				$this->db->where_not_in('user_id', $tracker);
			}
			
			$latest_check = $this->db->get('carts');
			echo $this->db->last_query(). '<br>';
			
			if($latest_check->num_rows() > 0) {
				
				$latest_cart = $latest_check->row();
				//$this->db->where('user_id', $latest_cart->user_id);
				//$this->db->where('checked_out', 0);
				//$this->db->where('id !=', $latest_cart->id);
				//$this->db->delete('carts');
				
				array_push($tracker, $latest_cart->user_id);
			}
			
			$i += 1;
			
		} while($latest_check->num_rows() > 0);
		//} while($i < 100);
		
	}
	
}
