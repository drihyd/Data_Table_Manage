<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');
	
class Cart_responder extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'page_initiater_helper',
			'coupon_helper',
		);
		$models  = array(
			'model_carts' 		=> 'carts',
			'model_cart_items' 	=> 'cart_items',
			'model_products' 	=> 'products',
			'model_skus' 		=> 'skus',
			'model_customers' 	=> 'customers',
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
	
	function index() {
		
		//$data               = initiate_page();
		$data['page_name']  = 'Abandoned Carts';
		$data['page_title'] = 'Abandoned Carts';
		
		$data['sidebar_element'] = 'side-abandoned-carts';
		
		$data['seo_title']       = 'Abandoned Carts';
		$data['seo_description'] = '';
		$data['seo_keywords']    = '';
		
		$this->load->helper('email_new_helper');
		$this->load->helper('email_api_helper');
		
		$hot_carts = array();
		$check = $this->carts->get_hot_carts();
		//echo $this->db->last_query();
		//print_r($check->num_rows());
		
		if($check->num_rows() > 0) {
			$hot_carts = $check->result();
		}
		
		$check = $this->carts->get_scheduled_carts();
		if($check->num_rows() > 0) {
			$hot_carts = array_merge($hot_carts, $check->result());
		}
		
		$data['carts'] = $hot_carts;
		$data['justsee'] = null;
		
		$cart_details_index = array();
		$cart_item_index = array();
		$product_index = array();
		$sku_index = array();
		
		foreach($hot_carts as $cart) {
			
			if($cart->user_id != 0) {
				$email = $this->customers->get_customer_email($cart->user_id);
				$name = $this->customers->get_customer_name($cart->user_id);
			} else if($cart->ship_to_email != '') {
				$email = $cart->ship_to_email;
				$name = $cart->ship_to_name;
			} else if($cart->bill_to_email != '') {
				$email = $cart->bill_to_email;
				$name = $cart->bill_to_name;
			} else {
				CONTINUE;
			}
						
			if($email == '' or $name == '') {
				CONTINUE;
			}
			
			
			
			$cart_details_index[$cart->id] = array(
				'name' => $name,
				'email' => $email,
			);
			
			$utms = "?utm_source=website%20db&utm_medium=emailer&utm_campaign=abandoned%20cart%20mailer&utm_term=regular&utm_content=&";
			
			$data['discount_mailer'] = FALSE;
			$data['abandon_coupon_id'] = 0;
			
			//echo $cart->schedule_discount;
			
			
			$cart_items = $this->cart_items->get_cart_items($cart->id);
			if($cart_items->num_rows() == 0) {
				CONTINUE;
			}
			
			$cart_items = $cart_items->result();
			$cart_item_index[$cart->id] = $cart_items;
			$final_products = array();
			
			foreach($cart_items as $cart_item) {
				$sku_id = $cart_item->sku_id;
				if( ! isset($sku_index[$sku_id])) {
					$sku_details = $this->skus->get($sku_id);
					if($sku_details->num_rows() == 0) {
						CONTINUE;
					}
					if($sku_details->row()->stock <= 0) {
						CONTINUE;
					}
					$sku_details = $sku_details->row();
	
					$sku_index[$sku_id] = $sku_details;
					$product_id = $sku_details->product_id;
					array_push($final_products, $cart_item);
					
					if( ! isset($product_index[$product_id])) {
						$product_details = $this->products->get($product_id);
						if($product_details->num_rows() == 0) {
							CONTINUE;
						}
						$product_details = $product_details->row();
						$product_index[$product_id] = $product_details;
					}
				}
			}
			
			if(count($final_products) <= 0) {
				CONTINUE;
			}
			$data['final_products'] = $final_products;
			
			if( ($cart->schedule_discount != NULL) AND (time() >= strtotime($cart->schedule_discount)) ) {
				
				$data['discount_mailer'] = TRUE;
				
				$coupon = create_abandoned_percent_coupon();
				
				$data['percent_off'] = $coupon->value;
				$data['min_order_value'] = $coupon->min_order_value;
				$data['code'] = $coupon->code;
				$data['abandon_coupon_id'] = $coupon->id;
				
				$utms = "?utm_source=website%20db&utm_medium=emailer&utm_campaign=abandoned%20cart%20mailer&utm_term=with_incentive&utm_content=&";
			}
			
			$data['utms'] = $utms;
			
			$data['cart_id'] = $cart->id;
			$data['cart_items'] = $cart_items;
			$data['cart_details_index'] = $cart_details_index;
			$data['cart_items_index'] = $cart_item_index;
			$data['product_index'] = $product_index;
			$data['sku_index'] = $sku_index;
			
			$this->load->view('cart_responder_view', $data);
		}
		
		
		
		//$this->load->view('header/header', $data);
		//$this->load->view('cart_responder_view', $data);
		//$this->load->view('footer/footer', $data);
	}
	
}
