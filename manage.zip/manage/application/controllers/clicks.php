<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Clicks extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'form',
			'email_helper',
            'page_initiater_helper',
        );
        $models = array();
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    
	function index() {
		
		$data = initiate_page();
        $data['page_name']  = 'Clicks';
        $data['page_title'] = 'Clicks';
        
        $data['sidebar_element']    = 'side-customers';
        $data['sidebar_subelement'] = 'side-clicks';
        
        $data['seo_title']          = 'Clicks';
        $data['seo_description']    = '';
        $data['seo_keywords']       = '';
		
		$clicks = array();
		$this->db->order_by('click_date_captured', 'DESC');
		$check = $this->db->get('clicks');
		if($check->num_rows() > 0) {
			$record = array();
			foreach($check->result() as $click) {
				if( ! in_array($click->click_user_id, $record)) {
					array_push($record, $click->click_user_id);
					array_push($clicks, $click);
				}
			}
		}
		$data['clicks'] = $clicks;
		
		$this->load->view('header', $data);
		$this->load->view('clicks_view', $data);
		$this->load->view('footer', $data);
		
	}
	
	function click_info($click_user_id) {
		
		$data = initiate_page();
        $data['page_name']  = 'Clicks';
        $data['page_title'] = 'Clicks';
        
        $data['sidebar_element']    = 'side-customers';
        $data['sidebar_subelement'] = 'side-clicks';
        
        $data['seo_title']          = 'Clicks';
        $data['seo_description']    = '';
        $data['seo_keywords']       = '';
		
		$click_id = (int) $click_user_id;
		if( ! $click_id) {
			$this->session->set_flashdata('form_errors', "Invalid ID");
			redirect('clicks', 'refresh');
		}
		
		$check = $this->db->get_where('clicks', array('click_user_id' => $click_user_id));
		if($check->num_rows() <= 0) {
			$this->session->set_flashdata('form_errors', "Invalid ID");
			redirect('clicks', 'refresh');
		}
		$data['clicks_info'] = $check->result();
		
		$this->load->view('header', $data);
		$this->load->view('click_info_view', $data);
		$this->load->view('footer', $data);
		
	}
	
	function delete_click() {
		$data = initiate_page();
		
		$result = array(
			'success' => FALSE,
			'error' => FALSE,
			'error_message' => array(),
			'success_message' => array(),
		);
		$error = 0;
		$errors = array();
		
		$file_name = $this->input->get('file_name', TRUE);
		$user_id   = (int) $this->input->get('user_id', TRUE);
		
		$check = $this->db->get_where('clicks', array('click_user_id' => $user_id));
		if($check->num_rows() <= 0) {
			$this->session->set_flashdata('alert-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Sorry, the image you are trying to delete doesn't exist.</strong></div>");
			redirect('clicks/click_info/' . $user_id);
		}
		
		foreach($check->result() as $click) {
			$images = $click->click_img_paths;
			$images = explode(',', $images);
			$images = array_filter($images);
			
			foreach($images as $key => $image) {
				//echo '-' . $image . '<br>';
				if($image == $file_name) {
					unset($images[$key]);
				}
			}
			
			$images = array_filter($images);
			$images = implode(',', $images);
			$images = trim($images);
			
			$new_data = array(
				'click_img_paths' => $images,
			);
			
			$this->db->where('click_id', $click->click_id);
			$this->db->update('clicks', $new_data);
		}
		
		$this->session->set_flashdata('alert-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Image deleted successfully.</strong></div>");
		redirect('clicks/click_info/' . $user_id);
	}
}
