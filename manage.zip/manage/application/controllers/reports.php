<?php
date_default_timezone_set("Asia/Kolkata");
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Reports extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_orders', '', TRUE);
        $this->load->model('mdl_order_items', '', TRUE);
        $this->load->model('mdl_categories', '', TRUE);
        $this->load->model('mdl_products', '', TRUE);
        $this->load->model('mdl_skus', '', TRUE);
        $this->load->model('mdl_customers', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index($monthYear=false) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'reports';
            $data['page_title'] = 'All Reports';
            
            $data['sidebar_element'] = 'side-monitor';
            $data['sidebar_subelement'] = 'side-reports-view';
            
            if($monthYear) {
              $monthYear = explode('-', htmlspecialchars($monthYear));
            }
            $month = (int) $monthYear[0];
            $year = (int) $monthYear[1];
            
            
            $this->db->order_by("id", "desc");
            //$this->mdl_orders->get_where_custom('DATE(ordered_on) >=', date('Y-m-d', strtotime('-30 days')))->result();
            //$this->mdl_orders->get_where_custom('YEAR(ordered_on)', date('Y', time()))->result();
            //$this->db->where('order_status', 'delivered');
            if( (isset($month)) && ($month > 0) && (isset($year)) && ($year > 0) ) {
              $this->db->where('YEAR(ordered_on)', $year);
              $orders = $this->mdl_orders->get_where_custom('MONTH(ordered_on)', $month)->result();
              $data['month'] = $month;
              $data['year'] = $year;
            } else {
			  redirect('reports/index/' . date('m-Y', time()), 'refresh');
              exit();
              $orders = $this->mdl_orders->get_where_custom('MONTH(ordered_on)', date('m', time()))->result();
            }
            $data['orders'] = $orders;
            
            $skus = $this->mdl_skus->get('id');
            $skus_list = array();

            foreach($skus->result() as $sku) {
                $skus_list[$sku->id] = $sku;
            }
            
            $categories = $this->mdl_categories->get('id');
            $categories_list = array();

            foreach($categories->result() as $category) {
                $categories_list[$category->id] = $category;
            }
            
            $products = $this->mdl_products->get('id');
            $products_list = array();

            foreach($products->result() as $product) {
                $products_list[$product->id] = $product;
            }
            
            
            $orders_status_num = array();
            $orders_cat_num = array();
            $cat_rev = array();
            $product_rev = array();
            $sku_rev = array();
            $cat_qty = array();
            $product_qty = array();
            $sku_qty = array();
            $orders_product_num = array();
            $orders_sku_num = array();
            $orders_custom_num = 0;
            $orders_unstitched_num = 0;
            $order_size_num = array();
            $payment_cod_num = 0;
            $payment_epay_num = 0;
            $total_revenue = 0;
            
            foreach($orders as $order) {
                
                //total revenue 
                if( ($order->order_status == 'delivered') OR ($order->order_status == 'dispatched') OR ($order->order_status == 'processing') OR ($order->order_status == 'placed')) :
                    $total_revenue += $order->grand_total;
                endif;
                
                //gather order statuses
                if(isset($orders_status_num[$order->order_status])) {
                    $orders_status_num[$order->order_status] += 1;
                }
                else {
                    $orders_status_num[$order->order_status] = 1;
                }
                
                //gather payment modes
                if($order->payment_mode == 'cod') {
                    $payment_cod_num += 1;
                }
                else {
                    $payment_epay_num += 1;
                }
                
                //order items
                $order_items = $this->mdl_order_items->get_where_custom('order_id', $order->id);
                foreach($order_items->result() as $order_item) {
                    
                    //gather category numbers
                    if(isset($orders_cat_num[$order_item->cat_id])) {
                        $orders_cat_num[$order_item->cat_id] += 1;
                        $cat_rev[$order_item->cat_id] += $order_item->net_price;
                        $cat_qty[$order_item->cat_id] += $order_item->qty;
                    }
                    else {
                        $orders_cat_num[$order_item->cat_id] = 1;
                        $cat_rev[$order_item->cat_id] = $order_item->net_price;
                        $cat_qty[$order_item->cat_id] = $order_item->qty;
                    }
                    
                    //gather product numbers
                    if(isset($orders_product_num[$order_item->product_id])) {
                        $orders_product_num[$order_item->product_id] += 1;
                        $product_rev[$order_item->product_id] += $order_item->net_price;
                        $product_qty[$order_item->product_id] += $order_item->qty;
                    }
                    else {
                        $orders_product_num[$order_item->product_id] = 1;
                        $product_rev[$order_item->product_id] = $order_item->net_price;
                        $product_qty[$order_item->product_id] = $order_item->qty;
                    }
                    
                    //gather sku numbers
                    if(isset($orders_sku_num[$order_item->sku_id])) {
                        $orders_sku_num[$order_item->sku_id] += 1;
                        $sku_rev[$order_item->sku_id] += $order_item->net_price;
                        $sku_qty[$order_item->sku_id] += $order_item->qty;
                    }
                    else {
                        $orders_sku_num[$order_item->sku_id] = 1;
                        $sku_rev[$order_item->sku_id] = $order_item->net_price;
                        $sku_qty[$order_item->sku_id] = $order_item->qty;
                    }
                    
                    //gather customized numbers
                    if($order_item->custom) :
                        $orders_custom_num += 1;
                    endif;
                    
                    //gather unstitched numbers
                    if($order_item->unstitched) :
                        $orders_unstitched_num += 1;
                    endif;
                    
                    //gather size numbers
                    if(isset($skus_list[$order_item->sku_id])) {
						if(isset($orders_size_num[$skus_list[$order_item->sku_id]->size])) {
							$orders_size_num[$skus_list[$order_item->sku_id]->size] += 1;
						} else {
							$orders_size_num[$skus_list[$order_item->sku_id]->size] = 1;
						}
					}
                    
                }
                    

            }
            
            $data['orders_status_num'] = $orders_status_num;
            $data['orders_cat_num'] = $orders_cat_num;
            $data['cat_rev'] = $cat_rev;
            $data['cat_qty'] = $cat_qty;
            $data['orders_product_num'] = $orders_product_num;
            $data['product_rev'] = $product_rev;
            $data['product_qty'] = $product_qty;
            $data['orders_sku_num'] = $orders_sku_num;
            $data['sku_rev'] = $sku_rev;
            $data['sku_qty'] = $sku_qty;
            $data['orders_custom_num'] = $orders_custom_num;
            $data['orders_unstitched_num'] = $orders_unstitched_num;
            $data['order_size_num'] = $order_size_num;
            $data['payment_cod_num'] = $payment_cod_num;
            $data['payment_epay_num'] = $payment_epay_num;
            $data['total_revenue'] = $total_revenue;
            
            $data['skus_list'] = $skus_list;
            $data['categories_list'] = $categories_list;
            $data['products_list'] = $products_list;
            
            $this->load->view('header', $data);
            $this->load->view('reports_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function today() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'orders';
            $data['page_title'] = 'All orders';
            
            $data['sidebar_element'] = 'side-orders';
            $data['sidebar_subelement'] = 'side-orders-view';
            
            $this->load->model('mdl_products');
            $this->load->model('mdl_skus');
            $this->load->model('mdl_product_images');
            
            $today_date = date('Y-m-d', time());
            
            $this->db->order_by("id", "desc");
            $orders = $this->mdl_orders->get_where_custom('date(ordered_on)', $today_date)->result();
            $data['orders'] = $orders;
            
            $orders_num = array();
            foreach($orders as $order) {
                if(isset($orders_num[$order->order_status])) {
                    $orders_num[$order->order_status] += 1;
                }
                else {
                    $orders_num[$order->order_status] = 1;
                }
            }
            
            $data['orders_num'] = $orders_num;
            
            $this->load->view('header', $data);
            $this->load->view('orders_today_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function month() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'orders';
            $data['page_title'] = 'All orders';
            
            $data['sidebar_element'] = 'side-orders';
            $data['sidebar_subelement'] = 'side-orders-view';
            
            $this->load->model('mdl_products');
            $this->load->model('mdl_skus');
            $this->load->model('mdl_product_images');
            
            $month = $this->input->post('month', true);
            
            if(!$month) {
                $month = date('m', time());
                $data['month_name'] = date('F', time());
            }
            else {
                if(!in_array($month, array('01', '02', '03', '04', '05', '06', '07','08','09','10','11','12'))) :
                    $this->session->set_flashdata('error', 'Invalid Month');
                    redirect('orders/month', 'refresh');
                endif;
                $data['month_name'] = date('F', strtotime($month - date('m', time()).' month'));
            }
            
            
            
            $this->db->order_by("id", "desc");
            $orders = $this->mdl_orders->get_where_custom('MONTH(ordered_on)', $month)->result();
            $data['orders'] = $orders;
            
            $orders_num = array();
            foreach($orders as $order) {
                if(isset($orders_num[$order->order_status])) {
                    $orders_num[$order->order_status] += 1;
                }
                else {
                    $orders_num[$order->order_status] = 1;
                }
            }
            
            $data['orders_num'] = $orders_num;
            
            $this->load->view('header', $data);
            $this->load->view('orders_month_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    
    function from_to() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'orders';
            $data['page_title'] = 'All orders';
            
            $data['sidebar_element'] = 'side-orders';
            $data['sidebar_subelement'] = 'side-orders-view';
            
            $this->load->model('mdl_products');
            $this->load->model('mdl_skus');
            $this->load->model('mdl_product_images');
            
            $from = $this->input->post('from', true);
            $to = $this->input->post('to', true);
            
            if(!$from || !$to) {
                $from = date('Y-m-d', strtotime('-30 days'));
                $to = date('Y-m-d', time());
                $data['from_to_name'] = 'Orders in the Last 30 Days';
            }
            else {
                if( !(checkdate(date('m', strtotime($from)), date('d', strtotime($from)), date('Y', strtotime($from))) && checkdate(date('m', strtotime($to)), date('d', strtotime($to)), date('Y', strtotime($to)))) ) :
                    $this->session->set_flashdata('error', 'Invalid Dates');
                    redirect('orders/from_to', 'refresh');
                endif;
                $data['from_to_name'] = 'Orders between ' . date('F d, Y', strtotime($from)) . ' and ' . date('F d, Y', strtotime($to));
            }
            
            $from = date('Y-m-d', strtotime($from));
            $from = date('Y-m-d', strtotime($to));
            
            $this->db->order_by("id", "desc");
            
            $this->mdl_orders->get_where_custom('DATE(ordered_on) >=', $from);
            $orders = $this->mdl_orders->get_where_custom('DATE(ordered_on) <=', $to)->result();
            
            $data['orders'] = $orders;
            
            $orders_num = array();
            foreach($orders as $order) {
                if(isset($orders_num[$order->order_status])) {
                    $orders_num[$order->order_status] += 1;
                }
                else {
                    $orders_num[$order->order_status] = 1;
                }
            }
            
            $data['orders_num'] = $orders_num;
            
            $this->load->view('header', $data);
            $this->load->view('orders_fromto_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    
    function order_info($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'orders';
            $data['page_title'] = 'All orders';
            
            $data['sidebar_element'] = 'side-orders';
            $data['sidebar_subelement'] = 'side-orders-view';
            
            $this->load->model('mdl_products');
            $this->load->model('mdl_skus');
            $this->load->model('mdl_order_items');
            $this->load->model('mdl_order_customizations');
            $this->load->model('mdl_customers');
            $this->load->model('mdl_product_images');
            
            $order_details = $this->mdl_orders->get_where($id);
            if($order_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $order_details = $order_details->row();
            }
            $data['order_details'] = $order_details;
            
            $order_items = $this->mdl_order_items->get_where_custom('order_id', $id);
            if($order_items->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $order_items = $order_items->result();
            }
            $data['order_items'] = $order_items;
            
            $customizations_list = array();
            foreach($order_items as $order_item) {
                $sku_details = $this->mdl_skus->get_where($order_item->sku_id)->row();
                $skus_list[$order_item->id] = $sku_details;
                
                $product_details = $this->mdl_products->get_where($sku_details->product_id)->row();
                $products_list[$order_item->id] = $product_details;
                
                if($order_item->custom) :
                    $customization_details = $this->mdl_order_customizations->get_where_custom('order_item_id',$order_item->id);
                    $customizations_list[$order_item->id] = $customization_details->row();
                endif;
                
            }
            $data['skus_list'] = $skus_list;
            $data['customizations_list'] = $customizations_list;
            $data['products_list'] = $products_list;
            
            
            $customer_details = $this->mdl_customers->get_where($order_details->customer_id);
            if($customer_details->num_rows() > 0) {
                $customer_details = $customer_details->row();
            }
            else {
                //redirect('404', 'refresh');
            }
            $data['customer_details'] = $customer_details;
            
            $data['page_title'] = 'Order '. $order_details->id;
             
            $this->load->view('header', $data);
            $this->load->view('order_info_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function print_invoice($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'orders';
            $data['page_title'] = 'All orders';
            
            $data['sidebar_element'] = 'side-orders';
            $data['sidebar_subelement'] = 'side-orders-view';
            
            $this->load->model('mdl_products');
            $this->load->model('mdl_skus');
            $this->load->model('mdl_order_items');
            $this->load->model('mdl_order_customizations');
            $this->load->model('mdl_customers');
            $this->load->model('mdl_product_images');
            
            $order_details = $this->mdl_orders->get_where($id);
            if($order_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $order_details = $order_details->row();
            }
            $data['order_details'] = $order_details;
            
            $order_items = $this->mdl_order_items->get_where_custom('order_id', $id);
            if($order_items->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $order_items = $order_items->result();
            }
            $data['order_items'] = $order_items;
            
            $customizations_list = array();
            foreach($order_items as $order_item) {
                $sku_details = $this->mdl_skus->get_where($order_item->sku_id)->row();
                $skus_list[$order_item->id] = $sku_details;
                
                $product_details = $this->mdl_products->get_where($sku_details->product_id)->row();
                $products_list[$order_item->id] = $product_details;
                
                if($order_item->custom) :
                    $customization_details = $this->mdl_order_customizations->get_where_custom('order_item_id',$order_item->id);
                    $customizations_list[$order_item->id] = $customization_details->row();
                endif;
                
            }
            $data['skus_list'] = $skus_list;
            $data['customizations_list'] = $customizations_list;
            $data['products_list'] = $products_list;
            
            
            $customer_details = $this->mdl_customers->get_where($order_details->customer_id);
            if($customer_details->num_rows() > 0) {
                $customer_details = $customer_details->row();
            }
            else {
                //redirect('404', 'refresh');
            }
            $data['customer_details'] = $customer_details;
            
            $data['page_title'] = 'Order '. $order_details->id;
             
            //$this->load->view('header', $data);
            $this->load->view('invoice_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function edit($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_product_images');
            
            $product_details = $this->mdl_order_items->get_where($id);
            if($product_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $product_details = $product_details->row();
            }
            $data['product_details'] = $product_details;
            
            $parent_category_details = $this->mdl_categories->get_where($product_details->cat_id);
            if($parent_category_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $parent_category_details = $parent_category_details->row();
            }
            $data['parent_category_details'] = $parent_category_details;
            
            
            $categories_list = $this->mdl_categories->get('id')->result();
            $data['categories_list'] = $categories_list;
            
            $product_images = $this->mdl_product_images->get_product_images($product_details->id);
            $data['product_images'] = $product_images;
            
            $data['tinyMC'] = TRUE;
            
            $data['page_title'] = 'Edit '.$product_details->name;

            $this->load->view('header', $data);
            $this->load->view('product_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function add()
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'Add New Product';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-add-product';
            
            $this->load->model('mdl_categories');
            
            $categories_list = $this->mdl_categories->get('id')->result();
            $data['categories_list'] = $categories_list;
            
            
            //$data['tinyMC'] = FALSE;

            $this->load->view('header', $data);
            $this->load->view('product_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add_child($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'Add New Product';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-add-product';
            
            $this->load->model('mdl_categories');
            
            $parent_category = $this->mdl_categories->get_where($id);
            if($parent_category->num_rows() != 1) {
                rediredct('404', 'refresh');
            }
            else {
                $parent_category = $parent_category->row();
            }
            $data['parent_category'] = $parent_category;
            
            $categories_list = $this->mdl_categories->get_where_custom('parent_id', $parent_category->id)->result();
            $data['categories_list'] = $categories_list;
            
            
            $data['page_title'] = 'Add Product Under '.$parent_category->name; 
            $this->load->view('header', $data);
            $this->load->view('product_add_child', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function delete($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'Add New Product';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-add-product';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_product_images');
            
            $product = $this->mdl_order_items->get_where($id);
            
            if($product->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $product = $product->row();
            }
            
            $product->code = implode('_', explode(' ',$product->code));
            
            //delete this Product's Images from storage and DB first
            $product_images = $this->mdl_product_images->get_where_custom('product_id', $product->id);
            
            foreach($product_images->result() as $image) {
                unlink('../assets/uploads/'.$image->url);
                $this->mdl_product_images->_delete($image->id);
            }
            
            if(file_exists('../assets/uploads/'.$product->code.'_front.jpg')) :
              unlink('../assets/uploads/'.$product->code.'_front.jpg');
            endif;
            if(file_exists('../assets/uploads/'.$product->code.'_back.jpg')) :
              unlink('../assets/uploads/'.$product->code.'_back.jpg');
            endif;
            if(file_exists('../assets/uploads/'.$product->code.'_left.jpg')) :
              unlink('../assets/uploads/'.$product->code.'_left.jpg');
            endif;
            if(file_exists('../assets/uploads/'.$product->code.'_right.jpg')) :
              unlink('../assets/uploads/'.$product->code.'_right.jpg');
            endif;
            if(file_exists('../assets/uploads/'.$product->code.'_closeup.jpg')) :
              unlink('../assets/uploads/'.$product->code.'_closeup.jpg');
            endif;
            
            //delete all SKUs listed under this product
            $this->load->model('mdl_skus');
            $skus = $this->mdl_skus->get_where_custom('product_id', $product->id);
            foreach($skus->result() as $sku) {
                $this->mdl_skus->_delete($sku->id);
            }
            
            // finally delete the product
            $this->mdl_order_items->_delete($product->id);
            
            redirect('products');
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function save($id = FALSE) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'All Products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $productName = $this->input->post('productName');
            if (!$productName):
                redirect('products');
            endif;
            $productCode = $this->input->post('productCode', true);
            $productSlug = $this->input->post('productSlug', true);
            $productCategory = $this->input->post('productCategory', true);
            $productPrice = $this->input->post('productPrice', true);
            $productColor = $this->input->post('productColor', TRUE);
            $productDesc = $this->input->post('productDesc', true);
            $productPosScore = (int)$this->input->post('productPosScore', true);
            
            if (is_int($productPosScore) && ($productPosScore >= 0) && ($productPosScore <= 1000)) {
                if ($id) {
                    $data = array(
                        'name' => $productName,
                        'code' => $productCode,
                        'slug' => $productSlug,
                        'cat_id' => $productCategory,
                        'price' => $productPrice,
                        'color' => $productColor,
                        'desc' => $productDesc,
                        'position_score' => $productPosScore
                    );
                    
                    $this->db->where('id !=', $id);
                    $slug_exists = $this->mdl_order_items->get_where_custom('slug', $productSlug);
                    
                    if ($slug_exists->num_rows() > 0) {
                        echo "Slug already exists. <a href='{$this->config->base_url() }products/edit/{$id}'>Enter a unique slug.</a>";
                    }
                    else {
                        $this->mdl_order_items->_update($id, $data);
                        $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
                        redirect("products/edit/{$id}");
                    }
                    
                }
                else {
                    $data = array(
                        'name' => $productName,
                        'code' => $productCode,
                        'slug' => $productSlug,
                        'cat_id' => $productCategory,
                        'price' => $productPrice,
                        'color' => $productColor,
                        'desc' => $productDesc,
                        'position_score' => $productPosScore
                    );
                    $slug_exists = $this->mdl_order_items->get_where_custom('slug', $productSlug);
                    if ($slug_exists->num_rows() > 0) {
                        echo "Slug already exists. <a href='{$this->config->base_url() }products/add'>Enter a unique slug.</a>";
                    }
                    else {
                        $this->mdl_order_items->_insert($data);
                        $id = mysql_insert_id();
                        $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
                        redirect("products/edit/{$id}");
                    }
                }
            }
            else {
                echo "Invalid Input. Please <a href='{$this->config->base_url() }products/edit/{$id}'>try again.</a>";
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function status_update($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'orders';
            $data['page_title'] = 'Update Orders';
            
            $data['sidebar_element'] = 'side-orders';
            $data['sidebar_subelement'] = 'side-orders-view';
            
            $order_check = $this->mdl_orders->get_where($id);
            if($order_check->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $order_details = $order_check->row();
            }
            
            $orderStatus = $this->input->post('orderStatus', true);
            if (!$orderStatus):
                redirect("orders/order_info/{$id}");
            endif;
            
            $order_status_possibilities = array('placed', 'processing', 'dispatched', 'on-hold', 'cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'delivered');
            
            if(!in_array(strtolower($orderStatus), $order_status_possibilities)) :
                redirect('404', 'refresh');
            endif;
            
            $new_data = array (
                'order_status' => $orderStatus
            );
            
            $this->mdl_orders->_update($order_details->id, $new_data);
            redirect("orders/order_info/{$order_details->id}", 'refresh');
            
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function payment_status_update($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'orders';
            $data['page_title'] = 'Update Orders';
            
            $data['sidebar_element'] = 'side-orders';
            $data['sidebar_subelement'] = 'side-orders-view';
            
            $order_check = $this->mdl_orders->get_where($id);
            if($order_check->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $order_details = $order_check->row();
            }
            
            $paymentStatus = $this->input->post('paymentStatus', true);
            if (!$paymentStatus):
                redirect("orders/order_info/{$id}");
            endif;
            
            $new_data = array (
                'payment_status' => $paymentStatus
            );
            
            $this->mdl_orders->_update($order_details->id, $new_data);
            redirect("orders/order_info/{$order_details->id}", 'refresh');
            
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function seosave($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'All Products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_product_images');
            
            $seoTitle = $this->input->post('productSeoTitle');
            $seoDesc = $this->input->post('productSeoDesc');
            $seoKeys = $this->input->post('productSeoKeys');
            $data = array(
                'seo_title' => $seoTitle,
                'seo_desc' => $seoDesc,
                'seo_keywords' => $seoKeys
            );
            $this->mdl_order_items->_update($id, $data);
            $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
            redirect("products/edit/{$id}?tab=seotags");

        }
        else {
            redirect('login', 'refresh');
        }
    }

    function DPimageSave($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'products';
            $data['page_title'] = 'All Products';
            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_product_images');
            
            $check = $this->mdl_order_items->get_where($id);
            if($check->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $product_details = $check->row();
            }
            
            $view = $this->input->post('view', true);
            if( !( in_array( strtolower($view), array('front', 'back', 'left', 'right', 'closeup') ) ) ) :
                redirect('404', 'refresh');
            endif;
            
            
            $config['upload_path'] = '../assets/uploads/';
            $config['allowed_types'] = 'jpg|jpeg';
            $config['file_name'] = implode('_', explode(' ',$product_details->code)).'_'.$view.'.jpg';
            $config['overwrite'] = TRUE;
            
            $this->load->library('upload', $config);
            if($_FILES['productDPChange']['size'] == 0) :
                redirect('404', 'refresh');
            endif;
            
            if (!$this->upload->do_upload('productDPChange')) {
                $data['uploadErrors'] = $this->upload->display_errors();
                echo $data['uploadErrors'] . '<br />';
                echo "<a href='{$this->config->base_url() }products/edit/{$id}?tab=productpics'>Please try again</a>";
            }
            else {
                $res = $this->upload->data();
                $DPname = implode('_', explode(' ',$product_details->code)).'_'.$view.'.jpg';
                $data = array(
                    'url' => $DPname,
                    'product_id' => $product_details->id,
                    'view' => $view,
                    'alt' => ucfirst($product_details->name).' '.$view.' view',
                    'title' => ucfirst($product_details->name).' '.$view.' view'
                );
                
                $current_image = $this->db->get_where('product_images', array('product_id' => $product_details->id, 'view' => $view));
                if($current_image->num_rows() > 0) {
                    $this->mdl_product_images->_update($current_image->row()->id, $data);
                    redirect("products/edit/{$product_details->id}?tab=productspics");
                }
                else {
                    $this->mdl_product_images->_insert($data);
                    redirect("products/edit/{$product_details->id}?tab=productspics");
                }
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }

}
