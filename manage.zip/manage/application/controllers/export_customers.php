<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Export_customers extends CI_Controller {
    
	function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
    
	function index() {
		$data = initiate_page();
        $data['page_name'] = 'Export Customers';
        $data['page_title'] = 'Export Customers';
        
        $data['sidebar_element'] = 'side-customers';
        $data['sidebar_subelement'] = 'side-export-customers';
        
        $data['seo_title'] = 'Export Customers';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
		
		$categories = array();
		$check = $this->db->get('categories');
		if($check->num_rows() > 0) {
			$categories = $check->result();
		}
		$data['categories'] = $categories;
		
		$this->load->view('header', $data);
		$this->load->view('export_customers_view', $data);
		$this->load->view('footer', $data);
	}
	
	function all() {
		
		$data = initiate_page();
		$customers = array();
		$check = $this->db->get('customers');
		if($check->num_rows() > 0) {
			$customers = $check->result();
		}
		$this->generate_customer_excel($customers, "taruni_customers_all");
	}
	
	function domestic_orders() {
		
		$data = initiate_page();
		
		$orders = array();
		$this->db->where_not_in('order_status', array('cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'on-hold'));
		$this->db->where('ship_to_country', 'India');
		$this->db->or_where('ship_to_country', 'india');
		$this->db->where('total_items >', 0);
		$this->db->where('total_amount >', 0);
		$check = $this->db->get('orders');
		
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$customer_id_list = array();
		foreach($orders as $order) {
			array_push($customer_id_list, $order->customer_id);
		}
		
		$customers = array();
		if(count($customer_id_list) > 0) {
			$this->db->where_in('id', $customer_id_list);
			$check = $this->db->get('customers');
			
			if($check->num_rows() > 0) {
				$customers = $check->result();
			}
		}
		
		$this->generate_customer_excel($customers, "taruni_customers_domestic_orders");
	}
	
	function foreign_orders() {
		
		$data = initiate_page();
		
		$orders = array();
		$this->db->where_not_in('order_status', array('cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'on-hold'));
		$this->db->where_not_in('ship_to_country', array('India', 'india'));
		$this->db->or_where_not_in('bill_to_country', array('India', 'india'));
		$this->db->where('total_items >', 0);
		$this->db->where('total_amount >', 0);
		$check = $this->db->get('orders');
		
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$customer_id_list = array();
		foreach($orders as $order) {
			array_push($customer_id_list, $order->customer_id);
		}
		
		$customers = array();
		if(count($customer_id_list) > 0) {
			$this->db->where_in('id', $customer_id_list);
			$check = $this->db->get('customers');
			
			if($check->num_rows() > 0) {
				$customers = $check->result();
			}
		}
		
		$this->generate_customer_excel($customers, "taruni_customers_foreign_orders");
	}
	
	function zero_orders() {
		
		$data = initiate_page();
		
		$orders = array();
		$this->db->where_not_in('order_status', array('cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'on-hold'));
		$this->db->where('total_items >', 0);
		$this->db->where('total_amount >', 0);
		$check = $this->db->get('orders');
		
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$customer_id_list = array();
		foreach($orders as $order) {
			array_push($customer_id_list, $order->customer_id);
		}
		
		$customers = array();
		if(count($customer_id_list) > 0) {
			$this->db->where_not_in('id', $customer_id_list);
			$check = $this->db->get('customers');
			
			if($check->num_rows() > 0) {
				$customers = $check->result();
			}
		}
		
		$this->generate_customer_excel($customers, "taruni_customers_zero_orders");
	}
	
	function one_order() {
		
		$data = initiate_page();
		
		$orders = array();
		$this->db->where_not_in('order_status', array('cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'on-hold'));
		$this->db->where('total_items >', 0);
		$this->db->where('total_amount >', 0);
		$check = $this->db->get('orders');
		
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$customer_order_index = array();
		$customer_id_index = array();
		foreach($orders as $order) {
			$customer_id = $order->customer_id;
			$check = $this->db->get_where('customers', array('id' => $customer_id));
			if($check->num_rows <= 0) {
				CONTINUE;
			}
			
			$customer = $check->row();
			$email = $customer->email;
			if($customer->is_guest == 1) {
				$email = $customer->guest_email;
			}
			
			if( ! isset($customer_order_index[$email])) {
				$customer_order_index[$email] = 0;
			}
			$customer_order_index[$email] += 1;
			
			if( ! isset($customer_id_index[$email])) {
				$customer_id_index[$email] = array();
			}
			array_push($customer_id_index[$email], $customer->id);
		}
		
		$customer_id_list = array();
		foreach($customer_order_index as $key => $value) {
			if($value == 1) {
				$ids = $customer_id_index[$key];
				$customer_id_list = array_merge($customer_id_list, $ids);
			}
		}

		$customers = array();
		if(count($customer_id_list) > 0) {
			$this->db->where_in('id', $customer_id_list);
			$check = $this->db->get('customers');
			
			if($check->num_rows() > 0) {
				$customers = $check->result();
			}
		}
		
		$this->generate_customer_excel($customers, "taruni_customers_one_order");
	}
	
	function repeat_orders() {
		
		$data = initiate_page();
		
		$orders = array();
		$this->db->where_not_in('order_status', array('cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'on-hold'));
		$this->db->where('total_items >', 0);
		$this->db->where('total_amount >', 0);
		$check = $this->db->get('orders');
		
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$customer_order_index = array();
		$customer_id_index = array();
		foreach($orders as $order) {
			$customer_id = $order->customer_id;
			$check = $this->db->get_where('customers', array('id' => $customer_id));
			if($check->num_rows <= 0) {
				CONTINUE;
			}
			
			$customer = $check->row();
			$email = $customer->email;
			if($customer->is_guest == 1) {
				$email = $customer->guest_email;
			}
			
			if( ! isset($customer_order_index[$email])) {
				$customer_order_index[$email] = 0;
			}
			$customer_order_index[$email] += 1;
			
			if( ! isset($customer_id_index[$email])) {
				$customer_id_index[$email] = array();
			}
			array_push($customer_id_index[$email], $customer->id);
		}
		
		$customer_id_list = array();
		foreach($customer_order_index as $key => $value) {
			if($value > 1) {
				$ids = $customer_id_index[$key];
				$customer_id_list = array_merge($customer_id_list, $ids);
			}
		}

		$customers = array();
		if(count($customer_id_list) > 0) {
			$this->db->where_in('id', $customer_id_list);
			$check = $this->db->get('customers');
			
			if($check->num_rows() > 0) {
				$customers = $check->result();
			}
		}
		
		$this->generate_customer_excel($customers, "taruni_customers_repeat_orders");
	}
	
	function category() {
		
		$data = initiate_page();
		
		$category_id = $this->input->post('category', TRUE);
		if( ( ! $category_id) OR ( ! (int) $category_id)) {
			$this->session->set_flashdata('form_errors', "<div class='alert alert-danger'>Error! Please select a valid Category</div>");
			redirect('export_customers', 'refresh');
			exit();
		}
		
		$check = $this->db->get_where('categories', array('id' => $category_id));
		if($check->num_rows() <= 0) {
			$this->session->set_flashdata('form_errors', "<div class='alert alert-danger'>Error! Please select a valid Category</div>");
			redirect('export_customers', 'refresh');
			exit();
		}
		
		$category = $check->row();
		$valid_category_ids = array($category->id);
		
		$check = $this->db->get_where('categories', array('parent_id' => $category->id));
		if($check->num_rows() > 0) {
			foreach($check->result() as $sub_cat) {
				array_push($valid_category_ids, $sub_cat->id);
			}
		}
		
		$order_ids = array();
		$this->db->where_in('cat_id', $valid_category_ids);
		$this->db->group_by('order_id');
		$check = $this->db->get('order_items');
		if($check->num_rows() > 0) {
			foreach($check->result() as $order_item) {
				array_push($order_ids, $order_item->order_id);
			}
		}
		
		$orders = array();
		if(count($order_ids) > 0) {
			$this->db->where_in('id', $order_ids);
			$this->db->where('total_items >', 0);
			$this->db->where('total_amount >', 0);
			$check = $this->db->get('orders');
			
			if($check->num_rows() > 0) {
				$orders = $check->result();
			}
		}
		
		$customer_id_list = array();
		foreach($orders as $order) {
			array_push($customer_id_list, $order->customer_id);
		}

		$customers = array();
		if(count($customer_id_list) > 0) {
			$this->db->where_in('id', $customer_id_list);
			$check = $this->db->get('customers');
			
			if($check->num_rows() > 0) {
				$customers = $check->result();
			}
		}
		
		$this->generate_customer_excel($customers, "taruni_customers_{$category->slug}");
	}
	
	function generate_customer_excel($customers, $title) {
		
		require APPPATH . 'controllers/class/PHPExcel.php';
		require_once APPPATH . 'controllers/class/PHPExcel/IOFactory.php';
		
		if(count($customers) == 0) {
			echo "Empty";
			return;
		}
		
		$excel_data = array();
		$excel_headings = array(
			'Name',
			'Email',
		);
		array_push($excel_data, $excel_headings);
		
		$email_record = array();
		foreach($customers as $customer) {
			$email = $customer->email;
			if($customer->is_guest == 1) {
				$email = $customer->guest_email;
			}
			if(in_array($email, $email_record)) {
				CONTINUE;
			}
			$row = array(
				ucwords($customer->name),
				$email,
			);
			array_push($excel_data, $row);
			array_push($email_record, $email);
		}
		
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->getProperties()->setCreator("Taruni");
		$objPHPExcel->getProperties()->setLastModifiedBy("Taruni");
		$objPHPExcel->getProperties()->setTitle("{$title}");
		$objPHPExcel->getProperties()->setSubject("{$title}");
		$objPHPExcel->getProperties()->setDescription("{$title}");
		
		$objPHPExcel->getActiveSheet()->fromArray($excel_data, null, 'A1');
		
		$date = date('M-d-Y', time());
		
		header("Content-Type: application/xlsx");
		header("Content-Disposition: attachment; filename={$title}.xlsx");
		header("Pragma: no-cache");
		header("Expires: 0");
		
		$highestColumn = $objPHPExcel->getActiveSheet()->getHighestDataColumn();
		$nCols = PHPExcel_Cell::columnIndexFromString($highestColumn);
		
		foreach (range(0, $nCols) as $col) {
			$objPHPExcel->getActiveSheet()->getColumnDimensionByColumn($col)->setWidth(30);                
		}
		
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
		$objWriter->save('php://output');
	}
		
}
