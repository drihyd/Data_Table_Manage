<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class ann_correction extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'email_helper',
            'page_initiater_helper',
        );
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function index($justsee=TRUE) {
		
		# HYDERABAD - TELANGANA
		
		$this->db->where('ship_to_state', 'andaman and nicobar islands');
		$this->db->where('ship_to_city', 'Hyderabad');
		$new_data = array(
			'ship_to_state' => 'telangana',
		);
		
		$this->db->update('orders', $new_data);
		
		
		# BENGALURU - KARNATAKA
		
		$this->db->where('ship_to_state', 'andaman and nicobar islands');
		$this->db->where('ship_to_city', 'Bengaluru');
		$new_data = array(
			'ship_to_state' => 'karnataka',
		);
		
		$this->db->update('orders', $new_data);
		
		
		# GURGAON - HARYANA
		
		$this->db->where('ship_to_state', 'andaman and nicobar islands');
		$this->db->where('ship_to_city', 'gurgaon');
		$new_data = array(
			'ship_to_state' => 'haryana',
		);
		
		$this->db->update('orders', $new_data);
		
		
		# GUNTUR _ ANDHRA PRADESH
		$this->db->where('ship_to_state', 'andaman and nicobar islands');
		$this->db->where('ship_to_city', 'Guntur');
		$new_data = array(
			'ship_to_state' => 'andhra pradesh',
		);
		
		$this->db->update('orders', $new_data);
		
		# TADEPALLIGUDEM - ANDHRA PRADESH
		$this->db->where('ship_to_state', 'andaman and nicobar islands');
		$this->db->where('ship_to_city', 'Tadepalligudem');
		$new_data = array(
			'ship_to_state' => 'andhra pradesh',
		);
		
		$this->db->update('orders', $new_data);
		
		# ELURU - ANDHRA PRADESH
		$this->db->where('ship_to_state', 'andaman and nicobar islands');
		$this->db->where('ship_to_city', 'Eluru');
		$new_data = array(
			'ship_to_state' => 'andhra pradesh',
		);
		
		$this->db->update('orders', $new_data);
		
		# GHAZIABAD - UTTAR PRADESH
		$this->db->where('ship_to_state', 'andaman and nicobar islands');
		$this->db->where('ship_to_city', 'Ghaziabad');
		$new_data = array(
			'ship_to_state' => 'uttar pradesh',
		);
		
		$this->db->update('orders', $new_data);
		
		# SRIKAKULAM - ANDHRA PRADESH
		$this->db->where('ship_to_state', 'andaman and nicobar islands');
		$this->db->where('ship_to_city', 'Srikakulam');
		$new_data = array(
			'ship_to_state' => 'andhra pradesh',
		);
		
		$this->db->update('orders', $new_data);
		
		# VISAKHAPATNAM - ANDHRA PRADESH
		$this->db->where('ship_to_state', 'andaman and nicobar islands');
		$this->db->where('ship_to_city', 'Visakhapatnam');
		$new_data = array(
			'ship_to_state' => 'andhra pradesh',
		);
		
		$this->db->update('orders', $new_data);
		
		# VIJAYAWADA - ANDHRA PRADESH
		$this->db->where('ship_to_state', 'andaman and nicobar islands');
		$this->db->where('ship_to_city', 'Vijayawada');
		$new_data = array(
			'ship_to_state' => 'andhra pradesh',
		);
		
		$this->db->update('orders', $new_data);
		
		# MAHBUBNAGAR - ANDHRA PRADESH
		$this->db->where('ship_to_state', 'andaman and nicobar islands');
		$this->db->where('ship_to_city', 'Mahbubnagar');
		$new_data = array(
			'ship_to_state' => 'telangana',
		);
		
		$this->db->update('orders', $new_data);
	}
	
	
}
