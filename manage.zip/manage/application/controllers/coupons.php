<?php
date_default_timezone_set("Asia/Kolkata");

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Coupons extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_coupons', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'coupons';
            $data['page_title'] = 'All coupons';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-coupons-view';
            
            $this->db->order_by('id', 'desc');
            $this->db->limit(1000);
            $coupons = $this->db->get('coupons');
            if($coupons->num_rows() > 0) {
              $coupons = $coupons->result();
            } else {
              $coupons = array();
            }
            $data['coupons'] = $coupons;
            
            $this->load->view('header', $data);
            $this->load->view('coupons_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function coupon_info($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'coupons';
            $data['page_title'] = 'All coupons';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-coupons-view';
            
            
            $coupon_details = $this->mdl_coupons->get_where($id);
            if($coupon_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $coupon_details = $coupon_details->row();
            }
            $data['coupon_details'] = $coupon_details;
            
            $check_coupon_usage_log = $this->db->get_where('coupon_usage_log', array('coupon_id' => $coupon_details->id));
            $coupon_usage_log = array();
            if($check_coupon_usage_log->num_rows() > 0) {
              $coupon_usage_log = $check_coupon_usage_log->result();
            }
            $data['coupon_usage_log'] = $coupon_usage_log;
            
            $data['page_title'] = 'coupon '. $coupon_details->id;
             
            $this->load->view('header', $data);
            $this->load->view('coupon_info_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function edit($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'coupons';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-coupons-view';
            
            $check_coupon_details = $this->db->get_where('coupons', array('id' => $id));
            $coupon_details = array();
            if($check_coupon_details->num_rows() > 0) {
              $coupon_details = $check_coupon_details->row();
            }
            $data['coupon_details'] = $coupon_details;
            
            $unique_codes = array();
            
            for ($i = 0; $i < 30; $i++) {
              $unique_code = $this->generate_coupon_codes();
              array_push($unique_codes, $unique_code);
            }
            $data['unique_codes'] = $unique_codes;
            
            $data['tinyMC'] = FALSE;
            
            $data['page_title'] = 'Edit Coupon';

            $this->load->view('header', $data);
            $this->load->view('coupon_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function add()
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'coupons';
            $data['page_title'] = 'Add New coupon';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-coupons-view';
            
            $unique_codes = array();
            
            for ($i = 0; $i < 30; $i++) {
              $unique_code = $this->generate_coupon_codes();
              array_push($unique_codes, $unique_code);
            }
            $data['unique_codes'] = $unique_codes;
            
            //$data['tinyMC'] = FALSE;

            $this->load->view('header', $data);
            $this->load->view('coupon_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    
    function delete($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'coupons';
            $data['page_title'] = 'Add New coupon';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-add-coupon';
            
            $check_coupon = $this->db->get_where('coupons', array('id' => $id));
            
            if($check_coupon->num_rows() > 0) {
              $coupon = $check_coupon->row();
              $this->db->where('id', $coupon->id);
              $this->db->delete('coupons');
            }
            
            redirect('coupons');
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function generate_coupon_codes() {
      
      $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      
      do { //keep generating codes until we get a unique one
        $new_coupon = '';
        for ($i = 0; $i < 6; $i++) {
          $new_coupon .= strtoupper($characters[rand(0, strlen($characters)-1)]);
        }
        $this->db->where('code', $new_coupon);
        $this->db->from('coupons');
        $similar_existing_codes = $this->db->count_all_results();
      } while ($similar_existing_codes >= 1);
      
      return strtoupper($new_coupon);
    }
     
    function save($id = FALSE) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'coupons';
            $data['page_title'] = 'All coupons';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-coupons-view';
            
            //$this->session->set_flashdata('error', 'Invalid Month');
            
            if($id) {
              $check = $this->db->get_where('coupons', array('id' => $id));
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form_error', 'Coupon does not exist');
                redirect('coupons', 'refresh');
              }
              
              $coupon_details = $check->row();
              
              $couponTitle = $this->input->post('couponTitle', true);
              if( (! $couponTitle) || ($couponTitle == '') ) {
                $this->session->set_flashdata('form_error', 'Please enter a valid Title for the coupon');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              $couponCode = strtoupper(trim($this->input->post('couponCode', true)));
              if( (! $couponTitle) || ($couponTitle == '') ) {
                $this->session->set_flashdata('form_error', 'Please enter a valid Coupon Code. No speical characters are allowed.');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              $this->db->where('id !=', $coupon_details->id);
              $check = $this->db->get_where('coupons', array('code' => $couponCode));
              if($check->num_rows() > 0) {
                $this->session->set_flashdata('form_error', 'The coupon code already exists. Please enter a unique coupon code.');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              $couponDesc = $this->input->post('couponDesc', true);
              if( (! $couponDesc) || ($couponDesc == '') ) {
                $this->session->set_flashdata('form_error', 'Please enter a description.');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              $couponError = $this->input->post('couponError', true);
              if( (! $couponError) || ($couponError == '') ) {
                $this->session->set_flashdata('form_error', 'Please enter an error message.');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              $couponType = $this->input->post('couponType', true);
              if( (! $couponType) || ($couponType == '') ) {
                $this->session->set_flashdata('form_error', 'Please choose a valid type for the coupon.');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              $valid_types = array('shipping_off', 'rupees_off', 'percent_off');
              
              if( ! in_array($couponType, $valid_types) ) {
                $this->session->set_flashdata('form_error', 'Please choose a valid type for the coupon.');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              if( $couponType != 'shipping_off') {
                $couponValue = $this->input->post('couponValue', true);
                if( (! $couponValue) || ($couponValue == '') || ( (float) $couponValue == '') ) {
                  $this->session->set_flashdata('form_error', 'Please specify a valid discount value');
                  redirect("coupons/edit/{$coupon_details->id}", 'refresh');
                }
              } else {
                $couponValue = 0;
              }
              
              $couponValidFrom = $this->input->post('couponValidFrom', true);
              if( (! $couponValidFrom) || ($couponValidFrom == '') ) {
                $this->session->set_flashdata('form_error', 'Please choose a valid "From Date".');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              $couponValidTill = $this->input->post('couponValidTill', true);
              if( (! $couponValidTill) || ($couponValidTill == '') ) {
                $this->session->set_flashdata('form_error', 'Please choose a valid "Till Date".');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              if( strtotime($couponValidTill) < strtotime($couponValidFrom) ) {
                $this->session->set_flashdata('form_error', '"Valid Till Date" cannot be earlier than "Valid From Date"');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              $couponUsageLimit = $this->input->post('couponUsageLimit', true);
              if( (! $couponUsageLimit) || ($couponUsageLimit == '') || ( ($couponUsageLimit != -1) && ((int)$couponUsageLimit == '') ) ) {
                $this->session->set_flashdata('form_error', 'Please enter a valid usage limit. It can be a number or -1');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              $couponSingleUsePerCust = $this->input->post('couponSingleUsePerCust', true);
              if((! $couponSingleUsePerCust)) {
                $couponSingleUsePerCust = 0;
              } else {
				  $couponSingleUsePerCust = 1;
			  }
			  
			  $couponForFirstTimeOrdersOnly = $this->input->post('couponForFirstTimeOrdersOnly', true);
              if((! $couponForFirstTimeOrdersOnly)) {
                $couponForFirstTimeOrdersOnly = 0;
              } else {
				  $couponForFirstTimeOrdersOnly = 1;
			  }
              
              $couponCustID = $this->input->post('couponCustID', true);
              if( ($couponCustID == '') ) {
                $this->session->set_flashdata('form_error', 'Please enter a valid customer ID or enter 0.');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              if($couponCustID != 0) {
                $check = $this->db->get_where('customers', array('id' => $couponCustID));
                if($check->num_rows() == 0) {
                  $this->session->set_flashdata('form_error', 'The customer ID does not exist. Please enter a valid customer ID');
                  redirect("coupons/edit/{$coupon_details->id}", 'refresh');
                }
              }
              
              $couponMinOrderValue = $this->input->post('couponMinOrderValue', true);
              if( ((float) $couponMinOrderValue < 0) ) {
                $this->session->set_flashdata('form_error', 'Please enter a valid Minimum order value or enter 0.');
                redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              }
              
              $new_data = array(
                'title' => $couponTitle,
                'code' => strtoupper($couponCode),
                'desc' => $couponDesc,
                'error_message' => $couponError,
                'type' => $couponType,
                'value' => $couponValue,
                'usage_limit' => $couponUsageLimit,
                'single_use_per_cust' => $couponSingleUsePerCust,
                'for_first_time_orders_only' => $couponForFirstTimeOrdersOnly,
                'valid_from' => date('Y-m-d H:i:s', strtotime($couponValidFrom)),
                'valid_till' => date('Y-m-d 23:59:59', strtotime($couponValidTill)),
                'owner_cust_id' => $couponCustID,
                'min_order_value' => $couponMinOrderValue
              );
              
              $this->db->where('id', $coupon_details->id);
              $this->db->update('coupons', $new_data);
              $this->session->set_flashdata('form_success', 'Changes saved successfully');
              redirect("coupons/edit/{$coupon_details->id}", 'refresh');
              
            } else {
              
              $couponTitle = $this->input->post('couponTitle', true);
              if( (! $couponTitle) || ($couponTitle == '') ) {
                $this->session->set_flashdata('form_error', 'Please enter a valid Title for the coupon');
                redirect("coupons/add", 'refresh');
              }
              
              $couponCode = strtoupper(trim($this->input->post('couponCode', true)));
              if( (! $couponTitle) || ($couponTitle == '') ) {
                $this->session->set_flashdata('form_error', 'Please enter a valid Coupon Code. No speical characters are allowed.');
                redirect("coupons/add", 'refresh');
              }
              
              $check = $this->db->get_where('coupons', array('code' => $couponCode));
              if($check->num_rows() > 0) {
                $this->session->set_flashdata('form_error', 'The coupon code already exists. Please enter a unique coupon code.');
                redirect("coupons/add", 'refresh');
              }
              
              $couponDesc = $this->input->post('couponDesc', true);
              if( (! $couponDesc) || ($couponDesc == '') ) {
                $this->session->set_flashdata('form_error', 'Please enter a description.');
                redirect("coupons/add", 'refresh');
              }
              
              $couponError = $this->input->post('couponError', true);
              if( (! $couponError) || ($couponError == '') ) {
                $this->session->set_flashdata('form_error', 'Please enter an error message.');
                redirect("coupons/add", 'refresh');
              }
              
              $couponType = $this->input->post('couponType', true);
              if( (! $couponType) || ($couponType == '') ) {
                $this->session->set_flashdata('form_error', 'Please choose a valid type for the coupon.');
                redirect("coupons/add", 'refresh');
              }
              
              $valid_types = array('shipping_off', 'rupees_off', 'percent_off');
              
              if( ! in_array($couponType, $valid_types) ) {
                $this->session->set_flashdata('form_error', 'Please choose a valid type for the coupon.');
                redirect("coupons/add", 'refresh');
              }
              
              if( $couponType != 'shipping_off') {
                $couponValue = $this->input->post('couponValue', true);
                if( (! $couponValue) || ($couponValue == '') || ( (float) $couponValue == '') ) {
                  $this->session->set_flashdata('form_error', 'Please specify a valid discount value');
                  redirect("coupons/add", 'refresh');
                }
              } else {
                $couponValue = 0;
              }
              
              $couponValidFrom = $this->input->post('couponValidFrom', true);
              if( (! $couponValidFrom) || ($couponValidFrom == '') ) {
                $this->session->set_flashdata('form_error', 'Please choose a valid "From Date".');
                redirect("coupons/add", 'refresh');
              }
              
              $couponValidTill = $this->input->post('couponValidTill', true);
              if( (! $couponValidTill) || ($couponValidTill == '') ) {
                $this->session->set_flashdata('form_error', 'Please choose a valid "Till Date".');
                redirect("coupons/add", 'refresh');
              }
              
              if( strtotime($couponValidTill) < strtotime($couponValidFrom) ) {
                $this->session->set_flashdata('form_error', '"Valid Till Date" cannot be earlier than "Valid From Date"');
                redirect("coupons/add", 'refresh');
              }
              
              $couponUsageLimit = $this->input->post('couponUsageLimit', true);
              if( (! $couponUsageLimit) || ($couponUsageLimit == '') || ( ($couponUsageLimit != -1) && ((int)$couponUsageLimit == '') ) ) {
                $this->session->set_flashdata('form_error', 'Please enter a valid usage limit. It can be a number or -1');
                redirect("coupons/add", 'refresh');
              }
              
              $couponSingleUsePerCust = $this->input->post('couponSingleUsePerCust', true);
              if((! $couponSingleUsePerCust)) {
                $couponSingleUsePerCust = 0;
              } else {
				  $couponSingleUsePerCust = 1;
			  }
			  
			  $couponForFirstTimeOrdersOnly = $this->input->post('couponForFirstTimeOrdersOnly', true);
              if((! $couponForFirstTimeOrdersOnly)) {
                $couponForFirstTimeOrdersOnly = 0;
              } else {
				  $couponForFirstTimeOrdersOnly = 1;
			  }
              
              $couponCustID = $this->input->post('couponCustID', true);
              if( ($couponCustID == '') ) {
                $this->session->set_flashdata('form_error', 'Please enter a valid customer ID or enter 0.');
                redirect("coupons/add", 'refresh');
              }
              
              if($couponCustID != 0) {
                $check = $this->db->get_where('customers', array('id' => $couponCustID));
                if($check->num_rows() == 0) {
                  $this->session->set_flashdata('form_error', 'The customer ID does not exist. Please enter a valid customer ID');
                  redirect("coupons/add", 'refresh');
                }
              }
              
              $couponMinOrderValue = $this->input->post('couponMinOrderValue', true);
              if( ((float) $couponMinOrderValue < 0) ) {
                $this->session->set_flashdata('form_error', "" . ((float) $couponMinOrderValue == '') . "Please enter a valid Minimum order value or enter 0.");
                redirect("coupons/add", 'refresh');
              }
              
              $new_data = array(
                'title' => $couponTitle,
                'code' => strtoupper($couponCode),
                'desc' => $couponDesc,
                'error_message' => $couponError,
                'type' => $couponType,
                'value' => $couponValue,
                'usage_limit' => $couponUsageLimit,
                'single_use_per_cust' => $couponSingleUsePerCust,
                'for_first_time_orders_only' => $couponForFirstTimeOrdersOnly,
                'valid_from' => date('Y-m-d H:i:s', strtotime($couponValidFrom)),
                'valid_till' => date('Y-m-d 23:59:59', strtotime($couponValidTill)),
                'owner_cust_id' => $couponCustID,
                'min_order_value' => $couponMinOrderValue,
                'date' => date('Y-m-d H:i:s', time())
              );
              
              $this->db->insert('coupons', $new_data);
              
              $id = $this->db->insert_id();
              $this->session->set_flashdata('form_success', 'Changes saved successfully');
              redirect("coupons/edit/{$id}", 'refresh');
            }
            
            
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function status_update($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'coupons';
            $data['page_title'] = 'Update coupons';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-coupons-view';
            
            $coupon_check = $this->mdl_coupons->get_where($id);
            if($coupon_check->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $coupon_details = $coupon_check->row();
            }
            
            $couponStatus = $this->input->post('couponStatus', true);
            if (!$couponStatus):
                redirect("coupons/coupon_info/{$id}");
            endif;
            
            $coupon_status_possibilities = array('placed', 'processing', 'dispatched', 'on-hold', 'cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'delivered');
            
            if(!in_array(strtolower($couponStatus), $coupon_status_possibilities)) :
                redirect('404', 'refresh');
            endif;
            
            if($couponStatus == 'delivered') {            
              $new_data = array (
                  'coupon_status' => $couponStatus,
                  'delivered_on' => date('Y-m-d H:i:s', time())
              );
            }
            else if($couponStatus == 'cancelled') {
              $new_data = array (
                  'coupon_status' => $couponStatus,
                  'cancelled_on' => date('Y-m-d H:i:s', time())
              );
              
              //adding back the cancelled stock to each sku 
              $check = $this->db->get_where('coupon_items', array('coupon_id' => $coupon_details->id));
              if($check->num_rows() > 0) {
                  $coupon_items = $check->result();
                  foreach($coupon_items as $coupon_item) {
                      $sku_id = $coupon_item->sku_id;
                      $coupon_qty = (int) $coupon_item->qty;
                      $check = $this->db->get_where('skus', array('id' => $sku_id));
                      if($check->num_rows() > 0) {
                          $sku_details = $check->row();
                          $current_stock = (int) $sku_details->stock;
                          $updated_stock = $current_stock + $coupon_qty;
                          $update_stock_data = array(
                            'stock' => $updated_stock
                          );
                          $this->db->where('id', $sku_details->id);
                          $this->db->update('skus', $update_stock_data);
                      }
                  }
              }
              
            }
            else {
              $new_data = array (
                  'coupon_status' => $couponStatus
              );
            }
            
            $this->mdl_coupons->_update($coupon_details->id, $new_data);
            redirect("coupons/coupon_info/{$coupon_details->id}", 'refresh');
            
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function payment_status_update($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'coupons';
            $data['page_title'] = 'Update coupons';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-coupons-view';
            
            $coupon_check = $this->mdl_coupons->get_where($id);
            if($coupon_check->num_rows() != 1) {
                redirect('404', 'refresh');
            }
            else {
                $coupon_details = $coupon_check->row();
            }
            
            $paymentStatus = $this->input->post('paymentStatus', true);
            if (!$paymentStatus):
                redirect("coupons/coupon_info/{$id}");
            endif;
            
            $new_data = array (
                'payment_status' => $paymentStatus
            );
            
            $this->mdl_coupons->_update($coupon_details->id, $new_data);
            redirect("coupons/coupon_info/{$coupon_details->id}", 'refresh');
            
        }
        else {
            redirect('login', 'refresh');
        }
    }

    function seosave($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'coupons';
            $data['page_title'] = 'All coupons';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-coupons-view';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_coupon_images');
            
            $seoTitle = $this->input->post('couponSeoTitle');
            $seoDesc = $this->input->post('couponSeoDesc');
            $seoKeys = $this->input->post('couponSeoKeys');
            $data = array(
                'seo_title' => $seoTitle,
                'seo_desc' => $seoDesc,
                'seo_keywords' => $seoKeys
            );
            $this->mdl_coupon_items->_update($id, $data);
            $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
            redirect("coupons/edit/{$id}?tab=seotags");

        }
        else {
            redirect('login', 'refresh');
        }
    }

    function DPimageSave($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'coupons';
            $data['page_title'] = 'All coupons';
            
            $data['sidebar_element'] = 'side-promos';
            $data['sidebar_subelement'] = 'side-coupons-view';
            
            $this->load->model('mdl_categories');
            $this->load->model('mdl_coupon_images');
            
            $check = $this->mdl_coupon_items->get_where($id);
            if($check->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $coupon_details = $check->row();
            }
            
            $view = $this->input->post('view', true);
            if( !( in_array( strtolower($view), array('front', 'back', 'left', 'right', 'closeup') ) ) ) :
                redirect('404', 'refresh');
            endif;
            
            
            $config['upload_path'] = '../assets/uploads/';
            $config['allowed_types'] = 'jpg|jpeg';
            $config['file_name'] = implode('_', explode(' ',$coupon_details->code)).'_'.$view.'.jpg';
            $config['overwrite'] = TRUE;
            
            $this->load->library('upload', $config);
            if($_FILES['couponDPChange']['size'] == 0) :
                redirect('404', 'refresh');
            endif;
            
            if (!$this->upload->do_upload('couponDPChange')) {
                $data['uploadErrors'] = $this->upload->display_errors();
                echo $data['uploadErrors'] . '<br />';
                echo "<a href='{$this->config->base_url() }coupons/edit/{$id}?tab=couponpics'>Please try again</a>";
            }
            else {
                $res = $this->upload->data();
                $DPname = implode('_', explode(' ',$coupon_details->code)).'_'.$view.'.jpg';
                $data = array(
                    'url' => $DPname,
                    'coupon_id' => $coupon_details->id,
                    'view' => $view,
                    'alt' => ucfirst($coupon_details->name).' '.$view.' view',
                    'title' => ucfirst($coupon_details->name).' '.$view.' view'
                );
                
                $current_image = $this->db->get_where('coupon_images', array('coupon_id' => $coupon_details->id, 'view' => $view));
                if($current_image->num_rows() > 0) {
                    $this->mdl_coupon_images->_update($current_image->row()->id, $data);
                    redirect("coupons/edit/{$coupon_details->id}?tab=couponspics");
                }
                else {
                    $this->mdl_coupon_images->_insert($data);
                    redirect("coupons/edit/{$coupon_details->id}?tab=couponspics");
                }
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function tracking_num_update($coupon_id) {
      if ($this->session->userdata('logged_in')) {
          $session_data = $this->session->userdata('logged_in');
          $data['username'] = $session_data['username'];
          $data['user_type'] = $session_data['type'];
          $data['user_email'] = $session_data['email'];
          
          $data['page_name'] = 'coupons';
          $data['page_title'] = 'All coupons';
          
          $data['sidebar_element'] = 'side-promos';
          $data['sidebar_subelement'] = 'side-coupons-view';
                    
          $check = $this->mdl_coupons->get_where($coupon_id);
          if($check->num_rows() == 0) {
            redirect('404', 'refresh');
          }
          
          $coupon_details = $check->row();
          
          $tracking_num = $this->input->post('tracking_number', true);
          
          $new_data = array(
            'tracking_number' => $tracking_num
          );
          
          $this->mdl_coupons->_update($coupon_details->id, $new_data);
          $this->session->set_flashdata('tracking_num_success', 'Tracking Number added successfully.');
          redirect("coupons/coupon_info/{$coupon_details->id}", 'refresh');
          
      }
      else {
          redirect('login', 'refresh');
      }
    }

}
