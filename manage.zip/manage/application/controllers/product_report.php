<?php
defined('BASEPATH') OR exit();

class Product_report extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$this->load->helper(array(
			'form',
			'email_improved_helper',
			'page_initiater_helper'
		));
	}
	
	function index() {
		
		$data                    		= initiate_page();
		$data['page_name']       		= 'Product Report';
		$data['page_title']      		= 'Product Report';
		$data['sidebar_element'] 		= 'side-monitor';
		$data['sidebar_subelement'] 	= 'side-product-report';
		$data['seo_title']       		= 'Product Report';
		$data['seo_description'] 		= '';
		$data['seo_keywords']    		= '';
		
		$has_data = TRUE;
		$product_code = $this->input->post('product_code', TRUE);
		if( ! $product_code) {
			$has_data = FALSE;
		}
		$data['has_data'] = $has_data;
		
		if($has_data) {
			
			$product_code = trim($product_code);
			$data['product_code'] = $product_code;
			
			$product_details = array();
			$this->db->where('code', $product_code);
			$check = $this->db->get('products');
			if($check->num_rows() > 0) {
				$product_details = $check->row();
			} else {
				$this->session->set_flashdata('form_message', "<div class='alert alert-danger'>Invalid Product Code</div>");
				redirect('product_report', 'refresh');
			}
			
			$this->db->where('product_id', $product_details->id);
			$check = $this->db->get('stock_logs');
			$stock_log = $check->row();
			$added_date = $stock_log->added_date;
			$modified_date = $stock_log->modified_date;
			
			$pieces_sold = 0;
			$revenue_generated = 0;
			$order_ids = array();
			$added_days = 0;
			$modified_days = 0;
			$last_order_days = 0;
			
			$now = time();
			$added_date = date('Y-m-d', strtotime($stock_log->added_date));
			$your_date = strtotime($added_date);
			$datediff = $now - $your_date;
			$days = floor($datediff/(60*60*24));
			$added_days = $days;
			
			if($stock_log->modified_date == '0000-00-00 00:00:00') {
				$modified_days = '-';
			} else {
				$now = time();
				$modified_date = date('Y-m-d', strtotime($stock_log->modified_date));
				$your_date = strtotime($modified_date);
				$datediff = $now - $your_date;
				$days = floor($datediff/(60*60*24));
				$modified_days = $days;
			}
			
			$order_items = array();
			$this->db->where('product_id', $product_details->id);
			$this->db->order_by('id', 'desc');
			$check = $this->db->get('order_items');
			if($check->num_rows() > 0) {
				$last_sale = $check->row();
				$order_items = $check->result();
				
				$last_order = array();
				$this->db->where('id', $last_sale->order_id);
				$check = $this->db->get('orders');
				if($check->num_rows() > 0) {
					$last_order = $check->row();
				}
			}
			
			$data['added_date'] = $added_date;
			$data['modified_date'] = $modified_date;
			
			if( (isset($last_order)) AND (count($last_order) > 0) ) {
				$now = time();
				$last_sale_date = date('Y-m-d', strtotime($last_order->ordered_on));
				$your_date = strtotime($last_sale_date);
				$datediff = $now - $your_date;
				$days = floor($datediff/(60*60*24));
				$last_order_days = $days;
			}
			
			foreach($order_items as $item) {
				
				array_push($order_ids, $item->order_id); 
				$pieces_sold += $item->qty;
				
				if($item->currency == 'inr') {
					$revenue_generated += $item->net_price;
				} else {
					$revenue_generated += ($item->net_price * 65);
				}
			}
			
			$order_ids = array_unique($order_ids);
			$orders = array();
			if(count($order_ids) > 0) {
				$this->db->where_in('id', $order_ids);
				$this->db->order_by('id', 'desc');
				$check = $this->db->get('orders');
				if($check->num_rows() > 0) {
					$orders = $check->result();
				}
			}
			
			$this->load->helper('valid_date_helper');
			$this->load->model('model_payments');
			$this->load->model('model_customers');
			$this->load->model('model_order_items');
			
			$payment_details_index = array();
			$alterations_index = array();
			$shipping_index = array();
			$order_nums = array();
			$customer_index = array();
			
			foreach($orders as $order) {
			
				$payment_details = '';
				$payment_type = 'COD';
				
				if($order->payment_mode != 'cod') {
					$check = $this->model_payments->get($order->payment_id);
					if($check->num_rows() > 0) {
						$payment_details = $check->row();
						$payment_type = 'EBS';
						if($payment_details->paypal_payer_id != NULL) {
							$payment_type = 'PayPal';
						}
					}
				}
				
				$payment_details_index[$order->id] = $payment_type;
				
				if( ! isset($order_nums[$order->order_status])) {
					$order_nums[$order->order_status] = 0;
				}
				$order_nums[$order->order_status] += 1;
				
				$shipping_index[$order->id] = 'domestic';
				if($order->ship_to_country_id != 99) {
					$shipping_index[$order->id] = 'foreign';
				}
				
				if( ! isset($customer_index[$order->customer_id])) {
					$customer_details = array();
					$check = $this->model_customers->get($order->customer_id);
					if($check->num_rows() > 0) {
						$customer_details = $check->row();
					}
					$customer_index[$order->customer_id] = $customer_details;
				}
				
				$filters = array(
					'order_id' => $order->id,
					'alterations !=' => '',
				);
				$check = $this->model_order_items->get_where_array($filters);
				if($check->num_rows() > 0) {
					$alterations_index[$order->id] = 1;
				}
			}
			
			$data['orders'] = $orders;
			$data['payment_details_index'] = $payment_details_index;
			$data['shipping_index'] = $shipping_index;
			$data['orders_num'] = $order_nums;		
			$data['customer_index'] = $customer_index;
			$data['alterations_index'] = $alterations_index;
			
			
			$this->load->model('mdl_categories');
			$this->load->model('mdl_skus');
			$this->load->model('mdl_product_images');
			
			$parent_category_details = $this->mdl_categories->get_where($product_details->cat_id)->row();
            $data['parent_category_details'] = $parent_category_details;
            
            $product_images = $this->mdl_product_images->get_product_images($product_details->id);
            $data['product_images'] = $product_images;        
            
            $skus_list = $this->mdl_skus->get_where_custom('product_id', $product_details->id);
            $data['skus_list'] = $skus_list->result();
			
			$product_attributes = array();
            $check = $this->db->get_where('product_attrs', array('product_id' => $product_details->id));
            if($check->num_rows() > 0) {
				$product_attributes = $check->result();
            }
            
            $data['product_attributes'] = $product_attributes;
			
			$data['product_details'] = $product_details;
			$data['stock_log'] = $stock_log;
			$data['pieces_sold'] = $pieces_sold;
			$data['revenue_generated'] = $revenue_generated;
			$data['added_days'] = $added_days;
			$data['modified_days'] = $modified_days;
			$data['last_order_days'] = $last_order_days;
			
		}
		
		$this->load->view('header', $data);
		$this->load->view('product_report_view', $data);
		$this->load->view('footer', $data);
		
	}
	
}
