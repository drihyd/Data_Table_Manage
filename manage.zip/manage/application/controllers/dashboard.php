<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Dashboard extends CI_Controller {
    function __construct() {
        parent::__construct();
        $helpers = array(
            'form',
            'page_initiater_helper',
        );
        $models = array(
            'model_carts' => 'carts',
            'model_categories' => 'categories',
            'model_customers' => 'customers',
            'model_orders' => 'orders',
            'model_order_items' => 'order_items',
            'model_products' => 'products',
            'model_skus' => 'skus',
            'model_users' => 'users',
            'model_reorder_thresholds' => 'reorder_thresholds',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function index() {
		
        // echo "<h1>Under maintenance</h1>";
        // echo '<pre>'; print_r($this->session->userdata); exit();
        $data = initiate_page();
        $data['page_name'] = 'dashboard';
        $data['page_title'] = 'Dashboard';
        
        $data['sidebar_element'] = 'side-dashboard';
        
        $data['seo_title'] = 'Dashboard';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
        
        //$from = date('Y-m-d', strtotime('today - 30 days'));
        //$to = date('Y-m-d', time());
        
        //$get_from = $from;
        //if ($this->input->get('from', true)) {
            //$get_from = $this->input->get('from');
        //}
        //$data['get_from'] = $get_from;
        //$get_to = $to;
        //if ($this->input->get('to')) {
            //$get_to = $this->input->get('to', true);
        //}
        //$data['get_to'] = $get_to;
        
        //if(strtotime($get_from) > strtotime($get_to)) {
			//$get_from = $get_to;
			//$data['get_from'] = $get_from;
			//$this->filter_error("FROM DATE cannot be greater than TO DATE.");
			//redirect('dashboard', 'refresh');
		//}
		
        /* todays */
        $todays_orders = $this->get_todays_orders();
        $data['todays_orders_num'] = $todays_orders->num_rows();
        
        $todays_order_worth = $this->get_orders_worth($todays_orders->result());
        $data['todays_order_worth'] = $todays_order_worth;
        
        $todays_registrations = $this->get_todays_registrations();
        $data['todays_registrations'] = $todays_registrations;

        
        /* other stats */
        //$filters_array = array(
            //'get_from' => $get_from,
            //'get_to' => $get_to,
        //);
        //$orders = $this->get_filtered_orders($filters_array);
        //$data['orders'] = $orders;
        
        //$sorted_orders_date = $this->sort_orders_date($orders, $get_from, $get_to);
        //$data['sorted_orders_date'] = $sorted_orders_date;
        
        //$sorted_revenues_date = $this->sort_revenues_date($orders, $get_from, $get_to);
        //$data['sorted_revenues_date'] = $sorted_revenues_date;
        
        ///* stocks */
        //$categories = $this->categories->get_all();
        //$category_index = array();
        //$stock_alerts = array();
        
        //foreach($categories->result() as $category) {
			//$threshold = $this->reorder_thresholds->get_where('cat_id', $category->id)->row();
			//$category_index[$category->id] = array(
				//'details' => $category,
				
				//'threshold_id' => $threshold->id,
				
				//'s' => 0,
				//'s_order' => 0,
				//'s_reorder_thresh' => $threshold->s,
				
				
				//'m' => 0,
				//'m_order' => 0,
				//'m_reorder_thresh' => $threshold->m,
				
				//'l' => 0,
				//'l_order' => 0,
				//'l_reorder_thresh' => $threshold->l,
				
				//'xl' => 0,
				//'xl_order' => 0,
				//'xl_reorder_thresh' => $threshold->xl,
				
				//'xxl' => 0,
				//'xxl_order' => 0,
				//'xxl_reorder_thresh' => $threshold->xxl,
				
				//'unstitched' => 0,
				//'unstitched_order' => 0,
				//'unstitched_reorder_thresh' => $threshold->unstitched,
			//);
			//$cat_array = $category_index[$category->id];
			
			//$skus = $this->skus->get_where('cat_id', $category->id);
			//$sku_index = array();
			//foreach($skus->result() as $sku) {
				//$sku_index[$sku->id] = $sku;
				//$size = strtolower($sku->size);
				//$cat_array[$size] += $sku->stock;
			//}
			//$filters = array(
				//'DATE(ordered_on) >=' => date('Y-m-d', strtotime('today - 3 months')),
				//'DATE(ordered_on) <=' => date('Y-m-d', strtotime('last day of previous month')),
				//'order_status !=' => 'cancelled',
				//'grand_total >' => 0,
				//'total_items >' => 0,
			//);
			//$orders = $this->orders->get_where_array($filters);
			//$order_index = array();
			//foreach($orders->result() as $order) {
				//$filters = array(
					//'order_id' => $order->id,
					//'cat_id' => $category->id,
				//);
				//$check_order_items = $this->order_items->get_where_array($filters);
				//$order_items = array();
				//if($check_order_items->num_rows() > 0) {
					//$order_items = $check_order_items->result();
				//}
				//foreach($order_items as $order_item) {
					//$cat_array["{$sku_index[$order_item->sku_id]->size}_order"] += $order_item->qty;
				//}
			//}	
			//$cat_array['s_order'] = ceil($cat_array['s_order']/3);
			//$cat_array['m_order'] = ceil($cat_array['m_order']/3);
			//$cat_array['l_order'] = ceil($cat_array['l_order']/3);
			//$cat_array['xl_order'] = ceil($cat_array['xl_order']/3);
			//$cat_array['xxl_order'] = ceil($cat_array['xxl_order']/3);
			//$cat_array['unstitched_order'] = ceil($cat_array['unstitched_order']/3);
			
			//$sizes = array('s', 'm', 'l', 'xl', 'xxl', 'unstitched');
			//foreach($sizes as $size) {
				//if( ($cat_array["{$size}"] <= $cat_array["{$size}_reorder_thresh"]) AND ($cat_array["{$size}_reorder_thresh"] > 0) ) {
					//array_push($stock_alerts, array(
						//'category_name' => $category->name,
						//'category_slug' => $category->slug,
						//'size' => "{$size}",
					//));
				//}
			//}
			
			//$category_index[$category->id] = $cat_array;
			//$data['category_index'] = $category_index;
		//}
		//$data['stock_alerts'] = $stock_alerts;
		
        //$this->load->view('header/header', $data);
        $this->load->view('header', $data);
        $this->load->view('dashboard_view', $data);
        //$this->load->view('footer/footer', $data);
        $this->load->view('footer', $data);
    }
    
    function logout() {
        $this->users->logout();
        redirect('login', 'refresh');
    }
    
    /**
     * Get filtered orders based on filters array
     * --
     * @param array $filters_array
     * --
     * @return array $result
     */
    function get_filtered_orders($filters_array) {
        $from = $filters_array['get_from'];
        $to = $filters_array['get_to'];
        $order_date_field = $this->orders->get_field_name('order_placed_date');
        $order_status_field = $this->orders->get_field_name('order_status');
        $grand_total_field = $this->orders->get_field_name('order_grand_total');
        $total_items_field = $this->orders->get_field_name('order_total_items');
        $filters = array();
        $filters["DATE({$order_date_field}) >="] = $from;
        $filters["DATE({$order_date_field}) <="] = $to;
        if (strtotime($from) == strtotime($to)) {
            $filters = array(); // empty the filters array
            $filters["DATE({$order_date_field}) ="] = $from;
        }
        //$filters["{$order_status_field} !="] = 'cancelled';
        $filters["{$grand_total_field} >"] = 0;
        $filters["{$total_items_field} >"] = 0;
        $orders = $this->orders->get_true_orders($filters);
        return $orders;
    }
    
    /**
     * Filter error generator and redirector
     * --
     * @param string $error
     * --
     * @return bool
     * --
     */
    function filter_error($error_message) {
		$this->load->library('user_agent');
		$this->session->set_flashdata('form_errors', "<div class='alert alert-danger'>{$error_message}</div>");
		if($this->agent->is_referral()) {
			redirect($this->agent->referrer(), 'refresh');
		}
	}
	
	/**
	 * Get today's orders
	 * --
	 * @param bool $only_num <returns only number if set to true>
	 * --
	 * @return bool/array $result
	 * --
	 */
	function get_todays_orders($num=FALSE) {
		$today = date('Y-m-d', time());
        //$order_date_field = $this->orders->get_field_name('order_placed_date');
        //$order_date_field = $this->orders->get_field_name('order_placed_date');
        //$order_status_field = $this->orders->get_field_name('order_status');
        //$grand_total_field = $this->orders->get_field_name('order_grand_total');
        //$total_items_field = $this->orders->get_field_name('order_total_items');
        //$filter_arrays = array(
			//"DATE({$order_date_field}) =" => $today,
			//"{$grand_total_field} >" => 0,
			//"{$total_items_field} >" => 0,
		//);
        //$result = $this->orders->get_where_array($filter_arrays);
        //if($num) {
			//return $result->num_rows();
		//}
		$this->db->where("DATE(ordered_on) = ", $today);
		$this->db->where('grand_total >', 0);
		$this->db->where('total_items >', 0);
		$this->db->where_not_in('order_status', array('cancelled', 'cancelled-refund-pending', 'cancelled-refunded', 'on-hold'));
		$check = $this->db->get('orders');
		return $check;
	}
	
	/**
	 * Get total order worth revenue
	 * --
	 * @param object $orders
	 * --
	 * @return int $worth
	 * --
	 */
	function get_orders_worth($orders) {
		$total = 0;
		foreach($orders as $order) {
			if($order->currency == 'usd') {
				$total += ($order->grand_total) * 65;
			} else {
				$total += ($order->grand_total);
			}
		}
		return $total;
	}
	
	/**
	 * Get today's registrations
	 * --
	 * @return int $num;
	 */
	function get_todays_registrations() {
		$today = date('Y-m-d', time());
		$reg_date_field = $this->customers->get_field_name('customer_registration_date');
		$filters = array(
			"DATE({$reg_date_field}) =" => $today,
		);
		return $this->customers->get_where_array($filters)->num_rows();
	}
    
    /**
     * Sort orders date wise
     * --
     * @param array $orders
     * --
     * @return array $result
     * --
     */
    function sort_orders_date($orders, $get_from, $get_to) {
		$sorted = array();
        $from_time = strtotime($get_from);
        $to_time = strtotime($get_to);
        foreach($orders->result() as $order) {
			$order_time = strtotime($order->ordered_on);
			while($from_time < $order_time) {
				$date = date('Y-m-d', $from_time);
				// google charts month starts with 0 -> jan, 11 -> dec
				$date = explode('-', $date);
				$month = $date[1] - 1;
				$date = $date[0].'-'.$month.'-'.$date[2];
				if( ! isset($sorted[$date])) {
					$sorted[$date] = 0;
				}
				$from_time = strtotime('+1 day', $from_time);
			}
			$date = date('Y-m-d', strtotime($order->ordered_on));
			// google charts month starts with 0 -> jan, 11 -> dec
			$date = explode('-', $date);
			$month = $date[1] - 1;
			$date = $date[0].'-'.$month.'-'.$date[2];
			
			if( ! isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$sorted[$date] += 1;
		}
		while($from_time <= $to_time) {
			$date = date('Y-m-d', $from_time);
			$date = explode('-', $date);
			$month = $date[1] - 1;
			$date = $date[0].'-'.$month.'-'.$date[2];
			if( ! isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$from_time = strtotime('+1 day', $from_time);
		}
		return $sorted;
	}
	
	/**
     * Sort revenues date wise
     * --
     * @param array $orders
     * --
     * @return array $result
     * --
     */
    function sort_revenues_date($orders, $get_from, $get_to) {
		$sorted = array();
        $from_time = strtotime($get_from);
        $to_time = strtotime($get_to);
        foreach($orders->result() as $order) {
			$order_time = strtotime($order->ordered_on);
			while($from_time < $order_time) {
				$date = date('Y-m-d', $from_time);
				// google charts month starts with 0 -> jan, 11 -> dec
				$date = explode('-', $date);
				$month = $date[1] - 1;
				$date = $date[0].'-'.$month.'-'.$date[2];
				if( ! isset($sorted[$date])) {
					$sorted[$date] = 0;
				}
				$from_time = strtotime('+1 day', $from_time);
			}
			$date = date('Y-m-d', strtotime($order->ordered_on));
			// google charts month starts with 0 -> jan, 11 -> dec
			$date = explode('-', $date);
			$month = $date[1] - 1;
			$date = $date[0].'-'.$month.'-'.$date[2];
			
			if( ! isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$sorted[$date] += $order->grand_total;
		}
		while($from_time <= $to_time) {
			$date = date('Y-m-d', $from_time);
			$date = explode('-', $date);
			$month = $date[1] - 1;
			$date = $date[0].'-'.$month.'-'.$date[2];
			if( ! isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$from_time = strtotime('+1 day', $from_time);
		}
		return $sorted;
	}
}
