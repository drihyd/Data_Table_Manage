<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sliders extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('mdl_sliders', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'types';
      $sliders = array();
      $query = $this->mdl_sliders->get('id');
      if($query) :
        foreach($query->result() as $slider) {
          
          $cat_name = $this->db->query("select * from categories where id = '{$slider->cat_id}'");
          $cat_name = $cat_name->row()->name;
          
          $types[$slider->id] = array(
            'id' => $slider->id,
            'cat_id' => $slider->cat_id,
            'url' => $slider->url,
            'caption' => $slider->caption,
            'supertext' => $slider->supertext,
            'subtext' => $slider->subtext,
            'image' => $slider->image
          );
        }
      endif;
      $data['types'] = $types;
      $this->load->view('header', $data);
      $this->load->view('slides_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function edit($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'types';
      
      $slider_details = array();
      $query = $this->mdl_sliders->get_where($id);
      
      foreach($query->result() as $slider) {
        
        $slider_details = array (
          'id' => $slider->id,
          'cat_id' => $slider->cat_id,
          'url' => $slider->url,
          'caption' => $slider->caption,
          'supertext' => $slider->supertext,
          'subtext' => $slider->subtext,
          'image' => $slider->image
        );
      }
      $data['slider_details'] = $slider_details;
      
      $query = $this->db->query("select * from categories where id = '{$slider_details['cat_id']}'");
      $category = array();
      $category = array(
        'id' => $query->row()->id,
        'name' => $query->row()->name,
        'parent_id' => $query->row()->parent_id
      );
      $data['category'] = $category;
      
      $data['tinyMC'] = FALSE;
      
      $this->load->view('header', $data);
      $this->load->view('slider_edit', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function save($id=FALSE) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'sliders';
      
      $sliderParentCat = $this->input->post('sliderParentCat');
      $sliderUrl = $this->input->post('sliderUrl');
      $sliderCaption = $this->input->post('sliderCaption');
      $sliderSupertext = $this->input->post('sliderSupertext');
      $sliderSubtext = $this->input->post('sliderSubtext');
      
      
      if($id) {
        if($_FILES['sliderImage']['name']) {
          
          $config['upload_path']='../assets/uploads/files/';
          $config['allowed_types']='gif|png|jpg|jpeg';
          $this->load->library('upload',$config);
          
          if(!$this->upload->do_upload('sliderImage')) {
            $data['uploadErrors'] = $this->upload->display_errors();
            echo $data['uploadErrors'].'<br>';
            echo "<a href='{$this->config->base_url()}sliders/edit/{$id}'>Please try again</a>"; 
          }
          else {
            $res = $this->upload->data();
            $DPname = $res['file_name'];
            $data = array(
              'cat_id' => $sliderParentCat,
              'url' => $sliderUrl,
              'caption' => $sliderCaption,
              'supertext' => $sliderSupertext,
              'subtext' => $sliderSubtext,
              'image' => $DPname
            );
            $current_image = $this->db->query("select * from sliders where id = {$id}");
            if(!($current_image->row()->image == '')) :
              unlink('../assets/uploads/files/'.$current_image->row()->image);
            endif;
            $this->mdl_sliders->_update($id, $data);
            $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
            //echo $data['success'];
            redirect("categories/parentedit/{$sliderParentCat}");
          }
        }
        else {
          $data = array(
            'cat_id' => $sliderParentCat,
            'url' => $sliderUrl,
            'caption' => $sliderCaption,
            'supertext' => $sliderSupertext,
            'subtext' => $sliderSubtext
          );
      
          $this->mdl_sliders->_update($id, $data);
          $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
          redirect("categories/parentedit/{$sliderParentCat}");
        }
      }
      else {
        
        if($_FILES['sliderImage']['name']) {
          
          $config['upload_path']='../assets/uploads/files/';
          $config['allowed_types']='gif|png|jpg|jpeg';
          $this->load->library('upload',$config);
          
          if(!$this->upload->do_upload('sliderImage')) {
            $data['uploadErrors'] = $this->upload->display_errors();
            echo $data['uploadErrors'].'<br>';
            echo "<a href='{$this->config->base_url()}categories/parentedit/{$sliderParentCat}'>Please try again</a>"; 
          }
          else {
            $res = $this->upload->data();
            $DPname = $res['file_name'];
            $data = array(
              'cat_id' => $sliderParentCat,
              'url' => $sliderUrl,
              'caption' => $sliderCaption,
              'supertext' => $sliderSupertext,
              'subtext' => $sliderSubtext,
              'image' => $DPname
            );
            
            $this->mdl_sliders->_insert($data);
            $data['success'] = "<div class='alert alert-success'>Record Added Successfully!</div>";
            redirect("categories/parentedit/{$sliderParentCat}");
          }
        }
        else {
          echo "<h1>Error!</h1>";
          echo "<a href='{$this->config->base_url()}categories/parentedit/{$sliderParentCat}'>Please try again</a>"; 
        }
      }
      
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function add($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'sliders';
      
      $query = $this->db->query("select * from categories where id = '{$id}'");
      $category = array();
      $category = array(
        'id' => $query->row()->id,
        'name' => $query->row()->name,
        'parent_id' => $query->row()->parent_id
      );
      
      $data['category'] = $category;
      
      $data['tinyMC'] = FALSE;
      
      $this->load->view('header', $data);
      $this->load->view('slider_add', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }

  function delete($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $slider_details = array();
      $query = $this->mdl_sliders->get_where($id);
      
      foreach($query->result() as $slider) {
        
        $slider_details = array (
          'cat_id' => $slider->cat_id
        );
      }
      
      $current_image = $this->db->query("select * from sliders where id = {$id}");
      if(!($current_image->row()->image == '')) :
        unlink('../assets/uploads/files/'.$current_image->row()->image);
      endif;
      
      $this->mdl_sliders->_delete($id);
      
      redirect("categories/parentedit/{$slider_details['cat_id']}");
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  
    
  function get($order_by) {
  $this->load->model('mdl_sliders');
  $query = $this->mdl_sliders->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_sliders');
  $query = $this->mdl_sliders->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_sliders');
  $query = $this->mdl_sliders->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_sliders');
  $query = $this->mdl_sliders->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_sliders');
  $this->mdl_sliders->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_sliders');
  $this->mdl_sliders->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_sliders');
  $this->mdl_sliders->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_sliders');
  $count = $this->mdl_sliders->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_sliders');
  $max_id = $this->mdl_sliders->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_sliders');
  $query = $this->mdl_sliders->_custom_query($mysql_query);
  return $query;
  }

}
