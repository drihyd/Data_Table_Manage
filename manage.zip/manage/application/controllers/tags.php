<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Tags extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_tags', '', TRUE);
        $this->load->model('mdl_tagged_products', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Tags';
            $data['page_title'] = 'All Tags';
            
            $data['sidebar_element'] = 'side-master-data';
            $data['sidebar_subelement'] = 'side-tags-view';
            
            $this->db->order_by('id', 'desc');
            $check = $this->mdl_tags->get('id');
            if($check->num_rows() > 0) {
              $tags = $check->result();
            }
            else {
              $tags = array();
            }
            
            $tag_num_products = array();
            foreach($tags as $tag) {
              $this->db->where('tag_id', $tag->id);
              $this->db->from('tagged_products');
              $tag_num_products[$tag->id] = $this->db->count_all_results();
            }
            
            $data['tags'] = $tags;
            $data['tag_num_products'] = $tag_num_products;
            
            $this->load->view('header', $data);
            $this->load->view('tags_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function delete($id) {
      if ($this->session->userdata('logged_in')) {
          $session_data = $this->session->userdata('logged_in');
          $data['username'] = $session_data['username'];
          $data['user_type'] = $session_data['type'];
          $data['user_email'] = $session_data['email'];
          
          $check = $this->mdl_tags->get_where($id);
          if($check->num_rows() > 0) {
            $tag = $check->row();
          }
          else {
            redirect('404', 'refresh');
          }
          
          //delete taged products table entries first
          $this->db->where('tag_id', $tag->id);
          $this->db->delete('tagged_products');
          
          //now delete actual tag
          $this->mdl_tags->_delete($tag->id);
          
          redirect($this->config->base_url().'tags');
      }
      else {
          redirect('login', 'refresh');  
      }
    }
    
    
    function edit($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit tag';
            $data['page_title'] = 'Edit tag';
            
            $data['sidebar_element'] = 'side-tags';
            $data['sidebar_subelement'] = 'side-tags-view';
            
            if( ! $id ) {
              redirect('404', 'refresh');
            }
            
            $check = $this->mdl_tags->get_where($id);
            if($check->num_rows() > 0) {
              $tag_details = $check->row();
            }
            else {
              $tag_details->array();
            }
            $data['tag_details'] = $tag_details;
            
            $this->load->model('mdl_tagged_products');
            $this->load->model('mdl_products');
            $this->load->model('mdl_categories');
            
            $tagged_products = array();
            $check = $this->mdl_tagged_products->get_where_custom('tag_id', $tag_details->id);
            if($check->num_rows() > 0) {
              $tagged_products = $check->result();
            }
            $data['tagged_products'] = $tagged_products;
            
            $products_info = array();
            foreach($tagged_products as $product) {
              $check = $this->mdl_products->get_where($product->product_id);
              if($check->num_rows() > 0) {
                $products_info[$product->product_id] = $check->row();
              }
            }
            $data['products_info'] = $products_info;
            
            $categories_info = array();
            foreach($products_info as $product) {
              $check = $this->mdl_categories->get_where($product->cat_id);
              if($check->num_rows() > 0) {
                $categories_info[$product->cat_id] = $check->row();
              }
            }
            $data['categories_info'] = $categories_info;
            
            $tagged_product_codes = array();
            //print_r($tagged_products);
            foreach($tagged_products as $product) {
              if(isset($products_info[$product->product_id])) {
                array_push($tagged_product_codes, $products_info[$product->product_id]->code);
              }
            }
            $data['tagged_product_codes'] = $tagged_product_codes;
            
            $this->load->view('header', $data);
            $this->load->view('tag_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function add() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Add tag';
            $data['page_title'] = 'Add tag';
            
            $data['sidebar_element'] = 'side-tags';
            $data['sidebar_subelement'] = 'side-add-tag';
            
            $this->load->view('header', $data);
            $this->load->view('tag_add', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function seosave($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'categories';
            $data['sidebar_element'] = 'side-tags';
            $data['sidebar_subelement'] = 'side-tags-view';
            
            $check = $this->mdl_tags->get_where($id);
            if($check->num_rows() == 0) :
                redirect('404', 'refresh');
            endif;
            
            $seoTitle = $this->input->post('tagSeoTitle', true);
            $seoDesc = $this->input->post('tagSeoDesc', true);
            $seoKeys = $this->input->post('tagSeoKeys', true);
            
            $data = array(
                'seo_title' => $seoTitle,
                'seo_desc' => $seoDesc,
                'seo_keywords' => $seoKeys
            );
            $this->mdl_tags->_update($id, $data);
            
            
            $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Upadated successfully.</strong></div>");
            redirect("tags/edit/{$id}?tab=seotags");

        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function save($id=null) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = '';
            
            $data['sidebar_element'] = 'side-cities';
            $data['sidebar_subelement'] = 'side-cities-view';
            
            $this->load->model('mdl_products');
            
            if($id) {
              $check = $this->mdl_tags->get_where($id);
              if($check->num_rows() > 0) {
                $tag_details = $check->row();
              }
              else {
                redirect('404', 'refresh');
              }
              
              $tagName = $this->input->post('tagName', true);
              $tagslug = $this->input->post('tagSlug', true);
              $tagDesc = $this->input->post('tagDesc', true);
              $tagPosScore = (int) $this->input->post('tagPosScore', true);
              $tagProductsList = $this->input->post('tagProductsList', true);
              
              if( (trim($tagName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("tags/edit/{$id}");
              }
              
              if( (trim($tagslug) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Slug cannot be empty.</strong></div>");
                redirect("tags/edit/{$id}");
              }
              
              $this->db->where('id !=', $id);
              $check = $this->mdl_tags->get_where_custom('slug', $tagslug);
              if($check->num_rows() > 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Slug already exists. Enter a unique slug.</strong></div>");
                redirect("tags/edit/{$id}");
              }
              
              if ( !(is_int($tagPosScore)) || (!($tagPosScore >= 0)) || (!($tagPosScore <= 1000))) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Position Score should be a number between 0 and 1000.</strong></div>");
                redirect("tags/edit/{$id}");
              }
              
              $taggedProductCodes = array();
              $taggedProducts = array();
              $invalidProductCodes = array();
              
              //print_r($tagProductsList);
              $tagProductsList = str_replace(' ', '', $tagProductsList);
              $taggedProductCodes = explode(',', $tagProductsList);
              $taggedProductCodes = array_unique($taggedProductCodes);
              
              foreach($taggedProductCodes as $productCode) {
                $check = $this->mdl_products->get_where_custom('code', $productCode);
                if($check->num_rows() > 0) {
                  array_push($taggedProducts, $check->row()->id);
                }
                else {
                  array_push($invalidProductCodes, $productCode);
                }
              }
              
              $this->db->where('tag_id', $tag_details->id);
              $this->db->delete('tagged_products');
              
              foreach($taggedProducts as $product) {
                
                $new_data = array(
                  'tag_id' => $tag_details->id,
                  'product_id' => $product
                );
                
                $this->mdl_tagged_products->_insert($new_data);
              }

              $new_data = array(
                'name' => $tagName,
                'slug' => $tagslug,
                'desc' => $tagDesc,
                'pos_score' => $tagPosScore
              );
              
              $this->mdl_tags->_update($tag_details->id, $new_data);
              
              //$this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully updated!</strong></div>");
              
              
              if(count($taggedProducts) > 0) {
                $add_count = count($taggedProducts);
                $this->session->set_flashdata('tag-success-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully addded {$add_count} product(s).</strong></div>");
              }
              
              if(count($invalidProductCodes) > 0) {
                $invalid_codes = implode(', ', $invalidProductCodes);
                $this->session->set_flashdata('tag-success-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button>The following products were invalid, and hence were not added:<br><strong>{$invalid_codes}.</strong></div>");
              }
              
              redirect("tags/edit/{$id}");
            
            }
            else {
              
              $tagName = $this->input->post('tagName', true);
              $tagslug = $this->input->post('tagSlug', true);
              $tagDesc = $this->input->post('tagDesc', true);
              $tagPosScore = (int) $this->input->post('tagPosScore', true);
              
              if( (trim($tagName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("tags/add");
              }
              
              if( (trim($tagslug) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Slug cannot be empty.</strong></div>");
                redirect("tags/add");
              }
              
              $check = $this->mdl_tags->get_where_custom('slug', $tagslug);
              if($check->num_rows() > 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Slug already exists. Enter a unique slug.</strong></div>");
                redirect("tags/add");
              }
              
              if ( !(is_int($tagPosScore)) || (!($tagPosScore >= 0)) || (!($tagPosScore <= 1000))) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Position Score should be a number between 0 and 1000.</strong></div>");
                redirect("tags/add");
              }

              $new_data = array(
                'name' => $tagName,
                'slug' => $tagslug,
                'desc' => $tagDesc,
                'pos_score' => $tagPosScore
              );
              
              $this->mdl_tags->_insert($new_data);
              $id = $this->db->insert_id();
              
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully added!</strong></div>");
              
              redirect("tags/edit/{$id}");
            
            }

        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function DPimageSave($id)
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];

            if ($id) {
                
                $check = $this->mdl_tags->get_where($id);
                if($check->num_rows() == 0) :
                    redirect('404', 'refresh');
                endif;
                
                if ($_FILES['tagDPChange']['name']) {
                    $config['upload_path'] = '../assets/uploads/tags';
                    $config['allowed_types'] = 'png|jpg|jpeg';
                    $this->load->library('upload', $config);
                    if (!$this->upload->do_upload('tagDPChange')) {
                        $data['uploadErrors'] = $this->upload->display_errors();
                        $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! {$data['uploadErrors']}</strong></div>");
                        redirect("tags/edit/{$id}?tab=displaypic");
                    }
                    else {
                        $res = $this->upload->data();
                        $DPname = 'tags/'.$res['file_name'];
                        $data = array(
                            'dp_image' => $DPname
                        );
                        $current_image = $this->mdl_tags->get_where($id);
                        if (!($current_image->row()->dp_image == '')):
                            unlink('../assets/uploads/' . $current_image->row()->dp_image);
                        endif;
                        $this->mdl_tags->_update($id, $data);
                        redirect("tags/edit/{$id}?tab=displaypic");
                    }
                }
                else {
                    echo "<h1>Error!</h1>";
                    echo "<a href='{$this->config->base_url() }tags/edit/{$id}'>Please try again</a>";
                }

            }
            else {
                redirect('404', 'refresh');
            }
        }
        else {
            redirect('login', 'refresh');
        }
    }

}
