<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');
class Fix_attributes extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper'
		);
		$models  = array(
			'model_products' => 'products',
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
	
	function index() {
		 
		$data['page_name']       = 'Fix Attributes';
		$data['page_title']      = 'Fix Attributes';
		
		$data['seo_title']       = 'Fix Attributes';
		$data['seo_description'] = '';
		$data['seo_keywords']    = '';
    
		$products = array();
		$check = $this->products->get_all();
		if($check->num_rows() > 0) {
			$products = $check->result();
		}
		
		$attributes = array();
		$check = $this->db->get('attributes');
		if($check->num_rows() > 0) {
			$attributes = $check->result();
		}
		
		$attribute_names = array();
		foreach($attributes as $attribute) {
			$attribute_names[$attribute->id] = $attribute->attr_name;
		}
		
		foreach($products as $product) {
			$product_id = $product->id;
			
			$attributes = array();
			$check = $this->db->get_where('product_attributes', array('product_id' => $product_id));
			if($check->num_rows() > 0) {
				$attributes = $check->result();
			}
			
			foreach($attributes as $attribute) {
				$attribute_id = $attribute->attribute_id;
				$attribute_value = array();
				$check = $this->db->get_where('attribute_values', array('id' => $attribute_id));
				if($check->num_rows() > 0) {
					$attribute_value = $check->row();
				}
				
				$name_of_attribute = $attribute_names[$attribute_value->attr_id];
				$value_of_attribute = $attribute_value->attr_value;
				
				$new_data = array(
					'product_id' 		=> $product->id,
					'attribute_name' 	=> $name_of_attribute,
					'attribute_value' 	=> $value_of_attribute,
				);
				
				$check = $this->db->get_where('product_attrs', array('product_id' => $product->id, 'attribute_name' => $name_of_attribute));
				if($check->num_rows() > 0) {
					$this->db->where('id', $check->row()->id);
					$this->db->update('product_attrs', $new_data);
				} else {
					$this->db->insert('product_attrs', $new_data);
				}
			}
		}
		exit();
	}
}
