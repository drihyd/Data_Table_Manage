<style>
    .numbers-section {
        padding: 30px 0 0;
        background: #fff;
    }
    table.dataTable tbody th, table.dataTable tbody td {padding:5px 10px;}
    .stat-card {
        display: inline-block;
        border: 1px dashed #cacaca;
        padding: 15px 15px 3px;
        margin: 10px;
        text-align: center;
    }
    .stat-card.small {
        padding: 5px 20px;
    }
    .stat-card.small h1 {
        font-size: 16px;
    }
    .text-align-center {
        text-align: center;
    }
    @media(max-width:767px) {
        .stat-card, .stat-card.small {
            width: 100%;
            padding: 5px;
            margin: 5px;
        }
        .stat-card.small h1 {
            margin: 5px;
            font-size: 14px;
        }
        .stat-card.small p {
            margin: 0;
        }
    }
</style>
<?php
//date_default_timezone_set("Asia/Kolkata");
setlocale(LC_MONETARY, 'en_IN');
?>
<div class="sub-header">Queries &amp; Feedback</div>  
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table dataTable">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Message</th>
                    <th>Date</th>
                  </tr>
                </thead>
                
                  
<?php if(count($feedbacks) > 0) { ?>
                <tbody>
<?php
        foreach ($feedbacks as $feedback) { ?> 
                  <tr>
                    <td><?php echo $feedback->id; ?></a></td>
                    <td><?php echo ucwords($feedback->name); ?></td>
                    <td><?php echo $feedback->email; ?></td>
                    <td><?php echo $feedback->phone; ?></td>
                    <td><?php echo ucfirst($feedback->message); ?></td>
                    <td><?php echo date('d M, Y', strtotime($feedback->date)); ?></td>
<?php   } // end of foreach loop ?>
                </tbody>
<?php
      } //end of if 
      else {  ?>  
                <tfoot>                
                  <tr align='center'>
                    <td colspan="6">No feedback / Queries</td>
                  </tr>
                </tfoot>
<?php } // end of else ?>                  
                
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>
     
    
  </div>
  <!-- /#main-content -->
