<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Loyal_customers extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		$models = array(
			'Order_model',
			'Customer_model',
			'Lead_bank_model'
		);
		foreach ($models as $file) {
			$this->load->model($file);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
	
	function index() {
		$data = initiate_page();
		$data['page_name'] = 'Loyal Customers';
		$data['page_title'] = 'Loyal Customers';

		$data['sidebar_element'] = 'side-customers';
		$data['sidebar_subelement'] = 'side-loyal-customers';

		$data['seo_title'] = 'Loyal Customers';
		$data['seo_description'] = '';
		$data['seo_keywords'] = '';
		
		$excel = $this->input->get('excel', true);
		
		$sql = "SELECT `c`.*, `o`.`customer_id`, GROUP_CONCAT(DISTINCT CONCAT(LOWER(`o`.`ship_to_country`),',',LOWER(`o`.`bill_to_country`))) countries, GROUP_CONCAT(DISTINCT CONCAT(LOWER(`o`.`ship_to_city`),',',LOWER(`o`.`bill_to_city`))) cities, MAX(`o`.`ordered_on`) ordered_on, COUNT(`o`.`customer_id`) total_orders, SUM(`o`.`grand_total`) as total_revenue FROM `orders`  as o, `customers` as c  WHERE  `o`.`order_status` in ('dispatched', 'delivered') and `o`.`customer_id` = `c`.`id` GROUP BY `c`.`id` HAVING total_orders >= 2";
		
		//SELECT `c`.*, `o`.`customer_id`, `o`.`ordered_on`, COUNT(`o`.`customer_id`) order_count, SUM(`o`.`grand_total`) as grand_total FROM  `orders`  as o, `customers` as c  WHERE  `o`.`order_status` in ('dispatched', 'delivered') and `o`.`customer_id` = `c`.`id` GROUP BY `c`.`id` HAVING order_count >= 2
		
		$orders = array();
		$check = $this->db->query($sql);
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$customer_data = array();
		
		foreach($orders as $order) {
			$customer_id = $order->id;
			$reg_date = $order->date;
			if($reg_date == '' OR $reg_date == '0000-00-00 00:00:00') {
				$reg_date = '2015-05-01 00:00:00';
			}
			$num_days = $this->num_days($reg_date);
			$order->num_days = $num_days;
			
			$email = $order->email;
			if($order->is_guest == 1) {
				$email = $order->guest_email;
			}
			$order->email = $email;
			
			$countries = explode(',', $order->countries);
			$countries = array_unique($countries);
			$order->countries = implode(', ', $countries);
			
			$cities = explode(',', $order->cities);
			$cities = array_unique($cities);
			$order->cities = implode(', ', $cities);
			
			$avg_order_value = $order->total_revenue/$order->total_orders;
			$order->avg_order_value = $avg_order_value;
			
			$last_order = $order->ordered_on;
			$last_order_days = $this->num_days($last_order);
			$order->last_order_days = $last_order_days;
			$order = (array) $order;
			array_push($customer_data, $order);
		}
		$data['customer_data'] = $customer_data;
		
		if($excel == 1) {
			$this->load->view('loyal_customers_excel', $data);
		} else {		
			$this->load->view('header', $data);
			$this->load->view('loyal_customers_view', $data);
			$this->load->view('footer', $data);
		}
	}
	
	function num_days($reg_date) {
		$date1 = new DateTime($reg_date);
		$date2 = new DateTime(date('Y-m-d H:i:s', time()));
		return $date2->diff($date1)->format("%a");
	}
	
	function index_old() {
		
		$data = initiate_page();
		$data['page_name'] = 'Loyal Customers';
		$data['page_title'] = 'Loyal Customers';

		$data['sidebar_element'] = 'side-customers';
		$data['sidebar_subelement'] = 'side-loyal-customers';

		$data['seo_title'] = 'Loyal Customers';
		$data['seo_description'] = '';
		$data['seo_keywords'] = '';
		
		$this->db->where_in('order_status', array('dispatched', 'delivered'));
		$this->db->where('total_items >', 0);
		$this->db->where('grand_total >', 0);
		$this->db->where('customer_id !=', 0);
		$this->db->from('orders');
		$this->db->join('customers', 'orders.customer_id = customers.id');
		
		$excel = $this->input->get('excel', true);
		
		$orders = array();
		$check = $this->db->get();
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$customer_data = array();
		
		foreach($orders as $order) {
			$customer_id = $order->customer_id;
			
			$email = $order->email;
			if($order->is_guest == 1) {
				$email = $order->guest_email;
			}
			
			if(isset($customer_data[$email])) {
				CONTINUE;
			} 
			$customer_data[$email] = array();
			$details = $customer_data[$email];
			
			$details['email'] 				= $email;
			$details['id'] 					= $order->customer_id;
			$details['name'] 				= $order->name;
			$details['total_orders'] 		= 0;
			$details['total_revenue'] 		= 0;
			$details['avg_order_value'] 	= 0;
			$details['type'] 				= 'domestic';
			$details['city'] 				= array();
			$details['state'] 				= array();
			$details['country'] 			= array();
			
			
			$this->db->where('email', $email);
			$this->db->or_where('guest_email', $email);
			$customers = $this->db->get('customers');
			
			$customer_ids = array();
			foreach($customers->result() as $customer) {
				array_push($customer_ids, $customer->id);
			}
			
			$all_orders = array();
			$this->db->where_in('customer_id', $customer_ids);
			$check = $this->db->get('orders');
			if($check->num_rows() > 0) {
				$all_orders = $check->result();
			}
			
			foreach($all_orders as $all_order) {
				$details['total_orders'] += 1;
				$details['total_revenue'] += $all_order->grand_total;
				
				if( (trim(strtolower($all_order->ship_to_country)) != 'india') OR (trim(strtolower($all_order->bill_to_country)) != 'india') ) {
					$details['type'] = 'foreign';
				}
				
				array_push($details['country'], trim(strtolower($all_order->ship_to_country)));
				array_push($details['state'], trim(strtolower($all_order->ship_to_state)));
				array_push($details['city'], trim(strtolower($all_order->ship_to_city)));
				
				if( trim(strtolower($all_order->ship_to_country)) != trim(strtolower($all_order->bill_to_country)) ) {
					array_push($details['country'], trim(strtolower($all_order->bill_to_country)));
				}
				
				if( trim(strtolower($all_order->ship_to_state)) != trim(strtolower($all_order->bill_to_state)) ) {
					array_push($details['state'], trim(strtolower($all_order->bill_to_state)));
				}
				
				if( trim(strtolower($all_order->ship_to_city)) != trim(strtolower($all_order->bill_to_city)) ) {
					array_push($details['city'], trim(strtolower($all_order->bill_to_city)));
				}
				
			}
			
			$details['avg_order_value'] = $details['total_revenue']/$details['total_orders'];
			$details['city'] = array_unique($details['city']);
			$details['state'] = array_unique($details['state']);
			$details['country'] = array_unique($details['country']);
			$customer_data[$email] = $details;
		}
		
		function cmp($a, $b) {
			if ($a['total_orders'] == $b['total_orders']) {
				return 0;
			}
			return ($a['total_orders'] > $b['total_orders']) ? -1 : 1;
		}
		
		usort($customer_data, "cmp");
		$data['customer_data'] = $customer_data;
		
		if($excel == 1) {
			$this->load->view('loyal_customers_excel', $data);
		} else {		
			$this->load->view('header', $data);
			$this->load->view('loyal_customers_view', $data);
			$this->load->view('footer', $data);
		}
	}
}
			
