<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class States extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_states', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'States';
            $data['page_title'] = 'All States';
            
            $data['sidebar_element'] = 'side-master-data';
            $data['sidebar_subelement'] = 'side-states';
            
            $this->load->model('mdl_countries');
            $this->load->model('mdl_shipping_rates');
            $this->load->model('mdl_shipping_times');
            
            $check = $this->mdl_states->get('id');
            if($check->num_rows() > 0) {
              $states = $check->result();
            }
            else {
              $states = array();
            }
            
            $check = $this->mdl_shipping_rates->get('id');
            if($check->num_rows() > 0) {
              $shipping_rates_info = array();
              foreach($check->result() as $shipping_rate) {
                $shipping_rates_info[$shipping_rate->id] = $shipping_rate;
              }
            }
            else {
              $shipping_rates_info = array();
            }
            
            $check = $this->mdl_shipping_times->get('id');
            if($check->num_rows() > 0) {
              $shipping_times_info = array();
              foreach($check->result() as $shipping_time) {
                $shipping_times_info[$shipping_time->id] = $shipping_time;
              }
            }
            else {
              $shipping_times_info = array();
            }
            
            $check = $this->mdl_countries->get('id');
            if($check->num_rows() > 0) {
              $countries_info = array();
              foreach($check->result() as $country) {
                $countries_info[$country->id] = $country;
              }
            }
            else {
              $countries_info = array();
            }            
            
            $data['shipping_rates_info'] = $shipping_rates_info;
            $data['shipping_times_info'] = $shipping_times_info;
            $data['countries_info'] = $countries_info;
            $data['states'] = $states;
            
            $this->load->view('header', $data);
            $this->load->view('states_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function delete() {
      if ($this->session->userdata('logged_in')) {
          $session_data = $this->session->userdata('logged_in');
          $data['username'] = $session_data['username'];
          $data['user_type'] = $session_data['type'];
          $data['user_email'] = $session_data['email'];
          
          $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Sorry! You are not auhtorised to delete States. Please contact DB Administrator.</strong></div>");
          redirect("states");
            
      }
      else {
          redirect('login', 'refresh');
      }
    }
    
    
    function edit($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = 'Edit Shipping Rate';
            
            $data['sidebar_element'] = 'side-states';
            $data['sidebar_subelement'] = 'side-states-view';
            
            if( ! $id ) {
              redirect('404', 'refresh');
            }
            
            $check = $this->mdl_states->get_where($id);
            if($check->num_rows() > 0) {
              $state_details = $check->row();
            }
            else {
              $state_details->array();
            }
            
            $data['state_details'] = $state_details;
            
            $this->load->model('mdl_countries');
            $this->load->model('mdl_shipping_rates');
            $this->load->model('mdl_shipping_times');
            
            $check = $this->mdl_shipping_rates->get('id');
            if($check->num_rows() > 0) {
              $shipping_rates = $check->result();
            }
            else {
              $shipping_rates = array();
            }
            
            $check = $this->mdl_shipping_times->get('id');
            if($check->num_rows() > 0) {
              $shipping_times = $check->result();
            }
            else {
              $shipping_times = array();
            }
            
            $check = $this->mdl_countries->get_where($state_details->country_id);
            if($check->num_rows() > 0) {
              $parent_country = $check->row();
            }
            else {
              $parent_country = array();
            }
            
            $data['parent_country'] = $parent_country;
            
            $data['shipping_rates'] = $shipping_rates;
            $data['shipping_times'] = $shipping_times;
            
            $this->load->view('header', $data);
            $this->load->view('state_edit', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function save($id=null) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'Edit Shipping Rate';
            $data['page_title'] = '';
            
            $data['sidebar_element'] = 'side-states';
            $data['sidebar_subelement'] = 'side-states-view';
            
            $this->load->model('mdl_shipping_rates');
            $this->load->model('mdl_shipping_times');
            
            if($id) {
              $check = $this->mdl_states->get_where($id);
              if($check->num_rows() > 0) {
                $state_details = $check->row();
              }
              else {
                redirect('404', 'refresh');
              }
              
              $stateName = $this->input->post('stateName', true);
              $stateShippingRateID = (int) $this->input->post('stateShippingRateID', true);
              $stateShippingTimeID = (int) $this->input->post('stateShippingTimeID', true);
              $stateTax = $this->input->post('stateTax', true);
              $stateCOD = (int) $this->input->post('stateCOD', true);
              
              if( (trim($stateName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("states/edit/{$id}");
              }
            
              if( (trim($stateShippingRateID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Rate cannot be empty.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              if( (trim($stateShippingTimeID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Time cannot be empty.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              if( (trim($stateTax) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Tax cannot be empty.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              if( (trim($stateCOD) == '') || ( ! in_array($stateCOD, array(0,1)) ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid COD Availability.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_rates->get_where($stateShippingRateID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Rate ID.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_times->get_where($stateShippingTimeID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Time ID.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              $new_data = array(
                'state_name' => $stateName,
                'shipping_rate_id' => $stateShippingRateID,
                'shipping_time_id' => $stateShippingTimeID,
                'tax_percentage' => $stateTax,
                'cod_available' => $stateCOD
              );
              
              $this->mdl_states->_update($id, $new_data);
              
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully updated!</strong></div>");
              redirect("states/edit/{$id}");
            
            }
            else {
              
              $stateName = $this->input->post('stateName', true);
              $stateShippingRateID = (int) $this->input->post('stateShippingRateID', true);
              $stateShippingTimeID = (int) $this->input->post('stateShippingTimeID', true);
              $stateTax = $this->input->post('stateTax', true);
              $stateCOD = (int) $this->input->post('stateCOD', true);
              
              if( (trim($stateName) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Name cannot be empty.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              if( (trim($stateCode) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Country Code cannot be empty.</strong></div>");
                redirect("states/edit/{$id}");
              }
            
              if( (trim($stateShippingRateID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Rate cannot be empty.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              if( (trim($stateShippingTimeID) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Shipping Time cannot be empty.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              if( (trim($stateTax) == '') ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Tax cannot be empty.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              if( (trim($stateCOD) == '') || ( ! in_array($stateCOD, array(0,1)) ) ) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid COD Availability.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_rates->get_where($stateShippingRateID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Rate ID.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              $check = $this->mdl_shipping_times->get_where($stateShippingTimeID);
              if($check->num_rows() == 0) {
                $this->session->set_flashdata('form-after-message', "<div class='alert alert-danger alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Error! Invalid Shipping Time ID.</strong></div>");
                redirect("states/edit/{$id}");
              }
              
              $new_data = array(
                'state_name' => $stateName,
                'shipping_rate_id' => $stateShippingRateID,
                'shipping_time_id' => $stateShippingTimeID,
                'tax_percentage' => $stateTax,
                'cod_available' => $stateCOD
              );
              
              $this->mdl_states->_insert($new_data);
              $id = $this->db->insert_id();
              $this->session->set_flashdata('form-after-message', "<div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Successfully added!</strong></div>");
              redirect("states/edit/{$id}");
            
            }

        }
        else {
            redirect('login', 'refresh');
        }
    }

}
