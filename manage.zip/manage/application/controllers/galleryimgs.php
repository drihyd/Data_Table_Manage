<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Galleryimgs extends CI_Controller {
  
  function __construct() {
    parent::__construct();
    $this->load->model('mdl_galleryimgs', '', TRUE);
    $this->load->helper(array('form'));
  }
  
  function index() {
    if($this->session->userdata('logged_in'))
    {
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'gallery';
      $galleryimgs = array();
      $query = $this->mdl_galleryimgs->get('id');
      if($query) :
        foreach($query->result() as $galleryimg) {
          
          $project_name = $this->db->query("select * from projects where id = '{$galleryimg->project_id}'");
          $project_name = $project_name->row()->name;
          
          $galleryimgs[$galleryimg->id] = array(
            'id' => $galleryimg->id,
            'project_id' => $galleryimg->project_id,
            'image' => $galleryimg->image_path
          );
        }
      endif;
      $data['galleryimgs'] = $galleryimgs;
      $this->load->view('header', $data);
      $this->load->view('gallery_view', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function edit($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'gallery';
      
      $galleryimg_details = array();
      $query = $this->mdl_galleryimgs->get_where($id);
      
      foreach($query->result() as $galleryimg) {
        
        $galleryimg_details = array (
          'id' => $galleryimg->id,
          'project_id' => $galleryimg->project_id,
          'caption' => $galleryimg->caption,
          'image' => $galleryimg->img_path
        );
      }
      $data['galleryimg_details'] = $galleryimg_details;
      
      $query = $this->db->query("select * from projects where id = '{$galleryimg_details['project_id']}'");
      $project = array();
      $project = array(
        'id' => $query->row()->id,
        'name' => $query->row()->name
      );
      $data['project'] = $project;
      
      $data['tinyMC'] = FALSE;
      
      $this->load->view('header', $data);
      $this->load->view('galleryimg_edit', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function save($id=FALSE) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'gallery';
      
      $galleryimgParentProject = $this->input->post('galleryimgParentProject');
      $galleryimgCaption = $this->input->post('galleryimgCaption');
      
      if($id) {
        if($_FILES['galleryimgImage']['name']) {
          
          $config['upload_path']='../assets/uploads/files/';
          $config['allowed_types']='gif|png|jpg|jpeg';
          $this->load->library('upload',$config);
          
          if(!$this->upload->do_upload('galleryimgImage')) {
            $data['uploadErrors'] = $this->upload->display_errors();
            echo $data['uploadErrors'].'<br>';
            echo "<a href='{$this->config->base_url()}galleryimgs/edit/{$id}'>Please try again</a>"; 
          }
          else {
            $res = $this->upload->data();
            $DPname = $res['file_name'];
            $data = array(
              'project_id' => $galleryimgParentProject,
              'caption' => $galleryimgCaption,
              'img_path' => $DPname
            );
            $current_image = $this->db->query("select * from gallery where id = {$id}");
            if(!($current_image->row()->image == '')) :
              unlink('../assets/uploads/files/'.$current_image->row()->image);
            endif;
            $this->mdl_galleryimgs->_update($id, $data);
            $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
            //echo $data['success'];
            redirect("projects/edit/{$galleryimgParentProject}");
          }
        }
        else {
          $data = array(
            'project_id' => $galleryimgParentProject,
            'caption' => $galleryimgCaption
          );
      
          $this->mdl_galleryimgs->_update($id, $data);
          $data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
          redirect("projects/edit/{$galleryimgParentProject}");
        }
      }
      else {
        
        if($_FILES['galleryimgImage']['name']) {
          $config['upload_path']='../assets/uploads/files/';
          $config['allowed_types']='gif|png|jpg|jpeg';
          $this->load->library('upload',$config);
          
          if(!$this->upload->do_upload('galleryimgImage')) {
            $data['uploadErrors'] = $this->upload->display_errors();
            echo $data['uploadErrors'].'<br>';
            echo "<a href='{$this->config->base_url()}projects/edit/{$galleryimgParentProject}'>Please try again</a>"; 
          }
          else {
            $res = $this->upload->data();
            $DPname = $res['file_name'];
            $data = array(
              'project_id' => $galleryimgParentProject,
              'caption' => $galleryimgCaption,
              'img_path' => $DPname
            );
            
            $this->mdl_galleryimgs->_insert($data);
            $data['success'] = "<div class='alert alert-success'>Record Added Successfully!</div>";
            redirect("projects/edit/{$galleryimgParentProject}");
          }
        }
        else {
          echo "<h1>Error!</h1>";
          echo "<a href='{$this->config->base_url()}projects/edit/{$galleryimgParentProject}'>Please try again</a>"; 
        }
      }
      
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function add($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      $data['page_name'] = 'gallery';
      
      $query = $this->db->query("select * from projects where id = '{$id}'");
      $project = array();
      $project = array(
        'id' => $query->row()->id,
        'name' => $query->row()->name
      );
      
      $data['project'] = $project;
      
      $data['tinyMC'] = FALSE;
      
      $this->load->view('header', $data);
      $this->load->view('galleryimg_add', $data);
      $this->load->view('footer', $data);
    }
    else {
      redirect('login', 'refresh');
    }
  }

  function delete($id) {
    if($this->session->userdata('logged_in')) {
      
      $session_data = $this->session->userdata('logged_in');
      $data['username'] = $session_data['username'];
      $data['user_type'] = $session_data['type'];
      
      $galleryimg_details = array();
      $query = $this->mdl_galleryimgs->get_where($id);
      
      foreach($query->result() as $galleryimg) {
        
        $galleryimg_details = array (
          'project_id' => $galleryimg->project_id
        );
      }
      
      $current_image = $this->db->query("select * from gallery where id = {$id}");
      if(!($current_image->row()->image == '')) :
        unlink('../assets/uploads/files/'.$current_image->row()->image);
      endif;
      
      $this->mdl_galleryimgs->_delete($id);
      
      redirect("projects/edit/{$galleryimg_details['project_id']}");
    }
    else {
      redirect('login', 'refresh');
    }
  }
  
  function get($order_by) {
  $this->load->model('mdl_galleryimgs');
  $query = $this->mdl_galleryimgs->get($order_by);
  return $query;
  }

  function get_with_limit($limit, $offset, $order_by) {
  $this->load->model('mdl_galleryimgs');
  $query = $this->mdl_galleryimgs->get_with_limit($limit, $offset, $order_by);
  return $query;
  }

  function get_where($id) {
  $this->load->model('mdl_galleryimgs');
  $query = $this->mdl_galleryimgs->get_where($id);
  return $query;
  }

  function get_where_custom($col, $value) {
  $this->load->model('mdl_galleryimgs');
  $query = $this->mdl_galleryimgs->get_where_custom($col, $value);
  return $query;
  }

  function _insert($data) {
  $this->load->model('mdl_galleryimgs');
  $this->mdl_galleryimgs->_insert($data);
  }

  function _update($id, $data) {
  $this->load->model('mdl_galleryimgs');
  $this->mdl_galleryimgs->_update($id, $data);
  }

  function _delete($id) {
  $this->load->model('mdl_galleryimgs');
  $this->mdl_galleryimgs->_delete($id);
  }

  function count_where($column, $value) {
  $this->load->model('mdl_galleryimgs');
  $count = $this->mdl_galleryimgs->count_where($column, $value);
  return $count;
  }

  function get_max() {
  $this->load->model('mdl_galleryimgs');
  $max_id = $this->mdl_galleryimgs->get_max();
  return $max_id;
  }

  function _custom_query($mysql_query) {
  $this->load->model('mdl_galleryimgs');
  $query = $this->mdl_galleryimgs->_custom_query($mysql_query);
  return $query;
  }

}
