<?php
date_default_timezone_set("Asia/Kolkata");
?>
<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class stock_logs extends CI_Controller {
    
    function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		$models = array(
			// add models
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
    }
    
    public function index() {
		
		$data = initiate_page();
		$data['page_name'] = 'Stock Logs';
		$data['page_title'] = 'Stock Logs';
		
		$data['sidebar_element'] = 'side-monitor';
		$data['sidebar_subelement'] = 'side-stock-logs';
		
		$data['seo_title'] = 'Stock Logs Report';
		$data['seo_desc'] = '';
		$data['seo_keywords'] = '';
		
		$skus = array();
		$this->db->where('stock >', 0);
		$check = $this->db->get('skus');
		if($check->num_rows() > 0) {
			$skus = $check->result();
		}
		
		$stock_index = array();
		
		$in_stock_product_ids = array();
		foreach($skus as $sku) {
			array_push($in_stock_product_ids, $sku->product_id);
			if( ! isset($stock_index[$sku->product_id])) {
				$stock_index[$sku->product_id] = 0;
			}
			$stock_index[$sku->product_id] += $sku->stock;
		}
		
		if(count($in_stock_product_ids) > 0) {
			$this->db->where_not_in('product_id', $in_stock_product_ids);
			$this->db->set('in_stock', 0);
			$this->db->update('stock_logs');
			
			$this->db->where_in('product_id', $in_stock_product_ids);
			$this->db->set('in_stock', 1);
			$this->db->update('stock_logs');
		}
		
		$zero_stock = 0;
		$this->db->where('in_stock', 0);
		$zero_stock = $this->db->get('stock_logs')->num_rows();
		$data['zero_stock'] = $zero_stock;
		
		$in_stock = 0;
		$this->db->where('in_stock', 1);
		$in_stock = $this->db->get('stock_logs');
		$data['in_stock'] = $in_stock->num_rows();
		
		$products = array();
		if($in_stock->num_rows() > 0) {
			$products = $in_stock->result();
		}
		
		$details_index = array();
		$age_index = array();
		$modified_index = array();
		$sale_index = array();
		
		$valid_order_ids = array();
		$valid_orders = array();
		
		$this->load->model('model_orders');
		$check = $this->model_orders->get_valid_orders();
		if($check->num_rows() > 0) {
			$valid_orders = $check->result();
		}
		
		foreach($valid_orders as $order) {
			array_push($valid_order_ids, $order->id);
		}
		
		foreach($products as $product) {
			
			$this->db->where('id', $product->product_id);
			$check = $this->db->get('products');
			if($check->num_rows() > 0) {
				$details_index[$product->product_id] = $check->row();
			}
			
			$this->db->where('product_id', $product->product_id);
			$this->db->where_in('order_id', $valid_order_ids);
			$order_items = array();
			$check = $this->db->get('order_items');
			if($check->num_rows() > 0) {
				$order_items = $check->result();
			}
			
			$sale_index[$product->product_id] = 0;
			
			foreach($order_items as $item) {
				$sale_index[$product->product_id] += $item->qty;
			}
			
			$added_days = $this->get_days(date('Y-m-d', strtotime($product->added_date)));
			if($product->modified_date == '0000-00-00 00:00:00') {
				$modified_days = '';
			} else {
				$modified_days = $this->get_days(date('Y-m-d', strtotime($product->modified_date)));
			}
			
			$age_index[$product->product_id] = $added_days;
			$modified_index[$product->product_id] = $modified_days;
		}
		
		asort($age_index);
		
		$data['details_index'] = $details_index;
		$data['stock_index'] = $stock_index;
		$data['age_index'] = $age_index;
		$data['modified_index'] = $modified_index;
		$data['sale_index'] = $sale_index;
		
		$this->load->view('header', $data);
		$this->load->view('stock_log_view', $data);
		$this->load->view('footer', $data);
	}
	
	function get_days($added_date) {
		$now = time();
		$your_date = strtotime("{$added_date}");
		$datediff = $now - $your_date;
		return floor($datediff/(60*60*24));
	}
    
    function index_old() {
		$data = initiate_page();
		$data['page_name'] = 'Stock Logs';
		$data['page_title'] = 'Stock Logs';

		$data['sidebar_element'] = 'side-monitor';
		$data['sidebar_subelement'] = 'side-stock-logs';

		$data['seo_title'] = 'Stock Logs Report';
		$data['seo_description'] = '';
		$data['seo_keywords'] = '';

		$products = array();
		$check = $this->db->get('stock_logs');
		if($check->num_rows() > 0) {
			$products = $check->result();
		}
		
		$i = 0;
		
		$this->db->where('stock >', 0);
		$check = $this->db->get('skus');
		$product_ids = array();
		if($check->num_rows() > 0) {
			foreach($check->result() as $sku) {
				array_push($product_ids, $sku->product_id);
			}
		}
		
		if(count($product_ids) > 0) {
			$new_data = array(
				'in_stock' => 0,
			);
			$this->db->where_not_in('product_id', $product_ids);
			$this->db->update('stock_logs', $new_data);
			
			$new_data = array(
				'in_stock' => 1,
			);
			$this->db->where_in('product_id', $product_ids);
			$this->db->update('stock_logs', $new_data);
		}
		
		//foreach($products as $product) {
			//$in_stock = 0;
			//$this->db->where('product_id', $product->product_id);
			//$this->db->where('stock >', 0);
			//$check = $this->db->get('skus');
			//if($check->num_rows() > 0) {
				//$in_stock = 1;
			//}
			//$this->db->where('product_id', $product->product_id);
			//$this->db->set('in_stock', $in_stock);
			//$this->db->update('stock_logs');
			
			//$i += 1;
			//if( $i == 10) {
				//echo 'hi';
				//exit();
			//}
		//}
		
		$slow_products = array();
		$product_sale_info = array();
		$product_age_info = array();
		$products = array();
		
		$this->db->where("DATE(`added_date`) <=", date('Y-m-d', strtotime('-30 days')));
		$this->db->where("DATE(`modified_date`) <=", date('Y-m-d', strtotime('-30 days')));
		$this->db->where('in_stock', 1);
		$check = $this->db->get('stock_logs');
		if($check->num_rows() > 0) {
			$products = $check->result();
		}
		
		foreach($products as $product) {
			$this->db->where('id', $product->product_id);
			$product_details = $this->db->get('products')->row();
			$slow_products[$product->product_id] = $product_details;
			$product_age_info[$product->product_id] = $product;
			
			$sold_pieces = 0;
			$order_items = array();
			$this->db->where('product_id', $product_details->id);
			$check = $this->db->get('order_items');
			if($check->num_rows() > 0) {
				$order_items = $check->result();
			}
			
			foreach($order_items as $item) {
				$sold_pieces += $item->qty;
			}
			
			$product_sale_info[$product->product_id] = $sold_pieces;			
		}
		
		//asort($product_sale_info);
		
		$data['slow_products'] = $slow_products;
		$data['product_sale_info'] = $product_sale_info;
		$data['product_age_info'] = $product_age_info;
		
		$this->load->view('header', $data);
		$this->load->view('stock_log_view', $data);
		$this->load->view('footer', $data);
	}
}
