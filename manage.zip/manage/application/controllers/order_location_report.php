<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class order_location_report extends CI_Controller {
    
    function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		$models = array(
			'model_orders' => 'orders',
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
    }
    
    function index() {
		$data = initiate_page();
		$data['page_name'] = 'Order Locations Report';
		$data['page_title'] = 'Order Locations Report';

		$data['sidebar_element'] = 'side-monitor';
		$data['sidebar_subelement'] = 'side-order-location-report';

		$data['seo_title'] = 'Order Locations Report';
		$data['seo_description'] = '';
		$data['seo_keywords'] = '';

		$from = date('Y-m-d', strtotime('today - 7 days'));
		$to = date('Y-m-d', time());

		$from_date = $from;
		$to_date = $to;

		if($this->input->get('from')) {
			$from_date = $this->input->get('from');
		}
		if($this->input->get('to')) {
			$to_date = $this->input->get('to');
		}
				
		if(strtotime($from_date) > strtotime($to_date)) {
			$get_from = $from;
			$data['from_date'] = $from;
			$this->session->set_flashdata('form_errors', "FROM DATE cannot be later than TO DATE.");
			redirect('color-report', 'refresh');
		}

		$data['get_from_date'] 	= $from_date;
		$data['get_to_date'] 	= $to_date;

		$filters = array(
			'DATE(ordered_on) >=' => $from_date,
			'DATE(ordered_on) <=' => $to_date,
		);
		
		$orders = array();
		$check = $this->orders->get_true_orders($filters);
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$data['orders'] = $orders;
		
		$domestic_orders_with_foreign_origin = 0;
		$foreign_orders_with_domestic_origin = 0;
		
		$domestic_orders_from_unknown_origin = 0;
		$foreign_orders_from_unknown_origin = 0;
		
		$domestic_orders_with_domestic_origin = 0;
		$foreign_orders_with_foreign_origin = 0;
		
		
		
		$foreign_origins_with_domestic_orders = array();
		$foreign_origins_with_foreign_orders = array();
		
		$unknown_origins_with_domestic_orders = array();
		$unknown_origins_with_foreign_orders = array();
		
		$foreign_locations_shipped_to_from_india = array();
		
		
		require_once('class/ip2location/ip2locationlite.class.php');
		$ipLite = new ip2location_lite;
		$ipLite->setKey('e7923ff52fde8b44c52b27b12063236d634ce8131739540979d32aaa53b4e03b');
		
		foreach ($orders as $order) {
			$ip = trim($order->v_ip);			
			$location_data = array();
			$origin = "unknown";
			if(($ip) AND ($ip != '')) {
				$country = NULL;
				//$location_data = $ipLite->getCity($ip);
				$country = $this->ip_info($ip, "Country");
				if($country != NULL) {
					$origin = $country;
				}
			}
			//if ( ! empty($location_data) AND is_array($location_data) AND isset($location_data['countryName'])) {
				//$origin = $location_data['countryName'];
			//}
			
			$origin = trim(strtolower($origin));
			$ship_to_country = strtolower(trim($order->ship_to_country));
			
			
			if($origin == 'india') {
				if($ship_to_country == 'india') {
					$domestic_orders_with_domestic_origin += 1;
				} else {
					$foreign_orders_with_domestic_origin += 1;
					
					if( ! isset($foreign_locations_shipped_to_from_india[$ship_to_country])) {
						$foreign_locations_shipped_to_from_india[$ship_to_country] = 0;
					}
					$foreign_locations_shipped_to_from_india[$ship_to_country] += 1;
				}
			} else if($origin == 'unknown') {
				if($ship_to_country == 'india') {
					$domestic_orders_from_unknown_origin += 1;
					if( ! isset($unknown_origins_with_domestic_orders[$origin])) {
						$unknown_origins_with_domestic_orders[$origin] = 0;
					}
					$unknown_origins_with_domestic_orders[$origin] += 1;
					
				} else {
					$foreign_orders_from_unknown_origin += 1;
					
					if ( ! isset($unknown_origins_with_foreign_orders[$origin])) {
						$unknown_origins_with_foreign_orders[$origin] = 0;
					}
					$unknown_origins_with_foreign_orders[$origin] += 1;
				}
			} else {
				if($ship_to_country == 'india') {
					$domestic_orders_with_foreign_origin += 1;
					if( ! isset($foreign_origins_with_domestic_orders[$origin])) {
						$foreign_origins_with_domestic_orders[$origin] = 0;
					}
					$foreign_origins_with_domestic_orders[$origin] += 1;
					
				} else {
					$foreign_orders_with_foreign_origin += 1;
					
					if ( ! isset($foreign_origins_with_foreign_orders[$origin])) {
						$foreign_origins_with_foreign_orders[$origin] = 0;
					}
					$foreign_origins_with_foreign_orders[$origin] += 1;
				}
			}
		}
		
		arsort($foreign_origins_with_domestic_orders);
		arsort($foreign_origins_with_foreign_orders);
		arsort($foreign_locations_shipped_to_from_india);
		arsort($unknown_origins_with_domestic_orders);
		arsort($unknown_origins_with_foreign_orders);

		$data['domestic_orders_with_foreign_origin'] = $domestic_orders_with_foreign_origin;
		$data['foreign_orders_with_domestic_origin'] = $foreign_orders_with_domestic_origin;
		
		$data['domestic_orders_from_unknown_origin'] = $domestic_orders_from_unknown_origin;
		$data['foreign_orders_from_unknown_origin'] = $foreign_orders_from_unknown_origin;
		
		$data['domestic_orders_with_domestic_origin'] = $domestic_orders_with_domestic_origin;
		$data['foreign_orders_with_foreign_origin'] = $foreign_orders_with_foreign_origin;
		
		
		$data['foreign_origins_with_domestic_orders'] = $foreign_origins_with_domestic_orders;
		$data['foreign_origins_with_foreign_orders'] = $foreign_origins_with_foreign_orders;
		
		$data['unknown_origins_with_domestic_orders'] = $unknown_origins_with_domestic_orders;
		$data['unknown_origins_with_foreign_orders'] = $unknown_origins_with_foreign_orders;
		
		$data['foreign_locations_shipped_to_from_india'] = $foreign_locations_shipped_to_from_india;
		
		//echo "domestic_orders_with_foreign_origin: " . $domestic_orders_with_foreign_origin . "<br><br>";
		//echo "foreign_orders_with_domestic_origin: " . $foreign_orders_with_domestic_origin . "<br><br>";;
		//echo "domestic_orders_with_domestic_origin: " . $domestic_orders_with_domestic_origin . "<br><br>";;
		//echo "foreign_orders_with_foreign_origin: " . $foreign_orders_with_foreign_origin . "<br><br>";;
		
		//echo "foreign_origins_with_domestic_orders: ";
		//print_r($foreign_origins_with_domestic_orders); echo "<br><br>";
		//echo "foreign_origins_with_foreign_orders: ";
		//print_r($foreign_origins_with_foreign_orders); echo "<br><br>";;
		//echo "foreign_locations_shipped_to_from_india: ";
		//print_r($foreign_locations_shipped_to_from_india); echo "<br><br>";;
		
		$this->load->view('header', $data);
		$this->load->view('order_locations_report_view', $data);
		$this->load->view('footer', $data);	
	}
	
	function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
		$output = NULL;
		if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
			$ip = $_SERVER["REMOTE_ADDR"];
			if ($deep_detect) {
				if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
					$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
				if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
					$ip = $_SERVER['HTTP_CLIENT_IP'];
			}
		}
		$purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
		$support    = array("country", "countrycode", "state", "region", "city", "location", "address");
		$continents = array(
			"AF" => "Africa",
			"AN" => "Antarctica",
			"AS" => "Asia",
			"EU" => "Europe",
			"OC" => "Australia (Oceania)",
			"NA" => "North America",
			"SA" => "South America"
		);
		if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
			$ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
			if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
				switch ($purpose) {
					case "location":
						$output = array(
							"city"           => @$ipdat->geoplugin_city,
							"state"          => @$ipdat->geoplugin_regionName,
							"country"        => @$ipdat->geoplugin_countryName,
							"country_code"   => @$ipdat->geoplugin_countryCode,
							"continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
							"continent_code" => @$ipdat->geoplugin_continentCode
						);
						break;
					case "address":
						$address = array($ipdat->geoplugin_countryName);
						if (@strlen($ipdat->geoplugin_regionName) >= 1)
							$address[] = $ipdat->geoplugin_regionName;
						if (@strlen($ipdat->geoplugin_city) >= 1)
							$address[] = $ipdat->geoplugin_city;
						$output = implode(", ", array_reverse($address));
						break;
					case "city":
						$output = @$ipdat->geoplugin_city;
						break;
					case "state":
						$output = @$ipdat->geoplugin_regionName;
						break;
					case "region":
						$output = @$ipdat->geoplugin_regionName;
						break;
					case "country":
						$output = @$ipdat->geoplugin_countryName;
						break;
					case "countrycode":
						$output = @$ipdat->geoplugin_countryCode;
						break;
				}
			}
		}
		return $output;
	}
}
