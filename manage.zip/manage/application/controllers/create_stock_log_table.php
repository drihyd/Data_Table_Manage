<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class create_stock_log_table extends CI_Controller {
    
    function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		$models = array(
			'model_products' => 'products',
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
    }
    
    function index() {
		$data = initiate_page();
		
		$ip_address = $this->input->ip_address();
		$user_id = $data['user_id'];
		
		$products = array();
		$check = $this->products->get_all();
		if($check->num_rows() > 0) {
			$products = $check->result();
		}
		
		$tracker = array();
		foreach($products as $product) {
			if(in_array($product->id, $tracker)) {
				CONTINUE;
			}
			array_push($tracker, $product->id);
			
			$in_stock = 0;
			$filters = array(
				'product_id' => $product->id,
				'stock >' => 0,
			);
			$stock_check = $this->db->get_where('skus', $filters);
			if($stock_check->num_rows() > 0) {
				$in_stock = 1;
			}
			$new_data = array(
				'product_id' 		=> $product->id,
				'product_code' 		=> $product->code,
				'added_date' 		=> date('2016-01-01 H:i:s', time()),
				'added_by_user_id' 	=> $user_id,
				'added_from_ip' 	=> $ip_address,
				'in_stock' 			=> $in_stock,
			);
			$this->db->insert('stock_logs', $new_data);
		}
	}
}
