<?php
date_default_timezone_set("Asia/Kolkata");

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Paypal_outbox extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_contests', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'PayPal Outbox';
            $data['page_title'] = 'Paypal Outbox';
            
            $data['sidebar_element'] = 'side-orders';
            $data['sidebar_subelement'] = 'side-paypal-outbox';
            
            $this->db->order_by('id', 'desc');
            $check = $this->db->get('paypal_outbox');
            $orders = array();
            
            if($check->num_rows() > 0) {
                $orders = $check->result();
            }
            $data['orders'] = $orders;
            
            $this->load->view('header', $data);
            $this->load->view('paypal_outbox_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
    
    function order_snapshot($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'PayPal Outbox';
            $data['page_title'] = 'Paypal Outbox';
            
            $data['sidebar_element'] = 'side-paypal-outbox';
            $data['sidebar_subelement'] = 'side-outbox-view';
            
            if( ! $id) {
                redirect('404', 'refresh');
            }
            
            $order_details = array();
            $check = $this->db->get_where('paypal_outbox', array('id' => $id));
            if($check->num_rows() > 0) {
                $order_details = $check->row();
            }
            
            $data['order_details'] = $order_details;
            
            //$this->load->view('header', $data);
            $this->load->view('outbox_snapshot_view', $data);
            //$this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

}
