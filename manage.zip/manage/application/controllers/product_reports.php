<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Product_reports extends CI_Controller

{
        function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_products', '', TRUE);
        $this->load->model('mdl_categories', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
        
        $this->load->model('datatable_model','datatable');
    }



   

    public function index()
    { 

        $this->product_listings();
    }

    function product_listings($id=NULL)
    {


        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];            
            $data['page_name'] = 'Report';
            $data['page_title'] = 'Products Reports';            
            $data['sidebar_element'] = 'side-products';
            $data['sidebar_subelement'] = 'side-products-view'; 
             $categories = $this->mdl_categories->get("name");    
             $categories = $categories->result();     
             $data['categories'] = $categories;    
             $data['page_name_new'] = "products_filter";    
            $this->load->view('header', $data);
            $this->load->view('products_reports', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }     
    }  

    function product_listings_ajax()
    {
        // echo '<pre>'; print_r($_POST); exit();

            $list = $this->datatable->get_datatables('products', null, null, true);

            $data = array();
            $no = 0;
            if (isset( $_POST['start'])) {
            $no = $_POST['start'];
            }

            foreach ($list as $item) {
            $no++;
            $row = array();

            $product_code = implode('_', explode(' ',$item->code));
            $product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
            
            if((is_array($product_images)) && (count(array_filter($product_images)) > 0)) {
                foreach($product_images as $image) {
                    $dpImage = $this->config->base_url().$image;
                    break;
                }
            } else {
                $dpImage = $this->config->base_url().'img/Not_Available.jpg';
            } 
            
    
            $row[] = "<img src='".$dpImage."' class='small-thumbnail tiny-thumbnail'>";
            $row[] = "<a href='". $this->config->base_url().'products/product_info/'.$item->id."'>". ucfirst($item->name)."</a>";
            $row[] = $item->code;
            $row[] = strtoupper($item->size);
            $row[] = $item->stock;
            $row[] = $item->price_inr;  
            $row[] = $item->price_usd;    
            $row[] = ucwords($item->cat_name);              
            $row[] =  '<a href="'.$this->config->base_url().'products/edit/'.$item->id.'" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>'."&nbsp;&nbsp;".'<a href="'.$this->config->base_url().'products/delete/'.$item->id.'" class="btn btn-default btn-edit delete-confirm" onclick="return confirm(\'Are you sure?\')"><span class="glyphicon glyphicon-trash"></span></a>';              
            
            $data[] = $row;
            }

            $output = array(                       
            "recordsTotal" => $this->datatable->count_all(),
            "recordsFiltered" => $this->datatable->count_filtered(),
            "data" => $data,
            ); 
            echo json_encode($output); 

    }   



function test_ajax()
    {
        // echo '<pre>'; print_r($_POST); exit();

            $list = $this->datatable->get_datatables('products', null, null, true);

            echo '<pre>'; print_r($list); exit();

            $data = array();
            $no = 0;
            if (isset( $_POST['start'])) {
            $no = $_POST['start'];
            }

            foreach ($list as $item) {
            $no++;
            $row = array();

            $product_code = implode('_', explode(' ',$item->code));
            $product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
            
            if((is_array($product_images)) && (count(array_filter($product_images)) > 0)) {
                foreach($product_images as $image) {
                    $dpImage = $this->config->base_url().$image;
                    break;
                }
            } else {
                $dpImage = $this->config->base_url().'img/Not_Available.jpg';
            } 
            
    
            $row[] = "<img src='".$dpImage."' class='small-thumbnail tiny-thumbnail'>";
            $row[] = "<a href='". $this->config->base_url().'products/product_info/'.$item->id."'>". ucfirst($item->name)."</a>";
            $row[] = $item->code;
            $row[] = strtoupper($item->size);
            $row[] = $item->stock;
            $row[] = $item->price_inr;  
            $row[] = $item->price_usd;    
            $row[] = ucwords($item->cat_name);              
            $row[] =  '<a href="'.$this->config->base_url().'products/edit/'.$item->id.'" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>'."&nbsp;&nbsp;".'<a href="'.$this->config->base_url().'products/delete/'.$item->id.'" class="btn btn-default btn-edit delete-confirm" onclick="return confirm(\'Are you sure?\')"><span class="glyphicon glyphicon-trash"></span></a>';              
            
            $data[] = $row;
            }

            $output = array(                       
            "recordsTotal" => $this->datatable->count_all(),
            "recordsFiltered" => $this->datatable->count_filtered(),
            "data" => $data,
            ); 
            echo json_encode($output); 

    }   

    public function get_parent_cat_id()
    {
    	$data=$this->datatable->get_parent_cat_id(8);
    	echo "<pre>";
    	print_r($data);
    	echo "</pre>";
    }
}