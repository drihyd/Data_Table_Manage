<?php
date_default_timezone_set("Asia/Kolkata");

if (!defined('BASEPATH'))
	exit('No direct script access allowed');
class Orders extends CI_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model('mdl_orders', '', TRUE);

		$helpers = array(
			'form',
			'page_initiater_helper',
		);
		$models = array(
			'model_orders' => 'orders',
		);

		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
	
	function index($period=NULL,$type=NULL) {
		
		$data = initiate_page();
		
		$data['page_name']  = 'orders';
		$data['page_title'] = 'All orders';

		$data['sidebar_element']    = 'side-orders';
		$data['sidebar_subelement'] = 'side-orders-view';
		
		$data['seo_title'] = 'Orders';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
        
        $this->load->helper('valid_date_helper');
        $this->load->model('model_payments');
        $this->load->model('model_customers');
        $this->load->model('model_order_items');
		
		$orders = array();
		
		if($type == NULL) {
			$check = $this->orders->get_all(500);
		}
		
		if($type == 'today') {
			$check = $this->orders->get_today();
		}
		
		if($type == 'month') {
			$month = $this->input->get('month', TRUE);
			$check = $this->orders->get_month($month);
		}
		
		if($type == 'fromto') {
			$from = $this->input->get('from', TRUE);
			$to = $this->input->get('to', TRUE);
			$check = $this->orders->get_from_to($from, $to);
		}
		
		
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$data['orders'] = $orders;
		
		$payment_details_index = array();
		$alterations_index = array();
		$shipping_index = array();
		$order_nums = array();
		$customer_index = array();
		
		foreach($orders as $order) {
			
			$payment_details = '';
			$payment_type = 'COD';
			
			if($order->payment_mode != 'cod') {
				$check = $this->model_payments->get($order->payment_id);
				if($check->num_rows() > 0) {
					$payment_details = $check->row();
					$payment_type = 'EBS';
					if($payment_details->paypal_payer_id != NULL) {
						$payment_type = 'PayPal';
					}
				}
			}
			
			$payment_details_index[$order->id] = $payment_type;
			
			if( ! isset($order_nums[$order->order_status])) {
				$order_nums[$order->order_status] = 0;
			}
			$order_nums[$order->order_status] += 1;
			
			$shipping_index[$order->id] = 'domestic';
			if($order->ship_to_country_id != 99) {
				$shipping_index[$order->id] = 'foreign';
			}
			
			if( ! isset($customer_index[$order->customer_id])) {
				$customer_details = array();
				$check = $this->model_customers->get($order->customer_id);
				if($check->num_rows() > 0) {
					$customer_details = $check->row();
				}
				$customer_index[$order->customer_id] = $customer_details;
			}
			
			$filters = array(
				'order_id' => $order->id,
				'alterations !=' => '',
			);
			$check = $this->model_order_items->get_where_array($filters);
			if($check->num_rows() > 0) {
				$alterations_index[$order->id] = 1;
			}
		}
		
		$data['orders'] = $orders;
		$data['payment_details_index'] = $payment_details_index;
		$data['shipping_index'] = $shipping_index;
		$data['orders_num'] = $order_nums;		
		$data['customer_index'] = $customer_index;
		$data['alterations_index'] = $alterations_index;
		
		$this->load->view('header', $data);
		$this->load->view('orders_view', $data);
		$this->load->view('footer', $data);
	}
	
	
	function today() {
		$data = initiate_page();
		
		$data['page_name']  = 'orders';
		$data['page_title'] = 'All orders';

		$data['sidebar_element']    = 'side-orders';
		$data['sidebar_subelement'] = 'side-orders-view';
		
		$data['seo_title'] = 'Orders';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
        
        $this->load->helper('valid_date_helper');
        $this->load->model('model_payments');
        $this->load->model('model_customers');
		
		$orders = array();
		$check = $this->orders->get_today();
		
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$data['orders'] = $orders;
		
		$payment_details_index = array();
		$alterations_index = array();
		$shipping_index = array();
		$order_nums = array();
		$customer_index = array();
		
		foreach($orders as $order) {
			
			$payment_details = '';
			$payment_type = 'COD';
			
			if($order->payment_mode != 'cod') {
				$check = $this->model_payments->get($order->payment_id);
				if($check->num_rows() > 0) {
					$payment_details = $check->row();
					$payment_type = 'EBS';
					if($payment_details->paypal_payer_id != NULL) {
						$payment_type = 'PayPal';
					}
				}
			}
			
			$payment_details_index[$order->id] = $payment_type;
			
			if( ! isset($order_nums[$order->order_status])) {
				$order_nums[$order->order_status] = 0;
			}
			$order_nums[$order->order_status] += 1;
			
			$shipping_index[$order->id] = 'domestic';
			if($order->ship_to_country_id != 99) {
				$shipping_index[$order->id] = 'foreign';
			}
			
			if( ! isset($customer_index[$order->customer_id])) {
				$customer_details = array();
				$check = $this->model_customers->get($order->customer_id);
				if($check->num_rows() > 0) {
					$customer_details = $check->row();
				}
				$customer_index[$order->customer_id] = $customer_details;
			}
		}
		
		$data['orders'] = $orders;
		$data['payment_details_index'] = $payment_details_index;
		$data['shipping_index'] = $shipping_index;
		$data['orders_num'] = $order_nums;		
		$data['customer_index'] = $customer_index;
		
		$this->load->view('header', $data);
		$this->load->view('orders_today_view', $data);
		$this->load->view('footer', $data);
	}
	
	function month() {
		
		$data = initiate_page();
		
		$data['page_name']  = 'orders';
		$data['page_title'] = 'All orders';

		$data['sidebar_element']    = 'side-orders';
		$data['sidebar_subelement'] = 'side-orders-view';
		
		$data['seo_title'] = 'Orders';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
        
        $this->load->helper('valid_date_helper');
        $this->load->model('model_payments');
        $this->load->model('model_customers');
        
        $month = $this->input->post('month', true);
		$year  = date('Y', time());
		
		if ( ! $month) {
			$month              = date('m', time());
			$data['month_name'] = date('F', time());
		} else {
			if (!in_array($month, array(
				'01',
				'02',
				'03',
				'04',
				'05',
				'06',
				'07',
				'08',
				'09',
				'10',
				'11',
				'12'
			))):
				$this->session->set_flashdata('error', 'Invalid Month');
				redirect('orders/month', 'refresh');
			endif;
			$data['month_name'] = date('F', strtotime($month - date('m', time()) . ' month'));
		}
        
		
		$orders = array();
		$check = $this->orders->get_month($month, $year);
		
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$data['orders'] = $orders;
		
		$payment_details_index = array();
		$alterations_index = array();
		$shipping_index = array();
		$order_nums = array();
		$customer_index = array();
		
		foreach($orders as $order) {
			
			$payment_details = '';
			$payment_type = 'COD';
			
			if($order->payment_mode != 'cod') {
				$check = $this->model_payments->get($order->payment_id);
				if($check->num_rows() > 0) {
					$payment_details = $check->row();
					$payment_type = 'EBS';
					if($payment_details->paypal_payer_id != NULL) {
						$payment_type = 'PayPal';
					}
				}
			}
			
			$payment_details_index[$order->id] = $payment_type;
			
			if( ! isset($order_nums[$order->order_status])) {
				$order_nums[$order->order_status] = 0;
			}
			$order_nums[$order->order_status] += 1;
			
			$shipping_index[$order->id] = 'domestic';
			if($order->ship_to_country_id != 99) {
				$shipping_index[$order->id] = 'foreign';
			}
			
			if( ! isset($customer_index[$order->customer_id])) {
				$customer_details = array();
				$check = $this->model_customers->get($order->customer_id);
				if($check->num_rows() > 0) {
					$customer_details = $check->row();
				}
				$customer_index[$order->customer_id] = $customer_details;
			}
		}
		
		$data['orders'] = $orders;
		$data['payment_details_index'] = $payment_details_index;
		$data['shipping_index'] = $shipping_index;
		$data['orders_num'] = $order_nums;		
		$data['customer_index'] = $customer_index;
		
		$this->load->view('header', $data);
		$this->load->view('orders_month_view', $data);
		$this->load->view('footer', $data);
	}
	
	
	function from_to() {
		
		$data = initiate_page();
		
		$data['page_name']  = 'orders';
		$data['page_title'] = 'All orders';

		$data['sidebar_element']    = 'side-orders';
		$data['sidebar_subelement'] = 'side-orders-view';
		
		$data['seo_title'] = 'Orders';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
        
        $this->load->helper('valid_date_helper');
        $this->load->model('model_payments');
        $this->load->model('model_customers');
		
		
		$from = $this->input->post('from', true);
		$to   = $this->input->post('to', true);
		
		if (!$from || !$to) {
			$from                 = date('Y-m-d', strtotime('-30 days'));
			$to                   = date('Y-m-d', time());
			$data['from_to_name'] = 'Orders in the Last 30 Days';
		} else {
			if (!(checkdate(date('m', strtotime($from)), date('d', strtotime($from)), date('Y', strtotime($from))) && checkdate(date('m', strtotime($to)), date('d', strtotime($to)), date('Y', strtotime($to))))):
				$this->session->set_flashdata('error', 'Invalid Dates');
				redirect('orders/from_to', 'refresh');
			endif;
			$data['from_to_name'] = 'Orders between ' . date('F d, Y', strtotime($from)) . ' and ' . date('F d, Y', strtotime($to));
		}
		
		$from = date('Y-m-d', strtotime($from));
		$to   = date('Y-m-d', strtotime($to));
		
		
		$orders = array();
		$check = $this->orders->get_from_to($from, $to);
		
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$data['orders'] = $orders;
		
		$payment_details_index = array();
		$alterations_index = array();
		$shipping_index = array();
		$order_nums = array();
		$customer_index = array();
		
		$total_shipping = 0;
		
		foreach($orders as $order) {
			
			$payment_details = '';
			$payment_type = 'COD';
			
			if($order->payment_mode != 'cod') {
				$check = $this->model_payments->get($order->payment_id);
				if($check->num_rows() > 0) {
					$payment_details = $check->row();
					$payment_type = 'EBS';
					if($payment_details->paypal_payer_id != NULL) {
						$payment_type = 'PayPal';
					}
				}
			}
			
			if(in_array($order->order_status, array('dispatched', 'delivered'))) {
				if($order->currency == 'inr') {
					$total_shipping += $order->shipping_cost;
				} else {
					$total_shipping += ($order->shipping_cost * 65);
				}
			}
			
			$payment_details_index[$order->id] = $payment_type;
			
			if( ! isset($order_nums[$order->order_status])) {
				$order_nums[$order->order_status] = 0;
			}
			$order_nums[$order->order_status] += 1;
			
			$shipping_index[$order->id] = 'domestic';
			if($order->ship_to_country_id != 99) {
				$shipping_index[$order->id] = 'foreign';
			}
			
			if( ! isset($customer_index[$order->customer_id])) {
				$customer_details = array();
				$check = $this->model_customers->get($order->customer_id);
				if($check->num_rows() > 0) {
					$customer_details = $check->row();
				}
				$customer_index[$order->customer_id] = $customer_details;
			}
		}
		
		$data['total_shipping'] = $total_shipping;
		$data['orders'] = $orders;
		$data['payment_details_index'] = $payment_details_index;
		$data['shipping_index'] = $shipping_index;
		$data['orders_num'] = $order_nums;		
		$data['customer_index'] = $customer_index;
		
		$this->load->view('header', $data);
		$this->load->view('orders_fromto_view', $data);
		$this->load->view('footer', $data);
	}
	
	function print_today() {
		
		$data = initiate_page();
		
		$data['page_name']  = 'orders';
		$data['page_title'] = 'All orders';

		$data['sidebar_element']    = 'side-orders';
		$data['sidebar_subelement'] = 'side-orders-view';
		
		$data['seo_title'] = 'Orders';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
        
        $this->load->helper('valid_date_helper');
        $this->load->model('model_payments');
        $this->load->model('model_customers');
        $this->load->model('model_order_items');
        $this->load->model('model_skus');
        $this->load->model('model_products');
        $this->load->model('model_order_customizations');
        $this->load->model('model_order_coupons');
		
		$orders = array();		
		$check = $this->orders->get_placed();
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$data['orders'] = $orders;
		
		$order_items_index = array();
		
		$product_details_index = array();
		$sku_details_index = array();
		
		$alterations_index = array();
		$customizations_index = array();
		$coupons_index = array();
		
		$payment_details_index = array();
		$shipping_index = array();
		$order_nums = array();
		$customer_index = array();
		
		foreach($orders as $order) {
			
			$order_items = array();
			$check = $this->model_order_items->get_where('order_id', $order->id);
			if($check->num_rows() > 0) {
				$order_items = $check->result();
			}
			
			$order_items_index[$order->id] = $order_items;
			
			foreach($order_items as $item) {
				$sku_details = array();
				$product_details = array();
				
				$check = $this->model_skus->get($item->sku_id);
				if($check->num_rows() > 0) {
					$sku_details = $check->row();
					$sku_details_index[$sku_details->id] = $sku_details;
				}
				
				$check = $this->model_products->get($item->product_id);
				if($check->num_rows() > 0) {
					$product_details = $check->row();
					$product_details_index[$product_details->id] = $product_details;
				}
				
				if($item->alterations != '') {
					$alterations_index[$item->id] = $item->alterations;
				}
				
				$check = $this->model_order_customizations->get_where('order_item_id', $item->id);
				if($check->num_rows() > 0) {
					$customizations_index[$item->id] = $check->row();
				}
			}
						
			$payment_details = NULL;
			$check = $this->model_payments->get($order->payment_id);
			if($check->num_rows() > 0) {
				$payment_details = $check->row();
			}
			$payment_details_index[$order->id] = $payment_details;
			
			if( ! isset($customer_index[$order->customer_id])) {
				$customer_details = array();
				$check = $this->model_customers->get($order->customer_id);
				if($check->num_rows() > 0) {
					$customer_details = $check->row();
				}
				$customer_index[$order->customer_id] = $customer_details;
			}
			
			$order_coupons = array();
			$check = $this->model_order_coupons->get_where('order_id', $order->id);
			if($check->num_rows() > 0) {
				$coupons_index[$order->id] = $check->row();
			}
		}
		
		$data['orders'] = $orders;
		$data['order_items_index'] = $order_items_index;
		$data['product_details_index'] = $product_details_index;
		$data['sku_details_index'] = $sku_details_index;
		
		$data['alterations_index'] = $alterations_index;
		$data['customizations_index'] = $customizations_index;
		$data['coupons_index'] = $coupons_index;
		
		$data['payment_details_index'] = $payment_details_index;
		$data['shipping_index'] = $shipping_index;
		$data['order_nums'] = $order_nums;
		$data['customer_index'] = $customer_index;
        
        $this->load->view('todays_orders_view', $data);
        
	}
	
	function order_info($id) {
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name']  = 'orders';
			$data['page_title'] = 'All orders';
			
			$data['sidebar_element']    = 'side-orders';
			$data['sidebar_subelement'] = 'side-orders-view';
			
			$this->load->model('mdl_products');
			$this->load->model('mdl_skus');
			$this->load->model('mdl_order_items');
			$this->load->model('mdl_order_customizations');
			$this->load->model('mdl_customers');
			$this->load->model('mdl_product_images');
			
			$order_details = $this->mdl_orders->get_where($id);
			if ($order_details->num_rows() == 0) {
				redirect('404', 'refresh');
			} else {
				$order_details = $order_details->row();
			}
			$data['order_details'] = $order_details;
			
			$payment_details = $this->db->get_where('payments', array(
				'id' => $order_details->payment_id
			));
			//print_r($payment_details->row());
			if ($payment_details->num_rows() > 0) {
				$data['payment_details'] = $payment_details->row();
			} else {
				$data['payment_details'] = array();
			}
			
			$order_items = $this->mdl_order_items->get_where_custom('order_id', $id);
			if ($order_items->num_rows() == 0) {
				log_message('error', "orders.php | order_info() | Order Items Not found for Order ID:{$order_details->id}");
				$order_items = array();
				//redirect('404', 'refresh');
			} else {
				$order_items = $order_items->result();
			}
			$data['order_items'] = $order_items;
			
			$check_order_coupons = $this->db->get_where('order_coupons', array(
				'order_id' => $order_details->id
			));
			$order_coupon        = array();
			if ($check_order_coupons->num_rows() > 0) {
				$order_coupon = $check_order_coupons->row();
			}
			
			$data['order_coupon'] = $order_coupon;
			
			$customizations_list = array();
			foreach ($order_items as $order_item) {
				
				$sku_details                = $this->mdl_skus->get_where($order_item->sku_id)->row();
				$skus_list[$order_item->id] = $sku_details;
				
				$product_details                = $this->mdl_products->get_where($sku_details->product_id)->row();
				$products_list[$order_item->id] = $product_details;
				
				if ($order_item->custom):
					$customization_details                = $this->mdl_order_customizations->get_where_custom('order_item_id', $order_item->id);
					$customizations_list[$order_item->id] = $customization_details->row();
				endif;
				
			}
			$data['skus_list']           = $skus_list;
			$data['customizations_list'] = $customizations_list;
			$data['products_list']       = $products_list;
			
			
			$customer_details = $this->mdl_customers->get_where($order_details->customer_id);
			if ($customer_details->num_rows() > 0) {
				$customer_details = $customer_details->row();
			} else {
				//redirect('404', 'refresh');
			}
			$data['customer_details'] = $customer_details;
			
			$data['page_title'] = 'Order ' . $order_details->id;
			
			$this->load->view('header', $data);
			$this->load->view('order_info_view', $data);
			$this->load->view('footer', $data);
		} else {
			redirect('login', 'refresh');
		}
	}
	
	function print_invoice($id) {
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name']  = 'orders';
			$data['page_title'] = 'All orders';
			
			$data['sidebar_element']    = 'side-orders';
			$data['sidebar_subelement'] = 'side-orders-view';
			
			$this->load->model('mdl_products');
			$this->load->model('mdl_skus');
			$this->load->model('mdl_order_items');
			$this->load->model('mdl_order_customizations');
			$this->load->model('mdl_customers');
			$this->load->model('mdl_product_images');
			
			$order_details = $this->mdl_orders->get_where($id);
			if ($order_details->num_rows() == 0) {
				redirect('404', 'refresh');
			} else {
				$order_details = $order_details->row();
			}
			$data['order_details'] = $order_details;
			
			$check_order_coupons = $this->db->get_where('order_coupons', array(
				'order_id' => $order_details->id
			));
			$order_coupon        = array();
			if ($check_order_coupons->num_rows() > 0) {
				$order_coupon = $check_order_coupons->row();
			}
			
			$data['order_coupon'] = $order_coupon;
			
			$order_items = $this->mdl_order_items->get_where_custom('order_id', $id);
			if ($order_items->num_rows() == 0) {
				redirect('404', 'refresh');
			} else {
				$order_items = $order_items->result();
			}
			$data['order_items'] = $order_items;
			
			$customizations_list = array();
			foreach ($order_items as $order_item) {
				$sku_details                = $this->mdl_skus->get_where($order_item->sku_id)->row();
				$skus_list[$order_item->id] = $sku_details;
				
				$product_details                = $this->mdl_products->get_where($sku_details->product_id)->row();
				$products_list[$order_item->id] = $product_details;
				
				if ($order_item->custom):
					$customization_details                = $this->mdl_order_customizations->get_where_custom('order_item_id', $order_item->id);
					$customizations_list[$order_item->id] = $customization_details->row();
				endif;
				
			}
			$data['skus_list']           = $skus_list;
			$data['customizations_list'] = $customizations_list;
			$data['products_list']       = $products_list;
			
			$this->load->model('model_payments');
			
			$payment_details = array();
			$check = $this->model_payments->get($order_details->payment_id);
			if($check->num_rows() > 0) {
				$payment_details = $check->row();
			}
			$data['payment_details'] = $payment_details;
			
			$customer_details = $this->mdl_customers->get_where($order_details->customer_id);
			if ($customer_details->num_rows() > 0) {
				$customer_details = $customer_details->row();
			} else {
				//redirect('404', 'refresh');
			}
			$data['customer_details'] = $customer_details;
			
			$data['page_title'] = 'Order ' . $order_details->id;
			
			//$this->load->view('header', $data);
			$this->load->view('invoice_view', $data);
			$this->load->view('footer', $data);
		} else {
			redirect('login', 'refresh');
		}
	}
	
	function edit($id) {
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name'] = 'products';
			
			$data['sidebar_element']    = 'side-products';
			$data['sidebar_subelement'] = 'side-products-view';
			
			$this->load->model('mdl_categories');
			$this->load->model('mdl_product_images');
			
			$product_details = $this->mdl_order_items->get_where($id);
			if ($product_details->num_rows() == 0) {
				redirect('404', 'refresh');
			} else {
				$product_details = $product_details->row();
			}
			$data['product_details'] = $product_details;
			
			$parent_category_details = $this->mdl_categories->get_where($product_details->cat_id);
			if ($parent_category_details->num_rows() == 0) {
				redirect('404', 'refresh');
			} else {
				$parent_category_details = $parent_category_details->row();
			}
			$data['parent_category_details'] = $parent_category_details;
			
			
			$categories_list         = $this->mdl_categories->get('id')->result();
			$data['categories_list'] = $categories_list;
			
			$product_images         = $this->mdl_product_images->get_product_images($product_details->id);
			$data['product_images'] = $product_images;
			
			$data['tinyMC'] = TRUE;
			
			$data['page_title'] = 'Edit ' . $product_details->name;
			
			$this->load->view('header', $data);
			$this->load->view('product_edit', $data);
			$this->load->view('footer', $data);
		} else {
			redirect('login', 'refresh');
		}
	}
	
	function add() {
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name']  = 'products';
			$data['page_title'] = 'Add New Product';
			
			$data['sidebar_element']    = 'side-products';
			$data['sidebar_subelement'] = 'side-add-product';
			
			$this->load->model('mdl_categories');
			
			$categories_list         = $this->mdl_categories->get('id')->result();
			$data['categories_list'] = $categories_list;
			
			
			//$data['tinyMC'] = FALSE;
			
			$this->load->view('header', $data);
			$this->load->view('product_add', $data);
			$this->load->view('footer', $data);
		} else {
			redirect('login', 'refresh');
		}
	}
	
	function add_child($id) {
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name']  = 'products';
			$data['page_title'] = 'Add New Product';
			
			$data['sidebar_element']    = 'side-products';
			$data['sidebar_subelement'] = 'side-add-product';
			
			$this->load->model('mdl_categories');
			
			$parent_category = $this->mdl_categories->get_where($id);
			if ($parent_category->num_rows() != 1) {
				rediredct('404', 'refresh');
			} else {
				$parent_category = $parent_category->row();
			}
			$data['parent_category'] = $parent_category;
			
			$categories_list         = $this->mdl_categories->get_where_custom('parent_id', $parent_category->id)->result();
			$data['categories_list'] = $categories_list;
			
			
			$data['page_title'] = 'Add Product Under ' . $parent_category->name;
			$this->load->view('header', $data);
			$this->load->view('product_add_child', $data);
			$this->load->view('footer', $data);
		} else {
			redirect('login', 'refresh');
		}
	}
	
	function delete($id) {
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name']  = 'products';
			$data['page_title'] = 'Add New Product';
			
			$data['sidebar_element']    = 'side-products';
			$data['sidebar_subelement'] = 'side-add-product';
			
			$this->load->model('mdl_categories');
			$this->load->model('mdl_product_images');
			
			$product = $this->mdl_order_items->get_where($id);
			
			if ($product->num_rows() != 1) {
				redirect('404', 'refresh');
			} else {
				$product = $product->row();
			}
			
			$product->code = implode('_', explode(' ', $product->code));
			
			//delete this Product's Images from storage and DB first
			$product_images = $this->mdl_product_images->get_where_custom('product_id', $product->id);
			
			foreach ($product_images->result() as $image) {
				unlink('../assets/uploads/' . $image->url);
				$this->mdl_product_images->_delete($image->id);
			}
			
			if (file_exists('../assets/uploads/' . $product->code . '_front.jpg')):
				unlink('../assets/uploads/' . $product->code . '_front.jpg');
			endif;
			if (file_exists('../assets/uploads/' . $product->code . '_back.jpg')):
				unlink('../assets/uploads/' . $product->code . '_back.jpg');
			endif;
			if (file_exists('../assets/uploads/' . $product->code . '_left.jpg')):
				unlink('../assets/uploads/' . $product->code . '_left.jpg');
			endif;
			if (file_exists('../assets/uploads/' . $product->code . '_right.jpg')):
				unlink('../assets/uploads/' . $product->code . '_right.jpg');
			endif;
			if (file_exists('../assets/uploads/' . $product->code . '_closeup.jpg')):
				unlink('../assets/uploads/' . $product->code . '_closeup.jpg');
			endif;
			
			//delete all SKUs listed under this product
			$this->load->model('mdl_skus');
			$skus = $this->mdl_skus->get_where_custom('product_id', $product->id);
			foreach ($skus->result() as $sku) {
				$this->mdl_skus->_delete($sku->id);
			}
			
			// finally delete the product
			$this->mdl_order_items->_delete($product->id);
			
			redirect('products');
		} else {
			redirect('login', 'refresh');
		}
	}
	
	function save($id = FALSE) //
		{
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name']  = 'products';
			$data['page_title'] = 'All Products';
			
			$data['sidebar_element']    = 'side-products';
			$data['sidebar_subelement'] = 'side-products-view';
			
			$productName = $this->input->post('productName');
			if (!$productName):
				redirect('products');
			endif;
			$productCode     = $this->input->post('productCode', true);
			$productSlug     = $this->input->post('productSlug', true);
			$productCategory = $this->input->post('productCategory', true);
			$productPrice    = $this->input->post('productPrice', true);
			$productColor    = $this->input->post('productColor', TRUE);
			$productDesc     = $this->input->post('productDesc', true);
			$productPosScore = (int) $this->input->post('productPosScore', true);
			
			if (is_int($productPosScore) && ($productPosScore >= 0) && ($productPosScore <= 1000)) {
				if ($id) {
					$data = array(
						'name' => $productName,
						'code' => $productCode,
						'slug' => $productSlug,
						'cat_id' => $productCategory,
						'price' => $productPrice,
						'color' => $productColor,
						'desc' => $productDesc,
						'position_score' => $productPosScore
					);
					
					$this->db->where('id !=', $id);
					$slug_exists = $this->mdl_order_items->get_where_custom('slug', $productSlug);
					
					if ($slug_exists->num_rows() > 0) {
						echo "Slug already exists. <a href='{$this->config->base_url() }products/edit/{$id}'>Enter a unique slug.</a>";
					} else {
						$this->mdl_order_items->_update($id, $data);
						$data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
						redirect("products/edit/{$id}");
					}
					
				} else {
					$data        = array(
						'name' => $productName,
						'code' => $productCode,
						'slug' => $productSlug,
						'cat_id' => $productCategory,
						'price' => $productPrice,
						'color' => $productColor,
						'desc' => $productDesc,
						'position_score' => $productPosScore
					);
					$slug_exists = $this->mdl_order_items->get_where_custom('slug', $productSlug);
					if ($slug_exists->num_rows() > 0) {
						echo "Slug already exists. <a href='{$this->config->base_url() }products/add'>Enter a unique slug.</a>";
					} else {
						$this->mdl_order_items->_insert($data);
						$id              = mysql_insert_id();
						$data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
						redirect("products/edit/{$id}");
					}
				}
			} else {
				echo "Invalid Input. Please <a href='{$this->config->base_url() }products/edit/{$id}'>try again.</a>";
			}
		} else {
			redirect('login', 'refresh');
		}
	}
	
	function status_update($id) {
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name']  = 'orders';
			$data['page_title'] = 'Update Orders';
			
			$data['sidebar_element']    = 'side-orders';
			$data['sidebar_subelement'] = 'side-orders-view';
			
			$order_check = $this->mdl_orders->get_where($id);
			if ($order_check->num_rows() != 1) {
				redirect('404', 'refresh');
			} else {
				$order_details = $order_check->row();
			}
			
			$orderStatus = $this->input->post('orderStatus', true);
			if (!$orderStatus):
				redirect("orders/order_info/{$id}");
			endif;
			
			$order_status_possibilities = array(
				'placed',
				'processing',
				'dispatched',
				'on-hold',
				'cancelled',
				'cancelled-refund-pending',
				'cancelled-refunded',
				'delivered'
			);
			
			if (!in_array(strtolower($orderStatus), $order_status_possibilities)):
				redirect('404', 'refresh');
			endif;
			
			if ($orderStatus == 'delivered') {
				$new_data = array(
					'order_status' => $orderStatus,
					'delivered_on' => date('Y-m-d H:i:s', time())
				);
				
				$this->load->helper('feedback_mail_helper');
				send_feedback_mail($order_details);
				
			} else if ($orderStatus == 'cancelled') {
				
				$new_data = array(
					'order_status' => $orderStatus,
					'cancelled_on' => date('Y-m-d H:i:s', time())
				);
				
				//adding back the cancelled stock to each sku 
				$check = $this->db->get_where('order_items', array(
					'order_id' => $order_details->id
				));
				if ($check->num_rows() > 0) {
					$order_items = $check->result();
					foreach ($order_items as $order_item) {
						$sku_id    = $order_item->sku_id;
						$order_qty = (int) $order_item->qty;
						$check     = $this->db->get_where('skus', array(
							'id' => $sku_id
						));
						if ($check->num_rows() > 0) {
							$sku_details       = $check->row();
							$current_stock     = (int) $sku_details->stock;
							$updated_stock     = $current_stock + $order_qty;
							$update_stock_data = array(
								'stock' => $updated_stock
							);
							$this->db->where('id', $sku_details->id);
							$this->db->update('skus', $update_stock_data);
						}
					}
				}
				
			} else {
				$new_data = array(
					'order_status' => $orderStatus
				);
				
				if($orderStatus == 'dispatched') {
					$this->send_dispatch_email($order_details);
				}
			}
			
			$this->mdl_orders->_update($order_details->id, $new_data);
			redirect("orders/order_info/{$order_details->id}", 'refresh');
			
		} else {
			redirect('login', 'refresh');
		}
	}
	
	function send_dispatch_email($order_details) {
		
		$this->load->helper('email_new_helper');
		$this->load->helper('email_api_helper');
		
		$customer_details = array();
		$check = $this->db->get_where('customers', array('id' => $order_details->customer_id));
		if($check->num_rows() > 0) {
			$customer_details = $check->row();
		}
		
		if(count($customer_details) == 0) {
			return;
		}
		
		$email = $customer_details->email;
		if($customer_details->is_guest == 1) {
			$email = $customer_details->guest_email;
		}
		
		$from = "eshop@taruni.in";
		$from_name = "Taruni";
		$to = $email;
		$to_name = ucwords($customer_details->name);
		$subject = "Your Order has been dispatched";
		
		ob_start();
?>
<!DOCTYPE html>
<html>

<head>
	<title>Taruni | Order Dispatched</title>
</head>

<body style="background: #efefef;padding: 30px;">
	<table width="550" style="width:550px;margin: 30px auto;background: #fff;font-family:Arial, Helvetica, sans-serif;text-align: center;margin: 0 auto;padding:0;border-collapse: collapse;">
		<tr width="550" style="width:550px;background: #fff; color: #fff;font-family: Arial, Helvetica, sans-serif;text-align: center;border-collapse: collapse;">
			<td colspan="3" width="550" style="padding:0;width:550px;background: #fff; color: #fff;font-family: Arial, Helvetica, sans-serif; text-align: center;">
				<a href="http://taruni.in/" target="_blank" style="display: inline-block;line-height:0;"><img src="http://taruni.in/assets/mailer/after-dispatch/banner.jpg" width="550" style="550px; margin: 0; display:inline-block;text-align:center;" alt="Order Dispatched" title="Order Dispatched"></a>
			</td>
		</tr>
		<tr width="550" style="width:550px;background: #fff; color: #fff;font-family: Arial, Helvetica, sans-serif;text-align: center;">
			<td width="30" style="width:30px;background: #fff; color: #fff;font-family: Arial, Helvetica, sans-serif; text-align: center;"></td>
			<td width="490" style="width:490px;background: #fff; color: #333;font-family: Arial, Helvetica, sans-serif; text-align: left;padding-top: 30px;padding-bottom:21px;">
				<p style="color: #333;font-size: 14px; line-height: 160%;margin: 0 0 12px;">
					<strong>Dear <?php echo ucwords($to_name); ?></strong>,
				</p>
				<p style="color: #333;font-size: 14px; line-height: 160%;margin: 0 0 12px;">
					A hello from Taruni!
				</p>
				<p style="color: #333;font-size: 14px; line-height: 160%;margin: 0 0 12px;">
					Here's the happy news: <strong>your order has been successfully dispatched.</strong>
				</p>
				<p style="color: #333;font-size: 14px; line-height: 160%;margin: 0 0 12px;">
					Our courier partner Fedex, will soon update you about the tracking number with an e-mail.
				</p>
				<p style="color: #333;font-size: 14px; line-height: 160%;margin: 0 0 12px;">
					It may take 24-48 hours for the live tracking to reflect on the website. So, please do be patient!
				</p>
				<p style="color: #333;font-size: 14px; line-height: 160%;margin: 0 0 12px;">
					In case there are any issues in tracking your order, do <a href="http://taruni.in/contact">write back</a> to us.
				</p>

<?php
if(trim(strtolower($order_details->ship_to_country)) != 'india') { ?>				
				<p style="color: #333;font-size: 14px; line-height: 160%;margin: 0 0 12px;">
					<strong>Please note:</strong> All orders are subject to Custom duty and customers may/may not be charged by the government/department of customs of the respective country to which parcel is being delivered. these duties do not come under the jurisdiction of Taruni.in and will be borne/paid by the customer.
				</p>
<?php
} ?>
				<p style="color: #333;font-size: 14px; line-height: 160%;margin: 0 0 12px;">
					Regards,<br>
					<strong>Team Taruni</strong><br>
				</p>
				<hr style="margin: 15px 0;">
				<a href="https://www.facebook.com/taruni.in" target="_blank" style="display: inline-block;"><img src="http://taruni.in/assets/mailer/fb-link-mailer.png" style="display: inline-block;width: 32px;" alt="Taruni Facebook" title="Taruni Facebook"></a>
				<a href="https://www.instagram.com/taruni.in/" target="_blank" style="display: inline-block;"><img src="http://taruni.in/assets/mailer/instagram-link-mailer.png" style="display: inline-block;width: 32px;" alt="Taruni Instagram" title="Taruni Instagram"></a>
				<a href="http://taruni.in/contact" target="_blank" style="display: inline-block; float: right;"><img src="http://taruni.in/assets/mailer/after-dispatch/button.png" style="display: inline-block;width: 100px;" alt="Taruni Contact" title="Taruni Contact"></a>
			</td>
			<td width="30" style="width:30px;background: #fff; color: #fff;font-family: Arial, Helvetica, sans-serif; text-align: center;"></td>
		</tr>
		<tr width="550" style="width:550px;background: #fff; color: #fff;font-family: Arial, Helvetica, sans-serif;text-align: center;border-collapse: collapse;">
			<td colspan="3" width="550" style="padding:0;width:550px;background: #fff; color: #fff;font-family: Arial, Helvetica, sans-serif; text-align: center;line-height:0;">
				<img src="http://taruni.in/assets/mailer/after-dispatch/footer.jpg" width="550" style="550px; margin: 0; display:inline-block;text-align:center;" alt="Taruni">
			</td>
		</tr>
	</table>
</body>
</html>

<?php
		$message = ob_get_clean();
		$plain_text_message = "";
		
		send_api_email($from, $from_name, $to, $to_name, $subject, $message, $plain_text_message);
		return;
		
	}
	
	function payment_status_update($id) {
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name']  = 'orders';
			$data['page_title'] = 'Update Orders';
			
			$data['sidebar_element']    = 'side-orders';
			$data['sidebar_subelement'] = 'side-orders-view';
			
			$order_check = $this->mdl_orders->get_where($id);
			if ($order_check->num_rows() != 1) {
				redirect('404', 'refresh');
			} else {
				$order_details = $order_check->row();
			}
			
			$paymentStatus = $this->input->post('paymentStatus', true);
			if (!$paymentStatus):
				redirect("orders/order_info/{$id}");
			endif;
			
			$new_data = array(
				'payment_status' => $paymentStatus
			);
			
			$this->mdl_orders->_update($order_details->id, $new_data);
			redirect("orders/order_info/{$order_details->id}", 'refresh');
			
		} else {
			redirect('login', 'refresh');
		}
	}
	
	function seosave($id) {
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name']  = 'products';
			$data['page_title'] = 'All Products';
			
			$data['sidebar_element']    = 'side-products';
			$data['sidebar_subelement'] = 'side-products-view';
			
			$this->load->model('mdl_categories');
			$this->load->model('mdl_product_images');
			
			$seoTitle = $this->input->post('productSeoTitle');
			$seoDesc  = $this->input->post('productSeoDesc');
			$seoKeys  = $this->input->post('productSeoKeys');
			$data     = array(
				'seo_title' => $seoTitle,
				'seo_desc' => $seoDesc,
				'seo_keywords' => $seoKeys
			);
			$this->mdl_order_items->_update($id, $data);
			$data['success'] = "<div class='alert alert-success'>Record Updated Successfully!</div>";
			redirect("products/edit/{$id}?tab=seotags");
			
		} else {
			redirect('login', 'refresh');
		}
	}
	
	function DPimageSave($id) {
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name']  = 'products';
			$data['page_title'] = 'All Products';
			
			$data['sidebar_element']    = 'side-products';
			$data['sidebar_subelement'] = 'side-products-view';
			
			$this->load->model('mdl_categories');
			$this->load->model('mdl_product_images');
			
			$check = $this->mdl_order_items->get_where($id);
			if ($check->num_rows() == 0) {
				redirect('404', 'refresh');
			} else {
				$product_details = $check->row();
			}
			
			$view = $this->input->post('view', true);
			if (!(in_array(strtolower($view), array(
				'front',
				'back',
				'left',
				'right',
				'closeup'
			)))):
				redirect('404', 'refresh');
			endif;
			
			
			$config['upload_path']   = '../assets/uploads/';
			$config['allowed_types'] = 'jpg|jpeg';
			$config['file_name']     = implode('_', explode(' ', $product_details->code)) . '_' . $view . '.jpg';
			$config['overwrite']     = TRUE;
			
			$this->load->library('upload', $config);
			if ($_FILES['productDPChange']['size'] == 0):
				redirect('404', 'refresh');
			endif;
			
			if (!$this->upload->do_upload('productDPChange')) {
				$data['uploadErrors'] = $this->upload->display_errors();
				echo $data['uploadErrors'] . '<br />';
				echo "<a href='{$this->config->base_url() }products/edit/{$id}?tab=productpics'>Please try again</a>";
			} else {
				$res    = $this->upload->data();
				$DPname = implode('_', explode(' ', $product_details->code)) . '_' . $view . '.jpg';
				$data   = array(
					'url' => $DPname,
					'product_id' => $product_details->id,
					'view' => $view,
					'alt' => ucfirst($product_details->name) . ' ' . $view . ' view',
					'title' => ucfirst($product_details->name) . ' ' . $view . ' view'
				);
				
				$current_image = $this->db->get_where('product_images', array(
					'product_id' => $product_details->id,
					'view' => $view
				));
				if ($current_image->num_rows() > 0) {
					$this->mdl_product_images->_update($current_image->row()->id, $data);
					redirect("products/edit/{$product_details->id}?tab=productspics");
				} else {
					$this->mdl_product_images->_insert($data);
					redirect("products/edit/{$product_details->id}?tab=productspics");
				}
			}
		} else {
			redirect('login', 'refresh');
		}
	}
	
	function tracking_num_update($order_id) {
		if ($this->session->userdata('logged_in')) {
			$session_data       = $this->session->userdata('logged_in');
			$data['username']   = $session_data['username'];
			$data['user_type']  = $session_data['type'];
			$data['user_email'] = $session_data['email'];
			
			$data['page_name']  = 'orders';
			$data['page_title'] = 'All orders';
			
			$data['sidebar_element']    = 'side-orders';
			$data['sidebar_subelement'] = 'side-orders-view';
			
			$check = $this->mdl_orders->get_where($order_id);
			if ($check->num_rows() == 0) {
				redirect('404', 'refresh');
			}
			
			$order_details = $check->row();
			
			$tracking_num = $this->input->post('tracking_number', true);
			
			$new_data = array(
				'tracking_number' => $tracking_num
			);
			
			$this->mdl_orders->_update($order_details->id, $new_data);
			$this->session->set_flashdata('tracking_num_success', 'Tracking Number added successfully.');
			redirect("orders/order_info/{$order_details->id}", 'refresh');
			
		} else {
			redirect('login', 'refresh');
		}
	}
	
}
