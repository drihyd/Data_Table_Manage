<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Region_report extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'email_helper',
            'page_initiater_helper',
        );
        $models = array(
            'model_carts' => 'carts',
            'model_categories' => 'categories',
            'model_customers' => 'customers',
            'model_orders' => 'orders',
            'model_order_items' => 'order_items',
            'model_products' => 'products',
            'model_skus' => 'skus',
            'model_users' => 'users',
            'model_reorder_thresholds' => 'reorder_thresholds',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function index($justsee=TRUE) {
		$data['justsee'] = $justsee;
		
		if( ! $this->input->get('month', TRUE)) {
			$month = date('M', time());
			$year = date('Y', time());
		} else {
			$monthYear = strtolower(trim($this->input->get('monthYear', TRUE)));
			$monthYear = explode('-', $monthYear);
			$month = (int) $this->input->get('month', TRUE);
			$year = (int) $this->input->get('year', TRUE);
			
			if( ($month > 12) OR ($month < 1)) {
				$month = date('M', time());
			}
			
			$phrase = "01-" . $month . "-" . $year;
			$month = date('M', strtotime($phrase));			
		}
		$from_phrase = "first day of " . $month . " " . $year;
		$to_phrase   = "last day of " . $month . " " . $year;
		
		$from_date = date('Y-m-d', strtotime($from_phrase));
		$to_date = date('Y-m-d', strtotime($to_phrase));
		
		//$from_date = date('Y-m-d', strtotime('2016-01-01'));
		//$to_date = date('Y-m-d', strtotime('2016-01-07'));
		
		$data['from_date'] = $from_date;
		$data['to_date'] = $to_date;
		
		#---------------------------------------------------------------
		# Get Month
		$current_month = date('m', strtotime($from_date));
		$current_year  = date('Y', strtotime($from_date));
		
		$orders_this_month = 0;
		$check = $this->orders->get_month($current_month, $current_year);
		if($check->num_rows() > 0) {
			$orders_this_month = $check->num_rows();
		}
		$data['orders_this_month'] = $orders_this_month;
		
		#---------------------------------------------------------------
		# Get all orders this week
		$all_orders = array();
		
		$this->db->where("DATE(ordered_on) >=", date('Y-m-d H:i:s', strtotime('1 January 2017')));
		$this->db->where("DATE(ordered_on) <=", date('Y-m-d H:i:s', time()));
		$this->db->where_not_in("order_status", array('cancelled', 'cancelled-refunded', 'cancelled-refund-pending'));
		$this->db->where("grand_total >", 0);
		$this->db->where("total_items >", 0);
		$this->db->where("ship_to_state", 'tamil nadu');
		
		$check = $this->db->get('orders');
		
		if($check->num_rows() > 0) {
			$all_orders = $check->result();
		}
		
		$total_orders = $check->num_rows();
		$order_ids = array();
		$total_order_value = 0;
		$total_domestic_orders = 0;
		$total_foreign_orders = 0;
		$order_country_index = array();
		$order_city_index = array();
		$customer_ids_who_ordered = array();
		$total_repeat_orders = 0;
		$total_first_time_orders = 0;
		
		foreach($all_orders as $order) {
			array_push($order_ids, $order->id);
			$total_order_value += $order->grand_total;
			$total_domestic_orders += 1; // add 1 by default. Reduce 1 if foregin check passes
			
			// foreign check
			$ship_country = trim(strtolower($order->ship_to_country));
			$ship_city = trim(strtolower($order->ship_to_city));
			$bill_country = trim(strtolower($order->bill_to_country));
			
			if( ($ship_country != 'india') OR ($bill_country != 'india') ) {
				$total_foreign_orders += 1;
				$total_domestic_orders -= 1; // reduce 1. It was increased by default before.
			}
			
			if( ! isset($order_country_index[$ship_country])) {
				$order_country_index[$ship_country] = array(
					'number' => 0,
					'value' => 0,
				);
			}
			$a = $order_country_index[$ship_country];
			$a['number'] += 1;
			$a['value'] += $order->grand_total;
			$order_country_index[$ship_country] = $a;
			
			# --
			
			if( ! isset($order_city_index[$ship_city])) {
				$order_city_index[$ship_city] = array(
					'value' => 0,
					'number' => 0,
					'country' => $ship_country,
				);
			}
			$a = $order_city_index[$ship_city];
			$a['number'] += 1;
			$a['value'] += $order->grand_total;
			$order_city_index[$ship_city] = $a;
			
			
			array_push($customer_ids_who_ordered, $order->customer_id);
			
			$total_first_time_orders += 1; // add 1 by default;
			$filters = array(
				'DATE(ordered_on) <' => $from_date,
				'customer_id' => $order->customer_id,
			);
			$check = $this->orders->get_where_array($filters);
			if($check->num_rows() > 0) {
				$total_repeat_orders += 1;
				$total_first_time_orders -= 1; // reduce 1. added 1 by default before.
			}
			
		}
		
		echo "total orders: " . $total_orders . '<br>';
		echo "total order value: " . $total_order_value . '<br>';
		echo "total domestic orders: " . $total_domestic_orders . '<br>';
		echo "total foreign orders: " . $total_foreign_orders . '<br>';
		
	}
	
	// get category size stock
	function get_category_size_stock($cat_id, $size) {
		$filters = array(
			'stock >' => 0,
			'size' => $size,
			'cat_id' => $cat_id,
		);
		$check = $this->skus->get_where_array($filters);
		$skus = array();
		$stock = 0;
		if($check->num_rows() > 0) {
			$skus = $check->result();
		}
		foreach($skus as $sku) {
			$stock += $sku->stock;
		}	
		return $stock;
	}
	
}
