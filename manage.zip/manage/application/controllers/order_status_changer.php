<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

date_default_timezone_set("Asia/Kolkata");
	
class Order_status_changer extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'page_initiater_helper',
		);
		$models  = array(
			'model_orders' 		=> 'orders',
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
	
	function index() {
		
		$orders = array();
		$check = $this->orders->get_where('order_status', 'dispatched');
		
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		$this->load->helper('feedback_mail_helper');
		
		foreach($orders as $order) {
			
			if(time() > strtotime($order->ordered_on . ' + 15 days')) {
				
				$new_data = array(
					'order_status' => 'delivered',
					'delivered_on' => date('Y-m-d H:i:s', time()),
				);
				
				$this->db->where('id', $order->id);
				$this->db->update('orders', $new_data);
				
				echo $order->id . '<br>';
				send_feedback_mail($order);
			}
		}
	}
	
}
