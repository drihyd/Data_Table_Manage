<?php

defined('BASEPATH') or exit('no direct script access allowed');

class Ganesh_discount_slasher extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$helpers = array(
			'form',
			'email_helper',
			'page_initiater_helper',
		);
		$models = array(
			// add models
		);
		foreach ($models as $file => $alias) {
			$this->load->model($file, $alias);
		}
		foreach ($helpers as $helper) {
			$this->load->helper($helper);
		}
	}
	
	function index() {
		
		$data = initiate_page();
		
		$ganesh_coupons = array();
		$check = $this->db->get('ganesh_game');
		foreach($check->result() as $game) {
			
			if($game->coupon_id != 0) {
				array_push($ganesh_coupons, $game->coupon_id);
			}
		}
		
		echo "<pre>";
		print_r($ganesh_coupons);
		echo "</pre>";
		
		$this->db->where_in('id', $ganesh_coupons);
		$this->db->set('min_order_value', 1000);
		$this->db->update('coupons');
		
		
	}
	
}
