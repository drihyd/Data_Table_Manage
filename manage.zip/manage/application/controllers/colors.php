<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Colors extends CI_Controller {
    
    function __construct() {
        parent::__construct();
    }
	
	function index() {
		
		echo "<hr>Products without colors<br>";
		
		$product_ids = array();
		$attribute_ids = $this->db->get_where('attribute_values', array('attr_id' => 2))->result();
		$ids_array = array();
		foreach($attribute_ids as $id) {
			array_push($ids_array, $id->id);
		}
		
		//print_r($ids_array);
		
		$this->db->where_in('attribute_id', $ids_array);
		$product_attributes = $this->db->get('product_attributes')->result();
		
		foreach($product_attributes as $attribute) {
			array_push($product_ids, $attribute->product_id);
		}
		
		//$this->db->where_in('product_id', $product_ids);
		//$ordered_products = $this->db-
		
		$top_colors = array();
		
		$order_products = array();
		
		$order_items = $this->db->get('order_items')->result();
		
		//foreach($order_items as $item) {
			//array_push($order_products, $item->product_id);
		//}
		
		//$order_products = array_unique($order_products);
		//echo "<br><br>";
		//print_r(count($order_products));
		//echo "<br><br>";
		
		foreach($order_items as $item) {
			$product_id = $item->product_id;
			
			$this->db->where_in('attribute_id', $ids_array);
			$this->db->where('product_id', $product_id);
			$product_color_id = $this->db->get(product_attributes);
			if($product_color_id->num_rows() > 0) {
				$attribute_id = $product_color_id->row()->attribute_id;
				$color = $this->db->get_where('attribute_values', array('id' => $attribute_id));
				if($color->num_rows() > 0) {
					$color = strtolower($color->row()->attr_value);
					
					if( ! isset($top_colors[$color])) {
						$top_colors[$color] = 0;
					}
					
					$top_colors[$color] += 1;
				}
			}
		}
		
		arsort($top_colors);
		print_r($top_colors);
		
		$i = 0;
		foreach($top_colors as $key => $value) {
			$i += $value;
		}
		
		echo "<br>".$i."<br>";	
		
		echo "<table>";
		
		
		foreach($top_colors as $key => $value) {
			echo "<tr><td>{$key}</td><td>{$value}</td></tr>";
		} 
		
		echo "</table>";
		//$this->db->where_not_in('id', $product_ids);
		//$products = $this->db->get('products');
		
		//print_r($products->num_rows());
		//echo "<br>";
		
		//print_r($products->result());
		
		
		echo "<hr><br>";
	}
	
}
