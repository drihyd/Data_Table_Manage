<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Ethnic_numbers extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'email_helper',
            'page_initiater_helper',
        );
    }
    
    function index($justsee=TRUE) {
		$dates = array();
		
		$cur_date = '2017-09-13';
		$today = date('Y-m-d', time());
		$i = 0;
		
		while($cur_date != $today) {
			$cur_date = date('Y-m-d', strtotime($cur_date . "+1 day"));
			
			$new_registrations = 0;
			$new_players = 0;
			$invites = 0;
			
			$dates[$cur_date] = array(
				'new_registrations' => 0,
				'new_players' => 0,
				'invites' => 0,
			);
			
			$temp = $dates[$cur_date];
			
			$this->db->where('DATE(`date`)', $cur_date);
			$check = $this->db->get('customers');
			$new_registrations = $check->num_rows();
			
			$this->db->where('DATE(`player_registered_datetime`)', $cur_date);
			$check = $this->db->get('ethnic_mela_players');
			$new_players = $check->num_rows();
			
			$this->db->where('DATE(`invitee_registered_datetime`)', $cur_date);
			$check = $this->db->get('ethnic_mela_invitees');
			$invites = $check->num_rows();
			
			$temp['new_registrations'] = $new_registrations;
			$temp['new_players'] = $new_players;
			$temp['invites'] = $invites;
			
			$dates[$cur_date] = $temp;
			$i += 1;
		}
?>
<style>
	body {
		font-family: 'Arial', sans-serif;
		font-size: 12px;
		text-align: left;
		padding: 15px;
		line-height: 15px;
		color: #333;
	}
	
	/* CSS Snippet For Responsive Table - Stylized */

/* Basic */

* {
  box-sizing: border-box;
}

table {
  border-spacing: 0px;
  border-collapse: collapse;
  width: 100%;
  max-width: 100%;
  margin-bottom: 15px;
  background-color: transparent; /* Change the background-color of table here */
  text-align: left; /* Change the text-alignment of table here */
}

th {
  font-weight: bold;
  border: 1px solid #cccccc; /* Change the border-color of heading here */
  padding: 8px;
}

td {
  border: 1px solid #cccccc; /* Change the border-color of cells here */
  padding: 8px;
}

/* Stylized */

/* Adding Striped Effect for odd rows */

tr {
  background-color: transparent; /* Change the default background-color of rows here */
}

tr:nth-of-type(2n+1) {
  background-color: #eeeeee; /* Change the background-color of odd rows here */
}

tr th {
  background-color: #dddddd; /* Change the background-color of heading here */
}

/* Adding Hover Effect for rows */

tr {
  -moz-transition: background-color 300ms ease-in-out 0s;
  -ms-transition: background-color 300ms ease-in-out 0s;
  -o-transition: background-color 300ms ease-in-out 0s;
  -webkit-transition: background-color 300ms ease-in-out 0s;
  transition: background-color 300ms ease-in-out 0s;
}

tr:hover {
  background-color: #fff176; /* Change the hover background-color of rows here */
}

/* Removing left and right border of rows for modern UIs */

tr {
  border-top: 1px solid #cccccc;
  border-bottom: 1px solid #cccccc;
}

th, td {
  border: none;
}
	
</style>
<table class="table dataTable">
	<thead>
		<tr>
			<th>Date</th>
			<th>New Registrations</th>
			<th>New Players</th>
			<th>Invitations</th>
		</tr>
	</thead>
	<tbody>
		
<?php
			foreach($dates as $date => $values) { ?>
			<tr>
				<td><?php echo date('d M, Y', strtotime($date)); ?></td>
				<td><?php echo $values['new_registrations']; ?></td>
				<td><?php echo $values['new_players']; ?></td>
				<td><?php echo $values['invites']; ?></td>
			</tr>
<?php
			} ?>
	</tbody>
</table>
<?php
		//$this->load->view('header_stripped', $data);
		//$this->load->view('footer', $data);
	}
	
}
