<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Analytics extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $helpers = array(
			'form',
			'email_helper',
            'page_initiater_helper',
        );
        $models = array(
            'model_carts' => 'carts',
            'model_categories' => 'categories',
            'model_customers' => 'customers',
            'model_orders' => 'orders',
            'model_order_items' => 'order_items',
            'model_products' => 'products',
            'model_skus' => 'skus',
            'model_users' => 'users',
            'model_reorder_thresholds' => 'reorder_thresholds',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function old_index() {
		
		$data = initiate_page();
        $data['page_name'] = 'Analytics';
        $data['page_title'] = 'Analytics';
        
        $data['sidebar_element'] = 'side-monitor';
        $data['sidebar_subelement'] = 'side-analytics';
        
        $data['seo_title'] = 'Analytics';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
		
		$from = date('Y-m-d', strtotime('today - 30 days'));
        $to = date('Y-m-d', time());
        
        $from_date = $from;
        $to_date = $to;
        
        if($this->input->get('from')) {
			$from_date = $this->input->get('from');
		}
		if($this->input->get('to')) {
			$to_date = $this->input->get('to');
		}
				
		if(strtotime($from_date) > strtotime($to_date)) {
			$get_from = $from;
			$data['from_date'] = $from;
			$this->session->set_flashdata('form_errors', "FROM DATE cannot be later than TO DATE.");
			redirect('analytics', 'refresh');
		}
		
		$data['get_from_date'] 	= $from_date;
		$data['get_to_date'] 	= $to_date;
		
		$data['get_utm_source'] 	= '';
		$data['get_utm_medium'] 	= '';
		$data['get_utm_campaign'] 	= '';
		$data['get_utm_term'] 		= '';
		$data['get_utm_content'] 	= '';
		
		$filters = array(
			'DATE(ordered_on) >=' => $from_date,
			'DATE(ordered_on) <=' => $to_date,
		);
		
		if($this->input->get('utm_source') != '') {
			$filters['utm_source'] = $this->input->get('utm_source');
			$data['get_utm_source'] = $this->input->get('utm_source');
		}
		if($this->input->get('utm_medium') != '') {
			$filters['utm_medium'] = $this->input->get('utm_medium');
			$data['get_utm_medium'] = $this->input->get('utm_medium');
		}
		if($this->input->get('utm_campaign') != '') {
			$filters['utm_campaign'] = $this->input->get('utm_campaign');
			$data['get_utm_campaign'] = $this->input->get('utm_campaign');
		}
		if($this->input->get('utm_term') != '') {
			$filters['utm_term'] = $this->input->get('utm_term');
			$data['get_utm_term'] = $this->input->get('utm_term');
		}
		if($this->input->get('utm_content') != '') {
			$filters['utm_content'] = $this->input->get('utm_content');
			$data['get_utm_content'] = $this->input->get('utm_content');
		}
		
		
		$all_utm_sources = array();
		$all_utm_mediums = array();
		$all_utm_campaigns = array();
		$all_utm_terms = array();
		$all_utm_contents = array();
		
		$orders = array();
		$check = $this->orders->get_all();
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		foreach($orders as $order) {
			
			if( (trim($order->utm_source) != '') AND ( ! in_array(trim($order->utm_source), $all_utm_sources)) ) {
				array_push($all_utm_sources, $order->utm_source);
			}
			if( (trim($order->utm_medium) != '') AND ( ! in_array(trim($order->utm_medium), $all_utm_mediums)) ) {
				array_push($all_utm_mediums, $order->utm_medium);
			}
			if( (trim($order->utm_campaign) != '') AND ( ! in_array(trim($order->utm_campaign), $all_utm_campaigns)) ) {
				array_push($all_utm_campaigns, $order->utm_campaign);
			}
			if( (trim($order->utm_term) != '') AND ( ! in_array(trim($order->utm_term), $all_utm_terms)) ) {
				array_push($all_utm_terms, $order->utm_term);
			}
			if( (trim($order->utm_content) != '') AND ( ! in_array(trim($order->utm_content), $all_utm_contents)) ) {
				array_push($all_utm_contents, $order->utm_content);
			}
		}
		
		$data['all_utm_sources'] = $all_utm_sources;
		$data['all_utm_mediums'] = $all_utm_mediums;
		$data['all_utm_campaigns'] = $all_utm_campaigns;
		$data['all_utm_terms'] = $all_utm_terms;
		$data['all_utm_content'] = $all_utm_content;
		
		$all_orders = array();
		$check = $this->orders->get_where_array($filters);		
		//echo $this->db->last_query();
		
		if($check->num_rows() > 0) {
			$all_orders = $check->result();
		}
		
		$data['orders'] = $all_orders;
		
		$sorted_orders_date = $this->sort_orders_date($check, $from_date, $to_date);
        $data['sorted_orders_date'] = $sorted_orders_date;
        
        $sorted_revenues_date = $this->sort_revenues_date($check, $from_date, $to_date);
        $data['sorted_revenues_date'] = $sorted_revenues_date;
		
		$total_orders = $check->num_rows();
		$order_ids = array();
		$total_order_value = 0;
		$total_domestic_orders = 0;
		$total_foreign_orders = 0;
		$order_country_index = array();
		$order_city_index = array();
		$customer_ids_who_ordered = array();
		$total_repeat_orders = 0;
		$total_first_time_orders = 0;
		
		$utm_sources_index = array();
		$utm_mediums_index = array();
		$utm_campaigns_index = array();
		$utm_terms_index = array();
		$utm_contents_index = array();
		
		foreach($all_orders as $order) {
			
			array_push($order_ids, $order->id);
			if($order->currency == 'inr') {
				$total_order_value += $order->grand_total;
			} else {
				$total_order_value += $order->grand_total * 65;
			}
			$total_domestic_orders += 1; // add 1 by default. Reduce 1 if foregin check passes
			
			// foreign check
			$ship_country = trim(strtolower($order->ship_to_country));
			$ship_city = trim(strtolower($order->ship_to_city));
			$bill_country = trim(strtolower($order->bill_to_country));
			
			if( ($ship_country != 'india') OR ($bill_country != 'india') ) {
				$total_foreign_orders += 1;
				$total_domestic_orders -= 1; // reduce 1. It was increased by default before.
			}
			
			if( ! isset($order_country_index[$ship_country])) {
				$order_country_index[$ship_country] = array(
					'number' => 0,
					'value' => 0,
				);
			}
			$a = $order_country_index[$ship_country];
			$a['number'] += 1;
			if($order->currency == 'inr') {
				$a['value'] += $order->grand_total;
			} else {
				$a['value'] += $order->grand_total * 65;
			}
			
			$order_country_index[$ship_country] = $a;
			
			# --
			
			if( ! isset($order_city_index[$ship_city])) {
				$order_city_index[$ship_city] = array(
					'value' => 0,
					'number' => 0,
				);
			}
			$a = $order_city_index[$ship_city];
			$a['number'] += 1;
			if($order->currency == 'inr') {
				$a['value'] += $order->grand_total;
			} else {
				$a['value'] += $order->grand_total * 65;
			}
			$order_city_index[$ship_city] = $a;
			
			
			array_push($customer_ids_who_ordered, $order->customer_id);
			
			$total_first_time_orders += 1; // add 1 by default;
			$filters = array(
				'DATE(ordered_on) <' => $from_date,
				'customer_id' => $order->customer_id,
			);
			$check = $this->orders->get_where_array($filters);
			if($check->num_rows() > 0) {
				$total_repeat_orders += 1;
				$total_first_time_orders -= 1; // reduce 1. added 1 by default before.
			}
			
			if(trim($order->utm_source) != '') {
				if( ! isset($utm_sources_index[$order->utm_source])) {
					$utm_sources_index[$order->utm_source] = 0;
				}
				$utm_sources_index[$order->utm_source] += 1;
			}
			
			if(trim($order->utm_medium) != '') {
				if( ! isset($utm_mediums_index[$order->utm_medium])) {
					$utm_mediums_index[$order->utm_medium] = 0;
				}
				$utm_mediums_index[$order->utm_medium] += 1;
			}
			
			if(trim($order->utm_campaign) != '') {
				if( ! isset($utm_campaigns_index[$order->utm_campaign])) {
					$utm_campaigns_index[$order->utm_campaign] = 0;
				}
				$utm_campaigns_index[$order->utm_campaign] += 1;
			}
			
			if(trim($order->utm_term) != '') {
				if( ! isset($utm_terms_index[$order->utm_term])) {
					$utm_terms_index[$order->utm_term] = 0;
				}
				$utm_terms_index[$order->utm_term] += 1;
			}
			
			if(trim($order->utm_content) != '') {
				if( ! isset($utm_contents_index[$order->utm_content])) {
					$utm_contents_index[$order->utm_content] = 0;
				}
				$utm_contents_index[$order->utm_content] += 1;
			}
			
		}
		
		#---------------------------------------------------------------
		# Get all new customers this week
		$all_customers = array();
		$filters = array(
			"DATE(date) >=" => $from_date,
			"DATE(date) <=" => $to_date,
		);
		$check = $this->customers->get_where_array($filters);
		if($check->num_rows() > 0) {
			$all_customers = $check->result();
		}
		
		$total_new_customers = $check->num_rows();
		
		$new_customer_ids = array();
		$total_guest_customers = 0;
		$total_new_customer_orders = 0;
		$total_guest_customer_orders = 0;
		
		foreach($all_customers as $customer) {
			array_push($new_customer_ids, $customer->id);
			if($customer->is_guest == 1) {
				$total_guest_customers += 1;
			}
			if( in_array($customer->id, $customer_ids_who_ordered)) {
				$total_new_customer_orders += 1;
				if($customer->is_guest == 1) {
					$total_guest_customer_orders += 1;
				}
			}
		}
		
		#---------------------------------------------------------------
		# Get all order items
		$order_items = array();
		if(count($order_ids) > 0) {
			$check = $this->order_items->get_where_in('order_id', $order_ids);
			if($check->num_rows() > 0) {
				$order_items = $check->result();
			}
		}
		$item_category_index = array();
		
		foreach($order_items as $item) {
			if( ! isset($item_category_index[$item->cat_id])) {
				$item_category_index[$item->cat_id] = array(
					'value' => 0,
					'number' => 0,
				);
			}
			$a = $item_category_index[$item->cat_id];
			$a['number'] += 1;
			$a['value'] += $item->net_price;
			$item_category_index[$item->cat_id] = $a;
			
		}
		
		#---------------------------------------------------------------
		# Abandoned Carts
		$abandoned_carts = 0;
		$filters = array(
			'DATE(date) >=' 	=> $from_date,
			'DATE(date) <=' 	=> $to_date,
			'checked_out' 		=> 0,
			'total_items >' 	=> 0,
			'total_amount >' 	=> 0,
			 
		);
		$check = $this->carts->get_where_array($filters);
		if($check->num_rows() > 0) {
			$abandoned_carts = $check->num_rows();
		}
		
		$data['abandoned_carts'] = $abandoned_carts;
		
		#---------------------------------------------------------------
		# Get category wise details
		$categories = array();
		$ignored_categories = array('1', '12');
		$check = $this->categories->get_where_not_in('id', $ignored_categories);
		if($check->num_rows() > 0) {
			$categories = $check->result();
		}
		
		$category_index = array();
		$reorder_index = array();
		foreach($categories as $category) {
			$category_index[$category->id] = array(
				'details' => $category,
			);
			$a = $category_index[$category->id];
			$sizes = array('s', 'm', 'l', 'xl', 'xxl', 'xxxl', 'unstitched');
			foreach($sizes as $size) {
				$stock = $this->get_category_size_stock($category->id, $size);
				$a[$size] = $stock;
			}
			$category_index[$category->id] = $a;
			$reorder_index[$category->id] = $this->reorder_thresholds->get_where('cat_id', $category->id)->result();
		}
				
		$data['total_orders'] = $total_orders;
		$data['total_order_value'] = $total_order_value;
		$data['total_domestic_orders'] = $total_domestic_orders;
		$data['total_foreign_orders'] = $total_foreign_orders;
		$data['order_country_index'] = $order_country_index;
		$data['order_city_index'] = $order_city_index;
		$data['total_first_time_orders'] = $total_first_time_orders;
		$data['total_repeat_orders'] = $total_repeat_orders;
		
		$data['total_new_customers'] = $total_new_customers;
		$data['total_guest_customers'] = $total_guest_customers;
		$data['total_new_customer_orders'] = $total_new_customer_orders;
		$data['total_guest_customer_orders'] = $total_guest_customer_orders;
		
		$data['item_category_index'] = $item_category_index;
		
		$data['category_index'] = $category_index;
		$data['reorder_index'] = $reorder_index;
		
		$data['utm_sources_index'] = $utm_sources_index;
		$data['utm_mediums_index'] = $utm_mediums_index;
		$data['utm_campaigns_index'] = $utm_campaigns_index;
		$data['utm_terms_index'] = $utm_terms_index;
		$data['utm_contents_index'] = $utm_contents_index;
		
		$this->load->view('header', $data);
		$this->load->view('analytics_view', $data);
		$this->load->view('footer', $data);
	}
	
	
	
	function index($excel_export=NULL) {
		
		$data = initiate_page();
        $data['page_name'] = 'Analytics';
        $data['page_title'] = 'Analytics';
        
        $data['sidebar_element'] = 'side-monitor';
        $data['sidebar_subelement'] = 'side-analytics';
        
        $data['seo_title'] = 'Analytics';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
		
		$from = date('Y-m-d', strtotime('today - 30 days'));
        $to = date('Y-m-d', time());
        
        $from_date = $from;
        $to_date = $to;
        
        if($this->input->get('from')) {
			$from_date = $this->input->get('from');
		}
		if($this->input->get('to')) {
			$to_date = $this->input->get('to');
		}
				
		if(strtotime($from_date) > strtotime($to_date)) {
			$get_from = $from;
			$data['from_date'] = $from;
			$this->session->set_flashdata('form_errors', "FROM DATE cannot be later than TO DATE.");
			redirect('analytics', 'refresh');
		}
		
		$data['get_from_date'] 	= $from_date;
		$data['get_to_date'] 	= $to_date;
		
		$filters = array(
			'DATE(ordered_on) >=' => $from_date,
			'DATE(ordered_on) <=' => $to_date,
		);
		
		$data['get_utm_source'] 	= '';
		$data['get_utm_medium'] 	= '';
		$data['get_utm_campaign'] 	= '';
		$data['get_utm_term'] 		= '';
		$data['get_utm_content'] 	= '';
		
		if($this->input->get('utm_source') != '') {
			$filters['utm_source'] = $this->input->get('utm_source');
			$data['get_utm_source'] = $this->input->get('utm_source');
		}
		if($this->input->get('utm_medium') != '') {
			$filters['utm_medium'] = $this->input->get('utm_medium');
			$data['get_utm_medium'] = $this->input->get('utm_medium');
		}
		if($this->input->get('utm_campaign') != '') {
			$filters['utm_campaign'] = $this->input->get('utm_campaign');
			$data['get_utm_campaign'] = $this->input->get('utm_campaign');
		}
		if($this->input->get('utm_term') != '') {
			$filters['utm_term'] = $this->input->get('utm_term');
			$data['get_utm_term'] = $this->input->get('utm_term');
		}
		if($this->input->get('utm_content') != '') {
			$filters['utm_content'] = $this->input->get('utm_content');
			$data['get_utm_content'] = $this->input->get('utm_content');
		}
		
		$print_url = $this->config->base_url() . 'analytics/index/excel_export?' . 'utm_source=' . $data['get_utm_source'] . '&utm_medium=' . $data['get_utm_medium'] . '&utm_campaign=' . $data['get_utm_campaign'] . '&utm_term=' . $data['get_utm_term'] . '&utm_content=' . $data['get_utm_content'] . '&from=' . $from_date . '&to=' . $to_date;
		
		$data['print_url'] = $print_url;
		
		$all_utm_sources = array();
		$all_utm_mediums = array();
		$all_utm_campaigns = array();
		$all_utm_terms = array();
		$all_utm_contents = array();
		
		$orders = array();
		$check = $this->orders->get_all();
		if($check->num_rows() > 0) {
			$orders = $check->result();
		}
		
		foreach($orders as $order) {
			if( (trim($order->utm_source) != '') AND ( ! in_array(trim($order->utm_source), $all_utm_sources)) ) {
				array_push($all_utm_sources, $order->utm_source);
			}
			if( (trim($order->utm_medium) != '') AND ( ! in_array(trim($order->utm_medium), $all_utm_mediums)) ) {
				array_push($all_utm_mediums, $order->utm_medium);
			}
			if( (trim($order->utm_campaign) != '') AND ( ! in_array(trim($order->utm_campaign), $all_utm_campaigns)) ) {
				array_push($all_utm_campaigns, $order->utm_campaign);
			}
			if( (trim($order->utm_term) != '') AND ( ! in_array(trim($order->utm_term), $all_utm_terms)) ) {
				array_push($all_utm_terms, $order->utm_term);
			}
			if( (trim($order->utm_content) != '') AND ( ! in_array(trim($order->utm_content), $all_utm_contents)) ) {
				array_push($all_utm_contents, $order->utm_content);
			}
		}
		
		$data['all_utm_sources'] = $all_utm_sources;
		$data['all_utm_mediums'] = $all_utm_mediums;
		$data['all_utm_campaigns'] = $all_utm_campaigns;
		$data['all_utm_terms'] = $all_utm_terms;
		$data['all_utm_contents'] = $all_utm_contents;
		
		
		
		$all_orders = array();
		$check = $this->orders->get_true_orders($filters);		
		//echo $this->db->last_query();
		
		if($check->num_rows() > 0) {
			$all_orders = $check->result();
		}
		
		$data['orders'] = $all_orders;
		$sorted = array();
		
		$order_ids = array();
		$customer_ids_who_ordered = array();
		$total_orders = 0;
		$total_order_revenue = 0;
		
		$utm_sources_index = array();
		$utm_mediums_index = array();
		$utm_campaigns_index = array();
		$utm_terms_index = array();
		$utm_contents_index = array();
		
		$product_index = array();
		
		$category_sales_index = array();
		
		foreach ($all_orders as $order) {
			
			$total_orders += 1;
			if($order->currency == 'inr') {
				$total_order_revenue += $order->grand_total;
			} else {
				$total_order_revenue += $order->grand_total * 65;
			}
			
			array_push($order_ids, $order->id);
			array_push($customer_ids_who_ordered, $order->customer_id);
			
			$from_d = strtotime($from_date);
			$to_d = strtotime($to_date);
			
			$order_time = strtotime($order->ordered_on);
			while ($from_d < $order_time) { # when no orders on this day
				$date  = date('Y-m-d', $from_d);
				$date  = explode('-', $date); 
				$month = $date[1] - 1; # decrement by 1 so 0 -> jan, 11 -> dec
				$date  = $date[0] . '-' . $month . '-' . $date[2];
				
				if (!isset($sorted[$date])) {
					$sorted[$date] 									= array();
					$sorted[$date]['order_num'] 					= 0;
					$sorted[$date]['revenue'] 						= 0;
					
					$sorted[$date]['domestic_orders_num'] 			= 0;
					$sorted[$date]['domestic_orders_revenue'] 			= 0;
					
					$sorted[$date]['foreign_orders_num'] 			= 0;
					$sorted[$date]['foreign_orders_revenue'] 			= 0;
					
					$sorted[$date]['new_customer_orders_num'] 		= 0;
					$sorted[$date]['new_customer_orders_revenue'] 	= 0;
					
					$sorted[$date]['old_customer_orders_num'] 		= 0;
					$sorted[$date]['old_customer_orders_revenue'] 	= 0;
					
					$sorted[$date]['guest_customer_orders_num'] 	= 0;
					$sorted[$date]['guest_customer_orders_revenue'] = 0;
					
					$sorted[$date]['new_customers_num'] 			= 0;
					$sorted[$date]['guest_num'] 					= 0;
					$sorted[$date]['repeat_customers_num'] 			= 0;
					
					$sorted[$date]['s'] 							= 0;
					$sorted[$date]['m'] 							= 0;
					$sorted[$date]['l'] 							= 0;
					$sorted[$date]['xl'] 							= 0;
					$sorted[$date]['xxl'] 							= 0;
					$sorted[$date]['xxxl'] 							= 0;
					$sorted[$date]['unstitched'] 					= 0;
					
					$sorted[$date]['product_list'] 					= array();
					$sorted[$date]['price_list'] 					= array();
				}
				$from_d = strtotime('+1 day', $from_d);
			}
			
			$date  = date('Y-m-d', strtotime($order->ordered_on));
			$date  = explode('-', $date);
			$month = $date[1] - 1; # decrement by 1 so 0 -> jan, 11 -> dec
			$date  = $date[0] . '-' . $month . '-' . $date[2];

			if (!isset($sorted[$date])) { # order is there on this day
				$sorted[$date] 									= array();
				$sorted[$date]['order_num'] 					= 0;
				$sorted[$date]['revenue'] 						= 0;
				
				$sorted[$date]['domestic_orders_num'] 			= 0;
				$sorted[$date]['domestic_orders_revenue'] 			= 0;
				
				$sorted[$date]['foreign_orders_num'] 			= 0;
				$sorted[$date]['foreign_orders_revenue'] 			= 0;
				
				$sorted[$date]['new_customer_orders_num'] 		= 0;
				$sorted[$date]['new_customer_orders_revenue'] 	= 0;
				
				$sorted[$date]['old_customer_orders_num'] 		= 0;
				$sorted[$date]['old_customer_orders_revenue'] 	= 0;
				
				$sorted[$date]['guest_customer_orders_num'] 	= 0;
				$sorted[$date]['guest_customer_orders_revenue'] = 0;
				
				$sorted[$date]['new_customers_num'] 			= 0;
				$sorted[$date]['guest_num'] 					= 0;
				$sorted[$date]['repeat_customers_num'] 			= 0;
				
				$sorted[$date]['s'] 							= 0;
				$sorted[$date]['m'] 							= 0;
				$sorted[$date]['l'] 							= 0;
				$sorted[$date]['xl'] 							= 0;
				$sorted[$date]['xxl'] 							= 0;
				$sorted[$date]['xxxl'] 							= 0;
				$sorted[$date]['unstitched'] 					= 0;
				
				$sorted[$date]['product_list'] 					= array();
				$sorted[$date]['price_list'] 					= array();
			}
			$sorted[$date]['order_num'] += 1;
			if($order->currency == 'inr') {
				$sorted[$date]['revenue'] += $order->grand_total;
			} else {
				$sorted[$date]['revenue'] += $order->grand_total * 65;
			}
			
			$order_items = array();
			$check = $this->db->get_where('order_items', array('order_id' => $order->id));
			if($check->num_rows() > 0) {
				$order_items = $check->result();
			}
			
			foreach($order_items as $item) {
				$sku_id = $item->sku_id;
				$sku_details = $this->db->get_where('skus', array('id' => $sku_id));
				if($sku_details->num_rows() == 0) {
					CONTINUE;
				}
				$sku_details = $sku_details->row();
				
				if( ! isset($category_sales_index[$item->cat_id])) {
					$category_sales_index[$item->cat_id] = array(
						'1-1000' => 0,
						'1001-2000' => 0,
						'2001-3000' => 0,
						'3001-4000' => 0,
						'4001-5000' => 0,
						'5001-6000' => 0,
						'6001-7000' => 0,
						'7001-8000' => 0,
						'8001-9000' => 0,
						'9001-10000' => 0,
						'10001-20000' => 0,
						'20001-50000' => 0,
						'>50000' => 0,
					);
				}
				$temp = $category_sales_index[$item->cat_id];
				if($item->unit_price <= 1000) {
					$temp['1-1000'] += $item->qty;
				} else if($item->unit_price <= 2000) {
					$temp['1001-2000'] += $item->qty;
				} else if($item->unit_price <= 3000) {
					$temp['2001-3000'] += $item->qty;
				} else if($item->unit_price <= 4000) {
					$temp['3001-4000'] += $item->qty;
				} else if($item->unit_price <= 5000) {
					$temp['4001-5000'] += $item->qty;
				} else if($item->unit_price <= 6000) {
					$temp['5001-6000'] += $item->qty;
				} else if($item->unit_price <= 7000) {
					$temp['6001-7000'] += $item->qty;
				} else if($item->unit_price <= 8000) {
					$temp['7001-8000'] += $item->qty;
				} else if($item->unit_price <= 9000) {
					$temp['8001-9000'] += $item->qty;
				} else if($item->unit_price <= 10000) {
					$temp['9001-10000'] += $item->qty;
				} else if($item->unit_price <= 20000) {
					$temp['10001-20000'] += $item->qty;
				} else if($item->unit_price <= 50000) {
					$temp['20001-50000'] += $item->qty;
				} else {
					$temp['>50000'] += $item->qty;
				}
				
				$category_sales_index[$item->cat_id] = $temp;
				
				$sorted[$date][strtolower($sku_details->size)] += $item->qty;
				array_push($sorted[$date]['product_list'], array( 'id' => $item->product_id, 'price' => $item->unit_price, 'size' => strtolower($sku_details->size)));
				$product_details = $this->db->get_where('products', array('id' => $item->product_id));
				if($product_details->num_rows() > 0) {
					if( ! isset($product_index[$item->product_id])) {
						$product_index[$item->product_id] = $product_details->row();
					}
				}
			}
			
			$data['category_sales_index'] = $category_sales_index;
			
			# add to domestic by default. If foregin check passes reduce.
			$sorted[$date]['domestic_orders_num'] += 1;
			if($order->currency == 'inr') {
				$sorted[$date]['domestic_orders_revenue'] += $order->grand_total;
			} else {
				$sorted[$date]['domestic_orders_revenue'] += $order->grand_total * 65;
			}
			
			# foreign check
			$ship_country = trim(strtolower($order->ship_to_country));
			$ship_city = trim(strtolower($order->ship_to_city));
			$bill_country = trim(strtolower($order->bill_to_country));
			if( ($ship_country != 'india') OR ($bill_country != 'india') ) {
				# foreign check passed
				
				# reduce domestic
				$sorted[$date]['domestic_orders_num'] -= 1;
				if($order->currency == 'inr') {
					$sorted[$date]['domestic_orders_revenue'] -= $order->grand_total;
				} else {
					$sorted[$date]['domestic_orders_revenue'] -= $order->grand_total * 65;
				}
				
				
				#increase foreign
				$sorted[$date]['foreign_orders_num'] += 1;
				if($order->currency == 'inr') {
					$sorted[$date]['foreign_orders_revenue'] += $order->grand_total;
				} else {
					$sorted[$date]['foreign_orders_revenue'] += $order->grand_total * 65;
				}
				
			}
			
			# country indexing
			if( ! isset($order_country_index[$ship_country])) {
				$order_country_index[$ship_country] = array(
					'number' => 0,
					'revenue' => 0,
				);
			}
			$order_country_index[$ship_country]['number'] += 1;
			if($order->currency == 'inr') {
				$order_country_index[$ship_country]['revenue'] += $order->grand_total;
			} else {
				$order_country_index[$ship_country]['revenue'] += $order->grand_total * 65;
			}
			
			
			# city indexing
			if( ! isset($order_city_index[$ship_city])) {
				$order_city_index[$ship_city] = array(
					'number' => 0,
					'revenue' => 0,
				);
			}
			$order_city_index[$ship_city]['number'] += 1;
			if($order->currency == 'inr') {
				$order_city_index[$ship_city]['revenue'] += $order->grand_total;
			} else {
				$order_city_index[$ship_city]['revenue'] += $order->grand_total * 65;
			}
			
			
			# add to first time orders by default. If repeat check passes, reduce
			$sorted[$date]['new_customer_orders_num'] += 1;
			if($order->currency == 'inr') {
				$sorted[$date]['new_customer_orders_revenue'] += $order->grand_total;
			} else {
				$sorted[$date]['new_customer_orders_revenue'] += $order->grand_total * 65;
			}
			
			
			# repeat check
			$filters = array(
				'DATE(ordered_on) <' => $from_date,
				'customer_id' => $order->customer_id,
			);
			$check = $this->orders->get_where_array($filters);
			if($check->num_rows() > 0) {
				#repeat check passes
				
				#reduce first time
				$sorted[$date]['new_customer_orders_num'] -= 1;
				if($order->currency == 'inr') {
					$sorted[$date]['new_customer_orders_revenue'] -= $order->grand_total;
				} else {
					$sorted[$date]['new_customer_orders_revenue'] -= $order->grand_total * 65;
				}
				
				
				#increase repeat
				$sorted[$date]['old_customer_orders_num'] += 1;
				if($order->currency == 'inr') {
					$sorted[$date]['old_customer_orders_revenue'] += $order->grand_total;
				} else {
					$sorted[$date]['old_customer_orders_revenue'] += $order->grand_total * 65;
				}
				
			}
			
			#guest
			$customer_details = $this->customers->get($order->customer_id)->row();
			if($customer_details->is_guest == 1) {
				$sorted[$date]['guest_customer_orders_num'] += 1;
				if($order->currency == 'inr') {
					$sorted[$date]['guest_customer_orders_revenue'] += $order->grand_total;
				} else {
					$sorted[$date]['guest_customer_orders_revenue'] += $order->grand_total * 65;
				}
				
			}
			
			
			if(trim($order->utm_source) != '') {
				if( ! isset($utm_sources_index[$order->utm_source])) {
					$utm_sources_index[$order->utm_source] = 0;
				}
				$utm_sources_index[$order->utm_source] += 1;
			}
			
			if(trim($order->utm_medium) != '') {
				if( ! isset($utm_mediums_index[$order->utm_medium])) {
					$utm_mediums_index[$order->utm_medium] = 0;
				}
				$utm_mediums_index[$order->utm_medium] += 1;
			}
			
			if(trim($order->utm_campaign) != '') {
				if( ! isset($utm_campaigns_index[$order->utm_campaign])) {
					$utm_campaigns_index[$order->utm_campaign] = 0;
				}
				$utm_campaigns_index[$order->utm_campaign] += 1;
			}
			
			if(trim($order->utm_term) != '') {
				if( ! isset($utm_terms_index[$order->utm_term])) {
					$utm_terms_index[$order->utm_term] = 0;
				}
				$utm_terms_index[$order->utm_term] += 1;
			}
			
			if(trim($order->utm_content) != '') {
				if( ! isset($utm_contents_index[$order->utm_content])) {
					$utm_contents_index[$order->utm_content] = 0;
				}
				$utm_contents_index[$order->utm_content] += 1;
			}
			
			
		}
		
		while ($from_d <= $to_d) { # fill the remaining days with no orders
			$date  = date('Y-m-d', $from_d);
			$date  = explode('-', $date);
			$month = $date[1] - 1;
			$date  = $date[0] . '-' . $month . '-' . $date[2];
			if (!isset($sorted[$date])) {
				$sorted[$date] 									= array();
				$sorted[$date]['order_num'] 					= 0;
				$sorted[$date]['revenue'] 						= 0;
				
				$sorted[$date]['domestic_orders_num'] 			= 0;
				$sorted[$date]['domestic_orders_revenue'] 			= 0;
				
				$sorted[$date]['foreign_orders_num'] 			= 0;
				$sorted[$date]['foreign_orders_revenue'] 			= 0;
				
				$sorted[$date]['new_customer_orders_num'] 		= 0;
				$sorted[$date]['new_customer_orders_revenue'] 	= 0;
				
				$sorted[$date]['old_customer_orders_num'] 		= 0;
				$sorted[$date]['old_customer_orders_revenue'] 	= 0;
				
				$sorted[$date]['guest_customer_orders_num'] 	= 0;
				$sorted[$date]['guest_customer_orders_revenue'] = 0;
				
				$sorted[$date]['new_customers_num'] 			= 0;
				$sorted[$date]['guest_num'] 					= 0;
				$sorted[$date]['repeat_customers_num'] 			= 0;
				
				$sorted[$date]['s'] 							= 0;
				$sorted[$date]['m'] 							= 0;
				$sorted[$date]['l'] 							= 0;
				$sorted[$date]['xl'] 							= 0;
				$sorted[$date]['xxl'] 							= 0;
				$sorted[$date]['xxxl'] 							= 0;
				$sorted[$date]['unstitched'] 					= 0;
				
				$sorted[$date]['product_list'] 					= array();
				$sorted[$date]['price_list'] 					= array();
			}
			$from_d = strtotime('+1 day', $from_d);
		}
		
		
		#---------------------------------------------------------------
		# Get all new customers this week
		$all_customers = array();
		$filters = array(
			"DATE(date) >=" => $from_date,
			"DATE(date) <=" => $to_date,
		);
		$check = $this->customers->get_where_array($filters);
		if($check->num_rows() > 0) {
			$all_customers = $check->result();
		}
		
		$total_new_customers = $check->num_rows();
		
		$new_customer_ids = array();
		$total_guest_customers = 0;
		$total_new_customer_orders = 0;
		$total_guest_customer_orders = 0;
		
		foreach($all_customers as $customer) {
			array_push($new_customer_ids, $customer->id);
			if($customer->is_guest == 1) {
				$total_guest_customers += 1;
			}
			if( in_array($customer->id, $customer_ids_who_ordered)) {
				$total_new_customer_orders += 1;
				if($customer->is_guest == 1) {
					$total_guest_customer_orders += 1;
				}
			}
		}
		
		#---------------------------------------------------------------
		# Get all order items
		$order_items = array();
		if(count($order_ids) > 0) {
			$check = $this->order_items->get_where_in('order_id', $order_ids);
			if($check->num_rows() > 0) {
				$order_items = $check->result();
			}
		}
		$item_category_index = array();
		
		foreach($order_items as $item) {
			if( ! isset($item_category_index[$item->cat_id])) {
				$item_category_index[$item->cat_id] = array(
					'value' => 0,
					'number' => 0,
				);
			}
			$a = $item_category_index[$item->cat_id];
			$a['number'] += 1;
			$a['value'] += $item->net_price;
			$item_category_index[$item->cat_id] = $a;
			
		}
		
		#---------------------------------------------------------------
		# Abandoned Carts
		$abandoned_carts = 0;
		$filters = array(
			'DATE(date) >=' 	=> $from_date,
			'DATE(date) <=' 	=> $to_date,
			'checked_out' 		=> 0,
			'total_items >' 	=> 0,
			'total_amount >' 	=> 0,
			 
		);
		$check = $this->carts->get_where_array($filters);
		if($check->num_rows() > 0) {
			$abandoned_carts = $check->num_rows();
		}
		
		$data['abandoned_carts'] = $abandoned_carts;
		
		#---------------------------------------------------------------
		# Get category wise details
		$categories = array();
		$ignored_categories = array('1', '12');
		$check = $this->categories->get_where_not_in('id', $ignored_categories);
		if($check->num_rows() > 0) {
			$categories = $check->result();
		}
		
		$category_index = array();
		$reorder_index = array();
		foreach($categories as $category) {
			$category_index[$category->id] = array(
				'details' => $category,
			);
			$a = $category_index[$category->id];
			$sizes = array('s', 'm', 'l', 'xl', 'xxl', 'xxxl', 'unstitched');
			foreach($sizes as $size) {
				$stock = $this->get_category_size_stock($category->id, $size);
				$a[$size] = $stock;
			}
			$category_index[$category->id] = $a;
			$reorder_index[$category->id] = $this->reorder_thresholds->get_where('cat_id', $category->id)->result();
		}
		
		//echo "<pre>";
		//print_r($category_sales_index);
		//echo "</pre>";
		
		$data['sorted_orders_date'] = $sorted;
		$data['total_orders'] = $total_orders;
		$data['total_order_value'] = $total_order_revenue;
		
		$data['total_new_customers'] = $total_new_customers;
		$data['total_guest_customers'] = $total_guest_customers;
		$data['total_new_customer_orders'] = $total_new_customer_orders;
		$data['total_guest_customer_orders'] = $total_guest_customer_orders;
		
		$data['item_category_index'] = $item_category_index;
		
		$data['category_index'] = $category_index;
		$data['reorder_index'] = $reorder_index;
		$data['product_index'] = $product_index;
		
		$data['utm_sources_index'] = $utm_sources_index;
		$data['utm_mediums_index'] = $utm_mediums_index;
		$data['utm_campaigns_index'] = $utm_campaigns_index;
		$data['utm_terms_index'] = $utm_terms_index;
		$data['utm_contents_index'] = $utm_contents_index;
		
		$data['analytics_graphs'] = 1;
		
		if($excel_export != NULL) {
			
			require      APPPATH . 'controllers/class/PHPExcel.php';
			require_once APPPATH . 'controllers/class/PHPExcel/IOFactory.php';
			
			$excel_data = array(); 
			$headings = array(
				# list out the headings
				'ID',
				'Items',
				'Grand Total (INR)',
				'Source',
				'Medium',
				'Campaign',
				'Term',
				'Content',
				'Type',
				'Date',
			);
			
			array_push($excel_data, $headings);
			$data_body = array();
			
			foreach($all_orders as $order) {
				$temp_row = array();
				
				$order_id = $order->id;
				$total_items = $order->total_items;
				$grand_total = $order->grand_total;
				$currency = $order->currency;
				
				if($currency == 'usd') {
					$grand_total = $order->grand_total * 65;
				}
				
				$utm_source = $order->utm_source;
				$utm_medium = $order->utm_medium;
				$utm_campaign = $order->utm_campaign;
				$utm_term = $order->utm_term;
				$utm_content = $order->utm_content;
				
				$type = 'domestic';
				if(trim(strtolower($order->ship_to_country)) != 'india') {
					$type = 'foreign';
				}
				
				$ordered_date = date("d M, Y", strtotime($order->ordered_on));
				
				
				array_push($temp_row,
					$order_id,
					$total_items,
					$grand_total,
					$utm_source,
					$utm_medium,
					$utm_campaign,
					$utm_term,
					$utm_content,
					$type,
					$ordered_date
				);
				
				array_push($excel_data, $temp_row);
			}
			
			//echo "<pre>";
			//print_r($excel_data);
			//echo "</pre>";
			//exit();
			
			$objPHPExcel = new PHPExcel();
			$objPHPExcel->getProperties()->setCreator("Taruni"); # change this
			$objPHPExcel->getProperties()->setLastModifiedBy("Taruni"); # change this
			$objPHPExcel->getProperties()->setTitle("Taruni Order Analytics Data"); # change this
			$objPHPExcel->getProperties()->setSubject("Taruni Order Analytics Data"); # change this
			$objPHPExcel->getProperties()->setDescription("Taruni Order Analytics Data"); # change this
			$objPHPExcel->getActiveSheet()->fromArray($excel_data, null, 'A1');
			header("Content-Type: application/xlsx");
			header("Content-Disposition: attachment; filename=taruni_order_analytics_data.xlsx"); # change this
			header("Pragma: no-cache");
			header("Expires: 0");
			$highestColumn = $objPHPExcel->getActiveSheet()->getHighestDataColumn();
			$nCols = PHPExcel_Cell::columnIndexFromString($highestColumn);
			foreach (range(0, $nCols) as $col) {
				$objPHPExcel->getActiveSheet()->getColumnDimensionByColumn($col)->setWidth(30);                
			}
			$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
			$objWriter->save('php://output');
			
		} else {
			$this->load->view('header', $data);
			$this->load->view('analytics_view', $data);
			$this->load->view('footer', $data);
		}
	}
	
	// get category size stock
	function get_category_size_stock($cat_id, $size) {
		$filters = array(
			'stock >' => 0,
			'size' => $size,
			'cat_id' => $cat_id,
		);
		$check = $this->skus->get_where_array($filters);
		$skus = array();
		$stock = 0;
		if($check->num_rows() > 0) {
			$skus = $check->result();
		}
		foreach($skus as $sku) {
			$stock += $sku->stock;
		}	
		return $stock;
	}
	
	
	function sort_orders_date($orders, $get_from, $get_to) {
		$sorted = array();
        $from_time = strtotime($get_from);
        $to_time = strtotime($get_to);
        foreach($orders->result() as $order) {
			$order_time = strtotime($order->ordered_on);
			while($from_time < $order_time) {
				$date = date('Y-m-d', $from_time);
				// google charts month starts with 0 -> jan, 11 -> dec
				$date = explode('-', $date);
				$month = $date[1] - 1;
				$date = $date[0].'-'.$month.'-'.$date[2];
				if( ! isset($sorted[$date])) {
					$sorted[$date] = 0;
				}
				$from_time = strtotime('+1 day', $from_time);
			}
			$date = date('Y-m-d', strtotime($order->ordered_on));
			// google charts month starts with 0 -> jan, 11 -> dec
			$date = explode('-', $date);
			$month = $date[1] - 1;
			$date = $date[0].'-'.$month.'-'.$date[2];
			
			if( ! isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$sorted[$date] += 1;
		}
		while($from_time <= $to_time) {
			$date = date('Y-m-d', $from_time);
			$date = explode('-', $date);
			$month = $date[1] - 1;
			$date = $date[0].'-'.$month.'-'.$date[2];
			if( ! isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$from_time = strtotime('+1 day', $from_time);
		}
		return $sorted;
	}
	
	/**
     * Sort revenues date wise
     * --
     * @param array $orders
     * --
     * @return array $result
     * --
     */
    function sort_revenues_date($orders, $get_from, $get_to) {
		$sorted = array();
        $from_time = strtotime($get_from);
        $to_time = strtotime($get_to);
        foreach($orders->result() as $order) {
			$order_time = strtotime($order->ordered_on);
			while($from_time < $order_time) {
				$date = date('Y-m-d', $from_time);
				// google charts month starts with 0 -> jan, 11 -> dec
				$date = explode('-', $date);
				$month = $date[1] - 1;
				$date = $date[0].'-'.$month.'-'.$date[2];
				if( ! isset($sorted[$date])) {
					$sorted[$date] = 0;
				}
				$from_time = strtotime('+1 day', $from_time);
			}
			$date = date('Y-m-d', strtotime($order->ordered_on));
			// google charts month starts with 0 -> jan, 11 -> dec
			$date = explode('-', $date);
			$month = $date[1] - 1;
			$date = $date[0].'-'.$month.'-'.$date[2];
			
			if( ! isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$sorted[$date] += $order->grand_total;
		}
		while($from_time <= $to_time) {
			$date = date('Y-m-d', $from_time);
			$date = explode('-', $date);
			$month = $date[1] - 1;
			$date = $date[0].'-'.$month.'-'.$date[2];
			if( ! isset($sorted[$date])) {
				$sorted[$date] = 0;
			}
			$from_time = strtotime('+1 day', $from_time);
		}
		return $sorted;
	}
	
	
	
	
}
