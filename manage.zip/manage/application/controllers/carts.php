<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Carts extends CI_Controller

{
    function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_carts', '', TRUE);
        $this->load->model('mdl_categories', '', TRUE);
        $this->load->model('mdl_products', '', TRUE);
        $this->load->model('mdl_skus', '', TRUE);
        $this->load->model('mdl_customers', '', TRUE);
        $this->load->helper(array(
            'form'
        ));
    }

    function index() //
    {
        redirect('404', 'refresh');
        exit();
    }
    
    function view($id) //
    {
        if ($this->session->userdata('logged_in')) {
            $session_data = $this->session->userdata('logged_in');
            $data['username'] = $session_data['username'];
            $data['user_type'] = $session_data['type'];
            $data['user_email'] = $session_data['email'];
            
            $data['page_name'] = 'carts';
            $data['page_title'] = 'View a cart';
            
            $data['sidebar_element'] = 'side-carts';
            
            //$id = $this->input->post('cart-id', true);
            
            $cart_details = $this->mdl_carts->get_where($id);
            if($cart_details->num_rows() == 0) {
                redirect('404', 'refresh');
            }
            else {
                $cart_details = $cart_details->row();
            }
            $data['cart_details'] = $cart_details;
            
            $cart_items = $this->db->get_where('cart_items', array('cart_id' => $id));
            if($cart_items->num_rows() == 0) {
                echo "zero items in this cart";
                exit();
                //redirect('404', 'refresh');
            }
            else {
                $cart_items = $cart_items->result();
            }
            $data['cart_items'] = $cart_items;
            
            $customizations_list = array();
            foreach($cart_items as $cart_item) {

                $sku_details = $this->mdl_skus->get_where($cart_item->sku_id)->row();
                $skus_list[$cart_item->id] = $sku_details;
                
                $product_details = $this->mdl_products->get_where($sku_details->product_id)->row();
                $products_list[$cart_item->id] = $product_details;
                
                if($cart_item->custom) :
                    $customization_details = $this->db->get_where('customizations', array('cart_item_id' => $cart_item->id) );
                    $customizations_list[$cart_item->id] = $customization_details->row();
                endif;
                
            }
            $data['skus_list'] = $skus_list;
            $data['customizations_list'] = $customizations_list;
            $data['products_list'] = $products_list;
            
            
            $customer_details = $this->mdl_customers->get_where($cart_details->customer_id);
            if($customer_details->num_rows() > 0) {
                $customer_details = $customer_details->row();
            }
            else {
                //redirect('404', 'refresh');
            }
            $data['customer_details'] = $customer_details;
            
            $data['page_title'] = 'cart '. $cart_details->id;
            
            
            $this->load->view('header', $data);
            $this->load->view('cart_view', $data);
            $this->load->view('footer', $data);
        }
        else {
            redirect('login', 'refresh');
        }
    }

}
