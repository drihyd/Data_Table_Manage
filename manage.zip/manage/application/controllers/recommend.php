<?php
defined('BASEPATH') OR exit();

class Recommend extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$this->load->helper(array(
			'form',
			'email_helper',
			'page_initiater_helper'
		));
	}
	
	function index() {
		
		$data                    		= initiate_page();
		$data['page_name']       		= 'Recommended Products';
		$data['page_title']      		= 'Recommended Products';
		$data['sidebar_element'] 		= 'side-products';
		$data['sidebar_subelement'] 	= 'side-recommended';
		$data['seo_title']       		= 'Recommended Products';
		$data['seo_description'] 		= '';
		$data['seo_keywords']    		= '';
		
		$products = array();
		$this->db->where('recommended', 1);
		$check = $this->db->get('products');
		
		if($check->num_rows() > 0) {
			$products = $check->result();
		}
		$data['products'] = $products;
		
		$this->load->view('header', $data);
		$this->load->view('recommended_view', $data);
		$this->load->view('footer', $data);
		
	}
	
	function add() {
		
		$data                    		= initiate_page();
		$data['page_name']       		= 'Recommended Products';
		$data['page_title']      		= 'Recommended Products';
		$data['sidebar_element'] 		= 'side-products';
		$data['sidebar_subelement'] 	= 'side-recommended';
		$data['seo_title']       		= 'Recommended Products';
		$data['seo_description'] 		= '';
		$data['seo_keywords']    		= '';
		
		$recomm_prod_codes = $this->input->post('recomm-prod-codes', TRUE);
		if( ( ! $recomm_prod_codes) OR (trim($recomm_prod_codes == '')) ) {
			$this->session->set_flashdata('form_errors', "<div class='alert alert-danger'>Please enter a valid Product-code</div>");
			redirect('recommend', 'refresh');
			exit();
		}
		
		$recomm_prod_codes = trim($recomm_prod_codes);
		$recomm_prod_codes = explode(',', $recomm_prod_codes);
		
		$errors = array();
		$i = 0;
		foreach($recomm_prod_codes as $product_code) {
			$product_code = trim($product_code);
			
			$this->db->where('code', $product_code);
			$check = $this->db->get('products');
			if($check->num_rows() == 0) {
				array_push($errors, $product_code);
				CONTINUE;
			}
			
			$product = $check->row();
			$new_data = array(
				'recommended' => 1,
			);
			$this->db->where('id', $product->id);
			$this->db->update('products', $new_data);
			$i += 1;
		}
		
		if($i > 0) {
			$this->session->set_flashdata('form_success', "<div class='alert alert-success'>{$i} product(s) successfully added to recommended list.</div>");
		}
		
		if(count($errors) > 0) {
			$error_message = '';
			foreach($errors as $error) {
				$error_message .= "<li>{$error}</li>";
			}
			$this->session->set_flashdata('form_errors', "<div class='alert alert-danger'><strong>Some errors occured:</strong><br>The following products could not be found:<ul>{$error_message}</ul></div>");
		}
		
		redirect('recommend', 'refresh');
	}
	
	function delete($product_id) {
		
		$data                    		= initiate_page();
		$data['page_name']       		= 'Recommended Products';
		$data['page_title']      		= 'Recommended Products';
		$data['sidebar_element'] 		= 'side-products';
		$data['sidebar_subelement'] 	= 'side-recommended';
		$data['seo_title']       		= 'Recommended Products';
		$data['seo_description'] 		= '';
		$data['seo_keywords']    		= '';
		
		$product_id = trim($product_id);
		$this->db->where('id', $product_id);
		$check = $this->db->get('products');
		if($check->num_rows() == 0) {
			$this->session->set_flashdata('form_errors', "<div class='alert alert-danger'>Sorry! Product could not be found. Please try again.</div>");
			redirect('recommend', 'refresh');
			exit();
		}
		
		$product = $check->row();
		$new_data = array(
			'recommended' => 0,
		);
		$this->db->where('id', $product->id);
		$this->db->update('products', $new_data);
		
		$this->session->set_flashdata('form_success', "<div class='alert alert-success'>Product successfully removed from the recommended list.</div>");
		redirect('recommend', 'refresh');
		exit();
	}
}
