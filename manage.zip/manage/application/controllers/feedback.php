<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Feedback extends CI_Controller {
    function __construct() {
        parent::__construct();
        $helpers = array(
            'form',
            'page_initiater_helper',
        );
        $models = array(
            'model_feedbacks' => 'feedbacks',
            'model_users' => 'users',
        );
        foreach ($models as $file => $alias) {
            $this->load->model($file, $alias);
        }
        foreach ($helpers as $helper) {
            $this->load->helper($helper);
        }
    }
    
    function index() {
        $data = initiate_page();
        $data['page_name'] = 'feedback';
        $data['page_title'] = 'Feedback';
        
        $data['sidebar_element'] = 'side-feedback';
        
        $data['seo_title'] = 'Feedback';
        $data['seo_description'] = '';
        $data['seo_keywords'] = '';
        
        $feedbacks = array();
        $check = $this->feedbacks->get_all();
        if($check->num_rows() > 0) {
			$feedbacks = $check->result();
		}
		$data['feedbacks'] = $feedbacks;
		
        $this->load->view('header/header', $data);
        $this->load->view('feedbacks_view', $data);
        $this->load->view('footer/footer', $data);
    }

}
