<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_order_customizations extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'order_customizations';
	}
	
	public function get_all() {
		$table = $this->table;
		
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get order by id
	 * --
	 * @param int $id
	 * --
	 * @return array $result
	 * --
	 */
	public function get($id) {
		$table = $this->table;
		
		$this->db->where('id', $id);
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get where -> custom field and value pair
	 * --
	 * @param string $field_name
	 * @param mixed $value
	 * --
	 * @return array $result
	 * --
	 */
	public function get_where($field_name, $value) {
		$table = $this->table;
		
		$this->db->where($field_name, $value);
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get where -> array of field and value pairs
	 * --
	 * @param array $field_value_pairs
	 * --
	 * @return array $result
	 */
	public function get_where_array($field_value_pairs) {
		$table = $this->table;
		
		foreach($field_value_pairs as $key => $value) {
			$this->db->where($key, $value);
		}
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_true_orders($field_value_pairs) {
		$table = $this->table;
		
		foreach($field_value_pairs as $key => $value) {
			$this->db->where($key, $value);
		}
		
		$this->db->where("order_status != 'cancelled' AND order_status != 'cancelled-refund-pending' AND order_status != 'cancelled-refunded' AND order_status != 'on-hold'");
		$result = $this->db->get($table);
		return $result;
	}
	
	// get where in
	public function get_where_in($field_name, $array) {
		$table = $this->table;
		
		$this->db->where_in($field_name, $array);
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_item_customizations($order_item_id) {
		$table = $this->table;
		
		$this->db->where('order_item_id', $order_item_id);
		$result = $this->db->get($table);
		return $result;
	}

}
