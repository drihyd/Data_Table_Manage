<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_orders extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'orders';
		
		// alias => actual_field_name
		$this->fields = array(
			'order_placed_date' 	=> 'ordered_on',
			'order_canceled_date' 	=> 'cancelled_on',
			'order_delivered_date' 	=> 'delivered_on',
			'order_status' 			=> 'order_status',
			'order_grand_total' 	=> 'grand_total',
			'order_total_items' 	=> 'total_items',
		);
	}
	
	/**
	 * Get field names array
	 * --
	 * @param string $alias
	 * --
	 * @return string $actual_field_name
	 */
	public function get_field_name($alias) {
		$fields = $this->fields;	
		return $fields[$alias];
	}
	
	public function get_all($limit=NULL) {
		$table = $this->table;
		
		if($limit != NULL) {
			$this->db->limit($limit);
		}
		
		$this->db->order_by('id', 'desc');
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_today() {
		$table = $this->table;
				
		$this->db->order_by('id', 'desc');
		$this->db->where('date(ordered_on)', date('Y-m-d', time()));
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_month($month, $year) {
		$table = $this->table;		
		$this->db->order_by('id', 'desc');
		$this->db->where('MONTH(ordered_on)', $month);
		$this->db->where('YEAR(ordered_on)', $year);
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_month_foreign($month, $year) {
		$table = $this->table;		
		$this->db->order_by('id', 'desc');
		$this->db->where('ship_to_country_id !=', 99);
		$this->db->where('MONTH(ordered_on)', $month);
		$this->db->where('YEAR(ordered_on)', $year);
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_from_to($from, $to) {
		$table = $this->table;		
		$this->db->order_by('id', 'desc');
		$this->db->where('DATE(ordered_on) >=', $from);
		$this->db->where('DATE(ordered_on) <=', $to);
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_placed() {
		$table = $this->table;
				
		$this->db->order_by('id', 'desc');
		$this->db->where('grand_total >', '0');
		$this->db->where('total_items >', '0');
		$this->db->where('order_status', 'placed');
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get order by id
	 * --
	 * @param int $id
	 * --
	 * @return array $result
	 * --
	 */
	public function get($id) {
		$table = $this->table;
		
		$this->db->where('id', $id);
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get where -> custom field and value pair
	 * --
	 * @param string $field_name
	 * @param mixed $value
	 * --
	 * @return array $result
	 * --
	 */
	public function get_where($field_name, $value) {
		$table = $this->table;
		
		$this->db->where($field_name, $value);
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get where -> array of field and value pairs
	 * --
	 * @param array $field_value_pairs
	 * --
	 * @return array $result
	 */
	public function get_where_array($field_value_pairs) {
		$table = $this->table;
		
		foreach($field_value_pairs as $key => $value) {
			$this->db->where($key, $value);
		}
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_true_orders($field_value_pairs) {
		$table = $this->table;
		
		foreach($field_value_pairs as $key => $value) {
			$this->db->where($key, $value);
		}
		
		$this->db->where("order_status != 'cancelled' AND order_status != 'cancelled-refund-pending' AND order_status != 'cancelled-refunded' AND order_status != 'on-hold'");
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_valid_orders() {
		$table = $this->table;
		$this->db->where("order_status != 'cancelled' AND order_status != 'cancelled-refund-pending' AND order_status != 'cancelled-refunded' AND order_status != 'on-hold'");
		$result = $this->db->get($table);
		return $result;
	}
	
	// get where in
	public function get_where_in($field_name, $array) {
		$table = $this->table;
		
		$this->db->where_in($field_name, $array);
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_placed_orders() {
		$table = $this->table;
		
		$this->db->order_by('id', 'desc');
		$this->db->where('order_status', 'placed');
		$this->db->where('total_amount >', 0);
		$this->db->where('total_items >', 0);
		$this->db->where('customer_id !=', 0);
		$result = $this->db->get($table);
		
		return $result;
	}

}
