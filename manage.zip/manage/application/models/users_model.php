<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class Users_model extends CI_Model { 
  
  function __construct() {
    parent:: __construct();
    $this->load->helper('url');
  }
  
  function login($username, $password) {

    $query = $this->db->get_where('users', array(
      'username' => $username, 
      'password' => MD5($password)
    ));

    if($query->num_rows() == 1) {
      return $query->result();
    }
    else {
      return FALSE;
    }
  }

}
