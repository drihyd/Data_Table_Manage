<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_carts extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'carts';
	}
	
		/**
	 * Get order by id
	 * --
	 * @param int $id
	 * --
	 * @return array $result
	 * --
	 */
	public function get($id) {
		$table = $this->table;
		
		$this->db->where('id', $id);
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get all
	 * --
	 * @return array $result
	 * --
	 */
	public function get_all() {
		$table = $this->table;
		
		$this->db->limit('1000');
		$this->db->order_by('id', 'desc');
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get where -> custom field and value pair
	 * --
	 * @param string $field_name
	 * @param mixed $value
	 * --
	 * @return array $result
	 * --
	 */
	public function get_where($field_name, $value) {
		$table = $this->table;
		
		$this->db->where($field_name, $value);
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get where -> array of field and value pairs
	 * --
	 * @param array $field_value_pairs
	 * --
	 * @return array $result
	 * --
	 */
	public function get_where_array($field_value_pairs) {
		$table = $this->table;
		
		$this->db->order_by('id', 'desc');
		foreach($field_value_pairs as $key => $value) {
			$this->db->where($key, $value);
		}
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_hot_carts() {
		$table = $this->table;
		
		$offset = $this->get_time_diff();
		$offset = explode(':', $offset);
		
		$sign = '+';
		$first = $offset[0];
		if($first[0] == '-') {
			$sign = '-';
		}
		
		$h = abs($offset[0]);
		$m = abs($offset[1]) / 60;
		
		
		$greater_date = date('Y-m-d',  strtotime('-2 hours'));
		$greater_datetime = date('Y-m-d H:i:s',  strtotime('-2 hours'));
		
		if($sign == '-') {
			$greater_datetime = strtotime($greater_datetime) - ($h * 3600) - ($m * 3600) - (5 * 3600) - (0.5 * 3600);
		} else {
			$greater_datetime = strtotime($greater_datetime) + ($h * 3600) + ($m * 3600) - (5 * 3600) - (0.5 * 3600);
		}
		
		//echo date('Y-m-d H:i:s', $ts).'<br>';
		
		$one_day_gap = date('Y-m-d H:i:s',  strtotime('+1 day'));
		
		$result = $this->db->query("SELECT * FROM (`carts`) WHERE (`last_modified` != '' AND `last_modified` >= '{$greater_datetime}') AND (`checked_out` = 0 AND `total_items` > 0 AND `total_amount` > 0) AND (`last_email` = '0000-00-00 00:00:00' OR `last_email` >= '{$one_day_gap}') AND (`user_id` != 0 OR `ship_to_email` != '' OR `bill_to_email` != '')");
		
		return $result;
	}
	
	public function get_scheduled_carts() {
		$table = $this->table;
		
		$actual_datetime = date('Y-m-d H:i:s', time());
		
		$result = $this->db->query("SELECT * FROM (`carts`) WHERE (`schedule_discount` != '' AND `schedule_discount` <= '{$actual_datetime}') AND (`checked_out` = 0 AND `total_items` > 0 AND `total_amount` > 0) AND (`user_id` != 0 OR `ship_to_email` != '' OR `bill_to_email` != '')");
		
		return $result;
	}
	
	function get_unix_timestamp($time) {
		$stamp = $this->db->query("SELECT UNIX_TIMESTAMP('{$time}');")->row();
		foreach($stamp as $r) {
			$stamp = $r;
			BREAK;
		}
		return $stamp;
	}
	
	function get_time_diff() {
		$diff = $this->db->query("select timediff(now(),convert_tz(now(),@@session.time_zone,'+00:00'));");
		foreach($diff->row() as $r) {
			$diff = $r;
			BREAK;
		}
		return $diff;
	}

}
