<?php

defined('BASEPATH') OR exit();

class Connection_model extends CI_Model {
	
	function __construct() {	
		parent::__construct();
		$this->table = 'connections';
	}
	
	# ------------------------------------------------------------------
	# Interface functions
	# ------------------------------------------------------------------
	
	public function get($filters) {
		if( ( ! $filters) OR (empty($filters)) ) {
			return FALSE;
		}
		
		return $this->_get($filters);
	}
	
	public function update($id, $new_data) {
		if( ( ! $id) OR ((int)$id == '') ) {
			return FALSE;
		}
		
		if( ( ! $new_data) OR (empty($new_data)) ) {
			return FALSE;
		}
		
		$filters = array(
			'id' => $id,
		);
		
		if( ! $this->_get($filters)) {
			return FALSE;
		}
		
		return $this->_update($id, $new_data);
	}
	
	public function insert($new_data) {
		if( ( ! $new_data) OR (empty($new_data)) ) {
			return FALSE;
		}
		
		return $this->_insert($new_data);
	}
	
	public function get_connections($id) {
		if( ( ! $id) OR ((int)$id == '') ) {
			return FALSE;
		}
		
		$filters = array(
			'lead_id' => $id,
		);
		
		return $this->_get_where($filters);
	}
	
	# ------------------------------------------------------------------
	# Base CRUD logic
	# ------------------------------------------------------------------
	
	private function _get($filters) {
		$table = $this->table;
		
		$this->db->where($filters);
		if( ! $check = $this->db->get($table)) {
			return FALSE;
		}
		
		if($check->num_rows() <= 0) {
			return FALSE;
		}
		
		return $check->row();
	}
	
	private function _update($id, $new_data) {
		$table = $this->table;
		
		$this->db->where('id', $id);
		if( ! $this->db->update($table, $new_data)) {
			return FALSE;
		}
		
		$filters = array(
			'id' => $id,
		);
		return $this->_get($filters);
	}
	
	private function _insert($new_data) {
		$table = $this->table;
		
		if( ! $this->db->insert($table, $new_data)) {
			return FALSE;
		}
		
		$id = $this->db->insert_id();
		$filters = array(
			'id' => $id,
		);
		return $this->_get($filters);
	}
	
	private function _get_where($filters) {
		$table = $this->table;
		
		$this->db->where($filters);
		if( ! $check = $this->db->get($table)) {
			return FALSE;
		}
		if($check->num_rows() <= 0) {
			return FALSE;
		}
		return $check->result();
	}
	
	# ------------------------------------------------------------------
	# Utility functions
	# ------------------------------------------------------------------
	
	
	
}
