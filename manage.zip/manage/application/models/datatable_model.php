<?php 
class Datatable_model extends CI_Model  {
    
    protected $username ;
    public $column_search = array();
    public $column_order = array();
    

    public function __construct()
    {
        parent::__construct();
        $this->username = $this->session->zap_username;
        $this->table = "products";
    }

    public function _query_for_products()
    {        
        $this->column_order = array('p.name','p.code','sk.size','sk.stock','sk.price_inr','sk.price_usd','sk.stock', 'pc.name'); 
        // $this->column_order = array(null, 'p.id','p.name','p.code','pc.name','sk.size','sk.price_inr','sk.price_usd','sk.stock'); 
        $this->column_search = array('p.name','p.code','pc.name','sk.size','sk.price_inr','sk.price_usd','sk.stock', 'pc.name');        
        $this->db->select('p.id as id,p.name as name,p.code as code,pc.name as cat_name,sk.size as size,sk.price_inr as price_inr,sk.price_usd as price_usd,sk.stock as stock');      
        $this->db->from('products p');        
        $this->db->join('categories pc', 'p.cat_id = pc.id');
        $this->db->join('skus sk', 'p.id = sk.product_id');
        // $this->db->group_by('p.id');


     
    }

    
    private function _get_datatables_query()
    {  
        $this->_query_for_products();
        $filter = $this->input->post();
     
        if($filter['prd_category'] != '')
        {
          $result_array=$this->get_parent_cat_id($this->input->post('prd_category'));
            $this->db->where_in('p.cat_id',  $result_array,false);        
        } 

        $this->db->where('sk.stock >', '0');       


     
        $i = 0;
     
         if (isset($this->column_search)) {         
         
            foreach ($this->column_search as $item) // loop column 
            {
                if(isset($_POST['search']['value']) && $_POST['search']['value'] != '') // if datatable send POST for search
                {                 
                    if($i===0) // first loop
                    {
                        // $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                        $this->db->like($item, $_POST['search']['value']);
                    }
                    else
                    {
                        $this->db->or_like($item, $_POST['search']['value']);
                    }
     
                    if(count($this->column_search) - 1 == $i) //last loop
                    {
                        // $this->db->group_end(); //close bracket
                    }
                }
                $i++;
            }
         }
         
        if(isset($_POST['order'])) // here order processing
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } 
        else if(isset($this->order))
        {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }

     $this->db->order_by('p.code asc, sk.stock desc');



    }
 
    function get_datatables($table='products')
    {
        $this->table = $table;    
     
        $this->_get_datatables_query();

        if(isset($_POST['length']) && $_POST['length'] != -1)       
        $this->db->limit($_POST['length'], $_POST['start']);

        $query = $this->db->get();

        error_log("Query:".$this->db->last_query());

        return $query->result();
    }

    public function get_filtered_data()
    {
        $this->table = 'products';
        $this->_get_datatables_query();
        $query = $this->db->get();

        return $query->result();
    }

    public function get_data()
    {
        $this->table = 'products';
        $this->_query_for_blankcases();
        $query = $this->db->get();
        return $query->result();
    }
 
    function count_filtered()
    {
        //$this->table= 'products';
        $this->_get_datatables_query();
        $query = $this->db->get();        
        $q = $query->row();    
        //return $q->q;SUM was taken
       //old
       return $query->num_rows();
    }    
 
    public function count_all()
    {       
        $this->db->from($this->table);
        
        $result = $this->db->get();
        return $result->num_rows();  
    }   


     public function get_parent_cat_id($catid=false)
    {       
            $query = $this->db->query("SELECT id FROM `categories` where $catid in  (id,parent_id)");
      
            $result_array=array();


            foreach ($query->result() as $row)
            {
                $result_array[]=$row->id;
            }


 //error_log("Query2:".json_encode($result_array));
        if(count($result_array)>0)
        {
            $val=implode(",",$result_array);
        }
        else
        {
            $val=$result_array;
        }
         //error_log("Query3:".$val);
        return $result_array;
        exit;
    }
}

?>