<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_postalcodes extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'postalcodes';
	}
	
	public function get($id) {
		$table = $this->table;
		
		$result = $this->db->get_where($table, array(
			'id' => $id,
		));
		
		return $result;
	}

}
