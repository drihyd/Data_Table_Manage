<?php

defined('BASEPATH') OR exit();

class Lead_bank_model extends CI_Model {
	
	function __construct() {	
		parent::__construct();
		$this->table = 'lead_bank';
		
		$this->connection_scores = array(
			'unknown' => 1,
			'family' => 10,
			'shared_order' => 10,
			'partner' => 10,
			'sister' => 10,
			'brother' => 10,
			'friend' => 9,
			'co_worker' => 5,
			'same_locality' => 3,
		);
			
	}
	
	# ------------------------------------------------------------------
	# Interface functions
	# ------------------------------------------------------------------
	
	public function make_lead($email, $date) {
		
		if( ( ! $date )) {
			$date = date('Y-m-d H:i:s', time());
		}
		
		if($date == '0000-00-00 00:00:00') {
			$date = '2015-06-10 00:00:00';
		}
		
		if ( ! filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return FALSE;
        }
        
        $invalid_emails = array(
			'test@test.com',
			'abc@def.com',
			'123@test.com',
			'noreply@abc.com',
			'stupid@idiot.com',
			'123@123.com',
			'billgates@microsoft.com',
		);
		
		if(in_array($email, $invalid_emails)) {
			return FALSE;
		}
		
		if($duplicate = $this->_is_duplicate($email) ) {
			return $duplicate;
		}
		
		return $this->_create_lead($email, $date);			
		
	}
	
	public function make_connection($lead_id1, $lead_id2, $connection) {
		
		if($lead_id1 == $lead_id2) {
			return;
		}
		
		$connection_scores = $this->connection_scores;
		if( isset($connection_scores[$connection])) {
			$score = $connection_scores[$connection];
		} else {
			$score = 1;
		}
		
		$new_data = array(
			'lead_id' => $lead_id1,
			'connected_to_id' => $lead_id2,
			'relation' => $connection,
			'score' => $score,
		);
		
		$filters = array(
			'lead_id' => $lead_id1,
			'connected_to_id' => $lead_id2,
		);
		
		$this->load->model('Connection_model');
		$connection = $this->Connection_model->get($filters);
		if($connection) {
			$old_score = $connection->score;
			if($score > $old_score) {
				$this->Connection_model->update($connection->id, $new_data);
			}
		} else {
			$this->Connection_model->insert($new_data);
		}
		return;
	}
	
	public function update($id, $new_data) {
		
		if( ( ! $id) OR ((int)$id == '') ) {
			return FALSE;
		}
		
		if( ( ! $new_data) OR (empty($new_data)) ) {
			return FALSE;
		}
		
		$filters = array(
			'id' => $id,
		);
		
		if( ! $this->_get($filters)) {
			return FALSE;
		}
		
		return $this->_update($id, $new_data);
	}
	
	public function get_lead_by_id($id) {
		if( ( ! $id) OR ((int)$id == '') ) {
			return FALSE;
		}
		$filters = array(
			'id' => $id,
		);
		return $this->_get($filters);
	}
	
	public function get_connected_leads() {
		$result = $this->_get_connected_leads();
		if( ! $result) {
			return array();
		}
		return $result;
	}
	
	public function connection_already_exists($lead_id1, $lead_id2) {
		$table = 'connections';
		
		$filters = array(
			'lead_id' => $lead_id1,
			'connected_to_id' => $lead_id2,
		);
		
		$this->db->where($filters);
		
		if( ! $check = $this->db->get($table)) {
			return FALSE;
		}
		
		if($check->num_rows() > 0) {
			return TRUE;
		}
		
		return FALSE;
	}

	
	# ------------------------------------------------------------------
	# Base CRUD logic
	# ------------------------------------------------------------------
	
	private function _get($filters) {
		$table = $this->table;
		
		$this->db->where($filters);
		if( ! $check = $this->db->get($table)) {
			return FALSE;
		}
		if($check->num_rows() <= 0) {
			return FALSE;
		}
		return $check->row();
	}
	
	private function _insert($new_data) {
		$table = $this->table;
		
		if( ! $this->db->insert($table, $new_data)) {
			return FALSE;
		}
		
		$id = $this->db->insert_id();
		
		$filters = array(
			'id' => $id,
		);
		return $this->_get($filters);
	}
	
	private function _update($id, $new_data) {
		$table = $this->table;
		
		$filters = array(
			'id' => $id,
		);
		
		$this->db->where($filters);
		if( ! $this->db->update($table, $new_data)) {
			return FALSE;
		}
		
		$filters = array(
			'id' => $id,
		);
		return $this->_get($filters);
	} 
	
	# ------------------------------------------------------------------
	# Utility functions
	# ------------------------------------------------------------------
	
	private function _is_duplicate($email) {
		$filters = array(
			'email' => $email,
		);
		
		return $this->_get($filters);
	}
	
	private function _create_lead($email, $date) {
		
		$new_data = array(
			'email' => $email,
			'identified_on' => $date,
		);
		
		return $this->_insert($new_data);
	}
	
	private function _get_connected_leads() {
		$table = $this->table;
		
		$this->db->where('connections >', 0);
		if( ! $check = $this->db->get($table)) {
			return FALSE;
		}
		if($check->num_rows() <= 0) {
			return FALSE;
		}
		return $check->result();
	}
	
}
