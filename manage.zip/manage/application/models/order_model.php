<?php

defined('BASEPATH') OR exit();

class Order_model extends CI_Model {
	
	function __construct() {	
		parent::__construct();
		$this->table = 'orders';
	}
	
	# ------------------------------------------------------------------
	# Interface functions
	# ------------------------------------------------------------------
	
	public function get_billable_orders() {
		$result = $this->_get_billable_orders();
		if( ! $result) {
			return array();
		}
		return $result;
	}
	
	public function get_orders($filters) {
		if( ( ! $filters) OR (empty($filters)) ) {
			return FALSE;
		}
		
		$result = $this->_get_where($filters);
		if( ! $result) {
			return array();
		}
		return $result;
	}
	
	public function get_all_orders() {
		$result = $this->_get_all();
		if( ! $result) {
			return array();
		}
		return $result;
	}
	
	# ------------------------------------------------------------------
	# Base CRUD logic
	# ------------------------------------------------------------------
	
	private function _get_all() {
		$table = $this->table;
		
		$this->db->where('customer_id !=', 0);
		$this->db->where('total_items >', 0);
		$this->db->where('grand_total >', 0);
		
		if( ! $check = $this->db->get($table)) {
			return FALSE;
		}
		if($check->num_rows() <= 0) {
			return FALSE;
		}
		return $check->result();
	}
	
	private function _get_where($filters) {
		$table = $this->table;
		
		$this->db->where($filters);
		if( ! $check = $this->db->get($table)) {
			return FALSE;
		}
		if($check->num_rows() <= 0) {
			return FALSE;
		}
		return $check->result();
	}
	
	# ------------------------------------------------------------------
	# Utility functions
	# ------------------------------------------------------------------
	
	/**
	 * Get orders with valid number of items and grand total.
	 * 
	 * Only orders that are already dispactched or delivered are considered.
	 * 
	 * return mixed | Result object or FALSE boolean
	 */ 
	private function _get_billable_orders() {
		$table = $this->table;
		
		$this->db->where('customer_id !=', 0);
		$this->db->where('total_items >', 0);
		$this->db->where('grand_total >', 0);
		$this->db->where_in('order_status', array('dispatched', 'delivered'));
		
		if( ! $result = $this->db->get($table)) {
			return FALSE;
		}
		
		if($result->num_rows() <= 0) {
			return FALSE;
		}
		
		return $result->result();
	}
	
}
