<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order_averages_model extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'order_averages';
	}
	
	# --------------------------------------------------------------------------
	# Interface functions
	# --------------------------------------------------------------------------
	
	public function update_averages($total_orders, $total_revenue, $avg_order_value) {
		
		if( ($total_orders == '') OR ((int)$total_orders == '') ) {
			return FALSE;
		}
		
		if( ($total_revenue == '') OR ((int)$total_revenue == '') ) {
			return FALSE;
		}
		
		if( ($avg_order_value == '') OR ((int)$avg_order_value == '') ) {
			return FALSE;
		}
		
		return $this->_update_averages($total_orders, $total_revenue, $avg_order_value);
	}
	
	# --------------------------------------------------------------------------
	# Basic CRUD Logic
	# --------------------------------------------------------------------------
	
	private function _insert($new_data) {
		$table = $this->table;
		
		if( ! $this->db->insert($table, $new_data)) {
			return FALSE;
		}
		return TRUE;
	}
	
	# --------------------------------------------------------------------------
	# Utility functions
	# --------------------------------------------------------------------------
	
	private function _update_averages($total_orders, $total_revenue, $avg_order_value) {
		$new_data = array(
			'total_orders' => $total_orders,
			'total_revenue' => $total_revenue,
			'avg_order_value' => $avg_order_value,
			'date' => date('Y-m-d H:i:s', time()),
		);
		
		return $this->_insert($new_data);
	}

}
