<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_cart_items extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'cart_items';
	}
	
	public function get_cart_items($cart_id) {
		$table = $this->table;
		$this->db->where('cart_id', $cart_id);
		$result = $this->db->get('cart_items');
		return $result;
	}
	
}
