<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_products extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'products';
	}
	
	public function get($id) {
		$table = $this->table;
		
		$result = $this->db->get_where($table, array(
			'id' => $id,
		));
		
		return $result;
	}
	
	public function get_all() {
		$table = $this->table;
		
		$result = $this->db->get($table);
		
		return $result;
	}

}
