<?php
	ob_start();
	setlocale(LC_MONETARY, 'en_IN');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Checkout Your Cart</title>
</head>
<body style='font-family: Arial, sans-serif;background: #f4f4f4;color: #333;font-size: 12px;padding: 15px;'>
	<div class='container' style='padding: 30px 15px;font-family: Arial, sans-serif;max-width:480px;margin: 30px auto; background: #fff;color: #333;box-shadow:1px 2px 5px #888'>
		<img src="<?php echo $this->config->base_url().'img/logo.png'; ?>" width='100'>
		<br><br>
		<p style="font-size: 12px;line-height: 160%;">
			Hi <?php echo ucwords($cart_details_index[$cart_id]['name']); ?>,<br>
			You have <?php echo count($cart_items); ?> items in your Cart. Would you like to <a href="<?php echo $this->config->base_url().'../cart/checkout'; ?>" target="_blank" style="text-decoration: none;">checkout</a> ?
		</p>
		<table style="margin-top: 15px;">
<?php
foreach($cart_items as $item) {
	$sku_id = $item->sku_id;
	$product_id = $sku_index[$item->sku_id]->product_id; ?>
	
			<tr>
				<td style="width:60px;background:#ddd;"><img src="<?php echo $this->config->base_url().'../assets/uploads/'.$product_index[$product_id]->code.'_dp.jpg'; ?>" width="60"></td>
				<td>
					<p style="font-size: 12px;font-weight: bold;margin: 0;margin-bottom: 3px;">
						<?php echo ucwords($product_index[$product_id]->name); ?>
					</p>
					<p style="font-size: 10px;color; #888;margin: 0;margin-bottom: 5px;line-height: 160%;">
						Rs. <?php echo money_format('%!.2n', $item->unit_price); ?><br>
						Size: <?php echo strtoupper($sku_index[$sku_id]->size); ?>
					</p>
				</td>
			</tr>
<?php
} ?>
		</table>
		<a href="<?php echo $this->config->base_url().'../cart/checkout'; ?>" style="display: inline-block;background:#15C;color: #fff;padding: 6px 18px;text-decoration: none;margin: 15px 0;">Check Out</a>
		
		<div style="background:#eee;border: 1px solid #ddd;font-size: 12px;color: #888;padding: 9px;padding-bottom: 0px;margin-top: 15px;">
			<p style="font-weight: bold;margin:0;margin-bottom:9px;">Having Trouble?</p>
			<p style="margin: 0;">
				<a href="<?php echo $this->config->base_url().'../contact'; ?>" target="_blank" style="text-decoration: none;font-size: 12px;margin:3px 0;">I'm unable to checkout</a><br>
				<a href="<?php echo $this->config->base_url().'../contact'; ?>" target="_blank" style="text-decoration: none;font-size: 12px;margin: 3px 0;">I have some questions</a>
			</p>
			<p style="marign: 0;font-size: 10px;color: #aaa;">Click on the above links and write to us. Our team will help you out.</p>
		</div>
		 
	</div> <!-- ./container -->
</body>
</html>
<?php
	$message = ob_get_clean();
	echo $message;
	
	if($justsee == null) {
		$this->load->helper('email_helper');
		//send_email('admin@taruni.in', 'Taruni Admin', 'sashank@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'nsathyendra1991@gmail.com', 'Taruni Weekly Report', $message, '');
		//send_email('esales@taruni.in', 'Taruni Admin', 'sathyendra@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'ranjith@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'nabeel@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'santhan@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'priya@deepredink.com', 'Taruni Weekly Report', $message, '');
	}
?>
