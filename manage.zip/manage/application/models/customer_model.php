<?php

defined('BASEPATH') OR exit();

class Customer_model extends CI_Model {
	
	function __construct() {	
		parent::__construct();
		$this->table = 'customers';
	}
	
	# ------------------------------------------------------------------
	# Interface functions
	# ------------------------------------------------------------------
	
	public function get_all() {
		$result = $this->_get_all();
		if( ! $result) {
			return array();
		}
		return $result;
	}
	
	# ------------------------------------------------------------------
	# Base CRUD logic
	# ------------------------------------------------------------------
	
	private function _get_all() {
		$table = $this->table;
		if( ! $check = $this->db->get($table)) {
			return FALSE;
		}
		if($check->num_rows() <= 0) {
			return FALSE;
		}
		return $check->result();
	}
	
	# ------------------------------------------------------------------
	# Utility functions
	# ------------------------------------------------------------------
	
	
}
