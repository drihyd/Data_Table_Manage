<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_reorder_thresholds extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'reorder_thresholds';
		
		// alias => actual_field_name
		$this->fields = array(
			'reorder_threshold_id' 	=> 'id',
		);
	}
	
	// get all
	public function get_all() {
		$table = $this->table;
		
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get field names array
	 * --
	 * @param string $alias
	 * --
	 * @return string $actual_field_name
	 */
	public function get_field_name($alias) {
		$fields = $this->fields;	
		return $fields[$alias];
	}
	
	/**
	 * Get order by id
	 * --
	 * @param int $id
	 * --
	 * @return array $result
	 * --
	 */
	public function get($id) {
		$table = $this->table;
		
		$this->db->where('id', $id);
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get where -> custom field and value pair
	 * --
	 * @param string $field_name
	 * @param mixed $value
	 * --
	 * @return array $result
	 * --
	 */
	public function get_where($field_name, $value) {
		$table = $this->table;
		
		$this->db->where($field_name, $value);
		$result = $this->db->get($table);
		return $result;
	}
	
	/**
	 * Get where -> array of field and value pairs
	 * --
	 * @param array $field_value_pairs
	 * --
	 * @return array $result
	 */
	public function get_where_array($field_value_pairs) {
		$table = $this->table;
		
		foreach($field_value_pairs as $key => $value) {
			$this->db->where($key, $value);
		}
		$result = $this->db->get($table);
		return $result;
	}
	
	// Update
	function update($id, $new_data) {
		$table = $this->table;
		
		$this->db->where('id', $id);
		$this->db->update($table, $new_data);
		return true;
	}

}
