<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Static_page_seo_model extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'static_page_seo';
	}
	
	# --------------------------------------------------------------------------
	# INTERFACES
	# --------------------------------------------------------------------------
	
	public function get_all() {
		return $this->_get_all();
	}
	
	public function get_page_by_id($id) {
		if( ( ! $id) OR ((int)$id == '') ) {
			return FALSE;
		}
		$filters = array(
			'id' => $id,
		);
		return $this->_get($filters);
	}
	
	public function update_page($filters, $new_data) {
		if( ( ! $filters) OR (empty($filters)) ) {
			return FALSE;
		}
		
		if( ( ! $new_data) OR (empty($new_data)) ) {
			return FALSE;
		}
		
		if( ! $this->_get($filters)) {
			return FALSE;
		}
		
		return $this->_update($filters, $new_data);
	}
	
	# --------------------------------------------------------------------------
	# BASE CRUD LOGIC (ALL PRIVATE)
	# --------------------------------------------------------------------------
	
	private function _get_all() {
		$table = $this->table;
		if( ! $result = $this->db->get($table)) {
			return FALSE;
		}
		if($result->num_rows() <= 0) {
			return FALSE;
		}
		return $result->result();
	}
	
	private function _get($filters) {
		$table = $this->table;
		$this->db->where($filters);
		if( ! $result = $this->db->get($table)) {
			return FALSE;
		}
		if($result->num_rows() <= 0) {
			return FALSE;
		}
		return $result->row();
	}
	
	private function _update($filters, $new_data) {
		$table = $this->table;
		$this->db->where($filters);
		if( ! $this->db->update($table, $new_data)) {
			return FALSE;
		}
		return $this->_get($filters);
	}

}
