<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_customers extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'customers';
		
		// alias => actual_field_name
		$this->fields = array(
			'customer_registration_date' => 'date',
			'customer_is_guest' => 'is_guest',
			'customer_guest_email' => 'guest_email',
			'customer_email' => 'email',
		);
	}

	public function get_field_name($alias) {
		$fields = $this->fields;	
		return $fields[$alias];
	}
	
	public function get($id) {
		$table = $this->table;
		
		$this->db->where('id', $id);
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_all() {
		$table = $this->table;
		
		$this->db->order_by('id', 'desc');
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_where($field_name, $value) {
		$table = $this->table;
		
		$this->db->where($field_name, $value);
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_where_array($field_value_pairs) {
		$table = $this->table;
		
		foreach($field_value_pairs as $key => $value) {
			$this->db->where($key, $value);
		}
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_customer_email($id) {
		$table = $this->table;
		
		$customer = $this->db->get_where($table, array(
			'id' => $id,
		))->row();
		
		if($customer->is_guest == 1) {
			return $customer->guest_email;
		}
		return $customer->email;
	}
	
	public function get_customer_name($id) {
		$table = $this->table;
		
		$customer = $this->db->get_where($table, array(
			'id' => $id,
		))->row();
		
		return $customer->name;
	}

}
