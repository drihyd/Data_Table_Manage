<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_users extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'users';
	}
	
	/**
     * Return session array if logged in else return false
     * --
     * @return bool/array <false if not logged in or session data array>
     * --
     */
    function check_logged_in() {
       
        if ( ! $this->session->userdata('logged_in')) {
            return false;
        }
        return $this->session->userdata('logged_in');
    }
    
    /**
     * Logout the user
     *
     * @return bool
     */
    function logout() {
        $this->session->sess_destroy();
        return true;
    }

}
		
