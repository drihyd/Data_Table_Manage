<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_wishlists extends CI_Model {
	
	function __construct() {
		parent::__construct();
		$this->table = 'wishlists';
	}
	
	public function get_all($order_by=null) {
		$table = $this->table;
		
		if( ! $order_by) {
			$order_by = 'desc';
		}
		$this->db->order_by('id', $order_by);
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get($id) {
		$table = $this->table;
		
		$this->db->where('id', $id);
		$result = $this->db->get($table);
		return $result;
	}
	
	public function get_where($field_name, $value, $order_by=null) {
		$table = $this->table;
		
		if( ! $order_by) {
			$order_by = 'desc';
		}
		
		$this->db->order_by('id', $order_by);
		$this->db->where($field_name, $value);
		$result = $this->db->get($table);
		return $result;
	}

}
