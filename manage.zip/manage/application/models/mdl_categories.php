<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');
  
class Mdl_categories extends CI_Model {
  function __construct() {
    parent::__construct();
  }
  function get_table() {
    $table = "categories";
    return $table;
  }
  
  function get($order_by) {
    $table = $this->get_table();
    $this->db->order_by($order_by);
    $query = $this->db->get($table);
    return $query;
  }
  function get_with_limit($limit, $offset, $order_by) {
    $table = $this->get_table();
    $this->db->limit($limit, $offset);
    $this->db->order_by($order_by);
    $query = $this->db->get($table);
    return $query;
  }
  function get_where($id) {
    $table = $this->get_table();
    $this->db->where('id', $id);
    $query = $this->db->get($table);
    return $query;
  }
  function get_where_custom($col, $value) {
    $table = $this->get_table();
    $this->db->where($col, $value);
    $query = $this->db->get($table);
    return $query;
  }
  function _insert($data) {
    $table = $this->get_table();
    $this->db->insert($table, $data);
  }
  function _update($id, $data) {
    $table = $this->get_table();
    $this->db->where('id', $id);
    $this->db->update($table, $data);
  }
  function _delete($id) {
    $table = $this->get_table();
    $this->db->where('id', $id);
    $this->db->delete($table);
  }
  function count_where($column, $value) {
    $table = $this->get_table();
    $this->db->where($column, $value);
    $query    = $this->db->get($table);
    $num_rows = $query->num_rows();
    return $num_rows;
  }
  function count_all() {
    $table    = $this->get_table();
    $query    = $this->db->get($table);
    $num_rows = $query->num_rows();
    return $num_rows;
  }
  function get_max() {
    $table = $this->get_table();
    $this->db->select_max('id');
    $query = $this->db->get($table);
    $row   = $query->row();
    $id    = $row->id;
    return $id;
  }
  function _custom_query($mysql_query) {
    $query = $this->db->query($mysql_query);
    return $query;
  }

  function get_sizes_order($category)
  {
    $sizes = array();
    if ($category == 'kids-wear') {
        for ($i=24,$j=0; $i < 42; $i+=2,$j++) { 
                $sizes ['kid_'.$i] = $j;               
        }
    }elseif($category== 'accessories'){
            $sizes = array('free'=>0);
        }else{
      $sizes = array(
                "s"     => 0,
                "m"     => 1,
                "l"     => 2,
                "xl"    => 3,
                "xxl"   => 4,
                "xxxl"  => 5,
            );
    }

    return $sizes;


  }

    function get_size_columns($category)
    {
       $sizes =  $this->get_cat_sizes($category);

       $columns = array();

           foreach ($sizes as $key => $size) {
                $columns [] = $size.'_size_SKU_code';
                $columns [] = $size.'_size_SKU_stock';
                $columns [] = $size.'_size_SKU_price_inr';
                $columns [] = $size.'_size_SKU_price_usd';
           }

        return $columns;
       
    }

    function get_cat_sizes($category)
    {
         $sizes = array();
        if ($category== 'kids-wear') {            
            for ($i=24; $i < 42; $i+=2) { 
                $sizes [] = 'kid_'.$i;               
            }
            $sizes []='unstitched';

        }elseif($category== 'accessories'){
            $sizes = array('free');
        }else{

            $sizes = array( 's', 'm', 'l', 'xl', 'xxl', 'xxxl', 'unstitched');
        }
        return $sizes;
    }

    function get_size_variables($category)
    {
        $size_columns = $this->get_size_columns($category);
        $variables = array();

        foreach ($size_columns as $key => $column) {
            $variables[] = ${$column};
        }

        return $variables;
    }
}
