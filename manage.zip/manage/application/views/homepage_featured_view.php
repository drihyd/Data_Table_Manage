    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#discountimage" aria-controls="discountimage" role="tab" data-toggle="tab">Discount Image</a></li>
        <li role="presentation"><a href="#arrivalimage" aria-controls="arrivalimage" role="tab" data-toggle="tab">New Arrivals Image</a></li>
        <li role="presentation"><a href="#dealzoneimage" aria-controls="dealzoneimage" role="tab" data-toggle="tab">Deal Zone Image</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
 <?php
    echo $this->session->flashdata('form-after-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="discountimage">
                <?php echo validation_errors(); ?>
                <?php echo form_open_multipart('homepage_featured/discountImageSave', array('class' => 'edit-form')); ?>
                  <legend>Featured Discount Image</legend>
                    
<?php
    $images = glob(APPPATH . '../../assets/uploads/homepage_featured/'.'discount'.'_*');
    if(count($images) > 0) {
      foreach($images as $image) { ?>
                    <img src="<?php echo $image; ?>" class="img-responsive" alt="" title="">
<?php
        break;
      } ?>
                    <div class="form-group margin-top-15">
                      <label for="discountImage" class="control-label">Change Featured Image</label>
                      <small class="text-warning">Must be 700 X 700 px</small><br>
                      <input type="file" class="form-control input-sm" id="discountImage" name="discountImage">
                    </div>
                    <input type="hidden" name="editType" value="update">
<?php         
    } // end of if 
    else { ?>
                    <div class="form-group margin-top-15">
                      <label for="discountImage" class="control-label">Add Display Image</label>
                      <input type="file" class="form-control input-sm" id="discountImage" name="discountImage">
                    </div>
<?php
    } ?>              
                  
                  <div class="form-group">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'dashboard' ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#discountimage tab end-->
              
              <div role="tabpanel" class="tab-pane" id="arrivalimage">
                <?php echo validation_errors(); ?>
                <?php echo form_open_multipart('homepage_featured/arrivalImageSave', array('class' => 'edit-form')); ?>
                  <legend>New Arrivals Image</legend>
                    
<?php
    $images = glob(APPPATH . '../../assets/uploads/homepage_featured/'.'arrival'.'_*');
    if(count($images) > 0) {
      foreach($images as $image) { ?>
                    <img src="<?php echo $image; ?>" class="img-responsive" alt="" title="">
<?php
        break;
      } ?>                    
                    <div class="form-group margin-top-15">
                      <label for="arrivalImage" class="control-label">Change Image</label>
                      <small class="text-warning">Must be 700 X 700 px</small><br>
                      <input type="file" class="form-control input-sm" id="arrivalImage" name="arrivalImage">
                    </div>
    <?php         } // end of if 
                  else { ?>
                    <div class="form-group margin-top-15">
                      <label for="arrivalImage" class="control-label">Add Display Image</label>
                      <input type="file" class="form-control input-sm" id="arrivalImage" name="arrivalImage">
                    </div>
    <?php         } ?>              
                  
                  <div class="form-group">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'dashboard' ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#arrivalimage tab end-->
              
              <div role="tabpanel" class="tab-pane" id="dealzoneimage">
                <?php echo validation_errors(); ?>
                <?php echo form_open_multipart('homepage_featured/dealzoneImageSave', array('class' => 'edit-form')); ?>
                  <legend>New Arrivals Image</legend>
                    
<?php
    $images = glob(APPPATH . '../../assets/uploads/homepage_featured/'.'dealzone'.'_*');
    if(count($images) > 0) {
      foreach($images as $image) { ?>
                    <img src="<?php echo $image; ?>" class="img-responsive" alt="" title="">
<?php
        break;
      } ?>                    <div class="form-group margin-top-15">
                      <label for="dealzoneImage" class="control-label">Change Image</label>
                      <small class="text-warning">Must be 700 X 700 px</small><br>
                      <input type="file" class="form-control input-sm" id="dealzoneImage" name="dealzoneImage">
                    </div>
    <?php         } // end of if 
                  else { ?>
                    <div class="form-group margin-top-15">
                      <label for="dealzoneImage" class="control-label">Add Display Image</label>
                      <input type="file" class="form-control input-sm" id="dealzoneImage" name="dealzoneImage">
                    </div>
    <?php         } ?>              
                  
                  <div class="form-group">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'dashboard' ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#dealzoneimage tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
