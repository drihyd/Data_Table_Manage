
    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#discountimage" aria-controls="discountimage" role="tab" data-toggle="tab">Uploaded</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <div class="tab-content">
 <?php
    echo $this->session->flashdata('form-after-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="discountimage">
<?php            
if( (isset($names)) && (is_array($names)) && (count($names) > 0) ) { ?>
                  <div class="alert alert-success"><?php echo count($names); ?> Images Uploaded Successfully</div>
<?php
} ?>

<?php
if( (isset($error_names)) && (count($error_names) > 0) ) { ?>
                <div class="alert alert-danger">Following files could not be uploaded.<br>
                  <ol class="">
<?php
  foreach($error_names as $name) { ?>
                    <li><?php echo $name; ?></li>
<?php
  }
} ?>
                  </ol>
                </div>
<?php            
if( (isset($names)) && (is_array($names)) && (count($names) > 0) ) { ?>
                  <ul class="list-inline">
<?php
  foreach($names as $name) { ?>
                  
                    <li>
                      <img src="<?php echo $this->config->base_url().'../assets/uploads/'.$name; ?>" class="img-responsive" style="max-width: 120px;">
                    </li>
                  
<?php
  } ?>
                  </ul> 
<?php
} ?>
                </div>
              </div> <!-- ./#discountimage tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
