<div class="sub-header">Manage News</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'news/add'; ?>" class="btn btn-brand btn-sm">New News-item +</a>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table table-sort table-sort-search table-sort-show-search-count">
                <thead>
                  <tr>
                    <th class="table-sort">Title</th>
                    <th>Slug</th>
                    <th class="table-sort">Content</th>
                    <th>Date</th>
                    <th width="100px">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  
<?php if($news) {
        foreach ($news as $news_item) { ?>
                  <tr>
                    <td><?php echo ucfirst($news_item['title']); ?></td>
                    <td><?php echo ucfirst($news_item['slug']); ?></td>
                    <td><?php echo substr(ucfirst($news_item['content']), 0, 70).'...'; ?></td>
                    <td><?php echo $news_item['date']; ?></td>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'news/edit/'.$news_item['id']; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'news/delete/'.$news_item['id']; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop
      } //end of if 
      else {  ?>                  
                  <tr align='center'>
                    <td colspan=7><a href="<?php echo $this->config->base_url().'news/add'; ?>" class="btn btn-default btn-sm">Start adding news +</a></td>
                  </tr
<?php } // end of else ?>                  
                </tbody>
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
