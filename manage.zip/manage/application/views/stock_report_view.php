<?php
date_default_timezone_set("Asia/Kolkata");
?>
<section class="stats-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12">
				
				<table class="table dataTable dataTableExt orders-table">
					<thead>						
						<tr>
							<th>Product</th>
							<th>Code</th>
							<th>Added (days ago)</th>
							<th>Last Modified (days ago)</th>
							<th>Last Sale (days ago)</th>
							<th>Sold Pieces</th>
							<th>Left in Stock</th>
						</tr>
					</thead>
					<tbody>
<?php
$slow_products = array();
$slow_product_index = array();
foreach($products as $product) {
	
	$product_id = $product->id;
	$stock_age = $stock_log_index[$product_id];
	
	$now = time();
	$added_date = date('Y-m-d', strtotime($stock_age->added_date));
	$your_date = strtotime($added_date);
	$datediff = $now - $your_date;
	$days = floor($datediff/(60*60*24));
	$added_days = $days;
	
	if($stock_age->modified_date == '0000-00-00 00:00:00') {
		$modified_days = '-';
	} else {
		$now = time();
		$modified_date = date('Y-m-d', strtotime($stock_age->modified_date));
		$your_date = strtotime($modified_date);
		$datediff = $now - $your_date;
		$days = floor($datediff/(60*60*24));
		$modified_days = $days;
	}
	
	$now = time();
	
	if(isset($last_sale_index[$product_id])) {
		$last_sale_date = $last_sale_index[$product_id];
		$last_sale_date = date('Y-m-d', strtotime($last_sale_date));
		$your_date = strtotime($last_sale_date);
		$datediff = $now - $your_date;
		$days = floor($datediff/(60*60*24));
		$last_sale_days = $days;
	} else {
		$last_sale_days = '-';
	}
	
	if($modified_days != '-') {
		$reference_days = $modified_days;
	} else {
		$reference_days = $added_days;
	}
	
	if( ($reference_days >= 15) AND ($last_sale_days >= 15) ) {
		array_push($slow_products, $product);
		if($last_sale_days == '-') {
			$slow_product_index[$product->id] = 'Never';
		} else {
			$slow_product_index[$product->id] = $last_sale_days;
		}
	}
	
?>
	
						<tr class="<?php if($sale_index[$product_id] <= 0) echo 'danger'; ?>">
							<td><a href="<?php echo $this->config->base_url().'products/product_info/' . $product_id; ?>" target="_blank"><?php echo ucwords($product->name); ?></a></td>
							<td><a href="<?php echo $this->config->base_url().'products/product_info/' . $product_id; ?>" target="_blank"><?php echo ucwords($product->code); ?></a></td>
							<td><?php echo $added_days; ?></td>
							<td><?php echo $modified_days; ?></td>
							<td><?php echo $last_sale_days; ?></td>
							<td><?php echo $sale_index[$product_id]; ?></td>
							<td><?php echo $stock_index[$product_id]; ?></td>

						</tr>
<?php
} ?>
					</tbody>
				</table>
			</div>
        </div>
		
	</div>
</section>

<?php
if( (count($slow_products) > 0) AND ($email_report == 1) ) {
ob_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Taruni Stock Report</title>
</head>
<body style="font-family:Arial, sans-serif;font-size:13px;color:#000;background: #f4f4f4;line-height:1.5;padding: 15px;">
	<div style="background: #fff;max-width:550px;display: block;margin: 15px auto;padding: 30px;border-bottom: 6px solid #000;">
		<img src="http://taruni.in/manage/img/logo.png" alt="Taruni Admin" title="Taruni Admin" width="90" style="display: block;margin-bottom:30px;">
		<h1 style="font-size: 21px;display:block;margin-bottom: 0;">Slow Products<br></h1>
		<p style="font-size: 12px; color: #888;margin: 0 0 6px;"><?php echo date('M d, Y', time()); ?></p>
		<div style="font-size: 13px;color: #333;display:block;margin: 15px 0 15px;">
<?php
$i = 0;
foreach($slow_products as $slow_product) {
	if($i < 5)  { ?>
			<p><strong><a href="<?php echo $this->config->base_url().'products/product_info/' . $slow_product->id; ?>" target="_blank"><?php echo ucwords($slow_product->name); ?></a>: </strong>Last order(days ago) - <?php echo $slow_product_index[$slow_product->id]; ?></p>
<?php
	} else {
		break;
	}
	$i += 1;
} ?>
			.<br>
			.<br>
			.<br>
			<br>
			<p><a href="<?php echo $this->config->base_url().'stock_reports'; ?>" target="_blank" style="display: inline-block;padding:9px 15px;background:#2196F3;color:#fff;text-decoration: none;font-weight: bold;">View Full Stock Report</a></p>
		</div>
		<p style="margin-bottom: 0px;">Thanks,<br><strong>Admin</strong></p>
	</div>
</body>
</html>

<?php
$message = ob_get_clean();

$from = 'admin@taruni.in';
$from_name = 'Taruni Admin';
$to = 'sathyendra@deepredink.com';
$to_name = 'sathyendra nagulapalli';
$subject = 'Stock Report';
$message = $message;
$plain_text_message = '';
$cc_emails = array(
	'hari@deepredink.com' => 'Hari Lahari',
	'ranjith@deepredink.com' => 'Ranjith Ramanujam',
);
$cc_emails = null;
send_improved_email($from, $from_name, $to, $to_name, $subject, $message, '', $cc_emails);

} ?>
