<div class="sub-header">Manage Shipping Rates</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'shipping_rates/add'; ?>" class="btn btn-default btn-sm">New Shipping Rate +</a>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 margin-top-15">
            
<?php
    echo $this->session->flashdata('form-after-message');
?>  
              <table class="table dataTableNoSort">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Rate (per KG)</th>
                    <th width="100px">Actions</th>
                  </tr>
                </thead>
                
                  
<?php if( count($shipping_rates) > 0 ) { ?>
                <tbody>
<?php
        foreach ($shipping_rates as $shipping_rate) { ?>
                  <tr>  
                    <td><?php echo ucwords($shipping_rate->name); ?></td>
                    <td><?php echo 'Rs. '.$shipping_rate->inr_rate; ?></td>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'shipping_rates/edit/'.$shipping_rate->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'shipping_rates/delete/'.$shipping_rate->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop ?>
                </tbody>
<?php
      } //end of if 
      else {  ?>  
                <tfoot>                
                  <tr align='center'>
                    <td colspan="6"><a href="<?php echo $this->config->base_url().'shipping_rates/add/'.$shipping_rates->id; ?>" class="btn btn-default">Start adding Shipping Rates +</a></td>
                  </tr>
                </tfoot>
<?php } // end of else ?>                  
                
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
