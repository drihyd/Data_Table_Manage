    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
 <?php
    echo $this->session->flashdata('form-after-message');
    echo $this->session->flashdata('discount-success-message');
    echo $this->session->flashdata('discount-error-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>
                <?php echo form_open('discounts/save/', array('class' => 'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="discountName" class="control-label">Name</label>
                    <input type="text" class="form-control input-sm nameForSlug" id="discountName" name="discountName" value="">
                  </div>
                  <div class="form-group inline">
                    <label for="discountSlug" class="control-label">Slug</label>
                    <input type="text" class="form-control input-sm slugForName" id="discountSlug" name="discountSlug" value="">
                  </div>
                  <div class="form-group inline">
                    <label for="discountPercentage" class="control-label">Discount Percentage</label>
                    <input type="text" class="form-control input-sm" id="discountPercentage" name="discountPercentage" value="">
                  </div><br>
                  <div class="form-group inline">
                    <label for="discountValidFrom" class="control-label">Valid From Date</label>
                    <input type="date" class="form-control input-sm" id="discountValidFrom" name="discountValidFrom" value="">
                  </div>
                  <div class="form-group inline">
                    <label for="discountValidFromTime" class="control-label">Valid From Time</label>
                    <input type="time" class="form-control input-sm" id="discountValidFromTime" name="discountValidFromTime" value="00:00">
                  </div>
                  <div class="form-group inline">
                    <label for="discountValidTill" class="control-label">Valid Till Date</label>
                    <input type="date" class="form-control input-sm" id="discountValidTill" name="discountValidTill" value="">
                  </div>
                  <div class="form-group inline">
                    <label for="discountValidTillTime" class="control-label">Valid Till Time</label>
                    <input type="time" class="form-control input-sm" id="discountValidTillTime" name="discountValidTillTime" value="00:00">
                  </div>
                  <div class="form-group">
                    <label for="discountDesc" class="control-label">Description</label>
                    <textarea id="discountDesc" name="discountDesc" style="max-width: 100%;min-width;100%;" class="form-control input-sm"></textarea>
                  </div>

                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'discounts'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#basicinfo tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
          <div class="col-sm-6">
        
              
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
