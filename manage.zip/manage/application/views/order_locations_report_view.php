<section class="stats-section">
	<div class="container-fluid">
		<div class="row">
            <div class="col-sm-12">
				
                <?php echo $this->session->flashdata('form_errors'); ?>
				<?php echo form_open('order_location_report', array('method' => 'GET', 'class' => 'edit-form clearfix inline')) ?>
                    
                    <div class="form-group inline one-third">
                      <label for="from">From</label>
                      <input type="date" class="form-control input-sm" name="from" value="<?php echo $get_from_date; ?>">
                    </div>
                    
                    <div class="form-group inline one-third">
                      <label for="from">To</label>
                      <input type="date" class="form-control input-sm" name="to" value="<?php echo $get_to_date; ?>">
                    </div>
                      
                    <div class='form-group inline'>
                      <input type="submit" class="btn btn-brand btn-wide" value="Filter">&nbsp; &nbsp; 
                      <a href="<?php echo $this->config->base_url().'order_location_report'; ?>">Reset Filters</a>
                    </div>
                </form>

<?php
if(count($orders) <= 0) {
	echo "<div class='alert alert-danger'>No Orders recieved in the selected time period.</div>";
}
?>                
            </div>
        </div>
        <!-- /.row -->
        
        <div class="row">
			<div class="col-xs-12">
				
				<table class="table">
					<thead>						
						<tr>
							<th>Type of Orders</th>
							<th>Number of Orders</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Domestic Orders Placed from Abroad</td>
							<td><?php echo $domestic_orders_with_foreign_origin; ?></td>
						</tr>
						<tr>
							<td>Foreign Orders Placed from India</td>
							<td><?php echo $foreign_orders_with_domestic_origin; ?></td>
						</tr>
						<tr>
							<td>Domestic Orders placed from India</td>
							<td><?php echo $domestic_orders_with_domestic_origin; ?></td>
						</tr>
						<tr>
							<td>Foreign Orders Placed from Abroad</td>
							<td><?php echo $foreign_orders_with_foreign_origin; ?></td>
						</tr>
						<tr>
							<td>Domestic Orders Placed from Unknown Origin</td>
							<td><?php echo $domestic_orders_from_unknown_origin; ?></td>
						</tr>
						<tr>
							<td>Foreign Orders Placed from Unknown Origin</td>
							<td><?php echo $foreign_orders_from_unknown_origin; ?></td>
						</tr>
					</tbody>
				</table>
				
				<br>
				<h2>Top Foreign Locations that place domestic Orders:</h2>
				<table class="table">
					<thead>						
						<tr>
							<th>Origin</th>
							<th>Number of Orders</th>
						</tr>
					</thead>
					<tbody>
<?php
if( (! empty($foreign_origins_with_domestic_orders))) {
	foreach($foreign_origins_with_domestic_orders as $country => $num) { ?>
						<tr>
							<td><?php echo ucwords($country); ?></td>
							<td><?php echo $num; ?></td>
						</tr>
<?php
	} ?>
<?php
} else { ?>
						<tr>
							<td colspan="2">No Records!</td>
<?php
} ?>
						</tr>
					</tbody>
				</table>
				
				<br>
				<h2>Top Foreign Locations that place foreign orders:</h2>
				<table class="table">
					<thead>						
						<tr>
							<th>Origin</th>
							<th>Number of Orders</th>
						</tr>
					</thead>
					<tbody>
<?php
if( (! empty($foreign_origins_with_foreign_orders))) {
	foreach($foreign_origins_with_foreign_orders as $country => $num) { ?>
						<tr>
							<td><?php echo ucwords($country); ?></td>
							<td><?php echo $num; ?></td>
						</tr>
<?php
	} ?>
<?php
} else { ?>
						<tr>
							<td colspan="2">No Records!</td>
<?php
} ?>
						</tr>
					</tbody>
				</table>
			</div>
        </div>
		
	</div>
</section>




