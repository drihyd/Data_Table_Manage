<?php
date_default_timezone_set("Asia/Kolkata");
?>
<section class="stats-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12">
				
				<table class="table dataTable orders-table">
					<thead>						
						<tr>
							<th>Product</th>
							<th>Code</th>
							<th>Added (days ago)</th>
							<th>Last Modified (days ago)</th>
							<th>Sold Pieces</th>
							<th>Left in Stock</th>
						</tr>
					</thead>
					<tbody>
<?php
foreach($age_index as $key => $value) {
	
	$product_id = $key;
	$product_details = $details_index[$product_id];
	$age = $value; ?>		
						<tr class="<?php if($sale_index[$product_id] <= 0) echo 'danger'; ?>">
							<td><a href="<?php echo $this->config->base_url().'products/product_info/' . $product_details->id; ?>" target="_blank"><?php echo ucwords($product_details->name); ?></a></td>
							<td><a href="<?php echo $this->config->base_url().'products/product_info/' . $product_details->id; ?>" target="_blank"><?php echo ucwords($product_details->code); ?></a></td>
							<td><?php echo $age_index[$product_id]; ?></td>
<?php
	if($modified_index[$product_id] == '') { ?>
							<td>-</td>
<?php
	} else { ?>
							<td><?php echo $modified_index[$product_id]; ?></td>
<?php
	} ?>
							<td><?php echo $sale_index[$product_id]; ?></td>
							<td><?php echo $stock_index[$product_id]; ?></td>
						</tr>
<?php
} ?>
					</tbody>
				</table>
			</div>
        </div>
		
	</div>
</section>




