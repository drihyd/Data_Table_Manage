<section class="stats-section">
	<div class="container-fluid">
		<div class="row">
            <div class="col-sm-12">
				
                <?php echo $this->session->flashdata('form_errors'); ?>
				<?php echo form_open('color_report', array('method' => 'GET', 'class' => 'edit-form clearfix')) ?>
                    
                    <div class="form-group inline one-third">
                      <label for="from">From</label>
                      <input type="date" class="form-control input-sm" name="from" value="<?php echo $get_from_date; ?>">
                    </div>
                    
                    <div class="form-group inline one-third">
                      <label for="from">To</label>
                      <input type="date" class="form-control input-sm" name="to" value="<?php echo $get_to_date; ?>">
                    </div>
                      
                    <div class='form-group inline'>
                      <input type="submit" class="btn btn-brand btn-wide" value="Filter">&nbsp; &nbsp; 
                      <a href="<?php echo $this->config->base_url().'color_report'; ?>">Reset Filters</a>
                    </div>
                </form>
<?php
$order_colors_array = array(); 
$i = 0;
foreach ($top_order_colors as $key => $value) {
	$order_colors_array[$i] = ucwords($key) . ' - ' . $value;
	$i += 1;
	if($i >= 10) {
		BREAK;
	}
}
//print_r($order_colors_array);

$stock_colors_array = array(); 
$i = 0;
foreach ($top_stock_colors as $key => $value) {
	$stock_colors_array[$i] = ucwords($key) . ' - ' . $value;
	$i += 1;
	if($i >= 10) {
		BREAK;
	}
}
//print_r($stock_colors_array);

if(count($order_colors_array) <= 0) {
	echo "<div class='alert alert-danger'>No Orders recieved in the selected time period.</div>";
}
?>                
            </div>
        </div>
        <!-- /.row -->
        
        <div class="row">
			<div class="col-xs-12">
				<table class="table">
					<thead>
						<tr>
							<th>Top Colors in Stock</th>
							<th>Top Colors in Orders</th>
						</tr>
					</thead>
					<tbody>
<?php
$i = 0;
while ($i < 10) { ?>		
						<tr>
							<td><?php echo $stock_colors_array[$i]; ?></td>
							<td><?php echo $order_colors_array[$i]; ?></td>
						</tr>
<?php
	$i += 1;
} ?>
					</tbody>
				</table>
			</div>
        </div>
		
	</div>
</section>




