<?php
//date_default_timezone_set("Asia/Kolkata");
setlocale(LC_MONETARY, 'en_IN');
?>

<div class="sub-header">
	Foreign Orders from <strong><?php echo date('d M, Y', strtotime($from_date)); ?></strong> to <strong><?php echo date('d M, Y', strtotime($to_date)); ?></strong>
</div>

<section class="stats-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12">
				
				<form action="<?php echo $this->config->base_url().'foreign_orders'; ?>" method="get" style="display: block; margin: 0 auto; width: 240px; text-align: center;">
					<label>Select Month</label><br>
					<div class="form-group" style="display: inline-block; text-align: center;">
						<select class="form-control input-sm" name="month">
							<?php
							for($i = 1; $i < 13; $i++) { ?>
								<option value="<?php echo $i; ?>"><?php echo date('M', strtotime('01-' . $i . '-1979')); ?></option>
							<?php
							} ?>
						</select>
					</div>
					<div class="form-group" style="display: inline-block;">
						<select class="form-control input-sm" name="year">
							<option value="<?php echo date('Y', strtotime('last year')); ?>"><?php echo date('Y', strtotime('last year')); ?></option>
							<option value="<?php echo date('Y', strtotime('this year')); ?>" selected><?php echo date('Y', strtotime('this year')); ?></option>
						</select>
					</div>
					<div class="form-group" style="display: inline-block;">
						<input type="submit" class="form-control input-sm" value="Submit" style="display: inline-block;">
					</div>
				</form>
				<hr>
				<div class="">
					<span class="inline-block"><strong>Total Orders: </strong><?php echo $orders_this_month; ?></span> | 
					<span class="inline-block"><strong>Total Weight: </strong><?php echo $total_weight; ?> KGs</span> | 
					<span class="inline-block"><strong>Total Revenue: </strong>INR <?php echo money_format('%!.2n', $total_revenue); ?></span>
				</div>
				<hr>
				<div class="table-responsive">
					<table class="table dataTable">
						<thead>
							<th>Order ID</th>
							<th>Grand Total</th>
							<th>Items</th>
							<th width="200">Customer</th>
							<th>Payment</th>
							<th>Date</th>
							<th>Ship To</th>
							<th>Status</th>
							<th>Action</th>
						</thead>
<?php
if(count($orders) > 0) { ?>
						<tbody>
<?php
	foreach($orders as $order) { ?>
							
							<tr class="<?php echo str_replace(' ', '-', $order->order_status); ?>">
								<td>
									<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank"><?php echo $order->id; ?></a>
								</td>
								<td width="100px">Rs. <?php echo money_format('%!.2n', $order->grand_total); ?></td>
								<td><?php echo $order->total_items; ?></td>
								<td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order->customer_id; ?>" target="_blank"><?php echo ucwords($customer_index[$order->customer_id]->name); ?> (<?php echo $order->customer_id; ?>)</a></td>
								<td><?php echo $order->payment_status; ?> (<?php echo $payment_details_index[$order->id]; ?>)</td>
								<td><?php echo date('M d, Y', strtotime($order->ordered_on)); ?></td>
								<td>
									<?php echo ucwords($order->ship_to_country); ?>
									<?php if ($shipping_index[$order->id] == 'foreign') {
										echo " <span class='' style='color: inherit;line-height: 0;font-size: 18px;position: relative; bottom: -2px;'>&#9992;</span>";
									} ?>

									<?php if (isset($alterations_index[$order->id]) AND ($alterations_index[$order->id] == 1) ) {
										echo " <span class='alteration-ind' style='color: inherit;line-height: 0;font-size: 18px;position: relative; bottom: -2px;'>&#9986;</span>";
									} ?>
								</td>
								<td>
								<?php
									if($order->order_status == 'cancelled-refund-pending') {
										echo 'Refund-pending';
									} else {
										echo ucwords($order->order_status);
									} ?>
								</td>
								<td class="edit-column">
									<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
								</td>
							</tr>
<?php
	} ?>
						</tbody>
<?php
} ?>
					</table>
				</div>
																
			</div>
		</div>
	</div>
</section>


			

