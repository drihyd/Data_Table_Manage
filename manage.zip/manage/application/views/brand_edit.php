<div class="sub-header">Edit Brand</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open_multipart('brands/save/'.$brand_details['id']); ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="brandName" class="control-label">Name</label>
                <input type="text" class="form-control nameForSlug" id="brandName" name="brandName" value="<?php echo $brand_details['name']; ?>">
              </div>
              <div class="form-group inline">
                <label for="brandSlug" class="control-label">Slug</label>
                <input type="text" class="form-control slugForName" id="brandSlug" name="brandSlug" value="<?php echo $brand_details['slug']; ?>">
              </div>
              <legend>Logo</legend>
<?php         if($brand_details['logo']) { ?>
              <img src="<?php echo $this->config->base_url().'../assets/uploads/files/'.$brand_details['logo']; ?>" class="img-responsive" alt="" title="">
                
              <div class="form-group margin-top-15">
                <label for="brandLogoChange" class="control-label">Change Logo</label>
                  <small class="text-warning">Height must be 90 px</small><br>
                <input type="file" class="form-control" id="brandLogoChange" name="brandLogoChange">
              </div>
              <input type="hidden" name="editType" value="update">
<?php         } // end of if 
              else { ?>
              <div class="form-group margin-top-15">
                <label for="brandLogoChange" class="control-label">Add Logo</label>
                <input type="file" class="form-control" id="brandLogoChange" name="brandLogoChange" required>
              </div>
              <input type="hidden" name="editType" value="create">
<?php         } ?>              
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
          
          <div class="col-sm-6">
            
            <?php echo validation_errors(); ?>
            <?php echo form_open('brands/seosave/'.$brand_details['id']); ?>
              <legend>SEO Tags</legend>
              <div class="form-group inline">
                <label for="brandSeoTitle" class="control-label">Page Title</label>
                <input type="text" class="form-control" id="brandSeoTitle" name="brandSeoTitle" value="<?php echo ucfirst($brand_details['seo_title']); ?>">
              </div>
              <div class="form-group inline">
                <label for="brandSeoDesc" class="control-label">Page Description</label>
                <input type="text" class="form-control" id="brandSeoDesc" name="brandSeoDesc" value="<?php echo ucfirst($brand_details['seo_desc']); ?>">
              </div>
              <div class="form-group inline">
                <label for="brandSeoKeys" class="control-label">Page Keywords</label>
                <input type="text" class="form-control" id="brandSeoKeys" name="brandSeoKeys" value="<?php echo ucfirst($brand_details['seo_keywords']); ?>">
              </div>
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
