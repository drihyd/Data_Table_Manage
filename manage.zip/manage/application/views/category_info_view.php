  <div class="sub-header">Actions</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12">
            <a href="<?php echo $this->config->base_url().'categories'; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Back to All Categories</a> 
<?php
if( $category_details->parent_id == 0 ) { ?>            
            
            &nbsp;<a href="<?php echo $this->config->base_url().'categories/parentedit/'.$category_details->id; ?>" class="btn btn-warning btn-xs"><span class="glyphicon glyphicon-edit"></span> Edit</a> 
            &nbsp;<a href="<?php echo $this->config->base_url().'categories/parentdelete/'.$category_details->id; ?>" class="btn btn-danger btn-xs delete-confirm"><span class="glyphicon glyphicon-trash"></span> Delete</a>
<?php
} else { ?>
            &nbsp;<a href="<?php echo $this->config->base_url().'categories/edit/'.$category_details->id; ?>" class="btn btn-warning btn-xs"><span class="glyphicon glyphicon-edit"></span> Edit</a> 
            &nbsp;<a href="<?php echo $this->config->base_url().'categories/delete/'.$category_details->id; ?>" class="btn btn-danger btn-xs delete-confirm"><span class="glyphicon glyphicon-trash"></span> Delete</a>
<?php
} ?>
            
          </div>
        </div>
      </div> <!-- /#container-fluid -->
    </section>
  
  <div class="sub-header">Category Info</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <p>Name: <?php echo ucwords($category_details->name); ?></p>
            <p>Slug: <?php echo $category_details->slug; ?></p>
<?php
if( isset($parent_category_details) ) : ?>
            <p>Parent Category: <a href="<?php echo $this->config->base_url().'categories/category_info/'.$parent_category_details->id; ?>"><?php echo ucwords($parent_category_details->name); ?></a></p>
<?php
endif; ?>            
<?php
if($category_details->cat_image != '') { ?>
            <p>Display Image: <img src="<?php echo $this->config->base_url().'../assets/uploads/category_dps/'.$category_details->cat_image; ?>" style="margin: 5px 0;max-width: 100px" class="small-thumbnail"></p>
<?php
} else { ?>
            <p>Display Image: <img src="<?php echo $this->config->base_url().'img/Not_Available.jpg'; ?>" class="small-thumbnail"></p>
            
<?php
} ?>
            <p>Description: <?php echo ucfirst($category_details->desc); ?></p>
            <p>Shipping Weight: <?php echo $category_details->shipping_weight. ' Kg'; ?></p>
            <p>Position Score: <?php echo ucfirst($category_details->position_score); ?></p>
            <p>SEO Title: <?php echo $category_details->seo_title; ?></p>
            <p>SEO Description: <?php echo $category_details->seo_desc; ?></p>
            <p>SEO Keywords: <?php echo $category_details->seo_keywords; ?></p>
            <p>Applicable Attributes:  
<?php
if(count($applicable_attributes) > 0) {
    $attributes_string = array();
    foreach($applicable_attributes as $attribute) {
        if(isset($attribute_names[$attribute])) {
          array_push($attributes_string, $attribute_names[$attribute]);
        }
    }
    echo implode(', ', $attributes_string); 
}
else {
    echo "No attributes selected";
}
?>
           </p>
            
<?php
if( $category_details->parent_id == 0 ) { ?>            
            <a href="<?php echo $this->config->base_url().'categories/parentedit/'.$category_details->id; ?>" class="btn btn-warning btn-xs"><span class="glyphicon glyphicon-edit"></span> Edit Details</a>
<?php
} else { ?>
            <a href="<?php echo $this->config->base_url().'categories/edit/'.$category_details->id; ?>" class="btn btn-warning btn-xs"><span class="glyphicon glyphicon-edit"></span> Edit Details</a>
<?php
} ?>
          </div>
          <div class="col-sm-6">
<?php
if($category_details->parent_id == 0) : ?>            
            <p><a href='#sub-categories-section' class="stat-value"><?php echo count($sub_categories_list); ?></a> Sub-categories</p>
<?php
endif; ?>
            <p><a href='#sub-products-section' class="stat-value"><?php echo count($sub_products_list); ?></a> Products listed directly under this Category</p>           
                       
          </div>
        </div>
      </div>
    </section>


<?php
if( $category_details->parent_id == 0 ): ?>    
  <div class="sub-header" id="sub-categories-section">Sub Categories</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12">
            <a href="<?php echo $this->config->base_url().'categories/add_child/'.$category_details->id; ?>" class="btn btn-xs btn-default">+ Add Sub Category</a><br><br>
<?php
if(count($sub_categories_list) > 0) { ?>
            <div class="table-responsive">
              <table class="table dataTableNoSort table-striped table-bordered">
                <thead>
                  <tr>
                    <th>Category Name</th>
                    <th>Number of Products</th>
                    <th>Actions</th>
                  </tr>                  
                </thead>
                <tbody>
<?php
  foreach($sub_categories_list as $sub_category) { ?>
                  <tr>         
                    <td><a href="<?php echo $this->config->base_url().'categories/category_info/'.$sub_category->id; ?>"><?php echo ucwords($sub_category->name); ?></td>
                    <td><a href="<?php echo $this->config->base_url().'categories/category_info/'.$sub_category->id.'#sub-products-section'; ?>"><?php echo $category_product_count[$sub_category->id]; ?></a></td>
                    <td class="edit-column tiny-col">
                      <a href="<?php echo $this->config->base_url().'categories/edit/'.$sub_category->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'categories/delete/'.$sub_category->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php
  } // end of foreach loop
} // end of IF
else { ?>
                  <tr>
                    <td colspan="3"><div class="alert alert-info">There are no Sub Categories Listed under this Category</div></td>
                  </tr>
<?php
} // end of else ?>
                </tbody>
              </table>
            </div> <!-- ./table-responsive -->
          </div>
        </div>
      </div>
    </section>
<?php
endif; ?>

  <div class="sub-header" id="sub-products-section">Products</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12">
            <a href="<?php echo $this->config->base_url().'products/add_child/'.$category_details->id; ?>" class="btn btn-xs btn-default">+ Add a Product</a><br><br>
<?php
if(count($sub_products_list) > 0) { ?>
            <div class="table-responsive">
              <table class="table table-condensed dataTableNoSort table-striped table-bordered">
                <thead>
                  <tr>
                    <th></th>
                    <th>Product Name</th>
                    <th>Product Code</th>
                    <th>Category Name</th>
                    <th>Actions</th>
                  </tr>                  
                </thead>
                <tbody>
<?php
  foreach($sub_products_list as $product) { ?>
                  <tr>
<?php
$product_code = implode('_', explode(' ',$product->code));
$product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
if((is_array($product_images)) && (count(array_filter($product_images)) > 0)) {
  foreach($product_images as $image) {
      $dpImage = $this->config->base_url().$image;
      break;
  }
} else {
  $dpImage = $this->config->base_url().'img/Not_Available.jpg';
} ?>
                    <td style="width: 50px;" class="tiny-col"><img src="<?php echo $dpImage; ?>" class="small-thumbnail tiny-thumbnail"></td>                    
                    <td><a href="<?php echo $this->config->base_url().'products/product_info/'.$product->id; ?>"><?php echo ucwords($product->name); ?></a></td>
                    <td><?php echo ucwords($product->code); ?></td>
                    <td><a href="<?php echo $this->config->base_url().'categories/category_info/'.$product->cat_id; ?>"><?php echo ucwords($category_index[$product->cat_id]->name); ?></td>
                    <td class="edit-column tiny-col">
                      <a href="<?php echo $this->config->base_url().'products/edit/'.$product->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'products/delete/'.$product->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php
  } // end of foreach loop
} // end of IF
else { ?>
                  <tr>
                    <td colspan="3"><div class="alert alert-info">There are no Products Listed directly under this Category</div></td>
                  </tr>
<?php
} // end of else ?>
                </tbody>
              </table>
            </div> <!-- ./table-responsive -->
          </div>
        </div>
      </div>
    </section>  
  
    
</div>
<!-- /#main-content -->
