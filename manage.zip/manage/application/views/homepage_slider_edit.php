<div class="sub-header">Edit Slider</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <a href="<?php echo $this->config->base_url().'homepage_sliders/delete/'.$homepage_slider_details['id']; ?>" class="btn btn-danger btn-sm margin-top-15 delete-confirm"><b>Delete</b> this homepage_slider</a>
            <?php echo validation_errors(); ?>
            <?php echo form_open_multipart('homepage_sliders/save/'.$homepage_slider_details['id'], array('class' => 'margin-top-15')); ?>
              <legend>Basic Info</legend>
              <img src="<?php echo $this->config->base_url().'../assets/uploads/files/'.$homepage_slider_details['image']; ?>" class="img-responsive" alt="<?php echo $homepage_slider_details['caption']; ?>" title="<?php echo $homepage_slider_details['caption']; ?>">
              <div class="form-group margin-top-15">
                <label for="homepage_sliderImage" class="control-label">Change homepage_slider Image</label>
                <input type="file" class="form-control" id="homepage_sliderImage" name="homepage_sliderImage" value="">
              </div>
              <div class="form-group inline">
                <label for="homepage_sliderUrl" class="control-label">URL</label><p class="help-block" style="margin: 0 0 3px 5px; font-size: 12px;display: inline-block">URL should start with http://</p>
                <input type="text" class="form-control" id="homepage_sliderUrl" name="homepage_sliderUrl" value="<?php echo $homepage_slider_details['url']; ?>">
                
              </div>
              <div class="form-group inline">
                <label for="homepage_sliderCaption" class="control-label">Caption</label>
                <input type="text" class="form-control" id="homepage_sliderCaption" name="homepage_sliderCaption" value="<?php echo $homepage_slider_details['caption']; ?>">
              </div>
              
               
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
