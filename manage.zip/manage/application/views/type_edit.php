<div class="sub-header">Edit Type</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <a href="<?php echo $this->config->base_url().'types/delete/'.$type_details['id']; ?>" class="btn btn-danger btn-sm margin-top-15 delete-confirm"><b>Delete</b> this type</a>
            <?php echo validation_errors(); ?>
            <?php echo form_open('types/save/'.$type_details['id'], array('class' => 'margin-top-15')); ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="typeName" class="control-label">Name</label>
                <input type="text" class="form-control" id="typeName" name="typeName" value="<?php echo $type_details['name']; ?>">
              </div>
              <div class="form-group inline">
                <label for="typeParentCat" class="control-label">Parent Category</label>
                <select class="form-control" name="typeParentCat" id="typeParentCat" readonly>
                  <option value="<?php echo $category['id']; ?>" selected><?php echo ucfirst($category['name']); ?></option>
                </select>
              </div>
               
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
