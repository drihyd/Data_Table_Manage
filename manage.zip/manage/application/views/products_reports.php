<style type="text/css">
  .dataTables_length{

    margin-top:10px!important;
  }

</style>
<div class="sub-header">Manage Products</div>
    <section class="stats-section">
      <div class="container-fluid">
<!-- 
      	      <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'products/add'; ?>" class="btn btn-default btn-sm">New Product +</a>
          </div>
        </div> -->
        <div class="row">

          <div class="col-md-12">
              <form style="position: initial;margin-left: -15px;">          
              <div class="col-md-3">
              <b>Filter By: </b></p>
              <div class="form-group-sm">
              <select id='prd_category' name="prd_category" class="form-control">
              <option value="">-- All Category --</option>  
              <?php 
              foreach ($categories as $key => $value) { ?>
              <option value="<?php echo $categories[$key]->id;?>"><?php echo ucwords($categories[$key]->name);?></option>
              <?php  }
              ?>       
     
              </select>
              </div>
              </div>      
              </form>
          </div>
               <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top:10px;">
                <div class="x_panel">                 
                  <div class="x_content">     
                      <table id="product_listing_datatable" class="table dataTableNoSort" style="margin-top:10px;">
                      <thead>
                        <tr>  

                   
                          <th>Product Image</th>
                          <th>Product Name</th>
                          <th>Product Code</th>                         
                          <th>Size</th>
                          <th>Qty</th>
                          <th>Price (INR)</th>     
                          <th>Price (USD)</th>    
                           <th>Category</th>  
                           <th>Actions</th>        
                                            
                        </tr>
                      </thead>
                     
                    </table>                 

                  </div>
                </div>
              </div>

          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>
  </div>
