<div class="sub-header">Add and Edit</div>
<section class="white-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				<?php echo $this->session->flashdata('form_success'); ?>
				<?php echo $this->session->flashdata('form_errors'); ?>
				<?php echo form_open('recommend/add', array('class' => 'edit-form')) ?>
					<legend>Add New</legend>
					<div class="form-group">
						<label for="recomm-prod-codes">List the Product Codes</label>
						<textarea class="form-control input-sm" id="recomm-prod-codes" name="recomm-prod-codes" required placeholder="code1, code2, code3 ..."></textarea>
					</div>
					
					<div class="form-group">
						<input type="submit" class="btn btn-brand btn-wide btn-sm" value="submit">
					</div>
					
				</form>
			</div>
			<div class="col-sm-6">
				<div class="edit-form">
					<legend>Added Products</legend>
					<table class="table dataTable orders-table">
						<thead>
							<tr>
								<th>Product Name</th>
								<th width="10" style="width: 10px;">&nbsp;</th>
							</tr>
						</thead>
						<tbody>
<?php
if(count($products) > 0) {
	foreach($products as $product) { ?>
							<tr>
								<td>
									<a href="<?php echo $this->config->base_url() . 'products/product_info/' . $product->id; ?>" target="_blank">
										<?php echo ucwords($product->name); ?>
									</a>
								</td>
								<td class="edit-column"  width="10" style="width: 10px;">
									<a href="<?php echo $this->config->base_url() . 'recommend/delete/' . $product->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="text text-danger">remove</span></a>
								</td>
							</tr>
<?php
	}
} else { ?>
							<tr>
								<td colspan=2>Nothing to show. Start adding products+</td>
								<td></td>
							</tr>
<?php
} ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>
