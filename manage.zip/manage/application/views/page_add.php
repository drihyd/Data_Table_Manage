<div class="sub-header">Add Page</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
<?php
                      echo $this->session->flashdata('form-after-message');
?>              
            <?php echo validation_errors(); ?>
            <?php echo form_open('pages/save/', array('class' =>'edit-form')); ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="pageName" class="control-label">Name</label>
                <input type="text" class="form-control input-sm nameForSlug" id="pageName" name="pageName" value="" required>
              </div>
              <div class="form-group inline">
                <label for="pageSlug" class="control-label">Slug</label>
                <input type="text" class="form-control input-sm slugForName" id="pageSlug" name="pageSlug" value="" required>
              </div>
              <div class="form-group inline">
                <label for="pageTitle" class="control-label">Title</label>
                <input type="text" class="form-control input-sm" id="pageTitle" name="pageTitle" value="" required>
              </div>
              <div class="form-group">
                <label for="pageExcerpt" class="control-label">Excerpt</label>
                <textarea class="form-control input-sm" id="pageExcerpt" name="pageExcerpt" style="max-width: 100%;min-width;100%;" required></textarea>
              </div>
              <div class="form-group">
                <label for="pageContent" class="control-label">Content</label>
                <textarea class="form-control mce" id="pageContent" name="pageContent"></textarea>
              </div>
              <div class="form-group">
                <label for="pageKeywords" class="control-label">Keywords</label>
                <textarea class="form-control input-sm" id="pageKeywords" name="pageKeywords"></textarea>
              </div>
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'pages'; ?>" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
