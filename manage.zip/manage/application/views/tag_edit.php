    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
        <li role="presentation"><a href="#displaypic" aria-controls="displaypic" role="tab" data-toggle="tab">Display Picture</a></li>
        <li role="presentation"><a href="#seotags" aria-controls="seotags" role="tab" data-toggle="tab">SEO Tags</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
 <?php
    echo $this->session->flashdata('form-after-message');
    echo $this->session->flashdata('tag-success-message');
    echo $this->session->flashdata('tag-error-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>
                <?php echo form_open('tags/save/'.$tag_details->id, array('class' => 'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="tagName" class="control-label">Name</label>
                    <input type="text" class="form-control input-sm nameForSlug" id="tagName" name="tagName" value="<?php echo $tag_details->name; ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="tagSlug" class="control-label">Slug</label>
                    <input type="text" class="form-control input-sm slugForName" id="tagSlug" name="tagSlug" value="<?php echo $tag_details->slug; ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="tagPosScore" class="control-label">Position Score</label>
                    <input type="number" min="0" max="1000" class="form-control input-sm" id="tagPosScore" name="tagPosScore" value="<?php echo $tag_details->pos_score; ?>">
                  </div><br>
                  <div class="form-group">
                    <label for="tagProductsList" class="control-label">Tagged Products (enter product codes seperated by commas)</label>
                    <textarea class="form-control input-sm" name="tagProductsList" id="tagProductsList" style="width: 100%; max-width: 100%; min-height: 100px;"><?php echo implode(',', $tagged_product_codes); ?></textarea>
                  </div>
                  
                  <div class="form-group">
                    <label for="tagDesc" class="control-label">Description</label>
                    <textarea id="tagDesc" name="tagDesc" style="max-width: 100%;min-width;100%;" class="form-control input-sm"><?php echo $tag_details->desc; ?></textarea>
                  </div>

                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'tags'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#basicinfo tab end-->
              
              <div role="tabpanel" class="tab-pane" id="displaypic">
                <?php echo validation_errors(); ?>
                <?php echo form_open_multipart('tags/DPimageSave'.'/'.$tag_details->id, array('class' => 'edit-form')); ?>
                  <legend>Tag Display Picture</legend>
                    
<?php       
                if($tag_details->dp_image != '') { ?>
                  <img src="<?php echo $this->config->base_url().'../assets/uploads/'.$tag_details->dp_image; ?>" class="img-responsive" alt="" title="">
<?php
                } else { ?>
                  <img src="<?php echo $this->config->base_url().'img/Not_Available.jpg'; ?>" class="img-responsive" alt="" title="" style="max-width: 400px">
<?php
                } ?>
                  <div class="form-group margin-top-15">
                    <label for="tagDPChange" class="control-label">Change Display Picture</label>
                    <small class="text-warning">Must be 500 X 300 px</small><br>
                    <input type="file" class="form-control input-sm" id="tagDPChange" name="tagDPChange">
                  </div>
                  <input type="hidden" name="editType" value="update">                  
                  <input type="hidden" name="tagId" value="tagId">
                  <input type="hidden" name="imageId" value="imageId">
                  <div class="form-group">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'tags'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#displaypic tab end-->
              
              <div role="tabpanel" class="tab-pane" id="seotags">
                <?php echo validation_errors(); ?>
                <?php echo form_open('tags/seosave/'.$tag_details->id, array('class' => 'edit-form')); ?>
                  <legend>SEO Tags</legend>
                  <div class="form-group inline">
                    <label for="tagSeoTitle" class="control-label">Page Title</label>
                    <input type="text" class="form-control input-sm" id="tagSeoTitle" name="tagSeoTitle" value="<?php echo ucfirst($tag_details->seo_title); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="tagSeoDesc" class="control-label">Page Description</label>
                    <input type="text" class="form-control input-sm" id="tagSeoDesc" name="tagSeoDesc" value="<?php echo ucfirst($tag_details->seo_desc); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="tagSeoKeys" class="control-label">Page Keywords</label>
                    <input type="text" class="form-control input-sm" id="tagSeoKeys" name="tagSeoKeys" value="<?php echo ucfirst($tag_details->seo_keywords); ?>">
                  </div>
                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'tags'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#seotags tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
          <div class="col-sm-6">
            <div class="edit-form">
              
              <legend>Added Products List</legend>
              <div class="list-group">
<?php 
foreach($tagged_products as $product) {
  if(isset($products_info[$product->product_id])) { 
    $prod = $products_info[$product->product_id]; ?>
                <div class="list-group-item">
                  <strong><?php echo $prod->code; ?></strong> | <?php echo ucwords($prod->name); ?>
                </div>
<?php
  }
  else { ?>
                <div class="list-group-item danger">
                  Invalid / deleted product
                </div>
<?php
  } ?>

<?php    
} ?>
              </div>
            </div>
              
            </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
