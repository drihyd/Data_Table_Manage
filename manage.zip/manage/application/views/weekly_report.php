<?php
	ob_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Taruni Weekly Report</title>
</head>
<body style='font-family: Arial, sans-serif;background: #f4f4f4;color: #333;font-size: 12px;padding: 15px;'>
	<div class='container' style='padding: 30px 15px;font-family: Arial, sans-serif;width:360px;margin: 30px auto; background: #fff;color: #333;box-shadow:1px 2px 5px #888'>
		<h1 style='text-align: center;color: #000;font-weight: normal;font-size: 18px;'>Taruni Weekly Report</h1>
		<h2 style='font-weight:normal; font-size: 15px;color:#888;text-align:center;'><?php echo date('d F', strtotime($from_date)); ?> - <?php echo date('d F', strtotime($to_date)); ?></h2>
		<div style='text-align: center; margin: 30px 0 0;'>
			<div style='display: inline-block; width: 90px; background: #f4f4f4;padding: 9px;margin-bottom: 3px;text-align: center;'>
				<h3 style='margin: 0;'><?php echo $total_orders; ?></h3>
				<p style='margin: 0;'>Total Orders</p>
			</div>
			<div style='display: inline-block; width: 90px; background: #f4f4f4;padding: 9px;margin-bottom: 3px;text-align: center;'>
				<h3 style='margin: 0;'><?php echo $orders_this_month; ?></h3>
				<p style='margin: 0;'>Orders in <?php echo date('M', strtotime($from_date)); ?></p>
			</div>
			<div style='display: inline-block; width: 90px; background: #f4f4f4;padding: 9px;margin-bottom: 3px;text-align: center;'>
				<h3 style='margin: 0;'><?php echo number_format(floor( (($total_order_value/100000) * 100))/100, 2); ?> L</h3>
				<p style='margin: 0;'>Order Value</p>
			</div>
		</div>
		<div>
			<table style='width: 360px;margin: 15px auto;text-align: left;font-weight: normal;'>
				<tr>
					<th>Total Domestic Orders</th>
					<td><?php echo $total_domestic_orders; ?> <span style='color:#888;'>(<?php echo @round(($total_domestic_orders/$total_orders) * 100,2); ?>%)</span></td>
				</tr>
				<tr>
					<th>Total Foreign Orders</th>
					<td><?php echo $total_foreign_orders; ?> <span style='color:#888;'>(<?php echo @round(($total_foreign_orders/$total_orders) * 100, 2); ?>%)</span></td>
				</tr>
				<tr>
					<th>Total First Time Orders</th>
					<td><?php echo $total_first_time_orders; ?> <span style='color:#888;'>(<?php echo @round(($total_first_time_orders/$total_orders) * 100, 2); ?>%)</span></td>
				</tr>
				<tr>
					<th>Total Repeat Orders</th>
					<td><?php echo $total_repeat_orders; ?> <span style='color:#888;'>(<?php echo @round(($total_repeat_orders/$total_orders) * 100, 2); ?>%)</span></td>
				</tr>
				<tr>
					<th>Orders From New Customers</th>
					<td><?php echo $total_new_customer_orders; ?> <span style='color:#888;'>(<?php echo @round(($total_new_customer_orders/$total_orders) * 100, 2); ?>%)</span></td>
				</tr>
				<tr>
					<th>Total Guest Orders</th>
					<td><?php echo $total_guest_customer_orders; ?> <span style='color:#888;'>(<?php echo @round(($total_guest_customer_orders/$total_orders) * 100, 2); ?>%)</span></td>
				</tr>
			</table>
			<h3 style='color: #888;margin: 30px 0 0; text-align:center;'>Top Countries by Order Value</h3>
			<table style='width: 300px;margin: 10px auto;text-align: left;font-weight: normal;'>
				<thead style='background: #f4f4f4;'>
					<tr>
						<th>Country</th>
						<th>Orders</th>
						<th>Value</th>
					</tr>
				</thead>
				<tbody>
				
<?php
arsort($order_country_index);
foreach($order_country_index as $key => $value) { ?>				
					<tr>
						<th><?php echo ucwords($key); ?></th>
						<td><?php echo $value['number']; ?></td>
						<td><?php echo number_format(floor( (($value['value']/100000) * 100))/100, 2); ?> L</td>
					</tr>
<?php
} ?>
				</tbody>
			</table>
			
			<h3 style='color: #888;margin: 30px 0 0; text-align:center;'>Top Cities by Order Value</h3>
			<table style='width: 300px;margin: 10px auto;text-align: left;font-weight: normal;'>
				<thead style='background: #f4f4f4;'>
					<tr>
						<th>City</th>
						<th>Orders</th>
						<th>Value</th>
					</tr>
				</thead>
				<tbody>
				
<?php
arsort($order_city_index);
foreach($order_city_index as $key => $value) { ?>				
					<tr>
						<th><?php echo ucwords($key); ?> (<?php echo ucwords($value['country']); ?>)</th>
						<td><?php echo $value['number']; ?></td>
						<td><?php echo number_format(floor( (($value['value']/100000) * 100))/100, 2); ?> L</td>
					</tr>
<?php
} ?>
				</tbody>
			</table>
			
		</div>
		<hr>
		<div style='text-align: center; margin: 21px 0 0;'>
			<div style='display: inline-block; width: 90px; background: #f4f4f4;padding: 9px;text-align: center;'>
				<h3 style='margin: 0;'><?php echo $total_new_customers; ?></h3>
				<p style='margin: 0;'>New Customers</p>
			</div>
			<div style='display: inline-block; width: 100px; background: #f4f4f4;padding: 9px;text-align: center;'>
				<h3 style='margin: 0;'><?php echo $abandoned_carts; ?></h3>
				<p style='margin: 0;'>Abandoned Carts</p>
			</div>
		</div>
		<table style='width: 360px;margin: 15px auto;text-align: left;font-weight: normal;'>
			<tr>
				<th>Total Guest Customers</th>
				<td><?php echo $total_guest_customers; ?> <span style='color:#888;'>(<?php echo @round(($total_guest_customers/$total_new_customers) * 100, 2); ?>%)</span></td>
			</tr>
		</table>
		<hr>
		<h3 style='color: #888;margin: 21px 0 0; text-align:center;'>Top Categories by Order Value</h3>
		<table style='width: 300px;margin: 10px auto;text-align: left;font-weight: normal;'>
			<thead style='background: #f4f4f4;'>
				<tr>
					<th>Category</th>
					<th>Orders</th>
					<th>Value</th>
				</tr>
			</thead>
			<tbody>
			
<?php
arsort($item_category_index);
arsort($item_category_index);
foreach($item_category_index as $key => $value) {
	$category = $category_index[$key]; ?>			
				<tr>
					<th><?php echo ucwords($category['details']->name); ?></th>
					<td><?php echo $value['number']; ?></td>
					<td><?php echo number_format(floor( (($value['value']/100000) * 100))/100, 2); ?> L</td>
				</tr>
<?php
} ?>
			</tbody>
		</table>
		<hr>
		
		<h3 style='color: #888;margin: 21px 0 0; text-align:center;'>Category Stock Levels</h3>
		<table style='width: 300px;margin: 10px auto;text-align: left;font-weight: normal;'>
			<thead style='background: #f4f4f4;'>
				<tr>
					<th>Category</th>
					<th>S</th>
					<th>M</th>
					<th>L</th>
					<th>XL</th>
					<th>XXL</th>
					<th>XXXL</th>
					<th>Unst.</th>
				</tr>
			</thead>
			<tbody>
			
<?php
arsort($category_index);
foreach($category_index as $category) { ?>			
				<tr>
					<th><?php echo ucwords($category['details']->name); ?></th>
					<td><?php echo strtoupper($category['s']); ?></td>
					<td><?php echo strtoupper($category['m']); ?></td>
					<td><?php echo strtoupper($category['l']); ?></td>
					<td><?php echo strtoupper($category['xl']); ?></td>
					<td><?php echo strtoupper($category['xxl']); ?></td>
					<td><?php echo strtoupper($category['xxxl']); ?></td>
					<td><?php echo strtoupper($category['unstitched']); ?></td>
				</tr>
<?php
} ?>
			</tbody>
		</table>
		
	</div> <!-- ./container -->
</body>
</html>
<?php
	$message = ob_get_clean();
	echo $message;
	
	if($justsee == null) {
		$this->load->helper('email_helper');
		// send_email('admin@taruni.in', 'Taruni Admin', 'sashank@deepredink.com', 'Taruni Weekly Report', $message, '');
		// send_email('admin@taruni.in', 'Taruni Admin', 'deepti@deepredink.com', 'Taruni Weekly Report', $message, '');
		// send_email('admin@taruni.in', 'Taruni Admin', 'shreya@deepredink.com', 'Taruni Weekly Report', $message, '');
		// send_email('admin@taruni.in', 'Taruni Admin', 'rohit@deepredink.com', 'Taruni Weekly Report', $message, '');
		// send_email('admin@taruni.in', 'Taruni Admin', 'nsathyendra1991@gmail.com', 'Taruni Weekly Report', $message, '');
		send_email('admin@taruni.in', 'Taruni Admin', 'rajkumar@deepredink.com', 'Taruni Weekly Report', $message, '');
		send_email('admin@taruni.in', 'Taruni Admin', 'ranjith@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'nabeel@deepredink.com', 'Taruni Weekly Report', $message, '');
		// send_email('admin@taruni.in', 'Taruni Admin', 'santhan@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'gaurika@deepredink.com', 'Taruni Weekly Report', $message, '');
	}
?>
