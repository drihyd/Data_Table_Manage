<?php
setlocale(LC_MONETARY, 'en_IN');
?>
<div class="admin-tabs">
  <ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="<?php echo $this->config->base_url().'reports/index'; ?>">All Reports</a></li>
    <!-- li role="presentation"><a href="<?php echo $this->config->base_url().'orders/today'; ?>">Today's Orders</a></li>
    <li role="presentation"><a href="<?php echo $this->config->base_url().'orders/month'; ?>">Monthly</a></li>
    <li role="presentation"><a href="<?php echo $this->config->base_url().'orders/from_to'; ?>">From - To</a></li -->
  </ul>
</div>  


    <section class="stats-section">
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-xs-12 margin-top-15">
<?php
if( (isset($month)) && (isset($year)) ) { ?>
            <h1>Report for <?php echo date("M, Y", strtotime("{$year}-{$month}-01")); ?></h1>
<?php
} else {
	$year = date("y", time());
	$month = date("m", time()); ?>
	
            <h1>Report for <?php echo date("M, Y", time()); ?></h1>
<?php
} ?>           
			<form id="repDateForm" onsubmit="return mySubmitFunction()">
				<div class="form-group inline">
					<input type="month" class="form-control input-sm" id="reportDate" value="<?php echo date("Y-m", strtotime("{$year}-{$month}-01")); ?>" name="reportDate">
				</div>
				<div class="form-group inline">
					<button type="submit" class="btn btn-default bnt-sm">Submit</button> 
				</div>
			</form>
			
			<script>
				function mySubmitFunction(e) {
				  				  
				  var dateField = document.getElementById("reportDate");
				  var date = dateField.value;
				  var date = date.split('-');
				  var month = date[1];
				  var year = date[0];
				  
				  window.location = "<?php echo $this->config->base_url().'reports/index/'; ?>" + month + '-' + year;
				  
				  return false;
				}
			</script>
			
          </div>
        </div> <!-- /.row -->
        
        <div class="row margin-top-30">
            <div class="col-xs-12">
                
                <h2>Revenue</h2>
                
                <div style="display: inline-block; padding: 3px 7px; background: #f4f4f4;margin: 5px;">
                    <p>Total Revenue:
                        INR <?php echo money_format('%!.0n', $total_revenue); ?> <small>(dispatched/delivered/processing/placed)</small>
                    </p>
                </div>
                
                <hr>
                
                <h2>Orders</h2>
<?php
$order_status_possibilities = array('placed', 'processing', 'dispatched', 'on-hold', 'cancelled', 'delivered', 'cancelled-refund-pending', 'cancelled-refunded');

foreach($order_status_possibilities as $order_possibility) { ?>

                <div style="display: inline-block; padding: 3px 7px; background: #f4f4f4;margin: 5px;">
                    <p><?php echo ucwords(implode(' ', explode('-', $order_possibility))); ?>:
<?php
      if(isset($orders_status_num[$order_possibility])) { ?>                    
                    <?php echo $orders_status_num[$order_possibility]; ?>
<?php      
      } else { ?>
                    0
<?php 
      } ?>                        
                    </p>
                </div>
<?php
} ?>
                <hr>
                
                <h2>Top Performing Categories</h2><br>

<?php
arsort($orders_cat_num); ?>

                
                <table class="table dataTableNoSort">
                    <thead>
                        <tr>
                            <th>Ranking</th>
                            <th>Category</th>
                            <th align="right">Total Orders</th>
                            <th align="right">Total Quantity</th>
                            <th align="right">Total Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
<?php                        
$i = 1;
foreach($orders_cat_num as $key => $value) { ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><a href="<?php echo $this->config->base_url(). 'categories/category_info/'. $key; ?>"><?php echo ucwords($categories_list[$key]->name); ?></a></td>
                            <td align="right"><?php echo $value; ?></td>
                            <td align="right"><?php echo $cat_qty[$key]; ?></td>
                            <td align="right">Rs. <?php echo money_format('%!.0n', $cat_rev[$key]); ?></td>
                        </tr>
<?php
                        $i += 1;    
} ?>                
                    </tbody>
                </table>
                
                <hr>
                
                <h2>Top Performing Products</h2><br>

<?php
arsort($orders_product_num); ?>

                
                <table class="table dataTableNoSort">
                    <thead>
                        <tr>
                            <th>Ranking</th>
                            <th>Product</th>
                            <th align="right">Total Orders</th>
                            <th align="right">Total Quantity</th>
                            <th align="right">Total Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
<?php                        
$i = 1;
foreach($orders_product_num as $key => $value) { ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><a href="<?php echo $this->config->base_url(). 'products/product_info/'. $key; ?>"><?php echo ucwords($products_list[$key]->name); ?></a></td>
                            <td align="right"><?php echo $value; ?></td>
                            <td align="right"><?php echo $product_qty[$key]; ?></td>
                            <td align="right">Rs. <?php echo money_format('%!.0n', $product_rev[$key]); ?></td>
                        </tr>
<?php
                        $i += 1;    
} ?>                
                    </tbody>
                </table>
                
                
                <hr>
                
                <h2>Top Performing SKUs</h2><br>

<?php
arsort($orders_sku_num); ?>

                
                <table class="table dataTableNoSort">
                    <thead>
                        <tr>
                            <th>Ranking</th>
                            <th>SKU Code</th>
                            <th>Size</th>
                            <th>Product</th>
                            <th>Category</th>
                            <th align="right">Total Quantity</th>
                            <th align="right">Total Revenue</th>
                            <th>Stock</th>
                        </tr>
                    </thead>
                    <tbody>
<?php                        
$i = 1;
foreach($orders_sku_num as $key => $value) { ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><a href="<?php echo $this->config->base_url(). 'skus/sku_info/'. $key; ?>"><?php echo ucwords($skus_list[$key]->sku_code); ?></a></td>
                            <td><?php echo ucwords($skus_list[$key]->size); ?></td>
                            <td><a href="<?php echo $this->config->base_url(). 'products/product_info/'. $skus_list[$key]->product_id; ?>"><?php echo ucwords($products_list[$skus_list[$key]->product_id]->name); ?></a></td>
                            <td><a href="<?php echo $this->config->base_url(). 'categories/category_info/'. $categories_list[$products_list[$skus_list[$key]->product_id]->cat_id]->id; ?>"><?php echo ucwords($categories_list[$products_list[$skus_list[$key]->product_id]->cat_id]->name); ?></a></td>
                            <td align="right"><?php echo $sku_qty[$key]; ?></td>
                            <td align="right">Rs. <?php echo money_format('%!.0n', $sku_rev[$key]); ?></td>

<?php
if($skus_list[$key]->stock == 0) { ?>
                            <td style="background:#CB5555; color:#fff;">
<?php
} 
else if( ($skus_list[$key]->stock < 5) && ($skus_list[$key]->stock != 0) ) { ?>                            
                            <td class="danger">
<?php
} 
else { ?>
                            <td>
<?php
} ?>
                              <?php echo $skus_list[$key]->stock; ?></td>
                            </td>
                        </tr>
<?php
                        $i += 1;    
} ?>                
                    </tbody>
                </table>
                
                
            </div>
        </div>
        
      </div> <!-- /#container-fluid -->
    </section>
    
    
    
    
  </div>
  <!-- /#main-content -->
