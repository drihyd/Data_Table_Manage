<?php setlocale(LC_MONETARY, 'en_IN'); ?>
 <style>
     
    #sidebar-wrapper, header {
        display: none !important;
    }
    body {
        font-family: 'arial';
        font-size: 14px;
        padding-left: 0 !important;
    }
    th {
        text-align: left;
    }
    #invoiceBox {
        display: block;
        margin: 0 auto;
    }
    th {
        font-size: 12px;
        padding: 5px;
    }
    td {
        font-size: 12px;
    }
    #invoiceBox td {
        font-size: 12px;
        padding: 5px;
    }
    h1, h2 {
        margin: 0;
    }
    p { 
        margin: 0;
    }
    hr {
        margin: 10px 0;
    }
    tr.warning {
      background: lightgray;
    }
    @media print {
        #back-link {
            display: none;
        }
        #printInv {
            display: none;
        }
        .warning {
          background: lightgray;
        }
    }

</style>

	

    <section class="stats-section" id="invoiceBox">
      <div class="container-fluid">
		
		<div class="row">
			<div class="col-xs-12">
				<img src="<?php echo $this->config->base_url().'img/logo.png'; ?>" width="150">
			</div>
		</div>
        <br><br> 
        <div class="row">
          
          
          <div class="col-sm-6">
            
              <small>Ship to:</small><br>
              <b><?php echo ucwords($order_details->ship_to_name); ?></b>
              <p><?php echo $order_details->ship_to_address; ?><br>
              <?php echo ucwords($order_details->ship_to_city); ?>, <?php echo ucwords($order_details->ship_to_state); ?> <?php echo $order_details->ship_to_postalcode; ?><br>
              <?php echo ucwords($order_details->ship_to_country); ?></p>
              <p>Phone: <?php echo $order_details->ship_to_phone; ?></p>
<?php
if($order_details->ship_to_alt_phone != '') { ?>
			  <p>Alt. Phone: <?php echo $order_details->ship_to_alt_phone; ?></p>
<?php
} ?>
          </div>
          <br>
          <div class="col-sm-6">
            
              <small>Bill to:</small><br>
              <b><?php echo ucwords($order_details->bill_to_name); ?></b>
              <p><?php echo $order_details->bill_to_address; ?><br>
              <?php echo ucwords($order_details->bill_to_city); ?>, <?php echo ucwords($order_details->bill_to_state); ?> <?php echo $order_details->bill_to_postalcode; ?><br>
              <?php echo ucwords($order_details->bill_to_country); ?></p>
              <p>Phone: <?php echo $order_details->bill_to_phone; ?></p>
            
          </div>
        
        </div>
        <br>
        <hr>
        
        <div class="row">
            <div class="col-xs-12">
                <b>Order ID: <?php echo $order_details->id; ?></b>
            </div>
        </div>
        
        <hr>
        <br>
        
        <div class="row">
            <div class="col-xs-12">
                <strong>Payment Status - <?php echo ucwords($order_details->payment_status); ?></strong>
<?php
if($order_details->payment_mode == 'cod') { ?>
                <br><strong>Cash On Delivery</strong>
<?php
} else {
	
	if($payment_details->paypal_payer_id != '') { ?>
				<br><strong>Payment Mode: PayPal [<?php echo $payment_details->transaction_id; ?>]</strong>
<?php
	} else { ?>
				<br><strong>Payment Mode: EBS [<?php echo $payment_details->transaction_id; ?>]</strong>
<?php
	}
} ?>
                <br><br>
                
                <table class="table table-condensed" border="1px" style="border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th>Product Details</th>
                            <th align="right">Unit Price</th>
                            <th>Discount Percentage</th>
                            <th>Quantity</th>
                            <th>Net Price</th>
                        </tr>
                    </thead>
                    <tbody>
<?php
$total_inr = 0;

$shipping_cost_inr = $order_details->shipping_cost;
if($order_details->currency == 'usd') {
	$shipping_cost_inr = $order_details->shipping_cost * 65;
}

$coupon_discount_inr = 0;

foreach($order_items as $order_item) {
	$product_unit_price_inr = $skus_list[$order_item->id]->price_inr;
	$product_price_inr = $product_unit_price_inr * $order_item->qty;
	$product_discounted_inr = $product_price_inr * (1 - ($order_item->discount_percentage/100));
	$product_net_inr_price = $product_discounted_inr;
	$total_inr += $product_discounted_inr; ?>
                        <tr>
                            <td>
                                <?php echo ucwords($products_list[$order_item->id]->name); ?> <br> 
                                SKU Code: <?php echo $skus_list[$order_item->id]->sku_code; ?> | 
                                Order Item ID: <?php echo $order_item->id; ?> | 
                                Order ID: <?php echo $order_item->order_id; ?> |
<?php if($order_item->custom) { ?> 
                                <span class="label label-default">Customized</span> | 
<?php } ?>
<?php if($skus_list[$order_item->id]->size != null) { ?> 
                                Size: <?php echo strtoupper($skus_list[$order_item->id]->size); ?>  
<?php } else { ?>
                                <span class="label label-default">Unstitched</span>
<?php 
      } ?> 
                            </td>
                            <td align="right">
								<?php echo 'INR' . ' ' . money_format('%!.2n', $product_unit_price_inr); ?>
								<?php //echo strtoupper($order_item->currency) . ' ' . money_format('%!.2n', $order_item->unit_price); ?>
								<?php
								if($order_item->gst > 0) {
									if($order_item->unit_price >= 1000) {
										echo "(12% GST)";
									} else {
										echo "(5% GST)";
									}
								} ?>
							</td>
                            <td align="center"><?php echo $order_item->discount_percentage; ?> %</td>
                            <td align="right"><?php echo $order_item->qty; ?></td>
                            <td align="right"><?php echo 'INR' . ' ' . money_format('%!.2n', $product_net_inr_price); ?></td>
                            <!-- td align="right"><?php echo strtoupper($order_item->currency) . ' ' . money_format('%!.2n', $order_item->net_price); ?></td -->
                        </tr>
<?php
} ?>
                        <tr>
                            
                          <td colspan="3" style="text-align:right;"><strong>Total</strong></td>
                          <td class="total-num"><?php echo $order_details->total_items; ?> items</td>
                          
                          <td class="total-sum" style="text-align: right"><strong><?php echo 'INR' . ' ' . money_format('%!.2n',$total_inr); ?></strong></td>
                          <!-- td class="total-sum" style="text-align: right"><strong><?php echo strtoupper($order_item->currency) . ' ' . money_format('%!.2n',$order_details->total_amount); ?></strong></td -->
                          
                        </tr>
                        
<?php
if( (count($order_coupon) > 0) && ($order_coupon->type == 'rupees_off') ) { ?>

                          <tr class="warning">
                            
                            <td colspan="3" style="text-align:right;"><strong>Coupon <?php echo $order_coupon->coupon_code; ?> | <?php echo ucfirst($order_coupon->title); ?></strong></td>
                            <td class="toal-num">&nbsp;</td>
                            
                            <!-- td class="total-sum" style="text-align: right"><strong> - <?php echo 'INR' . ' ' . money_format('%!.2n',$order_coupon->discount_amount); ?></strong></td -->
                            <?php 
								$coupon_discount_inr = $order_coupon->discount_amount;
								if($order_details->currency == 'usd') {
									$coupon_discount_inr = $order_coupon->discount_amount * 65;
								}
							?>
							<td class="total-sum" style="text-align: right"><strong> - <?php echo 'INR' . ' ' . money_format('%!.2n',$coupon_discount_inr); ?></strong></td>
                          </tr>
<?php
} ?>

<?php
if( (count($order_coupon) > 0) && ($order_coupon->type == 'percent_off') ) { ?>

                          <tr class="warning">
                            
                            <td colspan="3" style="text-align:right;"><strong>Coupon <?php echo $order_coupon->coupon_code; ?> | <?php echo ucfirst($order_coupon->title); ?></strong></td>
                            <td class="toal-num">&nbsp;</td>
                            
                            <!-- td class="total-sum" style="text-align: right"><strong> - <?php echo 'INR' . ' ' . money_format('%!.2n',$order_coupon->discount_amount); ?></strong></td -->
                            
                            <?php 
								$coupon_discount_inr = $total_inr * ($order_coupon->value/100);
							?>
                            <td class="total-sum" style="text-align: right"><strong> - <?php echo 'INR' . ' ' . money_format('%!.2n',$coupon_discount_inr); ?></strong></td>
                          </tr>
<?php
} ?>                        
                        
                        <tr>
                          
                          <td colspan="3" style="text-align:right;"><strong>Total Weight</strong></td>
                          <td class="toal-num"><?php echo $order_details->total_shipping_weight; ?> KG(s)</td>
                          
                          <td class="total-sum" style="text-align: right"></td>
                          
                        </tr>
                        <tr>
                          
                          <td colspan="3" style="text-align:right;"><strong>Total Shipping Cost for <?php echo ucwords($order_details->ship_to_city); ?></strong></td>
                          <td class="toal-num"></td>
                          
                          <td class="total-sum" style="text-align: right"><strong> <?php echo 'INR' . ' ' . money_format('%!.2n',$shipping_cost_inr); ?></strong></td>
                          <!-- td class="total-sum" style="text-align: right"><strong> <?php echo 'INR' . ' ' . money_format('%!.2n',$order_details->shipping_cost); ?></strong></td -->
                          
                        </tr>
                        
<?php
if( (count($order_coupon) > 0) && ($order_coupon->type == 'shipping_off') ) { ?>
                          <tr class="warning" style="background:lightgray;">
                            
                            <td colspan="3" style="text-align:right;"><strong>Coupon <?php echo $order_coupon->coupon_code; ?> | <?php echo ucfirst($order_coupon->title); ?></strong></td>
                            <td class="toal-num">&nbsp;</td>
                            
                            <td class="total-sum" style="text-align: right"><strong> - <?php echo 'INR' . ' ' . money_format('%!.2n',$order_details->shipping_cost); ?></strong></td>
                            
                            <?php 
								$coupon_discount_inr = $order_coupon->discount_amount;
								if($order_details->currency == 'usd') {
									$coupon_discount_inr = $order_coupon->discount_amount * 65;
								}
							?>
                            
                          </tr>
<?php
} ?>                              
                        
                        
<?php
if($order_details->cod_fee > 0) { ?>                          
                          <tr>
                            
                            <td colspan="3" style="text-align:right;"><strong>Convenience fee for Cash on Delivery orders below Rs. 1500</strong></td>
                            <td class="toal-num">Rs. 150</td>
                            
                            <td class="total-sum" style="text-align: right"><strong> Rs. 150.00</strong></td>
                            <?php $shipping_cost_inr += 150; ?>
                          </tr>
<?php
} ?>                        
                        
                        <tr>
                          
                          <td colspan="3" style="text-align:right;"><strong>Tax for <?php echo ucwords($order_details->ship_to_city); ?></strong></td>
                          <td class="toal-num"><?php echo $order_details->tax_percentage; ?> %</td>
                          
                          <td class="total-sum" style="text-align: right"><strong><?php echo 'INR' . ' ' . money_format('%!.2n', $order_details->total_amount * ($order_details->tax_percentage/100) ); ?></strong></td>
                          
                        </tr>
                        <tr>
                          
                          <td colspan="3" style="text-align:right;"><strong>Grand Total</strong></td>
                          <td class="toal-num"></td>
                          
                          <td class="total-sum" style="text-align: right"><strong><?php echo 'INR' . ' ' . money_format('%!.2n', ($total_inr - $coupon_discount_inr + $shipping_cost_inr)); ?></strong></td>
                          
                          <!-- td class="total-sum" style="text-align: right"><strong><?php echo strtoupper($order_item->currency) . ' ' . money_format('%!.2n', $order_details->grand_total); ?></strong></td -->
                          
                        </tr>
                        
                    </tbody>
                </table>
                
            </div>
        </div>
      
<?php if(count($customizations_list) > 0) : ?>
        
        <br>
        
        <div class="row">
            <div class="col-xs-12">
                <h3>Customizations</h3>
                <table class="table table-condensed margin-top-30"  border="1px" style="border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th>Order Item ID</th>
                            <th>SKU Code</th>
                            <th>Product Name</th>
                            <th>top collar</th>
                            <th>top shoulder</th>
                            <th>top armhole</th>
                            <th>top sleeve length</th>
                            <th>top chest</th>
                            <th>top waist</th>
                            <th>top hip</th>
                            <th>top length</th>
                            <th>bottom waist</th>
                            <th>bottom thigh</th>
                            <th>bottom knee</th>
                            <th>bottom bottom</th>
                            <th>bottom seat</th>
                            <th>bottom length</th>
                        </tr>
                    </thead>
                    <tbody>
<?php
foreach($customizations_list as $customization) { ?>
                        <tr>
                            <td><?php echo $customization->order_item_id; ?></td>
                            <td><?php echo $skus_list[$customization->order_item_id]->sku_code; ?></td>
                            <td><?php echo ucwords($products_list[$customization->order_item_id]->name); ?></td>
                            <td align="left"><?php echo $customization->top_collar; ?></td>
                            <td align="left"><?php echo $customization->top_shoulder; ?></td>
                            <td align="left"><?php echo $customization->top_armhole; ?></td>
                            <td align="left"><?php echo $customization->top_sleevelength; ?></td>
                            <td align="left"><?php echo $customization->top_chest; ?></td>
                            <td align="left"><?php echo $customization->top_waist; ?></td>
                            <td align="left"><?php echo $customization->top_hip; ?></td>
                            <td align="left"><?php echo $customization->top_length; ?></td>
                            <td align="left"><?php echo $customization->bottom_waist; ?></td>
                            <td align="left"><?php echo $customization->bottom_thigh; ?></td>
                            <td align="left"><?php echo $customization->bottom_knee; ?></td>
                            <td align="left"><?php echo $customization->bottom_bottom; ?></td>
                            <td align="left"><?php echo $customization->bottom_seat; ?></td>
                            <td align="left"><?php echo $customization->bottom_length; ?></td>
                        </tr>
<?php
} ?>
                        
                    </tbody>
                </table>
            </div>
        </div>      
        
<?php endif; ?>

		<div class="row">
            <div class="col-xs-12">
                <h3>Alterations</h3>
                <table class="table table-condensed margin-top-30"  border="1px" style="border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th>Order Item ID</th>
                            <th>SKU Code</th>
                            <th>Product Name</th>
                            <th>Size</th>
                            <th>Alterations</th>
                        </tr>
                    </thead>
                    <tbody>
<?php
$i = 0;
foreach($order_items as $item) {
	if($item->alterations != '') { ?>
                        <tr>
							<td><?php echo $item->id; ?></td>
                            <td><?php echo $item->sku_code; ?></td>
                            <td><?php echo ucwords($products_list[$item->id]->name); ?></td>
                            <td><?php echo ucwords($skus_list[$item->id]->size); ?></td>
                            <td><?php echo ucfirst($item->alterations); ?></td>
                        </tr>
<?php
		$i += 1;
	}
} ?>

<?php
if($i == 0) { ?>
						<tr>
							<td colspan="5">No alterations specified</td>
						</tr>
<?php
} ?>
                    </tbody>
                </table>
            </div>
        </div>


      </div>
    </section>
    
    <br>
    <button id="printInv">Print Invoice</button> &nbsp; <a id="back-link" href="<?php echo $this->config->base_url()."orders/order_info/{$order_details->id}"; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-chevron-left"></span> < Back</a>
        
</div>
<!-- /#main-content -->

<br><br>


