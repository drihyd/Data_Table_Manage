    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
<?php
    echo $this->session->flashdata('form-after-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>
                <?php echo form_open('shipping_times/save/'.$shipping_time_details->id, array('class' => 'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="timeName" class="control-label">Name</label>
                    <input type="text" class="form-control input-sm" id="timeName" name="timeName" value="<?php echo ucwords($shipping_time_details->name); ?>">
                  </div><br>
                  <div class="form-group inline">
                    <label for="timeMin" class="control-label">Minimum number of days</label>
                    <input type="number" class="form-control input-sm" id="timeMin" name="timeMin" value="<?php echo $shipping_time_details->min_days; ?>" min="1">
                  </div>
                  <div class="form-group inline">
                    <label for="timeMax" class="control-label">Maximum number of days</label>
                    <input type="number" class="form-control input-sm" id="timeMax" name="timeMax" value="<?php echo $shipping_time_details->max_days; ?>" min="1">
                  </div><br>
                  <div class="form-group">
                    <label for="timePhrase" class="control-label">Message/Phrase</label>
                    <input type="text" class="form-control input-sm" id="timePhrase" name="timePhrase" placeholder="Eg. Order before 2PM for same day delivery..." value="<?php echo ucfirst($shipping_time_details->phrase); ?>">
                  </div>
                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'shipping_times'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#basicinfo tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
