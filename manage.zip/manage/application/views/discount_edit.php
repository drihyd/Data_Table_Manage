    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
        <li role="presentation"><a href="#displaypic" aria-controls="displaypic" role="tab" data-toggle="tab">Display Picture</a></li>
        <li role="presentation"><a href="#seotags" aria-controls="seotags" role="tab" data-toggle="tab">SEO Tags</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
 <?php
    echo $this->session->flashdata('form-after-message');
    echo $this->session->flashdata('discount-success-message');
    echo $this->session->flashdata('discount-error-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>
                <?php echo form_open('discounts/save/'.$discount_details->id, array('class' => 'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="discountName" class="control-label">Name</label>
                    <input type="text" class="form-control input-sm nameForSlug" id="discountName" name="discountName" value="<?php echo $discount_details->name; ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="discountSlug" class="control-label">Slug</label>
                    <input type="text" class="form-control input-sm slugForName" id="discountSlug" name="discountSlug" value="<?php echo $discount_details->slug; ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="discountPercentage" class="control-label">Discount Percentage</label>
                    <input type="text" class="form-control input-sm" id="discountPercentage" name="discountPercentage" value="<?php echo $discount_details->discount_percentage; ?>">
                  </div><br>
                  <div class="form-group">
                    <label for="discountProductsList" class="control-label">Discounted Products (enter product codes seperated by commas)</label>
                    <textarea class="form-control input-sm" name="discountProductsList" id="discountProductsList" style="width: 100%; max-width: 100%; min-height: 100px;"><?php echo implode(',', $discounted_product_codes); ?></textarea>
                  </div>
                  <div class="form-group inline">
                    <label for="discountValidFrom" class="control-label">Valid From Date</label>
                    <input type="date" class="form-control input-sm" id="discountValidFrom" name="discountValidFrom" value="<?php echo date('Y-m-d', strtotime($discount_details->valid_from)); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="discountValidFromTime" class="control-label">Valid From Time</label>
                    <input type="time" class="form-control input-sm" id="discountValidFromTime" name="discountValidFromTime" value="<?php echo date('H:i:s', strtotime($discount_details->valid_from)); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="discountValidTill" class="control-label">Valid Till Date</label>
                    <input type="date" class="form-control input-sm" id="discountValidTill" name="discountValidTill" value="<?php echo date('Y-m-d', strtotime($discount_details->valid_till)); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="discountValidTillTime" class="control-label">Valid Till Time</label>
                    <input type="time" class="form-control input-sm" id="discountValidTillTime" name="discountValidTillTime" value="<?php echo date('H:i:s', strtotime($discount_details->valid_till)); ?>">
                  </div>
                  <div class="form-group">
                    <label for="discountDesc" class="control-label">Description</label>
                    <textarea id="discountDesc" name="discountDesc" style="max-width: 100%;min-width;100%;" class="form-control input-sm"><?php echo $discount_details->desc; ?></textarea>
                  </div>

                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'discounts'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#basicinfo tab end-->
              
              <div role="tabpanel" class="tab-pane" id="displaypic">
                <?php echo validation_errors(); ?>
                <?php echo form_open_multipart('discounts/DPimageSave'.'/'.$discount_details->id, array('class' => 'edit-form')); ?>
                  <legend>Discount Display Picture</legend>
                    
<?php       
                if($discount_details->dp_image != '') { ?>
                  <img src="<?php echo $this->config->base_url().'../assets/uploads/'.$discount_details->dp_image; ?>" class="img-responsive" alt="" title="">
<?php
                } else { ?>
                  <img src="<?php echo $this->config->base_url().'img/Not_Available.jpg'; ?>" class="img-responsive" alt="" title="" style="max-width: 400px">
<?php
                } ?>
                  <div class="form-group margin-top-15">
                    <label for="discountDPChange" class="control-label">Change Display Picture</label>
                    <small class="text-warning">Must be 500 X 300 px</small><br>
                    <input type="file" class="form-control input-sm" id="discountDPChange" name="discountDPChange">
                  </div>
                  <input type="hidden" name="editType" value="update">                  
                  <input type="hidden" name="discountId" value="discountId">
                  <input type="hidden" name="imageId" value="imageId">
                  <div class="form-group">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'discounts'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#displaypic tab end-->
              
              <div role="tabpanel" class="tab-pane" id="seotags">
                <?php echo validation_errors(); ?>
                <?php echo form_open('discounts/seosave/'.$discount_details->id, array('class' => 'edit-form')); ?>
                  <legend>SEO Tags</legend>
                  <div class="form-group inline">
                    <label for="discountSeoTitle" class="control-label">Page Title</label>
                    <input type="text" class="form-control input-sm" id="discountSeoTitle" name="discountSeoTitle" value="<?php echo ucfirst($discount_details->seo_title); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="discountSeoDesc" class="control-label">Page Description</label>
                    <input type="text" class="form-control input-sm" id="discountSeoDesc" name="discountSeoDesc" value="<?php echo ucfirst($discount_details->seo_desc); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="discountSeoKeys" class="control-label">Page Keywords</label>
                    <input type="text" class="form-control input-sm" id="discountSeoKeys" name="discountSeoKeys" value="<?php echo ucfirst($discount_details->seo_keywords); ?>">
                  </div>
                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'discounts'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#seotags tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
          <div class="col-sm-6">
            <div class="edit-form">
              
              <legend>Added Products List</legend>
              <div class="list-group">
<?php 
foreach($discounted_products as $product) {
  if(isset($products_info[$product->product_id])) { 
    $prod = $products_info[$product->product_id]; ?>
                <div class="list-group-item">
                  <strong><?php echo $prod->code; ?></strong> | <?php echo ucwords($prod->name); ?>
                </div>
<?php
  }
  else { ?>
                <div class="list-group-item danger">
                  Invalid / deleted product
                </div>
<?php
  } ?>

<?php    
} ?>
              </div>
            </div>
              
            </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
