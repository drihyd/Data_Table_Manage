<div class="sub-header">Manage Newsletter Leads</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table table-sort table-sort-search table-sort-show-search-count">
                <thead>
                  <tr>
                    <th class="table-sort">Name</th>
                    <th class="table-sort">Email</th>
                    <th class="table-sort">Phone</th>
                    <th class="table-sort">Gender</th>
                    <th class="table-sort">City</th>
                    <th class="table-sort">State</th>
                    <th class="table-sort">Country</th>
                    <th class="table-sort">IP Address</th>
                    <th class="table-sort">Device</th>
                    <th class="table-sort">Source URL</th>
                    <th class="table-sort">Product Name</th>
                    <th class="table-sort">Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  
<?php if($enquiry_leads) {
        foreach ($enquiry_leads as $enquiry_lead) { 
          $query = $this->db->query("select * from products where id = {$enquiry_lead['product_id']}");
          if($query->num_rows() > 0) {
            $product_name = $query->row()->name; 
          }
          else {
            $product_name = "<span class='text-danger'>Product Deleted</span>";
          } ?>
                  <tr>
                    <td><?php echo ucfirst($enquiry_lead['name']); ?></td>
                    <td><?php echo $enquiry_lead['email']; ?></td>
                    <td><?php echo $enquiry_lead['phone']; ?></td>
                    <td><?php echo ucfirst($enquiry_lead['gender']); ?></td>
                    <td><?php echo ucfirst($enquiry_lead['city']); ?></td>
                    <td><?php echo ucfirst($enquiry_lead['state']); ?></td>
                    <td><?php echo ucfirst($enquiry_lead['country']); ?></td>
                    <td><?php echo ucfirst($enquiry_lead['ip']); ?></td>
                    <td><?php echo ucfirst($enquiry_lead['device']); ?></td>
                    <td><?php echo $enquiry_lead['source_url']; ?></td>
                    <td><?php echo ucfirst($product_name); ?></td>
                    <td><?php echo $enquiry_lead['date']; ?></td>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'enquiry_leads/delete/'.$enquiry_lead['id']; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop
      } //end of if 
      else {  ?>                  
                  <tr align='center'>
                    <td colspan=13>Sorry! No Leads so far</td>
                  </tr>
<?php } // end of else ?>                  
                </tbody>
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
