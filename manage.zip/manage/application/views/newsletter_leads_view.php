<div class="sub-header">Manage Newsletter Leads</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table table-sort table-sort-search table-sort-show-search-count">
                <thead>
                  <tr>
                    <th class="table-sort">Name</th>
                    <th class="table-sort">Email</th>
                    <th class="table-sort">IP Address</th>
                    <th class="table-sort">Device</th>
                    <th class="table-sort">Source URL</th>
                    <th class="table-sort">Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  
<?php if($newsletter_leads) {
        foreach ($newsletter_leads as $newsletter_lead) { ?>
                  <tr>
                    <td><?php echo ucfirst($newsletter_lead['name']); ?></td>
                    <td><?php echo $newsletter_lead['email']; ?></td>
                    <td><?php echo ucfirst($newsletter_lead['ip']); ?></td>
                    <td><?php echo ucfirst($newsletter_lead['device']); ?></td>
                    <td><?php echo $newsletter_lead['source_url']; ?></td>
                    <td><?php echo $newsletter_lead['date']; ?></td>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'newsletter_leads/delete/'.$newsletter_lead['id']; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop
      } //end of if 
      else {  ?>                  
                  <tr align='center'>
                    <td colspan=13>Sorry! No Leads so far</td>
                  </tr>
<?php } // end of else ?>                  
                </tbody>
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
