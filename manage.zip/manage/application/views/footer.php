<?php
if(isset($analytics_graphs)) { ?>
	<div class="modal fade" id="analyticsOrdersModal">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">Orders</h4>
				</div>
				<div class="modal-body" style="max-height: 350px; overflow: auto;">
					<table class="table">
						
					</table>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
<?php
} ?>

  <div id="update_price_modal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Update Status</h4>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body">      	
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>




<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php echo $this->config->base_url(); ?>js/vendor/jquery-1.11.0.min.js"><\/script>')</script>

<script src="<?php echo $this->config->base_url(); ?>js/vendor/bootstrap.min.js"></script>
<script src="<?php echo $this->config->base_url(); ?>js/vendor/simple-lightbox.min.js"></script>












<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>




<?php if(isset($tinyMC)) : ?>
	<script src="//tinymce.cachefly.net/4.1/tinymce.min.js"></script>
	<script>
		tinymce.init({
			selector:'textarea.mce',
			plugins: ["textcolor", "advlist autolink lists link image charmap print preview anchor", "searchreplace visualblocks code fullscreen", "insertdatetime media table contextmenu paste", "hr"],
			toolbar: "forecolor backcolor insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
		});
	</script>
<?php endif; ?>










<script>
		$('#product-viewer-grid .product-box').click(function() {
			
			var box = $(this);
			var id = box.attr('id');
			var textarea = $('#selected-products-box');
			var selected = textarea.val();
			
			if(selected != '') {
				selected = selected.split(',');
			} else {
				selected = [];
			}
				
			if(box.hasClass('selected')) {
				box.removeClass('selected');
				selected = jQuery.grep(selected, function(value) {
					return value != id;
				});
			} else {
				box.addClass('selected');
				selected.push(id);
			}
			selected = selected.join();
			textarea.val(selected);
			
		});

	$('#update_price_form').submit(function(e) {
		e.preventDefault();
		var price_factor = $('#price_factor').val(); 		
		$.ajax($('#update_price_form').attr('action'), {
		    type: 'POST',  // http method
		    data: { factor: price_factor },  // data to submit
		    beforeSend:function () {
		    	$.LoadingOverlay("show");				
		    },
		    success: function (data, status, xhr) {		  
				$.LoadingOverlay("hide");			
				var mymodal = $('#update_price_modal');
			    mymodal.find('.modal-body').html(data);
			    mymodal.modal('show');
		    },
		    error: function (jqXhr, textStatus, errorMessage) {
		    	$.LoadingOverlay("hide");
		        var mymodal = $('#update_price_modal');
			    mymodal.find('.modal-body').html(data);
			    mymodal.modal('show');
		    }
		});
	});

	</script>






<?php if($page_name_new=="products_filter"){ ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs/jszip-2.5.0/dt-1.10.18/af-2.3.3/b-1.5.6/b-colvis-1.5.6/b-flash-1.5.6/b-html5-1.5.6/b-print-1.5.6/cr-1.5.0/fc-3.2.5/fh-3.1.4/kt-2.5.0/r-2.2.2/rg-1.1.0/rr-1.2.4/sc-2.0.0/sl-1.3.0/datatables.min.js"></script>


<?php } else { ?>
<script src="<?php echo $this->config->base_url(); ?>js/jquery-ui/jquery-ui.min.js"></script>
<script src="//cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>
<script src="//cdn.datatables.net/plug-ins/3cfcc339e89/integration/jqueryui/dataTables.jqueryui.js"></script>
<script src="<?php echo $this->config->base_url(); ?>js/main.js"></script>
<?php } ?>

<?php if($page_name_new=="products_filter"){ ?>

<script type="text/javascript">
  $(document).ready( function() {
   var table;
	table = $('#product_listing_datatable').dataTable({ 
	"dom": 'Blfrtip',
	"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
	'processing': true,
	'serverSide': true,
	'serverMethod': 'post',
	'searching':true,


	"order": [], 
	buttons: [
        {
            extend: 'excel',
            text: '<span class="fa fa-file-excel-o"></span> Excel Export',
            exportOptions: {
        modifier: {
            page: 'all'
        }
    },
    customize: function (xlsx)
    {
        var sheet = xlsx.xl.worksheets['sheet1.xml'];
        $('row:first c', sheet).attr('s', '7');
    }
        },
         {
            extend: 'pdf',
            text: '<span class="fa fa-file-excel-o"></span> PDF Export',
            exportOptions: {
                modifier: {
          
                     page: 'all',
             
                }
            }
        }
    ],

	// Load data for the table's content from an Ajax source
	"ajax": {
	"url": "<?php echo site_url('product_reports/product_listings_ajax')?>",
	"type": "POST",
	"data": function ( data ) {
		data.prd_category = $('#prd_category').val();

		
	}
	},


"pageLength": 50, 
  columnDefs: [
        { targets: [0,1,2,3,4,5,6], visible: true},
     
    ]
        
        
    });



$('#prd_category').on('change', function () {   

     table.api().ajax.reload();

      });



});



</script>

<?php } ?>










<script>
	$(document).ready(function() {

		<?php
		if( isset( $sidebar_element ) ) { ?>
			$('#<?php echo $sidebar_element; ?>').addClass('active');
		<?php
		} ?>

		<?php
		if( isset( $sidebar_subelement ) ) { ?>
			$('#<?php echo $sidebar_subelement; ?>').addClass('active');
			$('#<?php echo $sidebar_element; ?>-dropmenu').addClass('in');
		<?php
		} ?>    
	});
</script>

<script>
	$('#bulkApproveAll').click(function() {
		if($(this).is(":checked")) {
			$('.bulkApprove').prop('checked', true);
		}
		else {
			$('.bulkApprove').prop('checked', false);
		}
	});
</script>

<?php
if(isset($analytics_graphs)) { ?>

	<script>
		google.load('visualization', '1', {
			packages: ['corechart']
		});
		google.setOnLoadCallback(drawChart);

		function drawChart() {

			var orderData = new google.visualization.DataTable();
			orderData.addColumn('date', 'Day');
			orderData.addColumn('number', 'Total Orders');
			orderData.addColumn('number', 'Target');
			orderData.addColumn('number', 'New');
			orderData.addColumn('number', 'Repeat');
			
			orderData.addRows([
				<?php
					$i = 0;
					foreach($sorted_orders_date as $key => $value) {
					if($i != 0) echo ','; ?>						
					[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo $value['order_num']; ?>, 9, <?php echo $value['new_customer_orders_num']; ?>, <?php echo $value['old_customer_orders_num']; ?>]
				<?php
					$i += 1;
				} ?>
			]);

			var domesticForeignData = new google.visualization.DataTable();
			domesticForeignData.addColumn('date', 'Day');
			domesticForeignData.addColumn('number', 'Domestic');
			domesticForeignData.addColumn('number', 'Foreign');

			domesticForeignData.addRows([
				<?php
					$i = 0;
					foreach($sorted_orders_date as $key => $value) {
					if($i != 0) echo ','; ?>						
					[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo $value['domestic_orders_num']; ?>, <?php echo $value['foreign_orders_num']; ?>]
					<?php
					$i += 1;
				} ?>
			]);


			var domesticForeignRevData = new google.visualization.DataTable();
			domesticForeignRevData.addColumn('date', 'Day');
			domesticForeignRevData.addColumn('number', 'Domestic Revenue');
			domesticForeignRevData.addColumn('number', 'Foreign Revenue');

			domesticForeignRevData.addRows([
				<?php
					$i = 0;
					foreach($sorted_orders_date as $key => $value) {
					if($i != 0) echo ','; ?>						
					[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo number_format(floor( (($value['domestic_orders_revenue']/100000) * 100))/100, 2); ?>, <?php echo number_format(floor( (($value['foreign_orders_revenue']/100000) * 100))/100, 2); ?>]
					<?php
					$i += 1;
				} ?>
			]);

			var orderOptions = {
				left: 0,
				'legend':'bottom',
				chartArea: {
					left: 20,
					top: 20,
					width: "100%"
				},
				backgroundColor: { fill:'transparent' },
				hAxis: {
					format: 'd MMM',
					gridlines: {count: 10}
				},
				vAxis: {
					gridlines: {
						color: 'none'
					},
					format: '0'
				},
				lineWidth: 1,
				pointSize: 1,
			};

			// orders
			var orders = new google.visualization.LineChart(document.getElementById('orders'));
			orders.draw(orderData, orderOptions);

			google.visualization.events.addListener(orders, 'select', selectHandlerOrders);
			function selectHandlerOrders() {
				var selectedData = orders.getSelection(), row, item;
				row = selectedData[0].row;
				item = orderData.getValue(row,0);
				item = "'"+item+"'"
				item = item.split(" ");
				//console.log(item);
				var date = ''+item[1]+'-'+item[2]+'-'+item[3]
				//console.log(date);
				ordersChartShowOrders(date);
				orders.setSelection();
			}

			// domestic Foreign
			var domesticForeign = new google.visualization.LineChart(document.getElementById('domesticForeign'));
			domesticForeign.draw(domesticForeignData, orderOptions);
			// domestic Foreign revenue
			var domesticForeignRev = new google.visualization.LineChart(document.getElementById('domesticForeignRev'));
			domesticForeignRev.draw(domesticForeignRevData, orderOptions);
			// new and repeat
			//var newRepeat = new google.visualization.LineChart(document.getElementById('newRepeat'));
			//newRepeat.draw(newRepeatData, orderOptions);

			var newRepeatData = new google.visualization.DataTable();
			newRepeatData.addColumn('date', 'Day');
			newRepeatData.addColumn('number', 'First Time');
			newRepeatData.addColumn('number', 'Repeat Orders');

			newRepeatData.addRows([
				<?php
					$i = 0;
					foreach($sorted_orders_date as $key => $value) {
					if($i != 0) echo ','; ?>						
					[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo $value['new_customer_orders_num']; ?>, <?php echo $value['old_customer_orders_num']; ?>]
					<?php
					$i += 1;
					} ?>
			]);

			var revenueData = new google.visualization.DataTable();
			revenueData.addColumn('date', 'Day');
			revenueData.addColumn('number', 'Revenue (in Lakhs)');

			revenueData.addRows([
				<?php
				$i = 0;
				foreach($sorted_orders_date as $key => $value) {
				if($i != 0) echo ','; ?>						
				[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo number_format(floor( (($value['revenue']/100000) * 100))/100, 2); ?>]
				<?php
				$i += 1;
				} ?>
			]);

			var revenuesOptions = {
				left: 0,
				'legend':'bottom',
				chartArea: {
					left: 50,
					top: 20,
					width: "100%"
				},
				backgroundColor: { fill:'transparent' },
				hAxis: {
					format: 'd MMM',
					gridlines: {count: 10}
				},
				vAxis: {
					gridlines: {
						color: 'none'
					},
					format: '0L',
					minValue: 1
				},
				lineWidth: 1
			};

			// revenues
			var revenues = new google.visualization.LineChart(document.getElementById('revenues'));
			revenues.draw(revenueData, orderOptions);
		};
	</script>

	<?php
	if(count($orders) > 0) { ?>                  
		<script type="text/javascript">
			google.load("visualization", "1", {packages:["corechart"]});
			google.setOnLoadCallback(drawChart);
			function drawChart() {
				// *********************************************************************
				var dataSources = google.visualization.arrayToDataTable([
					['Source', 'No. of Leads'],
					<?php
						$i = 0;
						foreach($utm_sources_index as $key => $value) { ?>                          
							['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
						<?php
							$i += $value;
						} ?>
						<?php if($i != $total_orders) { ?>
							['Empty',     <?php echo abs($total_orders - $i); ?>]
						<?php
						} ?>
				]);

				var optionsSources = {
					title: 'Utm_sources',
					left: 0,
					'legend':'bottom',
					chartArea: {
						left: 20,
						top: 20,
						width: "100%"
					},
					backgroundColor: { fill:'transparent' },
					hAxis: {
						format: 'd MMM',
						gridlines: {count: 10}
					},

					vAxis: {
						gridlines: {
							olor: 'none'
						},
						format: '0',
						minValue: 10
					},
					lineWidth: 1
				};
	
				// *********************************************************************                        
				var dataMediums = google.visualization.arrayToDataTable([
					['Medium', 'No. of Leads'],
					<?php
						$i = 0;
						foreach($utm_mediums_index as $key => $value) { ?>                          
							['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
							<?php $i += $value; ?>
						<?php
						} ?>
						<?php if($i != $total_orders) { ?>
							['Empty',     <?php echo abs($total_orders - $i); ?>]
						<?php
						} ?>
				]);

				var optionsMediums = {
					title: 'Utm_mediums',
					left: 0,
					'legend':'bottom',
					chartArea: {
						left: 20,
						top: 20,
						width: "100%"
					},
					backgroundColor: { fill:'transparent' },
					hAxis: {
						format: 'd MMM',
						gridlines: {count: 10}
					},
					vAxis: {
						gridlines: {
							color: 'none'
						},
						format: '0',
						minValue: 10
					},
					lineWidth: 1
				};
				
				// *********************************************************************
				var dataCampaigns = google.visualization.arrayToDataTable([
					['Campaign', 'No. of Leads'],
					<?php
						$i = 0;
						foreach($utm_campaigns_index as $key => $value) { ?>                          
							["<?php echo ucwords($key); ?>",     <?php echo $value; ?>],
							<?php $i += $value; ?>
						<?php
						} ?>
						<?php if($i != $total_orders) { ?>
							['Empty',     <?php echo abs($total_orders - $i); ?>]
						<?php
						} ?>
				]);

				var optionsCampaigns = {
					title: 'Utm_campaigns',
					left: 0,
					'legend':'bottom',
					chartArea: {
						left: 20,
						top: 20,
						width: "100%"
					},
					backgroundColor: { fill:'transparent' },
					hAxis: {
						format: 'd MMM',
						gridlines: {count: 10}
					},

					vAxis: {
						gridlines: {
							olor: 'none'
						},
						format: '0',
						minValue: 10
					},
					lineWidth: 1
				};
				
				// *********************************************************************
				var dataTerms = google.visualization.arrayToDataTable([
				['Term', 'No. of Leads'],
				<?php
				$i = 0;
				foreach($utm_terms_index as $key => $value) { ?>                          
				['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
				<?php
				$i += $value;
				} 
				if($i != $total_orders) { ?>
				['Empty',     <?php echo abs($total_orders - $i); ?>]
				<?php
				}
				?>
				]);

				var optionsTerms = {
				title: 'Utm_terms',
				left: 0,
				'legend':'bottom',
				chartArea: {
				left: 20,
				top: 20,
				width: "100%"
				},
				backgroundColor: { fill:'transparent' },
				hAxis: {
				format: 'd MMM',
				gridlines: {count: 10}
				},

				vAxis: {
				gridlines: {
				color: 'none'
				},
				format: '0',
				minValue: 10
				},
				lineWidth: 1
				};

				// *********************************************************************
				var dataContents = google.visualization.arrayToDataTable([
					['Content', 'No. of Leads'],
					<?php
						$i = 0;
						foreach($utm_contents_index as $key => $value) { ?>                          
							['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
							<?php $i += $value; ?>
						<?php
						} ?>
						<?php if($i != $total_orders) { ?>
							['Empty',     <?php echo abs($total_orders - $i); ?>]
						<?php
						}
						?>
				]);

				var optionsContents = {
					title: 'Utm_contents',
					left: 0,
					'legend':'bottom',
					chartArea: {
						left: 20,
						top: 20,
						width: "100%"
					},
					backgroundColor: { fill:'transparent' },
					hAxis: {
						format: 'd MMM',
						gridlines: {count: 10}
					},

					vAxis: {
						gridlines: {
							color: 'none'
						},
						format: '0',
						minValue: 10
					},
					lineWidth: 1
				};
				
				var chartSources = new google.visualization.PieChart(document.getElementById('piechartSources'));
				
				google.visualization.events.addListener(chartSources, 'select', selectHandlerSources);
				function selectHandlerSources() {
					var selectedData = chartSources.getSelection(), row, item;
					row = selectedData[0].row;
					item = dataSources.getValue(row,0);
					item = item.split(" ").join('-').toLowerCase();
					//console.log(item);
					var selector = 'source-'+item;
					//console.log(selector);
					ordersChartShowOrders(selector);
					chartSources.setSelection(null);
				}
				
				var chartMediums = new google.visualization.PieChart(document.getElementById('piechartMediums'));
				
				google.visualization.events.addListener(chartMediums, 'select', selectHandlerMediums);
				function selectHandlerMediums() {
					var selectedData = chartMediums.getSelection(), row, item;
					row = selectedData[0].row;
					item = dataMediums.getValue(row,0);
					item = item.split(" ").join('-').toLowerCase();
					//console.log(item);
					var selector = 'medium-'+item;
					//console.log(selector);
					ordersChartShowOrders(selector);
					chartMediums.setSelection(null);
				}
				
				var chartCampaigns = new google.visualization.PieChart(document.getElementById('piechartCampaigns'));
				google.visualization.events.addListener(chartCampaigns, 'select', selectHandlerCampaigns);
				function selectHandlerCampaigns() {
					var selectedData = chartCampaigns.getSelection(), row, item;
					row = selectedData[0].row;
					item = dataCampaigns.getValue(row,0);
					item = item.split(" ").join('-').toLowerCase();
					//console.log(item);
					var selector = 'campaign-'+item;
					//console.log(selector);
					ordersChartShowOrders(selector);
					chartCampaigns.setSelection(null);
				}
				
				//var chartTerms = new google.visualization.PieChart(document.getElementById('piechartTerms'));
				//var chartContents = new google.visualization.PieChart(document.getElementById('piechartContents'));

				chartSources.draw(dataSources, optionsSources);
				chartMediums.draw(dataMediums, optionsMediums);
				chartCampaigns.draw(dataCampaigns, optionsCampaigns);
				//chartTerms.draw(dataTerms, optionsTerms);
				//chartContents.draw(dataContents, optionsContents);
			}
		</script>


		<!-- div class="col-sm-4 col-sm-offset-2 text-align-left">
		<div id="piechartTerms" style="text-align:left;width: 100%;height:320px"></div>
		</div>
		<div class="col-sm-4 text-align-left">
		<div id="piechartContents" style="text-align:left;width: 100%;height:320px"></div>
		</div -->

	<?php
	} ?>


<?php
} ?>

<script>
	var lightbox = $('.prod-photos a').simpleLightbox({'history': false});
	var clickslb = $('.clicks-photo-box a.imgLink').simpleLightbox({'history': false});
</script>

	

</body>
</html>
