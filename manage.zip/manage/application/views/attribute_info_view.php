
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'attributes/add'; ?>" class="btn btn-default btn-sm">Add <strong>Add</strong> New Attribute +</a> 
            &nbsp;<a href="<?php echo $this->config->base_url().'attribute_values/add_child_attr_value/'.$attribute_details->id; ?>" class="btn btn-default btn-sm">Add <strong>Add</strong> New Attribute Value +</a>
          </div>
        </div>
        
        <div class="row">
          <div class="col-xs-12">
            <div class="table-responsive margin-top-30">
              <table class="table dataTableNoPagination">
                <thead>
                  <tr>
                    <th>Attribute Value</th>
                    <th>Parent Attribute</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
<?php
foreach($attribute_values as $attribute_value) { ?>
                  <tr>
                    <td><?php echo $attribute_value->attr_value; ?></td>
                    <td><?php echo $attribute_details->attr_name; ?></td>
                    <td class="edit-column tiny-col" width="50px">
                      <a href="<?php echo $this->config->base_url().'attribute_values/edit/'.$attribute_value->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'attribute_values/delete/'.$attribute_value->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>                                  
<?php
} ?>

                </tbody>
              </table>  
            </div>
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
