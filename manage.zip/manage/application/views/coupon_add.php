    <?php $this->load->helper('encode_helper'); ?>
    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
      </ul>
    </div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
<?php
                      echo $this->session->flashdata('form-after-message');
?>              
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>

<?php
if($this->session->flashdata('form_error') != '') { ?>
                <div class="alert alert-danger alert-dismissible fade in" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                  <strong>Error!</strong> <?php echo $this->session->flashdata('form_error'); ?>
                </div>
<?php
} ?>

<?php
if($this->session->flashdata('form_success') != '') { ?>
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                  <strong>Success!</strong> <?php echo $this->session->flashdata('form_success'); ?>
                </div>
<?php
} ?>
                
                <?php echo form_open('coupons/save/', array('class'=>'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="couponTitle" class="control-label">Title</label>
                    <input type="text" class="form-control input-sm" id="couponTitle" name="couponTitle" value="" required>
                  </div>
                  <div class="form-group inline">
                    <label for="couponCode" class="control-label" style="display:block;">Code <small><a href="#" data-toggle="modal" data-target="#couponCodesModal" class="pull-right">Get Codes</a></small></label>
                    <input type="text" class="form-control input-sm codeClean" id="couponCode" name="couponCode" value="" required>
                  </div>
                  <div class="form-group">
                    <label for="couponDesc" class="control-label">Description</label>
                    <textarea class="form-control input-sm" style="max-width: 100%; min-width: 100%; min-height: 100px;" id="couponDesc" name="couponDesc" required></textarea>
                  </div>
                  <div class="form-group">
                    <label for="couponError" class="control-label">Error Message</label>
                    <textarea class="form-control input-sm" style="max-width: 100%; min-width: 100%; min-height: 100px;" id="couponError" name="couponError" required></textarea>
                  </div>
                  <div class="form-group inline">
                    <label for="couponType" class="control-label">Type</label>
                    <select class="form-control input-sm" id="couponType" name="couponType" required>
                      <option value="shipping_off">Free Shipping</option>
                      <option value="rupees_off">Rupees Off</option>
                      <option value="percent_off">Percent Off</option>
                    </select>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="couponValue" class="control-label"><span class="rupeesOff">Rupees</span> <span class="slash">/</span> <span class="percentOff">Percent</span> Off</label>
                    <input type="text" class="form-control input-sm" id="couponValue" name="couponValue" value="" disabled>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="couponUsageLimit" class="control-label">Usage Limit ( -1 for no limit )</label>
                    <input type="text" class="form-control input-sm" id="couponUsageLimit" name="couponUsageLimit" value="" required>
                  </div><br>
                  
                  <div class="form-group inline">
                    <label for="couponValidFrom" class="control-label">Valid From</label>
                    <input type="date" class="form-control input-sm" id="couponValidFrom" name="couponValidFrom" value="" required>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="couponValidTill" class="control-label">Valid Till</label>
                    <input type="date" class="form-control input-sm" id="couponValidTill" name="couponValidTill" value="" required>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="couponCustID" class="control-label">Customer ID (0 if not applicable)</label>
                    <input type="text" class="form-control input-sm" id="couponCustID" name="couponCustID" value="" required>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="couponMinOrderValue" class="control-label">Minimum Order Value</label>
                    <input type="text" class="form-control input-sm" id="couponMinOrderValue" name="couponMinOrderValue" value="" required>
                  </div>
                  
                  <div class="form-group inline">
                    <div class="checkbox">
						<label>
						  <input type="checkbox" name="couponSingleUsePerCust" value="1"> Single Use Per Customer
						</label>
					</div>
                  </div>
                  
                  <div class="form-group inline">
                    <div class="checkbox">
						<label>
						  <input type="checkbox" name="couponForFirstTimeOrdersOnly" value="1"> For first-time orders only
						</label>
					</div>
                  </div>
                  
                  <div class="form-group margin-top-30">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'coupons'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./end basicinfo tab -->
              
              
            
            </div> <!-- ./ end tab-content -->
            
          </div>
          <div class="col-sm-6">
            
            
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->


  <!-- Modal -->
  <div class="modal fade" id="couponCodesModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-sm" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="myModalLabel">Unique Coupon Codes</h4>
        </div>
        <div class="modal-body">
          <ul class="list-inline">
<?php
foreach($unique_codes as $unique_code) { ?>
            <li style="width: 30%;;margin: 0;font-family:courier;"><?php echo $unique_code; ?></li>
<?php
} ?>          
          </ul>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
