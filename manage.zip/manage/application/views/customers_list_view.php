<style>
	body {
		font-family: 'Arial', sans-serif;
		font-size: 12px;
		text-align: left;
	}
	
	table {
		border-collapse: collapse;
	}
	
	td {
		padding: 3px 6px;
		font-size: 12px;
	}
	
	th {
		text-align: left;
		padding: 3px 6px;
		font-size: 12px;
	}
</style>
<table border="1">
	<thead>
		<tr>
			<th>Name</th>
			<th>Email</th>
			<th>Registred On</th>
		</tr>
	</thead>
	
	<tbody>
<?php
$emails = array();
foreach($customers as $customer) {
	
	if($customer->is_guest == 1) {
		$email = strtolower($customer->guest_email);
	} else {
		$email = strtolower($customer->email);
	}
	
	if( ! in_array($email, $emails)) { ?>	
		
		<tr>
			<td><?php echo ucwords($customer->name); ?></td>
			<td><?php echo strtolower($email); ?></td>
			<td><?php echo date('M d, Y', strtotime($customer->date)); ?></td>
		</tr>
		
<?php
		array_push($emails, $email);
	
	}
	
} ?>
	</tbody>
</table>
	
