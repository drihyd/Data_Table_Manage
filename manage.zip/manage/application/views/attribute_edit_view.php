  <div class="sub-header">Edit Attribute</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
<?php
                      echo $this->session->flashdata('form-after-message');
?>              
            <?php echo validation_errors(); ?>
            <?php echo form_open('attributes/save/'.$attribute_details->id, array('class' =>'edit-form')); ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="attributeName" class="control-label">Attribute Name</label>
                <input type="text" class="form-control input-sm" id="attributeName" name="attributeName" value="<?php echo ucwords($attribute_details->attr_name); ?>" required>
              </div>
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'attributes'; ?>" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
