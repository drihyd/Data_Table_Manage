<?php
setlocale(LC_MONETARY, 'en_IN');

require APPPATH . 'controllers/class/PHPExcel.php';
require_once APPPATH . 'controllers/class/PHPExcel/IOFactory.php';

$excel_data = array();

$csv_headings = array(
	'Name',
	'ID',
	'Email',
	'Total Orders',
	'Total Revenue',
	'Average Order Value',
	'Age',
	'Last order',
	'Cities',
	'Countries',
);
array_push($excel_data, $csv_headings);

if(count($customer_data) > 0) {
	foreach($customer_data as $customer) {
		if($customer['total_orders'] > 1) {
			
			$row 				= array();
			$name 				= ucwords($customer['name']);
			$id 				= $customer['id'];
			$email 				= $customer['email'];
			$total_orders 		= $customer['total_orders'];
			$total_revenue 		= money_format('%!.2n',$customer['total_revenue']);
			$avg_order_value 	= money_format('%!.0n',$customer['avg_order_value']);
			$age 				= ucwords($customer['num_days']);
			$last_order 		= ucwords($customer['last_order_days']);
			$cities 			= ucwords($customer['cities']);
			$countries 			= ucwords($customer['countries']);
			array_push($row, $name, $id, $email, $total_orders, $total_revenue, $avg_order_value, $age, $last_order, $cities, $countries);
			array_push($excel_data, $row);
		
		}
	}
}

//echo "<pre>";
//print_r($excel_data);
//echo "</pre>";

//exit();

$objPHPExcel = new PHPExcel();

$objPHPExcel->getProperties()->setCreator("Deepredink");
$objPHPExcel->getProperties()->setLastModifiedBy("Deepredink");
$objPHPExcel->getProperties()->setTitle("Office 2007 XLSX Test Document");
$objPHPExcel->getProperties()->setSubject("Office 2007 XLSX Test Document");
$objPHPExcel->getProperties()->setDescription("Leads");

$objPHPExcel->getActiveSheet()->fromArray($excel_data, null, 'A1');
$time = date('d-F-Y', time());
header("Content-Type: application/xlsx");
header("Content-Disposition: attachment; filename=taruni_loyal_customers_{$time}.xlsx");
header("Pragma: no-cache");
header("Expires: 0");

$highestColumn = $objPHPExcel->getActiveSheet()->getHighestDataColumn();
$nCols         = PHPExcel_Cell::columnIndexFromString($highestColumn);

foreach (range(0, $nCols) as $col) {
	//$objPHPExcel->getActiveSheet()->getColumnDimensionByColumn($col)->setAutoSize(true);
	$objPHPExcel->getActiveSheet()->getColumnDimensionByColumn($col)->setWidth(30);
}

$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
$objWriter->save('php://output');
