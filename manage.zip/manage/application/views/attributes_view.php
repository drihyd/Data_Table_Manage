<div class="sub-header">Manage Attributes</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'attributes/add'; ?>" class="btn btn-default btn-sm">Add <strong>Add</strong> New Attribute +</a> 
            <!-- &nbsp;<a href="<?php echo $this->config->base_url().'attribute_values/add'; ?>" class="btn btn-default btn-sm">Add <strong>Add</strong> New Attribute Value +</a -->
          </div>
        </div>
        
        
        <div class="row">
          <div class="col-xs-12">

<?php
                      echo $this->session->flashdata('message');
?>
            
            <div class="table-responsive">
              <table class="table dataTableNoPagination">
                <thead>
                  <tr>
                    <th>Attribute Value</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
<?php
foreach($attributes as $attribute) { ?>
            
                  <tr class="warning" id="<?php echo strtolower(str_replace(' ', '-', $attribute->attr_name)); ?>">
                    <td><?php echo ucwords($attribute->attr_name); ?></td>
                    <td class="edit-column tiny-col" width="50px">
                      <a href="<?php echo $this->config->base_url().'attributes/edit/'.$attribute->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'attributes/delete/'.$attribute->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
                  
<?php
} ?>

                </tbody>
              </table>  
            </div>
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

</div>
  <!-- /#main-content -->
