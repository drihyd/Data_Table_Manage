<div class="sub-header">Manage Pages</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'pages/add'; ?>" class="btn btn-default btn-sm">New Page +</a>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table dataTableNoSort">
                <thead>
                  <tr>
                    <th class="table-sort">Page Name</th>
                    <th class="table-sort">Title</th>
                    <th>Slug</th>
                    <th width="100px">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  
<?php if($pages) {
        foreach ($pages as $page) { ?>
                  <tr>
                    <td><?php echo ucfirst($page->name); ?></td>
                    <td><?php echo ucfirst($page->title); ?></td>
                    <td><?php echo $page->slug; ?></td>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'pages/edit/'.$page->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'pages/delete/'.$page->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop
      } //end of if 
      else {  ?>                  
                  <tr align='center'>
                    <td colspan=7><a href="<?php echo $this->config->base_url().'pages/add'; ?>" class="btn btn-default btn-sm">Start adding pages +</a></td>
                  </tr
<?php } // end of else ?>                  
                </tbody>
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
