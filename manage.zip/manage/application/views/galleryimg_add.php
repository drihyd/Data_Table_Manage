<div class="sub-header">Add Gallery Image</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open_multipart('galleryimgs/save/', array('class' => 'margin-top-15')); ?>
              <legend>Basic Info</legend>
            
              <div class="form-group margin-top-15">
                <label for="galleryimgImage" class="control-label">Add gallery Image</label>
                <input type="file" class="form-control" id="galleryimgImage" name="galleryimgImage" value="">
              </div>
              <div class="form-group inline">
                <label for="galleryimgCaption" class="control-label">Caption</label>
                <input type="text" class="form-control" id="galleryimgCaption" name="galleryimgCaption" value="">
              </div>
              <div class="form-group inline">
                <label for="galleryimgParentProject" class="control-label">Parent Project</label>
                <select class="form-control" name="galleryimgParentProject" id="galleryimgParentProject" readonly>
                  <option value="<?php echo $project['id']; ?>" selected><?php echo ucfirst($project['name']); ?></option>
                </select>
              </div>
               
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
