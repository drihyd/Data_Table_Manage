<?php setlocale(LC_MONETARY, 'en_IN'); ?>
 <style>
    body {
        font-family: 'Arial', sans-serif;
        font-size: 14px;
        padding-left: 0 !important;
        line-height: 140%;
    }

</style>
<section class="stats-section" id="invoiceBox">
      <div class="container-fluid">
       
        Cart ID: <a href="<?php echo $this->config->base_url().'carts/view/'.$order_details->cart_id; ?>"><?php echo $order_details->cart_id; ?></a><br>
        Customer ID: <a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order_details->customer_id; ?>"><?php echo $order_details->customer_id; ?></a><br>
        Grand Total: Rs. <?php echo money_format('%!.2n', $order_details->grand_total_inr); ?> (incl. shipping, discounts, coupons)<br>
        Grand Total USD: $ <?php echo money_format('%!.2n', $order_details->grand_total_usd); ?> (incl. shipping, discounts, coupons)<br><br>
        <?php echo $order_details->order_snapshot; ?>
