  </div>
  <!-- /#main-content -->
  
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="<?php echo $this->config->base_url(); ?>js/vendor/jquery-1.11.0.min.js"><\/script>')</script>
  
  <script src="<?php echo $this->config->base_url(); ?>js/vendor/bootstrap.min.js"></script>
  <!-- script src="<?php echo $this->config->base_url(); ?>js/vendor/tablesort.js"></script -->
  <script src="<?php echo $this->config->base_url(); ?>js/jquery-ui/jquery-ui.min.js"></script>
  <script src="//cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>
  <script src="//cdn.datatables.net/plug-ins/3cfcc339e89/integration/jqueryui/dataTables.jqueryui.js"></script>
  
  <?php if(isset($tinyMC)) : ?>
  <script src="//tinymce.cachefly.net/4.1/tinymce.min.js"></script>
  <script>
    tinymce.init({
      selector:'textarea.mce',
      plugins: ["textcolor", "advlist autolink lists link image charmap print preview anchor", "searchreplace visualblocks code fullscreen", "insertdatetime media table contextmenu paste", "hr"],
      toolbar: "forecolor backcolor insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
    });
  </script>
  <?php endif; ?>
  <script src="<?php echo $this->config->base_url(); ?>js/main.js"></script>
  <script>
    $(document).ready(function() {
<?php
if( isset( $sidebar_element ) ) : ?>
        $('#<?php echo $sidebar_element; ?>').addClass('active');
<?php
endif;
if( isset( $sidebar_subelement ) ) : ?>
        $('#<?php echo $sidebar_subelement; ?>').addClass('active');
        $('#<?php echo $sidebar_element; ?>-dropmenu').addClass('in');
<?php
endif; 
?>    
    });

  </script>
  
  <script>
    $('#bulkApproveAll').click(function() {
      if($(this).is(":checked")) {
        $('.bulkApprove').prop('checked', true);
      }
      else {
        $('.bulkApprove').prop('checked', false);
      }
    });
  </script>
  
</body>
</html>
