<div class="sub-header">Export Customers</div>
<section class='stats-section'>
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12">
				
				<?php echo $this->session->flashdata('form_errors'); ?>
				
				<a href="<?php echo $this->config->base_url() . 'export_customers/all'; ?>" class="btn btn-link">All</a>
				<a href="<?php echo $this->config->base_url() . 'export_customers/domestic_orders'; ?>" class="btn btn-link">Domestic</a>
				<a href="<?php echo $this->config->base_url() . 'export_customers/foreign_orders'; ?>" class="btn btn-link">Foreign</a>
				<a href="<?php echo $this->config->base_url() . 'export_customers/zero_orders'; ?>" class="btn btn-link">Zero Orders</a>
				<a href="<?php echo $this->config->base_url() . 'export_customers/one_order'; ?>" class="btn btn-link">One Order</a>
				<a href="<?php echo $this->config->base_url() . 'export_customers/repeat_orders'; ?>" class="btn btn-link">Repeat Orders</a>
				
				<form class="form-inline" style="display: inline-block;border: 1px dashed #f4f4f4;background:#f4f4f4;padding: 9px;" method="POST" action="<?php echo $this->config->base_url() . 'export_customers/category'; ?>">
					By Category: 
					<select class="form-control input-sm" name="category">
<?php
foreach($categories as $category) { ?>
						<option value="<?php echo $category->id; ?>"><?php echo ucwords($category->name); ?></option>
<?php
} ?>
					</select>
					
					<input type="submit" class="btn btn-default" value="Export">
				</form>
				
			</div>
		</div>
	</div>
</section>
