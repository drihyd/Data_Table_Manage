<div class="sub-header">Manage Products</div>
<section class="stats-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12">
				<table class="table dataTable">
					<thead>
						<tr>
							<th width="20" style="width: 50px;">ID</th>
							<th>Category</th>
							<th>S</th>
							<th>M</th>
							<th>L</th>
							<th>XL</th>
							<th>XXL</th>
							<th>Unstitched</th>
							<th width="20" style="width: 50px;">Actions</th>
						</tr>
					</thead>
					<tbody>
<?php
foreach($reorder_values as $value) { ?>
						<tr>
							<td><?php echo $value->id; ?></td>
							<td><?php echo ucfirst($category_index[$value->cat_id]->name); ?></td>
							<td><?php echo $value->s; ?></td>
							<td><?php echo $value->m; ?></td>
							<td><?php echo $value->l; ?></td>
							<td><?php echo $value->xl; ?></td>
							<td><?php echo $value->xxl; ?></td>
							<td><?php echo $value->unstitched; ?></td>
							<td width="20" style="width: 50px;"><a href="<?php echo $this->config->base_url().'reorder/edit/'.$value->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a></td>
						</tr>
<?php
} ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</section>
