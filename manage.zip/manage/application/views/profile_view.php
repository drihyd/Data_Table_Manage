<div class="sub-header">Profile</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
<?php
if(isset($success)) : ?>
            <div class="label label-success"><?php echo $success; ?></div><br><br>
<?php
endif; ?>
            <p><strong>Username: </strong> <?php echo $user_details->username; ?></p>
            <p><strong>User-type: </strong> <?php echo $user_details->type; ?></p>
            <p><strong>Email: </strong> <?php echo $user_details->email; ?></p>
            <p><a href="<?php echo $this->config->base_url().'profile/change_pass'; ?>" class="btn btn-sm btn-brand">Change Password</a></p>

          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
