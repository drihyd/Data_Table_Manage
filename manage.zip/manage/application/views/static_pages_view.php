<div class="sub-header">All Static Pages</div>
<section class="stats-section">
	<div class="container-fluid">
		<div class="row">
            <div class="col-sm-12">
<?php
	echo $this->session->flashdata('message');
?>
				
				<table class="table dataTable orders-table">
					<thead>
						<tr>
							<th width="200">Page Name</th>
							<th>Title</th>
							<th>Description</th>
							<th>Keywords</th>
							<th width="60">Actions</th>
						</tr>
					</thead>
					<tbody>
<?php
if(count($static_pages) > 0) {
	foreach($static_pages as $page) { ?>
						<tr>
							<td>
								<a href="<?php echo $this->config->base_url().'static_page_seo/edit/'.$page->id; ?>"><?php echo ucwords($page->page); ?></a>
							</td>
							<td><?php echo substr(ucwords($page->seo_title), 0, 100) . '...'; ?></td>
							<td><?php echo substr(ucfirst($page->seo_desc), 0, 100) . '...'; ?></td>
							<td><?php echo substr(ucwords($page->seo_keywords), 0, 100) . '...'; ?></td>
							<td class="edit-column">
								<a href="<?php echo $this->config->base_url().'static_page_seo/edit/'.$page->id; ?>" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
							</td>
						</tr>
<?php
	}
} else { ?>
						<tr>
							<td colspan="5">No Pages Found</td>
						</tr>
<?php
} ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</section>
