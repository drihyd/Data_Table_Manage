<?php setlocale(LC_MONETARY, 'en_IN'); ?>
 <style>
     
    #sidebar-wrapper, header {
        display: none !important;
    }
    body {
        font-family: 'arial';
        font-size: 14px;
        padding-left: 0 !important;
    }
    th {
        text-align: left;
    }
    #invoiceBox {
        display: block;
        margin: 0 auto;
    }
    th {
        font-size: 12px;
        padding: 5px;
    }
    td {
        font-size: 12px;
    }
    #invoiceBox td {
        font-size: 12px;
        padding: 5px;
    }
    h1, h2 {
        margin: 0;
    }
    p { 
        margin: 0;
    }
    hr {
        margin: 10px 0;
    }
    
    @media print {
        #back-link {
            display: none;
        }
        #printInv {
            display: none;
        }
    }

</style>

  

    <section class="stats-section" id="invoiceBox">
      <div class="container-fluid">
       
        
        <div class="row">
          
<?php
if($cart_details->ship_to_address != '') { ?>          
          <div class="col-sm-6">
            
              <small>Ship to:</small><br>
              <b><?php echo ucwords($cart_details->ship_to_name); ?></b>
              <p><?php echo $cart_details->ship_to_address; ?><br>
              <?php echo $cart_details->ship_to_city; ?>, <?php echo $cart_details->ship_to_state; ?> <?php echo $cart_details->ship_to_postalcode; ?></p>
              <p>Phone: <?php echo $cart_details->ship_to_phone; ?></p>
            
          </div>
          <br>
          <div class="col-sm-6">
            
              <small>Bill to:</small><br>
              <b><?php echo ucwords($cart_details->bill_to_name); ?></b>
              <p><?php echo $cart_details->bill_to_address; ?><br>
              <?php echo $cart_details->bill_to_city; ?>, <?php echo $cart_details->bill_to_state; ?> <?php echo $cart_details->bill_to_postalcode; ?></p>
              <p>Phone: <?php echo $cart_details->bill_to_phone; ?></p>
            
          </div>
<?php
} ?>
        
        </div>
        <br>
        <hr>
        
        <div class="row">
            <div class="col-xs-12">
                <b>cart ID: <?php echo $cart_details->id; ?></b>
            </div>
        </div>
        
        <hr>
        <br>
        
        <div class="row">
            <div class="col-xs-12">
<?php
if($cart_details->checked_out == 1) { ?>              
                <strong><span class="label label-success">Checked out</span></strong>
<?php
} else { ?>
                <strong><span class="label label-danger">Not Checked out</span></strong>
<?php
} ?>
<?php
if($cart_details->payment_mode == 'cod') { ?>
                <br><strong>Cash On Delivery</strong>
<?php
} ?>
                <br><br>
                <table class="table table-condensed" bcart="1px" style="bcart-collapse: collapse;">
                    <thead>
                        <tr>
                            <th>Product Details</th>
                            <th align="right">Unit Price</th>
                            <th>Discount Percentage</th>
                            <th>Quantity</th>
                            <th>Net Price</th>
                        </tr>
                    </thead>
                    <tbody>
<?php
foreach($cart_items as $cart_item) { ?>
                        <tr>
                            <td>
                                <?php echo ucwords($products_list[$cart_item->id]->name); ?> <br> 
                                SKU Code: <?php echo $skus_list[$cart_item->id]->sku_code; ?> | 
                                cart Item ID: <?php echo $cart_item->id; ?> | 
                                cart ID: <?php echo $cart_item->cart_id; ?> |
<?php if($cart_item->custom) { ?> 
                                <span class="label label-default">Customized</span> | 
<?php } ?>
<?php if($skus_list[$cart_item->id]->size != null) { ?> 
                                Size: <?php echo strtoupper($skus_list[$cart_item->id]->size); ?>  
<?php } else { ?>
                                <span class="label label-default">Unstitched</span>
<?php 
      } ?> 
                            </td>
                            <td align="right">Rs. <?php echo money_format('%!.2n', $cart_item->unit_price); ?></td>
                            <td align="center"><?php echo $cart_item->discount_percentage; ?> %</td>
                            <td align="right"><?php echo $cart_item->qty; ?></td>
                            <td align="right">Rs. <?php echo money_format('%!.2n', $cart_item->price); ?></td>
                        </tr>
<?php
} ?>
                        <tr>
                            
                          <td colspan="3" style="text-align:right;"><strong>Total</strong></td>
                          <td class="total-num"><?php echo $cart_details->total_items; ?> items</td>
                          
                          <td class="total-sum" style="text-align: right"><strong>Rs. <?php echo money_format('%!.2n',$cart_details->total_amount); ?></strong></td>
                          
                        </tr>
                        <tr>
                          
                          <td colspan="3" style="text-align:right;"><strong>Total Weight</strong></td>
                          <td class="toal-num"><?php echo $cart_details->total_shipping_weight; ?> KG(s)</td>
                          
                          <td class="total-sum" style="text-align: right"></td>
                          
                        </tr>
                        <!-- tr>
                          
                          <td colspan="3" style="text-align:right;"><strong>Total Shipping Cost for <?php echo ucwords($cart_details->ship_to_city); ?></strong></td>
                          <td class="toal-num"><?php echo $cart_details->shipping_rate; ?> / KG</td>
                          
                          <td class="total-sum" style="text-align: right"><strong> Rs. <?php echo money_format('%!.2n',$cart_details->total_shipping_weight * $cart_details->shipping_rate); ?></strong></td>
                          
                        </tr>
                        
<?php
if($cart_details->cod_fee > 0) { ?>                          
                          <tr>
                            
                            <td colspan="3" style="text-align:right;"><strong>Convenience fee for Cash on Delivery carts below Rs. 1500</strong></td>
                            <td class="toal-num">Rs. 150</td>
                            
                            <td class="total-sum" style="text-align: right"><strong> Rs. 150.00</strong></td>
                            
                          </tr>
<?php
} ?>                        
                        
                        <tr>
                          
                          <td colspan="3" style="text-align:right;"><strong>Tax for <?php echo ucwords($cart_details->ship_to_city); ?></strong></td>
                          <td class="toal-num"><?php echo $cart_details->tax_percentage; ?> %</td>
                          
                          <td class="total-sum" style="text-align: right"><strong><?php echo 'Rs. ' . money_format('%!.2n', $cart_details->total_amount * ($cart_details->tax_percentage/100) ); ?></strong></td>
                          
                        </tr>
                        <tr>
                          
                          <td colspan="3" style="text-align:right;"><strong>Grand Total</strong></td>
                          <td class="toal-num"></td>
                          <td class="total-sum" style="text-align: right"><strong>Rs. <?php echo money_format('%!.2n', $cart_details->grand_total); ?></strong></td>
                          
                        </tr -->
                        
                    </tbody>
                </table>
            </div>
        </div>
      
<?php if(count($customizations_list) > 0) : ?>
        
        <div class="row margin-top-30">
            <div class="col-xs-12">
                <h3>Alterations</h3>
                
                <div class="table-responsive">
                <table class="table table-condensed" id="customList">
                    
                    <thead>
                        <tr>
                            <th>Order Item ID</th>
                            <th>SKU Code</th>
                            <th>Product Name</th>
                            <th>Alteration details</th>
                        </tr>
                    </thead>
                    
                    <tbody>
<?php
foreach($cart_items as $item) {
	if($item->alterations != '') { ?>
                        <tr>
							<td><?php echo $item->id; ?></td>
                            <td><?php echo $skus_list[$item->id]->sku_code; ?></td>
                            <td><?php echo ucwords($products_list[$item->id]->name); ?></td>
                            <td><?php echo ucfirst($item->alterations); ?></td>
                        </tr>
<?php
	}
} ?>
                    </tbody>
                </table>
                </div> <!-- ./table-resposnive -->
            </div>
          </div>
        
        
        <br>
        
        <div class="row">
            <div class="col-xs-12">
                <h3>Customizations</h3>
                <table class="table table-condensed"  bcart="1px" style="bcart-collapse: collapse;">
                    <thead>
                        <tr>
                            <th>cart Item ID</th>
                            <th>SKU Code</th>
                            <th>Product Name</th>
                            <th>top collar</th>
                            <th>top shoulder</th>
                            <th>top armhole</th>
                            <th>top sleeve length</th>
                            <th>top chest</th>
                            <th>top waist</th>
                            <th>top hip</th>
                            <th>top length</th>
                            <th>bottom waist</th>
                            <th>bottom thigh</th>
                            <th>bottom knee</th>
                            <th>bottom bottom</th>
                            <th>bottom seat</th>
                            <th>bottom length</th>
                        </tr>
                    </thead>
                    <tbody>
<?php
foreach($customizations_list as $customization) { ?>
                        <tr>
                            <td><?php echo $customization->cart_item_id; ?></td>
                            <td><?php echo $skus_list[$customization->cart_item_id]->sku_code; ?></td>
                            <td><?php echo ucwords($products_list[$customization->cart_item_id]->name); ?></td>
                            <td align="left"><?php echo $customization->top_collar; ?></td>
                            <td align="left"><?php echo $customization->top_shoulder; ?></td>
                            <td align="left"><?php echo $customization->top_armhole; ?></td>
                            <td align="left"><?php echo $customization->top_sleevelength; ?></td>
                            <td align="left"><?php echo $customization->top_chest; ?></td>
                            <td align="left"><?php echo $customization->top_waist; ?></td>
                            <td align="left"><?php echo $customization->top_hip; ?></td>
                            <td align="left"><?php echo $customization->top_length; ?></td>
                            <td align="left"><?php echo $customization->bottom_waist; ?></td>
                            <td align="left"><?php echo $customization->bottom_thigh; ?></td>
                            <td align="left"><?php echo $customization->bottom_knee; ?></td>
                            <td align="left"><?php echo $customization->bottom_bottom; ?></td>
                            <td align="left"><?php echo $customization->bottom_seat; ?></td>
                            <td align="left"><?php echo $customization->bottom_length; ?></td>
                        </tr>
<?php
} ?>
                        
                    </tbody>
                </table>
            </div>
        </div>
        
        
        
        
<?php endif; ?>
      </div>
    </section>
    
    <br>
    <!-- button id="printInv">Print Invoice</button --> &nbsp;&nbsp;&nbsp; <a id="back-link" href="<?php echo $this->config->base_url()."customers"; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-chevron-left"></span> < Back</a>
        
</div>
<!-- /#main-content -->

<br><br>



