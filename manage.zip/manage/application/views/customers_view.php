<div class="sub-header">Manage Customers</div>
    <section class="stats-section">
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table dataTableNoSort">
                <thead>
                  <tr>
                    <th class="table-sort">Customer ID</th>
                    <th class="table-sort">Email</th>
                    <th class="table-sort">Name</th>
                    <th class="table-sort">Phone</th>
                    <th class="table-sort" width="150px">Reg. Date</th>
                    <th class="table-sort">Subscribed to Newsletter</th>
                    <th width="50px">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  
<?php if($customers) {
        foreach ($customers as $customer) { ?>
                  <tr>
<?php
if( $customer->is_guest ) { ?>                     
                    <td><?php echo $customer->id; ?> <span class="label label-danger">guest</span></td>
<?php
} else { ?>
                    <td><?php echo $customer->id; ?></td>
<?php
} ?>

<?php
if($customer->is_guest == 1) { ?>
                    <td><?php echo $customer->guest_email; ?></td>
<?php
} else { ?>
					<td><?php echo $customer->email; ?></td>
<?php
} ?>
                    <td><?php echo ucwords($customer->name); ?></td>
                    <td><?php echo $customer->phone; ?></td>
<?php
if($customer->date != '0000-00-00 00:00:00') { ?>                    
                    <td><?php echo date('d M, Y, h:i a', strtotime($customer->date)); ?></td>
<?php
} else { ?>
					<td>- NA -</td>
<?php
} ?>
<?php
if($customer->donot_send_newsletter == 0) { ?>
                    <td>Yes</td>
<?php
} else { ?>
                    <td><strong class='text-danger'>No</strong></td>
<?php
} ?>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'customers/customer_info/'.$customer->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
                      <!-- a href="<?php echo $this->config->base_url().'customers/delete/'.$customer->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a -->
                    </td>
                  </tr>
<?php   } // end of foreach loop
      } //end of if 
      else {  ?>                  
                  <tr align='center'>
                    <td colspan=7><a href="<?php echo $this->config->base_url().'pages/add'; ?>" class="btn btn-default btn-sm">Start adding pages +</a></td>
                  </tr
<?php } // end of else ?>                  
                </tbody>
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
