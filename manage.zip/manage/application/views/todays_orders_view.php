<?php
setlocale(LC_MONETARY, 'en_IN');
?>

<!DOCTYPE html>
<html>
<head>
	<title>Newly Placed Orders</title>
	<link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/bootstrap.min.css">
	<!-- link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/style.css" -->
	
	<style>
		body {
			padding:0;
			max-width: 1000px;
			margin: 0 auto;
			font-size: 12px;
			color: #333;
			font-family: Arial, sans-serif;
		}
		
		table, table.table {
			margin: 15px 0;
		}
		
		.table>thead>tr>th,
		.table>tbody>tr>th,
		.table>tfoot>tr>th,
		.table>thead>tr>td,
		.table>tbody>tr>td,
		.table>tfoot>tr>td {
			padding: 0;
		}
		
		.table.half-tds td, .table.half-tds th {
			width: 50%;
		}
		
		th {
			font-weight: normal;
		}
		
		.table>tbody+tbody {
			//border: none;
		}
		
		.align-right {
			text-align: right;
		}
		
		.table>thead>tr>th,
		.table>tbody>tr>th,
		.table>tfoot>tr>th,
		.table>thead>tr>td,
		.table>tbody>tr>td,
		.table>tfoot>tr>td {
			padding: 0px;
		}
		
		th.right-algn {
			text-align: right;
		}
		
		td.heading, th.heading {
			font-weight: bold;
		}
		
		.bold {
			font-weight: bold;
		}
		
		article {
			page-break-after: always;
			padding-top: 60px;
			padding-bottom: 60px;
			border-bottom: 1px dashed #000;
		}
		
		.logo {
			margin: 15px 0 30px;
		}
		
		hr {
			margin: 9px 0;
			display: none;
		}
		
		h2.heading {
			font-size: 15px;
			font-weight: bold;
			margin: 0;
		}
		
		@media print{
			body {
				max-width: none;
				margin: 0;
			}
			article {
				padding: 0;
				border: none;
				margin-bottom: 0;
			}
		}
		
	</style>
	
</head>
<body>

<?php
foreach($orders as $order) {
	
	$customer_details = $customer_index[$order->customer_id];
	$payment_details = $payment_details_index[$order->id];
	
	//$alterations = 
	//$order_items =  ?>
	
	<article>
		<img src="<?php echo $this->config->base_url().'img/logo.png'; ?>" width="120" class="logo">
		
		<table class="table half-tds">
			
			<thead>
				<tr>
					<th>
						<strong>Order ID:</strong> <?php echo $order->id; ?>
					</th>
					<th class="right-algn">
						<strong>Placed On:</strong> <?php echo date('M d, Y', strtotime($order->ordered_on)); ?>
					</th>
				</tr>
			</thead>
		
		</table>
		<hr>
		<table class="table half-tds">
						
			<tbody>
				
				<tr>
					<td class="heading">Placed By</td>
					<td><?php echo ucwords($customer_details->name); ?> [<?php echo ucwords($customer_details->id); ?>]</td>
				</tr>
				
				<tr>
					<td class="heading">Total Amount</td>
					<td><?php echo strtoupper($order->currency); ?> <?php echo money_format('%!.2n',$order->grand_total) ?></td>
				</tr>
				
				<tr>
					<td class="heading">Payment Status</td>
					<td><?php echo ucwords($order->payment_status); ?></td>
				</tr>

<?php
if($order->payment_mode == 'epay') {
	$payment_details = $payment_details_index[$order->id];
	$payment_type = 'PayPal';
	if($payment_details->paypal_payer_id == NULL) {
		$payment_type = 'EBS';
	} ?>
	
				<tr>
					<td class="heading">Payment Mode</td>
					<td><?php echo $payment_type; ?></td>
				</tr>
				
				<tr>
					<td class="heading">Transaction ID</td>
					<td><?php echo $payment_details->transaction_id; ?></td>
				</tr>
<?php
} else { ?>
				<tr>
					<td class="heading">Payment Mode</td>
					<td><?php echo strtoupper($order->payment_mode); ?></td>
				</tr>

<?php
} ?>
				
			</tbody>
		
		</table>
		<hr>
		
		<table class="table half-tds">
			<thead>
				<tr>
					<th class="heading">Shipping Address</th>
					<th class="heading">Billing Address</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><?php echo ucwords($order->ship_to_name); ?></td>
					<td><?php echo ucwords($order->bill_to_name); ?></td>
				</tr>
				<tr>
					<td>
						<?php echo $order->ship_to_email; ?><br>
						<?php echo ucwords($order->ship_to_phone); ?><br>
<?php
if($order->ship_to_alt_phone != '') { ?>
						<?php echo ucwords($order->ship_to_alt_phone); ?><br>
<?php
} ?>
					</td>
					<td><?php echo $order->bill_to_email; ?><br><?php echo ucwords($order->bill_to_phone); ?></td>
				</tr>
				<tr>
					<td><?php echo ucwords($order->ship_to_address); ?></td>
					<td><?php echo ucwords($order->bill_to_address); ?></td>
				</tr>
				<tr>
					<td><?php echo ucwords($order->ship_to_city); ?>, <?php echo ucwords($order->ship_to_state); ?>, <?php echo ucwords($order->ship_to_country); ?></td>
					<td><?php echo ucwords($order->ship_to_city); ?>, <?php echo ucwords($order->bill_to_state); ?>, <?php echo ucwords($order->bill_to_country); ?></td>
				</tr>
				<tr>
					<td><?php echo ucwords($order->ship_to_postalcode); ?></td>
					<td><?php echo ucwords($order->bill_to_postalcode); ?></td>
				</tr>
			</tbody>
		</table>
		<hr>
		
		<!-- h2 class="heading">Order Summary</h2 -->
		<table class="table">
				<tr>
					<th class="heading">S. No.</th>
					<th class="heading">Product</th>
					<th class="heading align-right">Price (INR)</th>
					<th class="heading align-right">Discount</th>
					<th class="heading align-right">Qty.</th>
					<th class="heading align-right">Net Price (INR)</th>
				</tr>
			</thead>
			
			<tbody>
<?php
$order_items = $order_items_index[$order->id];
$order_coupon = NULL;
if(isset($coupons_index[$order->id])) {
	$order_coupon = $coupons_index[$order->id];
}

$customization_exists = NULL;
$alteration_exists = NULL;

$i = 0;


# -------------
$total_inr = 0;

$shipping_cost_inr = $order->shipping_cost;
if($order->currency == 'usd') {
	$shipping_cost_inr = $order->shipping_cost * 65;
}

if($order->cod_fee > 0) {
	$shipping_cost_inr += $order->cod_fee;
}

$coupon_discount_inr = 0;
# -------------

foreach($order_items as $item) {
	$i += 1;
	$sku_details = $sku_details_index[$item->sku_id];
	$product_details = $product_details_index[$item->product_id];
	
	$alteration_phrase = NULL;
	
	if($item->alterations != '') {
		$alteration_exists = 1;
		$alteration_phrase = 'Refer alterations';
	}
	
	$customizations = NULL;
	
	$customizations_phrase = NULL;
	if(isset($customizations_index[$item->id])) {
		$customization_exists = 1;
		$customizations = $customizations_index[$item->id];
		$customizations_phrase = 'Refer customizations';
	}
	
	# -----------
	$product_unit_price_inr = $sku_details->price_inr;
	$product_price_inr = $product_unit_price_inr * $item->qty;
	$product_discounted_inr = $product_price_inr * (1 - ($item->discount_percentage/100));
	$product_net_inr_price = $product_discounted_inr;
	$total_inr += $product_discounted_inr;
	# -----------
	
	
	?>
				<tr>
					<td style="vertical-align: middle;"><?php echo $i; ?></td>
					<td>
						<small>SKU Code: <?php echo $sku_details->sku_code; ?></small><br>
						<strong><?php echo ucwords($product_details->name); ?></strong><br>
						<small>Size: <strong><?php echo strtoupper($sku_details->size); ?></strong></small> | 
						<!-- small>INR: <strong><?php echo money_format('%!.2n',$sku_details->price_inr); ?></strong></small --> 
						<small>USD <strong><?php echo money_format('%!.2n',$sku_details->price_usd); ?></strong></small> 
						<?php if($alteration_phrase) echo ' | ' . $alteration_phrase; ?>
						<?php if($customizations_phrase) echo ' | ' . $customizations_phrase; ?>
					</td>
					<td align="right">
						<?php echo money_format('%!.2n',$product_unit_price_inr) ?>
						<?php //echo money_format('%!.2n',$item->unit_price) ?>
						<?php
						if($item->gst > 0) {
							if($item->unit_price >= 1000) {
								echo "(12% GST)";
							} else {
								echo "(5% GST)";
							}
						} ?>
					</td>
					<td align="right"><?php echo $item->discount_percentage; ?> %</td>
					<td align="right"><?php echo $item->qty; ?></td>
					<td align="right"><?php echo money_format('%!.2n',$product_net_inr_price) ?></td>
					<!-- td align="right"><?php echo money_format('%!.2n',$item->net_price) ?></td -->
				</tr>
<?php
	} ?>
				<tr>
					<td colspan="4" align="right"><strong>Total Items</strong></td>
					<td align="right"><?php echo $order->total_items; ?></td>
					<td align="right"><strong><?php echo money_format('%!.2n',$total_inr); ?></strong></td>
					<!-- td align="right"><strong><?php echo money_format('%!.2n',$order->total_amount); ?></strong></td -->
				</tr>

<?php
if( (count($order_coupon) > 0) && ($order_coupon->type == 'rupees_off') ) { ?>

				<tr>
					<td colspan="4" align="right"><strong>Coupon <?php echo $order_coupon->coupon_code; ?> | <?php echo ucfirst($order_coupon->title); ?></strong></td>
					<td align="right">&nbsp;</td>
					<!-- td align="right"><strong> - Rs. <?php echo money_format('%!.2n',$order_coupon->discount_amount); ?></strong></td -->
					
					<?php 
						$coupon_discount_inr = $order_coupon->discount_amount;
						if($order->currency == 'usd') {
							$coupon_discount_inr = $order_coupon->discount_amount * 65;
						}
					?>
					<td align="right">
						<strong>
							- INR. <?php echo money_format('%!.2n', $coupon_discount_inr); ?>
							<?php
							if($order->currency == 'usd') { ?>
								(USD <?php echo money_format('%!.2n', $order_coupon->discount_amount); ?>)
							<?php
							} ?>
						</strong>
					</td>
					
				</tr>
<?php
} ?>

<?php
if( (count($order_coupon) > 0) && ($order_coupon->type == 'percent_off') ) { ?>

				<tr>
					<td colspan="4" align="right"><strong>Coupon <?php echo $order_coupon->coupon_code; ?> | <?php echo ucfirst($order_coupon->title); ?></strong></td>
					<td align="right">- <?php echo $order_coupon->value; ?> %</td>
					<!-- td align="right"><strong> - <?php echo money_format('%!.2n',$order_coupon->discount_amount); ?></strong></td -->
					
					<?php 
						$coupon_discount_inr = $total_inr * ($order_coupon->value/100);
					?>
					<td align="right">
						<strong>
							- <?php echo money_format('%!.2n', $coupon_discount_inr); ?>
							<?php
							if($order->currency == 'usd') { ?>
								(USD <?php echo money_format('%!.2n', $order_coupon->discount_amount); ?>)
							<?php
							} ?>
						</strong>
					</td>
					
				</tr>
<?php
} ?>
				
				<tr>
					<td colspan="4" align="right"><strong>Total Weight</strong></td>
					<td align="right"><?php echo $order->total_shipping_weight; ?> KG(s)</td>
					<td align="right"></td>
				</tr>
				
				<tr>
					<td colspan="4" align="right"><strong>Total Shipping Cost for <?php echo ucwords($order->ship_to_city); ?></strong></td>
					<td align="right"></td>
					<!-- td align="right"><strong><?php echo strtoupper($order->currency); ?> <?php echo money_format('%!.2n',$order->shipping_cost); ?></strong></td -->
					<td align="right">
						<strong>
							<?php echo 'INR'; ?> <?php echo money_format('%!.2n', $shipping_cost_inr); ?>
							<?php
							if($order->currency == 'usd' AND $order->shipping_cost > 0) { ?>
								(USD <?php echo money_format('%!.2n', $order->shipping_cost); ?>)
							<?php
							} ?>
						</strong>
					</td>
				</tr>

<?php
if( (count($order_coupon) > 0) && ($order_coupon->type == 'shipping_off') ) { ?>
				<tr align="right">
					<td colspan="4"><strong>Coupon <?php echo $order_coupon->coupon_code; ?> | <?php echo ucfirst($order_coupon->title); ?></strong></td>
					<td>&nbsp;</td>
					<td>
						<strong>
							- INR. <?php echo money_format('%!.2n', $shipping_cost_inr); ?>
							<?php
							if($order->currency == 'usd') { ?>
								(USD <?php echo money_format('%!.2n', $order->shipping_cost); ?>)
							<?php
							} ?>
						</strong>
					</td>
					
					<?php 
						$coupon_discount_inr = $order_coupon->discount_amount;
						if($order_details->currency == 'usd') {
							$coupon_discount_inr = $order_coupon->discount_amount * 65;
						}
					?>
					
				</tr>
<?php
} ?>

<?php
if($order->cod_fee > 0) { ?>                          
				<tr align="right">
					<td colspan="4"><strong>Convenience fee for Cash on Delivery orders below Rs. 1500</strong></td>
					<td>Rs. 150</td>
					<td><strong>150.00</strong></td>
				</tr>
<?php
} ?>
				<tr align="right">
					<td colspan="4"><strong>Tax for <?php echo ucwords($order->ship_to_city); ?></strong></td>
					<td><?php echo $order->tax_percentage; ?> %</td>
					<td><strong><?php echo money_format('%!.2n', $order->total_amount * ($order->tax_percentage/100) ); ?></strong></td>
				</tr>
				
				<tr align="right">
					<td colspan="4"><strong>Grand Total</strong></td>
					<?php
					if($order->currency == 'usd') { ?>
					<td><strong><?php echo 'USD' . ' ' . money_format('%!.2n', $order->grand_total); ?></strong></td>
					<?php
					} else { ?>
					<td></td>
					<?php
					} ?>
					<td><strong><?php echo 'INR' . ' ' . money_format('%!.2n', ($total_inr - $coupon_discount_inr + $shipping_cost_inr)); ?></strong></td>
				</tr>

			</tbody>
		</table>
		
<?php
if($customization_exists == 1) { ?>
			
		<h2 class="heading">Customizations</h2>
		
		<table class="table">
			<thead>
				<tr>
					<th class="heading">Order Item ID</th>
					<th class="heading">SKU Code</th>
					<th class="heading">Product Name</th>
					<th class="heading">top collar</th>
					<th class="heading">top shoulder</th>
					<th class="heading">top armhole</th>
					<th class="heading">top sleeve length</th>
					<th class="heading">top chest</th>
					<th class="heading">top waist</th>
					<th class="heading">top hip</th>
					<th class="heading">top length</th>
					<th class="heading">bottom waist</th>
					<th class="heading">bottom thigh</th>
					<th class="heading">bottom knee</th>
					<th class="heading">bottom bottom</th>
					<th class="heading">bottom seat</th>
					<th class="heading">bottom length</th>
				</tr>
			</thead>
			<tbody>
<?php
foreach($order_items as $item) {
	if(isset($customizations_index[$item->id])) {
		$customization = $customizations_index[$item->id];
		$sku_details = $sku_details_index[$item->sku_id];
		$product_details = $product_details_index[$item->product_id]; ?>
		
				<tr>
					<td><?php echo $item->id; ?></td>
					<td><?php echo $sku_details->sku_code; ?></td>
					<td><?php echo ucwords($product_details->name); ?></td>
					<td align="left"><?php echo $customization->top_collar; ?></td>
					<td align="left"><?php echo $customization->top_shoulder; ?></td>
					<td align="left"><?php echo $customization->top_armhole; ?></td>
					<td align="left"><?php echo $customization->top_sleevelength; ?></td>
					<td align="left"><?php echo $customization->top_chest; ?></td>
					<td align="left"><?php echo $customization->top_waist; ?></td>
					<td align="left"><?php echo $customization->top_hip; ?></td>
					<td align="left"><?php echo $customization->top_length; ?></td>
					<td align="left"><?php echo $customization->bottom_waist; ?></td>
					<td align="left"><?php echo $customization->bottom_thigh; ?></td>
					<td align="left"><?php echo $customization->bottom_knee; ?></td>
					<td align="left"><?php echo $customization->bottom_bottom; ?></td>
					<td align="left"><?php echo $customization->bottom_seat; ?></td>
					<td align="left"><?php echo $customization->bottom_length; ?></td>
				</tr>
<?php
	}
	
} ?>
				
			</tbody>
		</table>
<?php
} ?>

<?php
if($alteration_exists) { ?>
			
		<h2 class="heading">Alterations</h2>
		
		<table class="table">
			<thead>
				<tr>
					<th class="heading">Order Item ID</th>
					<th class="heading">SKU Code</th>
					<th class="heading">Product Name</th>
					<th class="heading">Size</th>
					<th class="heading">Alterations</th>
				</tr>
			</thead>
			<tbody>
<?php
foreach($order_items as $item) {
	if($item->alterations != '') {
		$sku_details = $sku_details_index[$item->sku_id];
		$product_details = $product_details_index[$item->product_id]; ?>
				<tr>
					<td><?php echo $item->id; ?></td>
					<td><?php echo $item->sku_code; ?></td>
					<td><?php echo ucwords($product_details->name); ?></td>
					<td><?php echo strtoupper($sku_details->size); ?></td>
					<td><?php echo ucfirst($item->alterations); ?></td>
				</tr>
<?php
		}
} ?>
				
			</tbody>
		</table>
<?php
} ?>
		
	</article>

<?php
} ?>

<script>
	window.print();
</script>

</body>
</html> 
