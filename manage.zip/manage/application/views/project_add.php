<div class="sub-header">Add Project</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open_multipart('projects/save/'); ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="projectName" class="control-label">Name</label>
                <input type="text" class="form-control nameForSlug" id="projectName" name="projectName" value="" required>
              </div>
              <div class="form-group inline">
                <label for="projectSlug" class="control-label">Slug</label>
                <input type="text" class="form-control slugForName" id="projectSlug" name="projectSlug" value="" required>
              </div>
              <div class="form-group">
                <label for="projectDesc" class="control-label">Description</label>
                <textarea class="form-control mce" id="projectDesc" name="projectDesc" required></textarea>
              </div>
              <legend>Display Picture</legend>
              <div class="form-group margin-top-15">
                <label for="projectDPChange" class="control-label">Add Display Image</label>
                <input type="file" class="form-control" id="projectDPChange" name="projectDPChange" required>
              </div>
              <input type="hidden" name="editType" value="create">
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
            
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
