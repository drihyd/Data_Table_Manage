<div class="sub-header">Add Child Category Under <?php echo ucwords($parent_category_details->name); ?></div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open('categories/save/', array('class' => 'edit-form')); ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="categoryName" class="control-label">Name</label>
                <input type="text" class="form-control input-sm nameForSlug" id="categoryName" name="categoryName" value="" required>
              </div>
              <div class="form-group inline">
                <label for="categorySlug" class="control-label">Slug</label>
                <input type="text" class="form-control input-sm slugForName" id="categorySlug" name="categorySlug" value="" required>
              </div>
              <div class="form-group inline">
                <label for="categoryParent" class="control-label">Select Parent Category</label>
                <select class="form-control input-sm" id="categoryParent" name="categoryParent" required>
                  <option value="<?php echo $parent_category_details->id; ?>"><?php echo ucwords($parent_category_details->name); ?></option>
                </select>
              </div>
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>              
              
            </form>
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
