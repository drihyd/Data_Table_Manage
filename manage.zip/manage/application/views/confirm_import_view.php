    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#discountimage" aria-controls="discountimage" role="tab" data-toggle="tab">Importing to DB</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-10 col-sm-offset-1">
            <div class="tab-content">
 <?php
    echo $this->session->flashdata('form-after-message');
    echo $this->session->flashdata('message');
?>             
              <div role="tabpanel" class="tab-pane active" id="discountimage">
                <div class='alert alert-success alert-dismissible fade in' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span></button><strong>Products and SKU's imported successfully. <a href="<?php echo $this->config->base_url().'products'; ?>">Verify Products ></a></strong></div>
              </div> <!-- ./#discountimage tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
