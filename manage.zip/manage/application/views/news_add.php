<div class="sub-header">Add News</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open('news/save/'); ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="newsTitle" class="control-label">Title</label>
                <input type="text" class="form-control nameForSlug" id="newsTitle" name="newsTitle" value="">
              </div>
              <div class="form-group inline">
                <label for="newsSlug" class="control-label">Slug</label>
                <input type="text" class="form-control slugForName" id="newsSlug" name="newsSlug" value="">
              </div>
              <div class="form-group inline">
                <label for="newsDate" class="control-label">Date</label>
                <input type="date" class="form-control" id="newsDate" name="newsDate" value="">
              </div>
              <div class="form-group">
                <label for="newsContent" class="control-label">Content</label>
                <textarea class="form-control mce" id="newsContent" name="newsContent"></textarea>
              </div>
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
