
<?php setlocale(LC_MONETARY, 'en_IN'); ?>
  
  <div class="sub-header">Actions</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12">
            <a href="<?php echo $this->config->base_url().'coupons'; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Back to All coupons</a>&nbsp;<a href="<?php echo $this->config->base_url().'coupons/edit/'.$coupon_details->id; ?>" class="btn btn-warning btn-xs"><span class="glyphicon glyphicon-edit"></span> Edit</a> 
            &nbsp;<a href="<?php echo $this->config->base_url().'coupons/delete/'.$coupon_details->id; ?>" class="btn btn-danger btn-xs delete-confirm"><span class="glyphicon glyphicon-trash"></span> Delete</a>
          </div>
        </div>
      </div> <!-- /#container-fluid -->
    </section>
  
  <div class="sub-header">Coupon Details</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          
          <div class="col-sm-6">
            <p>ID: <?php echo $coupon_details->id; ?></p>
            <p>Title: <?php echo ucfirst($coupon_details->title); ?></p>
            <p>Desc: <?php echo ucfirst($coupon_details->desc); ?></p>
            <p>Error Message: <?php echo ucfirst($coupon_details->error_message); ?></p>
            <p>Code: <b><?php echo $coupon_details->code; ?></b></p>
<?php
if($coupon_details->usage_limit == -1) { ?>            
            <p>Usage Limit: Infinite</p>
<?php
} else { ?>
            <p>Usage Limit: <?php echo ucfirst($coupon_details->usage_limit); ?></p>
<?php
} ?>
            <p>Times Used: <?php echo $coupon_details->times_used; ?></p>
            <p>Valid From: <?php echo date('d F, Y', strtotime($coupon_details->valid_from)); ?></p>
            <p>Valid To: <?php echo date('d F, Y', strtotime($coupon_details->valid_till)); ?></p>
<?php
if($coupon_details->owner_cust_id != 0) { ?>
            <p>Assigned to Customer: <a href="<?php echo $this->config->base_url().'customers/customer_info/'.$coupon_details->owner_cust_id; ?>"><?php echo $coupon_details->owner_cust_id; ?></a></p>
<?php
} ?>
            <p>Type: <?php echo ucfirst($coupon_details->type); ?></p>
<?php
if( ($coupon_details->type == 'rupees_off') ) { ?>           
            <p>Value: Rs. <?php echo $coupon_details->value; ?></p>
<?php
} ?>

<?php
if( ($coupon_details->type == 'percent_off') ) { ?>           
            <p>Value: <?php echo $coupon_details->value; ?> %</p>
<?php
} ?>
            <p>Minimum Order Value: Rs. <?php echo $coupon_details->min_order_value; ?></p>
            
                        
          </div>
          
        </div> <!-- /.row -->
        
        
        
      </div> <!-- /#container-fluid -->
    </section>
    
    <div class="sub-header">Coupon Usage Log</div>
    
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12">
            <div class="table-responsive">
              <table class="table dataTable no-footer">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Coupon ID</th>
                    <th>Order ID</th>
                    <th>Customer ID</th>
                    <th>Date</th>
                  </tr>                  
                </thead>                
                <tbody>
<?php
if(count($coupon_usage_log) > 0) {
  foreach($coupon_usage_log as $log) { ?>
                  <tr>
                    <td><?php echo $log->id; ?></td>
                    <td><?php echo $log->coupon_id; ?></td>
                    <td><a href="<?php echo $this->config->base_url().'orders/order_info/'.$log->order_id; ?>"><?php echo $log->order_id; ?></a></td>
                    <td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$log->customer_id; ?>"><?php echo $log->customer_id; ?></a></td>
                    <td><?php echo date("d F, Y", strtotime($log->date)); ?></td>
                  </tr>
<?php
  }
} else { ?>
                  <tr>
                    <td>No logs so far</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
<?php
} ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
       
</div>
<!-- /#main-content -->
