<div class="sub-header">Manage Categories</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'categories/parentadd'; ?>" class="btn btn-default btn-sm">Add <strong>Parent</strong> Category +</a> 
            &nbsp;<a href="<?php echo $this->config->base_url().'categories/add'; ?>" class="btn btn-default btn-sm">Add <strong>Child</strong> Category +</a>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table dataTableNoSort">
                <thead>
                  <tr>
                    <th>Category Name</th>
                    <th>Parent</th>
                    <th width="100px">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  
<?php if($categories) {
        foreach ($categories as $category) { ?>
                  
<?php     if($category->parent_id == 0) : ?>
                  <tr>
                    <td class="warning"><a href="<?php echo $this->config->base_url().'categories/category_info/'.$category->id; ?>"><strong><?php echo ucfirst($category->name); ?></strong></a></td>
                    <td class="warning"></td>
                    <td class="edit-column warning">
                      <a href="<?php echo $this->config->base_url().'categories/parentedit/'.$category->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'categories/parentdelete/'.$category->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php       foreach($categories as $parentfilter) {
              if($parentfilter->parent_id == $category->id) : ?>
                  <tr>
                    <td><a href="<?php echo $this->config->base_url().'categories/category_info/'.$parentfilter->id; ?>"><?php echo ucfirst($parentfilter->name); ?></a></td>
                    <td><a href="<?php echo $this->config->base_url().'categories/category_info/'.$category->id; ?>"><?php echo ucfirst($category->name); ?></a></td>
                    <td class="edit-column tiny-col">
                      <a href="<?php echo $this->config->base_url().'categories/edit/'.$parentfilter->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'categories/delete/'.$parentfilter->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php         endif;
            }
          endif;
        }
      }
      else {  ?>                  
                  <tr align='center'>
                    <td colspan=7><a href="<?php echo $this->config->base_url().'categories/add'; ?>" class="btn btn-default btn-sm">Start adding Categories +</a></td>
                  </tr
<?php } // end of else ?>                  
                </tbody>
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
