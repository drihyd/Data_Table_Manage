<style>
    .numbers-section {
        padding: 30px 0 0;
        background: #fff;
    }
    table.dataTable tbody th, table.dataTable tbody td {padding:5px 10px;}
    .stat-card {
        display: inline-block;
        border: 1px dashed #cacaca;
        padding: 15px 15px 3px;
        margin: 10px;
        text-align: center;
    }
    .stat-card.small {
        padding: 5px 20px;
    }
    .stat-card.small h1 {
        font-size: 16px;
    }
    .text-align-center {
        text-align: center;
    }
    @media(max-width:767px) {
        .stat-card, .stat-card.small {
            width: 100%;
            padding: 5px;
            margin: 5px;
        }
        .stat-card.small h1 {
            margin: 5px;
            font-size: 14px;
        }
        .stat-card.small p {
            margin: 0;
        }
    }
</style>
<?php
//date_default_timezone_set("Asia/Kolkata");
setlocale(LC_MONETARY, 'en_IN');
?>
<div class="sub-header">Participants</div>  
    
    <section class="numbers-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12 text-align-center">
                    <div class="edit-form inline stat-card small">
                        <h1><?php echo count($participants); ?></h1>
                        <p>Total Pairs</p>
                    </div>
                    <div class="edit-form inline stat-card small">
                        <h1><?php echo $completed.' / '.count($participants); ?></h1>
                        <p>Completed the Game</p>
                    </div>
                    <div class="edit-form inline stat-card small">
                        <h1><?php echo (count($participants) - $completed) .' / '.count($participants); ?></h1>
                        <p>Yet to Complete</p>
                    </div>
                    <div class="edit-form inline stat-card small">
                        <h1><?php echo $new_regs; ?></h1>
                        <p>Total New Registrations for the contest</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 text-align-center">
                    <div class="edit-form inline stat-card">
                        <h1><?php echo 'Rs. '.money_format('%!.0n', $total_coupon_value); ?></h1>
                        <p>Total Value of Coupons Given</p>
                    </div>
                     <div class="edit-form inline stat-card">
                        <h1><?php echo 'Rs. '.money_format('%!.0n', $total_claimed_value); ?></h1>
                        <p>Total Value of Coupons Claimed</p>
                    </div>
                    <div class="edit-form inline stat-card">
                        <h1><?php echo $claim_order_number; ?></h1>
                        <p>Orders Placed to claim coupons</p>
                    </div>
                    <div class="edit-form inline stat-card">
                        <h1><?php echo 'Rs. '.money_format('%!.0n', $claim_revenue); ?></h1>
                        <p>Revenue generated while claiming coupons</p>
                    </div><br>
                    <div class="edit-form inline stat-card">
                        <h1><?php echo $orders_from_new_regs; ?></h1>
                        <p>Orders from Newly Acquired Customers</p>
                    </div>
                    <div class="edit-form inline stat-card">
                        <h1><?php echo 'Rs. '.money_format('%!.0n', $revenue_from_new_regs); ?></h1>
                        <p>Revenue from Newly Acquired Customers</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="stats-section">
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table dataTable">
                <thead>
                  <tr>
                    <th>First Participant</th>
                    <th>Second Participant</th>
                    <th>Score</th>
                    <th>Discount Won</th>
                    <th>Game Status</th>
                    <th>Date</th>
                  </tr>
                </thead>
                
                  
<?php if(count($participants) > 0) { ?>
                <tbody>
<?php
        foreach ($participants as $participant) {
			$player_one = $customer_index[$participant->first_email];
			$player_two = $customer_index[$participant->second_email];?> 
                  <tr>
                    <td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$player_one->id; ?>"><?php echo ucwords($player_one->name); ?></a></td>
                    <td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$player_two->id; ?>"><?php echo ucwords($player_two->name); ?></a></td>
                    <td><?php echo $participant->score; ?></td>
                    <td><?php echo 'Rs. ' . $participant->discount_amount; ?></td>
                    <td><?php if($participant->second_answers != '') { echo "<span class='label label-success'>Complete</span>";} else {echo "<span class='label label-danger'>Incomplete</span>";} ?></td>
                    <td><?php echo date('d M Y', strtotime($participant->played_date)); ?></td>
                  </tr>
<?php   } // end of foreach loop ?>
                </tbody>
<?php
      } //end of if 
      else {  ?>  
                <tfoot>                
                  <tr align='center'>
                    <td colspan="6">No participants</td>
                  </tr>
                </tfoot>
<?php } // end of else ?>                  
                
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>
     
    
  </div>
  <!-- /#main-content -->

<?php
//echo "<pre>";
//print_r($claim_orders);
//echo "</pre>";
