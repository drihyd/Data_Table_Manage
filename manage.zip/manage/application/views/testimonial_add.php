<div class="sub-header">Add Page</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open('testimonials/save/'); ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="testimonialName" class="control-label">Customer's Name</label>
                <input type="text" class="form-control" id="testimonialName" name="testimonialName" value="" required>
              </div>
              <div class="form-group inline">
                <label for="testimonialSlug" class="control-label">Slug</label>
                <input type="text" class="form-control" id="testimonialSlug" name="testimonialSlug" value="" required>
              </div>
              <div class="form-group">
                <label for="testimonialContent" class="control-label">Testimonial Content</label>
                <textarea class="form-control mce" id="testimonialContent" name="testimonialContent" required></textarea>
              </div>
              <div class="alert alert-info"><small>To add <strong>SEO Meta Tags</strong>, save this basic info and edit the newly created testimonial</small></div>
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
