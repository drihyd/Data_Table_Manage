<script type="text/javascript" src="https://www.google.com/jsapi?autoload={'modules':[{'name':'visualization','version':'1.1','packages':['corechart', 'timeline', 'bar']}]}"></script>
<?php setlocale(LC_MONETARY, 'en_IN'); ?>
<div class="sub-header">From: <b><?php echo date('d M, Y', strtotime($get_from_date)); ?></b> &nbsp;&nbsp;&nbsp;&nbsp;To: <b><?php echo date('d M, Y', strtotime($get_to_date)); ?></b> &nbsp;&nbsp;(<?php echo $total_orders; ?>)</div>
<section class="stats-section">
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
				
                <?php echo $this->session->flashdata('form_errors'); ?>
				<?php echo form_open('analytics', array('method' => 'GET', 'class' => 'edit-form clearfix')) ?>
                    
                    <div class="form-group inline one-third">
						<label for="utm_source">Source</label>
						<select class="form-control input-sm" name="utm_source" id="utm_source">
							<option value="">All</option>
<?php
foreach($all_utm_sources as $key) {
	if(trim($key) == trim($get_utm_source)) { ?>
							<option value="<?php echo $key; ?>" selected><?php echo ucwords($key); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $key; ?>"><?php echo ucwords($key); ?></option>
<?php
	}
} ?>
						</select>
                    </div>
                    
					<div class="form-group inline one-third">
						<label for="utm_medium">Medium</label>
						<select class="form-control input-sm" name="utm_medium" id="utm_medium">
							<option value="">All</option>
<?php
foreach($all_utm_mediums as $key) {
	if(trim($key) == trim($get_utm_medium)) { ?>
							<option value="<?php echo $key; ?>" selected><?php echo ucwords($key); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $key; ?>"><?php echo ucwords($key); ?></option>
<?php
	}
} ?>
						</select>
                    </div>

					<div class="form-group inline one-third">
						<label for="utm_campaign">Campaign</label>
						<select class="form-control input-sm" name="utm_campaign" id="utm_campaign">
							<option value="">All</option>
<?php
foreach($all_utm_campaigns as $key) {
	if(trim($key) == trim($get_utm_campaign)) { ?>
							<option value="<?php echo $key; ?>" selected><?php echo ucwords($key); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $key; ?>"><?php echo ucwords($key); ?></option>
<?php
	}
} ?>
						</select>
                    </div>
                    
                    <div class="form-group inline one-third">
						<label for="utm_term">Term</label>
						<select class="form-control input-sm" name="utm_term" id="utm_term">
							<option value="">All</option>
<?php
foreach($all_utm_terms as $key) {
	if(trim($key) == trim($get_utm_term)) { ?>
							<option value="<?php echo $key; ?>" selected><?php echo ucwords($key); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $key; ?>"><?php echo ucwords($key); ?></option>
<?php
	}
} ?>
						</select>
                    </div>
                    
                    <div class="form-group inline one-third">
						<label for="utm_content">Content</label>
						<select class="form-control input-sm" name="utm_content" id="utm_content">
							<option value="">All</option>
<?php
foreach($all_utm_contents as $key) {
	if(trim($key) == trim($get_utm_content)) { ?>
							<option value="<?php echo $key; ?>" selected><?php echo ucwords($key); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $key; ?>"><?php echo ucwords($key); ?></option>
<?php
	}
} ?>
						</select>
                    </div>

                    <div class="form-group inline one-third">
                      <label for="from">From</label>
                      <input type="date" class="form-control input-sm" name="from" value="<?php echo $get_from_date; ?>">
                    </div>
                    
                    <div class="form-group inline one-third">
                      <label for="from">To</label>
                      <input type="date" class="form-control input-sm" name="to" value="<?php echo $get_to_date; ?>">
                    </div>
                      
                    <div class='form-group inline'>
                      <input type="submit" class="btn btn-brand btn-wide" value="Filter">&nbsp; &nbsp; 
                      <a href="<?php echo $this->config->base_url().'analytics'; ?>">Reset Filters</a>
                    </div>
                </form>
                
            </div>
        </div>
        <!-- /.row -->
        
        <div class="row">
			<div class="col-sm-4 text-align-center">
				  <div class="graph-box inline">
					<div id="piechartSources" class="actual-graph" style="width: 100%;"></div>
				  </div>
			  </div>
			  <div class="col-sm-4 text-align-center">
				  <div class="graph-box inline">
					  <div id="piechartMediums" class="actual-graph" style="width: 100%;"></div>
				  </div>
			  </div>
			  <div class="col-sm-4 text-align-center">
				<div class="graph-box inline">
					<div id="piechartCampaigns" class="actual-graph" style="width: 100%;"></div>
				</div>
			  </div>
		</div>
        <br>
        <br>
        <div class="row">
			<div class="col-xs-12">
				
				<div class="graph-box inline half">
					<div id="orders" class="actual-graph"></div>
				</div>
				
				<div class="graph-box inline half">
					<div id="revenues"></div>
				</div>
				
				<div class="graph-box inline half">
					<div id="domesticForeign" class="actual-graph"></div>
				</div>
				
				<div class="graph-box inline half">
					<div id="domesticForeignRev"></div>
				</div>
				
				<script>
					google.load('visualization', '1', {
						packages: ['corechart']
					});
					google.setOnLoadCallback(drawChart);

					function drawChart() {

						var orderData = new google.visualization.DataTable();
						orderData.addColumn('date', 'Day');
						orderData.addColumn('number', 'Total Orders');
						orderData.addColumn('number', 'New');
						orderData.addColumn('number', 'Repeat');

						orderData.addRows([
<?php
$i = 0;
foreach($sorted_orders_date as $key => $value) {
	if($i != 0) echo ','; ?>						
							[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo $value['order_num']; ?>, <?php echo $value['new_customer_orders_num']; ?>, <?php echo $value['old_customer_orders_num']; ?>]
<?php
		$i += 1;
} ?>
						]);
						
						var domesticForeignData = new google.visualization.DataTable();
						domesticForeignData.addColumn('date', 'Day');
						domesticForeignData.addColumn('number', 'Domestic');
						domesticForeignData.addColumn('number', 'Foreign');
						
						domesticForeignData.addRows([
<?php
$i = 0;
foreach($sorted_orders_date as $key => $value) {
	if($i != 0) echo ','; ?>						
							[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo $value['domestic_orders_num']; ?>, <?php echo $value['foreign_orders_num']; ?>]
<?php
		$i += 1;
} ?>
						]);
						
						
						var domesticForeignRevData = new google.visualization.DataTable();
						domesticForeignRevData.addColumn('date', 'Day');
						domesticForeignRevData.addColumn('number', 'Domestic Revenue');
						domesticForeignRevData.addColumn('number', 'Foreign Revenue');
						
						domesticForeignRevData.addRows([
<?php
$i = 0;
foreach($sorted_orders_date as $key => $value) {
	if($i != 0) echo ','; ?>						
							[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo number_format(floor( (($value['domestic_orders_revenue']/100000) * 100))/100, 2); ?>, <?php echo number_format(floor( (($value['foreign_orders_revenue']/100000) * 100))/100, 2); ?>]
<?php
		$i += 1;
} ?>
						]);
						
						
						
						var orderOptions = {
							left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0',
								minValue: 10
							},
							lineWidth: 2,
							pointSize: 2,
						};
						
						
						
						

						
						// orders
						var orders = new google.visualization.LineChart(document.getElementById('orders'));
						orders.draw(orderData, orderOptions);
						// domestic Foreign
						var domesticForeign = new google.visualization.LineChart(document.getElementById('domesticForeign'));
						domesticForeign.draw(domesticForeignData, orderOptions);
						// domestic Foreign revenue
						var domesticForeignRev = new google.visualization.LineChart(document.getElementById('domesticForeignRev'));
						domesticForeignRev.draw(domesticForeignRevData, orderOptions);
						// new and repeat
						//var newRepeat = new google.visualization.LineChart(document.getElementById('newRepeat'));
						//newRepeat.draw(newRepeatData, orderOptions);
						
						var newRepeatData = new google.visualization.DataTable();
						newRepeatData.addColumn('date', 'Day');
						newRepeatData.addColumn('number', 'First Time');
						newRepeatData.addColumn('number', 'Repeat Orders');
						newRepeatData.addRows([
<?php
$i = 0;
foreach($sorted_orders_date as $key => $value) {
	if($i != 0) echo ','; ?>						
							[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo $value['new_customer_orders_num']; ?>, <?php echo $value['old_customer_orders_num']; ?>]
<?php
		$i += 1;
} ?>
						]);


						
						
						
						var revenueData = new google.visualization.DataTable();
						revenueData.addColumn('date', 'Day');
						revenueData.addColumn('number', 'Revenue (in Lakhs)');

						revenueData.addRows([
<?php
$i = 0;
foreach($sorted_orders_date as $key => $value) {
	if($i != 0) echo ','; ?>						
							[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo number_format(floor( (($value['order_revenue']/100000) * 100))/100, 2); ?>]
<?php
		$i += 1;
} ?>
						]);
						
						var revenuesOptions = {
							left: 0,
							'legend':'bottom',
							chartArea: {
								left: 50,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0L',
								minValue: 1
							},
							lineWidth: 1
						};
						
						// revenues
						var revenues = new google.visualization.LineChart(document.getElementById('revenues'));
						revenues.draw(revenueData, orderOptions);
					}
				</script>
				
<?php
if(count($orders) > 0) { ?>                  
                  <script type="text/javascript">
                      google.load("visualization", "1", {packages:["corechart"]});
                      google.setOnLoadCallback(drawChart);
                      function drawChart() {
// *********************************************************************
                        var dataSources = google.visualization.arrayToDataTable([
                          ['Source', 'No. of Leads'],
<?php
$i = 0;
foreach($utm_sources_index as $key => $value) { ?>                          
                        ['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
<?php
	$i += $value;
} 
	if($i != $total_orders) { ?>
						['Empty',     <?php echo abs($total_orders - $i); ?>]
<?php
	}
?>
                      ]);

                        var optionsSources = {
                          title: 'Utm_sources',
                          left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0',
								minValue: 10
							},
							lineWidth: 1
                        };
// *********************************************************************                        
                      var dataMediums = google.visualization.arrayToDataTable([
                        ['Medium', 'No. of Leads'],
<?php
$i = 0;
foreach($utm_mediums_index as $key => $value) { ?>                          
                        ['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
<?php
	$i += $value;
} 
	if($i != $total_orders) { ?>
						['Empty',     <?php echo abs($total_orders - $i); ?>]
<?php
	}
?>
                      ]);

                      var optionsMediums = {
                        title: 'Utm_mediums',
                        left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0',
								minValue: 10
							},
							lineWidth: 1
                      };  
// *********************************************************************
                      var dataCampaigns = google.visualization.arrayToDataTable([
                        ['Campaign', 'No. of Leads'],
<?php
$i = 0;
foreach($utm_campaigns_index as $key => $value) { ?>                          
                        ['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
<?php
	$i += $value;
} 
	if($i != $total_orders) { ?>
						['Empty',     <?php echo abs($total_orders - $i); ?>]
<?php
	}
?>
                      ]);

                      var optionsCampaigns = {
                        title: 'Utm_campaigns',
                        left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0',
								minValue: 10
							},
							lineWidth: 1
                      };
// *********************************************************************
                      var dataTerms = google.visualization.arrayToDataTable([
                        ['Term', 'No. of Leads'],
<?php
$i = 0;
foreach($utm_terms_index as $key => $value) { ?>                          
                        ['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
<?php
	$i += $value;
} 
	if($i != $total_orders) { ?>
						['Empty',     <?php echo abs($total_orders - $i); ?>]
<?php
	}
?>
                      ]);

                      var optionsTerms = {
                        title: 'Utm_terms',
                        left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0',
								minValue: 10
							},
							lineWidth: 1
                      };

// *********************************************************************
                      var dataContents = google.visualization.arrayToDataTable([
                        ['Content', 'No. of Leads'],
<?php
$i = 0;
foreach($utm_contents_index as $key => $value) { ?>                          
                        ['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
<?php
	$i += $value;
} 
	if($i != $total_orders) { ?>
						['Empty',     <?php echo abs($total_orders - $i); ?>]
<?php
	}
?>
                      ]);

                      var optionsContents = {
                        title: 'Utm_contents',
                        left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0',
								minValue: 10
							},
							lineWidth: 1
                      };                        

                        var chartSources = new google.visualization.PieChart(document.getElementById('piechartSources'));
                        var chartMediums = new google.visualization.PieChart(document.getElementById('piechartMediums'));
                        var chartCampaigns = new google.visualization.PieChart(document.getElementById('piechartCampaigns'));
                        //var chartTerms = new google.visualization.PieChart(document.getElementById('piechartTerms'));
                        //var chartContents = new google.visualization.PieChart(document.getElementById('piechartContents'));
                     

                        chartSources.draw(dataSources, optionsSources);
                        chartMediums.draw(dataMediums, optionsMediums);
                        chartCampaigns.draw(dataCampaigns, optionsCampaigns);
                        //chartTerms.draw(dataTerms, optionsTerms);
                        //chartContents.draw(dataContents, optionsContents);
                      }
                    </script>
                  
                  
                  <!-- div class="col-sm-4 col-sm-offset-2 text-align-left">
                    <div id="piechartTerms" style="text-align:left;width: 100%;height:320px"></div>
                  </div>
                  <div class="col-sm-4 text-align-left">
                    <div id="piechartContents" style="text-align:left;width: 100%;height:320px"></div>
                  </div -->

<?php
} ?>				
				
				
			</div>
			
			
		</div>
		<br>
		<br>
		
		
		
	</div>
</section>

