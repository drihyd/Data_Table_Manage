<div class="sub-header">Manage Homepage Sliders</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'homepage_sliders/add'; ?>" class="btn btn-brand btn-sm">New Homepage Slider +</a>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table table-sort table-sort-search table-sort-show-search-count">
                <thead>
                  <tr>
                    <th>Image</th>
                    <th class="table-sort">Caption</th>
                    <th class="table-sort">URL</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  
<?php if($homepage_sliders) {
        foreach ($homepage_sliders as $homepage_slider) { ?>
                  <tr>
                    <td><img src="<?php echo $this->config->base_url().'../assets/uploads/files/'.$homepage_slider->image; ?>" alt="<?php echo ucfirst($homepage_slider->caption); ?>"class="img-responsive" width="150px"></td>
                    <td><?php echo ucfirst($homepage_slider->caption); ?></td>
                    <td><?php echo $homepage_slider->url; ?></td>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'homepage_sliders/edit/'.$homepage_slider->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'homepage_sliders/delete/'.$homepage_slider->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop
      } //end of if 
      else {  ?>                  
                  <tr align='center'>
                    <td colspan=7><a href="<?php echo $this->config->base_url().'homepage_sliders/add'; ?>" class="btn btn-default">Start adding Homepage Sliders +</a></td>
                  </tr
<?php } // end of else ?>                  
                </tbody>
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
