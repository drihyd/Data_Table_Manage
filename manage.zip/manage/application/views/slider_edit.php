<div class="sub-header">Edit Slider</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <a href="<?php echo $this->config->base_url().'sliders/delete/'.$slider_details['id']; ?>" class="btn btn-danger btn-sm margin-top-15 delete-confirm"><b>Delete</b> this slider</a>
            <?php echo validation_errors(); ?>
            <?php echo form_open_multipart('sliders/save/'.$slider_details['id'], array('class' => 'margin-top-15')); ?>
              <legend>Basic Info</legend>
              <img src="<?php echo $this->config->base_url().'../assets/uploads/files/'.$slider_details['image']; ?>" class="img-responsive" alt="<?php echo $slider_details['caption']; ?>" title="<?php echo $slider_details['caption']; ?>">
              <div class="form-group margin-top-15">
                <label for="sliderImage" class="control-label">Change slider Image</label>
                <input type="file" class="form-control" id="sliderImage" name="sliderImage" value="">
              </div>
              <div class="form-group inline">
                <label for="sliderUrl" class="control-label">URL</label><p class="help-block" style="margin: 0 0 3px 5px; font-size: 12px;display: inline-block">URL should start with http://</p>
                <input type="text" class="form-control" id="sliderUrl" name="sliderUrl" value="<?php echo $slider_details['url']; ?>">
                
              </div>
              <div class="form-group inline">
                <label for="sliderCaption" class="control-label">Caption</label>
                <input type="text" class="form-control" id="sliderCaption" name="sliderCaption" value="<?php echo $slider_details['caption']; ?>">
              </div>
              <div class="form-group inline">
                <label for="sliderSubtext" class="control-label">Subtext</label>
                <input type="text" class="form-control" id="sliderSubtext" name="sliderSubtext" value="<?php echo $slider_details['subtext']; ?>">
              </div>
              <div class="form-group inline">
                <label for="sliderSupertext" class="control-label">Supertext</label>
                <input type="text" class="form-control" id="sliderSupertext" name="sliderSupertext" value="<?php echo $slider_details['supertext']; ?>">
              </div>
              <div class="form-group inline">
                <label for="sliderParentCat" class="control-label">Parent Category</label>
                <select class="form-control" name="sliderParentCat" id="sliderParentCat" readonly>
                  <option value="<?php echo $category['id']; ?>" selected><?php echo ucfirst($category['name']); ?></option>
                </select>
              </div>
               
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
