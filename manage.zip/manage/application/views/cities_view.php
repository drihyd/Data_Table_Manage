<div class="sub-header">Manage Cities</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <!-- a href="<?php echo $this->config->base_url().'cities/add'; ?>" class="btn btn-default btn-sm">New City +</a -->
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 margin-top-15">
            
<?php
    echo $this->session->flashdata('form-after-message');
?>  
              <table class="table dataTable">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th width="150px">Name</th>
                    <th>Parent State</th>
                    <th style="text-align:right;">Shipping Rate (per KG)</th>
                    <th>Shipping Time</th>
                    <th>Tax Percentage</th>
                    <th>COD Available</th>
                    <th width="100px">Actions</th>
                  </tr>
                </thead>
                
                  
<?php if( count($cities) > 0 ) { ?>
                <tbody>
<?php
        foreach ($cities as $city) { ?>
                  <tr>  
                    <td><?php echo $city->id; ?></td>
                    <td><?php echo ucwords($city->city_name); ?></td>
                    <td><?php echo ucwords($states_info[$city->state_id]->state_name); ?></td>
                    <td align="right"><?php echo 'Rs. '.$shipping_rates_info[$city->shipping_rate_id]->inr_rate; ?></td>
<?php
          if( ((int) $shipping_times_info[$city->shipping_time_id]->min_days) == ( (int) $shipping_times_info[$city->shipping_time_id]->max_days) ) { ?>
                    <td><?php echo $shipping_times_info[$city->shipping_time_id]->min_days; ?> Day(s)</td>
<?php
          } else { ?>
                    <td><?php echo $shipping_times_info[$city->shipping_time_id]->min_days; ?> to <?php echo $shipping_times_info[$city->shipping_time_id]->max_days; ?> Days</td>
<?php
          } ?>
                    <td><?php echo $city->tax_percentage; ?> %</td> 
<?php
          if($city->cod_available == 1) { ?>
                    <td><strong class="text-success">Yes</strong></td>
<?php
          } else { ?>
                    <td>No</td>
<?php
          } ?>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'cities/edit/'.$city->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'cities/delete/'.$city->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop ?>
                </tbody>
<?php
      } //end of if 
      else {  ?>  
                <tfoot>                
                  <tr align='center'>
                    <td colspan="6"><a href="<?php echo $this->config->base_url().'cities/add/'.$cities->id; ?>" class="btn btn-default">Start adding States +</a></td>
                  </tr>
                </tfoot>
<?php } // end of else ?>                  
                
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
