    <?php $this->load->helper('encode_helper'); ?>
    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
      </ul>
    </div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
<?php
                      echo $this->session->flashdata('form-after-message');
?>              
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>

<?php
if($this->session->flashdata('form_error') != '') { ?>
                <div class="alert alert-danger alert-dismissible fade in" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                  <strong>Error!</strong> <?php echo $this->session->flashdata('form_error'); ?>
                </div>
<?php
} ?>

<?php
if($this->session->flashdata('form_success') != '') { ?>
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                  <strong>Success!</strong> <?php echo $this->session->flashdata('form_success'); ?>
                </div>
<?php
} ?>
                
                <?php echo form_open('coupons/save/'.$coupon_details->id, array('class'=>'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="couponTitle" class="control-label">Title</label>
                    <input type="text" class="form-control input-sm" id="couponTitle" name="couponTitle" value="<?php echo $coupon_details->title; ?>" required>
                  </div>
                  <div class="form-group inline">
                    <label for="couponCode" class="control-label" style="display:block;">Code <small><a href="#" data-toggle="modal" data-target="#couponCodesModal" class="pull-right">Get Codes</a></small></label>
                    <input type="text" class="form-control input-sm codeClean" id="couponCode" name="couponCode" value="<?php echo $coupon_details->code; ?>" required>
                  </div>
                  <div class="form-group">
                    <label for="couponDesc" class="control-label">Description</label>
                    <textarea class="form-control input-sm" style="max-width: 100%; min-width: 100%; min-height: 100px;" id="couponDesc" name="couponDesc" required><?php echo $coupon_details->desc; ?></textarea>
                  </div>
                  <div class="form-group">
                    <label for="couponError" class="control-label">Error Message</label>
                    <textarea class="form-control input-sm" style="max-width: 100%; min-width: 100%; min-height: 100px;" id="couponError" name="couponError" required><?php echo $coupon_details->error_message; ?></textarea>
                  </div>
                  <div class="form-group inline">
                    <label for="couponType" class="control-label">Type</label>
                    <select class="form-control input-sm" id="couponType" name="couponType" required>
<?php
if($coupon_details->type == 'shipping_off') { ?>                      
                      <option value="shipping_off" selected>Free Shipping</option>
<?php
} else { ?>
                      <option value="shipping_off">Free Shipping</option>
<?php
} ?>

<?php
if($coupon_details->type == 'rupees_off') { ?>                      
                      <option value="rupees_off" selected>Rupees Off</option>
<?php
} else { ?>
                      <option value="rupees_off">Rupees Off</option>
<?php
} ?>

<?php
if($coupon_details->type == 'percent_off') { ?>                      
                      <option value="percent_off" selected>Percent Off</option>
<?php
} else { ?>
                      <option value="percent_off">Percent Off</option>
<?php
} ?>

                    </select>
                  </div>
                  
                  <div class="form-group inline">
<?php
if($coupon_details->type == 'rupees_off') { ?>                    
                    <label for="couponValue" class="control-label"><span class="rupeesOff">Rupees</span> <span class="slash" style="display: none;">/</span> <span class="percentOff" style="display: none;">Percent</span> Off</label>
                    <input type="text" class="form-control input-sm" id="couponValue" name="couponValue" value="<?php echo $coupon_details->value; ?>" required>
<?php
} ?>

<?php
if($coupon_details->type == 'percent_off') { ?>                    
                    <label for="couponValue" class="control-label"><span class="rupeesOff" style="display: none;">Rupees</span> <span class="slash" style="display: none;">/</span> <span class="percentOff">Percent</span> Off</label>
                    <input type="text" class="form-control input-sm" id="couponValue" name="couponValue" value="<?php echo $coupon_details->value; ?>" required>
<?php
} ?>

<?php
if($coupon_details->type == 'shipping_off') { ?>                    
                    <label for="couponValue" class="control-label"><span class="rupeesOff">Rupees</span> <span class="slash">/</span> <span class="percentOff">Percent</span> Off</label>
                    <input type="text" class="form-control input-sm" id="couponValue" name="couponValue" value="<?php echo $coupon_details->value; ?>" disabled>
<?php
} ?>          
                    
                  </div>
                  
                  <div class="form-group inline">
                    <label for="couponUsageLimit" class="control-label">Usage Limit ( -1 for no limit )</label>
                    <input type="text" class="form-control input-sm" id="couponUsageLimit" name="couponUsageLimit" value="<?php echo $coupon_details->usage_limit; ?>" required>
                  </div><br>
                  
                  <div class="form-group inline">
                    <label for="couponValidFrom" class="control-label">Valid From</label>
                    <input type="date" class="form-control input-sm" id="couponValidFrom" name="couponValidFrom" value="<?php echo date('Y-m-d', strtotime($coupon_details->valid_from)); ?>" required>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="couponValidTill" class="control-label">Valid Till</label>
                    <input type="date" class="form-control input-sm" id="couponValidTill" name="couponValidTill" value="<?php echo date('Y-m-d', strtotime($coupon_details->valid_till)); ?>" required>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="couponCustID" class="control-label">Customer ID (0 if not applicable)</label>
                    <input type="text" class="form-control input-sm" id="couponCustID" name="couponCustID" value="<?php echo $coupon_details->owner_cust_id; ?>" required>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="couponMinOrderValue" class="control-label">Minimum Order Value</label>
                    <input type="text" class="form-control input-sm" id="couponMinOrderValue" name="couponMinOrderValue" value="<?php echo $coupon_details->min_order_value; ?>" required>
                  </div>
                  
                  <div class="form-group inline">
                    <div class="checkbox">
						<label>
						  <input type="checkbox" name="couponSingleUsePerCust" value="1" <?php if($coupon_details->single_use_per_cust == 1) echo 'checked'; ?>> Single Use Per Customer
						</label>
					</div>
                  </div>
                  
                  <div class="form-group inline">
                    <div class="checkbox">
						<label>
						  <input type="checkbox" name="couponForFirstTimeOrdersOnly" value="1" <?php if($coupon_details->for_first_time_orders_only == 1) echo 'checked'; ?>> For first-time orders only
						</label>
					</div>
                  </div>
                  
                  <div class="form-group margin-top-30">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'coupons/coupon_info/'.$coupon_details->id; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./end basicinfo tab -->
              
              
            
            </div> <!-- ./ end tab-content -->
            
          </div>
          <div class="col-sm-6">
            <div class="edit-form">
              <legend>Info</legend>
              <p>ID: <?php echo $coupon_details->id; ?></p>
              <p>Title: <?php echo ucfirst($coupon_details->title); ?></p>
              <p>Desc: <?php echo ucfirst($coupon_details->desc); ?></p>
              <p>Error Message: <?php echo ucfirst($coupon_details->error_message); ?></p>
              <p>Code: <b><?php echo $coupon_details->code; ?></b></p>
  <?php
  if($coupon_details->usage_limit == -1) { ?>            
              <p>Usage Limit: Infinite</p>
  <?php
  } else { ?>
              <p>Usage Limit: <?php echo ucfirst($coupon_details->usage_limit); ?></p>
  <?php
  } ?>
              <p>Times Used: <?php echo $coupon_details->times_used; ?></p>
              <p>Valid From: <?php echo date('d F, Y', strtotime($coupon_details->valid_from)); ?></p>
              <p>Valid To: <?php echo date('d F, Y', strtotime($coupon_details->valid_till)); ?></p>
  <?php
  if($coupon_details->owner_cust_id != 0) { ?>
              <p>Assigned to Customer: <a href="<?php echo $this->config->base_url().'customers/customer_info/'.$coupon_details->owner_cust_id; ?>"><?php echo $coupon_details->owner_cust_id; ?></a></p>
  <?php
  } ?>
              <p>Type: <?php echo ucfirst($coupon_details->type); ?></p>
  <?php
  if( ($coupon_details->type == 'rupees_off') ) { ?>           
              <p>Value: Rs. <?php echo $coupon_details->value; ?></p>
  <?php
  } ?>

  <?php
  if( ($coupon_details->type == 'percent_off') ) { ?>           
              <p>Value: <?php echo $coupon_details->value; ?> %</p>
  <?php
  } ?>
              <p>Minimum Order Value: Rs. <?php echo $coupon_details->min_order_value; ?></p>
            </div>
            
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->


  <!-- Modal -->
  <div class="modal fade" id="couponCodesModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-sm" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="myModalLabel">Unique Coupon Codes</h4>
        </div>
        <div class="modal-body">
          <ul class="list-inline">
<?php
foreach($unique_codes as $unique_code) { ?>
            <li style="width: 30%;;margin: 0;font-family:courier;"><?php echo $unique_code; ?></li>
<?php
} ?>          
          </ul>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
