
<?php setlocale(LC_MONETARY, 'en_IN'); ?>
  
  <div class="sub-header">Actions</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12">
            <a href="<?php echo $this->config->base_url().'orders'; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Back to All Orders</a>
            &nbsp; <a href="<?php echo $this->config->base_url().'orders/print_invoice/'.$order_details->id; ?>" class="btn btn-xs btn-warning">Generate Invoice</a>
          </div>
        </div>
      </div> <!-- /#container-fluid -->
    </section>
  
  <div class="sub-header">Order Details</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          
          <div class="col-sm-4">
            <div class="edit-form">
              <h2>Customer Info</h2>
              <p>Name: <?php echo ucwords($customer_details->name); ?><br>
                 Customer ID: <a href="<?php echo $this->config->base_url().'customers/customer_info/'.$customer_details->id; ?>"><?php echo $customer_details->id; ?></a><br>
                 Email: <a href="mailto:<?php echo $customer_details->id; ?>"><?php echo $customer_details->email; ?></a><br>
                 Gender: <?php echo $customer_details->gender; ?><br>
                 Age: <?php echo $customer_details->age; ?><br>
              </p>
            </div>
          </div>
          
          <div class="col-sm-4">
            <div class="edit-form">
              <h2>Shipping Address</h2>
              <p><?php echo ucwords($order_details->ship_to_name); ?><br>
                 <a href="mailto:<?php echo $order_details->ship_to_email; ?>"><?php echo $order_details->ship_to_email; ?></a><br>
                 <?php echo $order_details->ship_to_phone; ?><br>
<?php
if($order_details->ship_to_alt_phone != '') { ?>
				 <?php echo $order_details->ship_to_alt_phone; ?><br>
<?php
} ?>
				 <br>
                 <?php echo $order_details->ship_to_address; ?><br>
                 <?php echo $order_details->ship_to_city; ?><br>
                 <?php echo $order_details->ship_to_state; ?><br>
              <p><?php echo $order_details->ship_to_country; ?>
              </p>
            </div>
          </div>
          
          <div class="col-sm-4">
            <div class="edit-form">
              <h2>Billing Address</h2>
              <p><?php echo ucwords($order_details->bill_to_name); ?><br>
                 <a href="mailto:<?php echo $order_details->bill_to_email; ?>"><?php echo $order_details->bill_to_email; ?></a><br>
                 <?php echo $order_details->bill_to_phone; ?><br><br>
                 <?php echo $order_details->bill_to_address; ?><br>
                 <?php echo $order_details->bill_to_city; ?><br>
                 <?php echo $order_details->bill_to_state; ?><br>
              <p><?php echo $order_details->bill_to_country; ?>
              </p>
            </div>            
          </div>

        </div>
        
        <div class="row">

          <div class="col-sm-4">
<?php
if($order_details->payment_status == 'due') { ?>            
            <div class="edit-form" style="background: #FFE2D9;">
<?php
} else { ?>
            <div class="edit-form" style="background: #D9FFED;">
<?php
} ?>
              <h2>Payment Info</h2>
<?php
if( (count($payment_details) > 0) && ($payment_details->paypal_payment == 1) ) { ?>
              <p>Payment Mode: <span class="badge" style="background: #009cde;">PayPal</span></p>
<?php
} else if($order_details->payment_mode == 'epay') { ?>
              <p>Payment Mode: <span class="badge">EBS</span></p>
<?php
} else { ?>
              <p>Payment Mode: <span class="badge"><?php echo strtoupper($order_details->payment_mode); ?></span></p>
<?php
} ?>
              <p style="display:inline-block; margin-right: 5px;">Payment Status:
                <?php echo form_open("orders/payment_status_update/{$order_details->id}", array('style' => 'display: inline-block')); ?>
                  <select name="paymentStatus" required>
<?php 
if($order_details->payment_status == 'fraud') { ?>
                    <option value="fraud" selected>Fraud</option>
                    <option value="paid">Paid</option>
                    <option value="due">Due</option>
<?php
} else { ?>

<?php 
  if($order_details->payment_status == 'paid') { ?>                   
                    <option value="paid" selected>Paid</option>
<?php
  } else { ?>                 
                    <option value="paid">Paid</option>
<?php
  }
      
  if($order_details->payment_status == 'due') { ?>                   
                    <option value="due" selected>Due</option>
<?php
  } else { ?>                 
                    <option value="due">Due</option>
<?php
  } ?>

<?php
} ?>      
                  </select>

                  <button type="submit" class="" style="padding: 0 5px;font-size: 12px;">Update</button>
<?php
if($this->session->flashdata('payment_status_message') != ''): ?>
              <div class="alert alert-danger alert-dismissible fade in" style="display: inline-block;" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">Ã—</span></button>
                <strong class="text-danger"><?php echo ucfirst($this->session->flashdata('payment_status_message')); ?></strong>
              </div>
<?php
  endif; ?>            
                </form>
              </p>
<?php
if(count($payment_details) > 0) { ?>
<?php
  if($payment_details->paypal_payment == 1) { ?>             
              <p>Transaction Message: <span class="text-danger"><?php echo $payment_details->paypal_payment_status; ?></span><br>
              Payment ID: <span class="text-danger"><?php echo $order_details->payment_id; ?> (<?php echo $payment_details->transaction_id; ?>)</p>
<?php
  } else { ?>
              <p>Transaction Message: <span class="text-danger"><?php echo $payment_details->response_message; ?></span><br>
              Payment ID: <span class="text-danger"><?php echo $order_details->payment_id; ?> (<?php echo $payment_details->payment_id; ?>)</p>
<?php
  } ?>
<?php
} ?>
            </div>
          </div>
          
          <div class="col-sm-8">
            <div class="edit-form">
              <h2>Order Status</h2>
<?php $ordered_on_date = strtotime($order_details->ordered_on); ?>             
              <p>Order ID: <?php echo $order_details->id; ?><br>
                 Cart ID: <?php echo $order_details->cart_id; ?>
              </p>
              <p>
                 Ordered On: <?php echo date('M d Y H:i:s', $ordered_on_date); ?><br>
<?php if($order_details->delivered_on != null) {
         $delivered_on_date = strtotime($order_details->delivered_on); ?>             
              Delivered On: <?php echo date('M d Y H:i:s', $delivered_on_date); ?><br>
<?php
       } else { ?>
              <span style="color: lightgray;">Delivered On: </span><br>
<?php
       } ?>
       
<?php if($order_details->cancelled_on != null) {
         $cancelled_on_date = strtotime($order_details->cancelled_on); ?>             
              Cancelled On: <?php echo date('M d Y H:i:s', $cancelled_on_date); ?><br>
<?php
       } else { ?>
              <span style="color: lightgray;">Cancelled On: </span><br>
<?php
       } ?>       
              </p>
              <p>Total Amount: <?php echo strtoupper($order_details->currency) . ' ' . money_format('%!.2n', $order_details->grand_total); ?>/-<br>
                 No. of Items: <?php echo $order_details->total_items; ?>   
              </p>
              <p style="display:inline-block; margin-right: 5px;">Order Status:
                <?php echo form_open("orders/status_update/{$order_details->id}", array('style' => 'display: inline-block')); ?>
                  <select name="orderStatus" required>
<?php if($order_details->order_status == 'placed') { ?>                   
                    <option value="placed" selected>Placed</option>
<?php
      } else { ?>                 
                    <option value="placed">Placed</option>
<?php
      }
      
      if($order_details->order_status == 'processing') { ?>                   
                    <option value="processing" selected>Processing</option>
<?php
      } else { ?>                 
                    <option value="processing">Processing</option>
<?php
      }
      if($order_details->order_status == 'dispatched') { ?>                   
                    <option value="dispatched" selected>Dispatched</option>
<?php
      } else { ?>                 
                    <option value="dispatched">Dispatched</option>
<?php
      }
      if($order_details->order_status == 'on-hold') { ?>                   
                    <option value="on-hold" selected>On Hold</option>
<?php
      } else { ?>                 
                    <option value="on-hold">On Hold</option>
<?php
      }
      if($order_details->order_status == 'cancelled') { ?>                   
                    <option value="cancelled" selected>Cancelled</option>
<?php
      } else { ?>                 
                    <option value="cancelled">Cancelled</option>
<?php
      }
      if($order_details->order_status == 'delivered') { ?>                   
                    <option value="delivered" selected>Delivered</option>
<?php
      } else { ?>                 
                    <option value="delivered">Delivered</option>
<?php
      }
      if($order_details->order_status == 'cancelled-refund-pending') { ?>                   
                    <option value="cancelled-refund-pending" selected>Cancelled - Refund Pending</option>
<?php
      } else { ?>                 
                    <option value="cancelled-refund-pending">Cancelled - Refund Pending</option>
<?php
      }
      if($order_details->order_status == 'cancelled-refunded') { ?>                   
                    <option value="cancelled-refunded" selected>Cancelled - Refunded</option>
<?php
      } else { ?>                 
                    <option value="cancelled-refunded">Cencelled - Refunded</option>
<?php
      } ?>
                  </select>

                  <button type="submit" class="" style="padding: 0 5px;font-size: 12px;">Update</button>
<?php
if($this->session->flashdata('payment_status_message') != ''): ?>
              <div class="alert alert-danger alert-dismissible fade in" style="display: inline-block;" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">Ã—</span></button>
                <strong class="text-danger"><?php echo ucfirst($this->session->flashdata('payment_status_message')); ?></strong>
              </div>
<?php
  endif; ?>            
                </form>
              </p>

<?php
if( ($order_details->order_status == 'dispatched') ) {
  if( $order_details->tracking_number == '' ) { ?>            
              
              <p style="display:inline-block; margin-right: 5px;">Tracking Number: 
                <?php echo form_open("orders/tracking_num_update/{$order_details->id}", array('style' => 'display: inline-block')); ?>
                  <input type="text" name="tracking_number" id="tracking_number" style="display inline-block;">
                  <button type="submit" class="" style="padding: 0 5px;font-size: 12px;">Update</button>
                </form>
              </p>
<?php
  } else { ?>
              <p>
                Tracking Number:
                <div id="as-root"></div><script>(function(e,t,n){var r,i=e.getElementsByTagName(t)[0];if(e.getElementById(n))return;r=e.createElement(t);r.id=n;r.src="//apps.aftership.com/all.js";i.parentNode.insertBefore(r,i)})(document,"script","aftership-jssdk")</script> 
                <div class="as-track-button" data-tracking-number="<?php echo $order_details->tracking_number; ?>" data-counter="true" data-support="true" data-width="300" data-size="small"></div>
                <?php echo form_open("orders/tracking_num_update/{$order_details->id}", array('style' => 'display: inline-block')); ?>
                  <input type="text" name="tracking_number" id="tracking_number" style="display inline-block;" value="<?php echo $order_details->tracking_number; ?>">
                  <button type="submit" class="" style="padding: 0 5px;font-size: 12px;">Update</button>
                </form>
              </p>
<?php
  }
} ?>

<?php
  if($this->session->flashdata('tracking_num_success') != ''): ?>
              <div class="alert alert-success alert-dismissible fade in" style="display: inline-block;" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">Ã—</span></button>
                <strong class="text-success"><?php echo ucfirst($this->session->flashdata('tracking_num_success')); ?></strong>
              </div>
<?php
  endif; ?>
  
<?php
  if($this->session->flashdata('tracking_num_error') != ''): ?>
              <div class="alert alert-danger alert-dismissible fade in" style="display: inline-block;" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">Ã—</span></button>
                <strong class="text-danger"><?php echo ucfirst($this->session->flashdata('tracking_num_error')); ?></strong>
              </div>
<?php
  endif; ?>


              <br>
              <p><a href="<?php echo $this->config->base_url().'orders/print_invoice/'.$order_details->id; ?>" class="btn btn-xs btn-warning">Generate Invoice</a></p>
            </div>            
          </div>
          
        </div> <!-- ./row -->          
      </div>
    </section>
    
    
    
  <div class="sub-header">Order Items</div>
    <section class="stats-section">
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table dataTable">
                <thead>
                  <tr>
                    <th>Order Item ID</th>
                    <th>SKU Code</th>
                    <th>Product Name</th>
                    <th>Customization</th>
                    <th>Size</th>
                    <th>Unit Price</th>
                    <th>Discount Percentage</th>
                    <th>Qty</th>
                    <th>Net Price</th>
                  </tr>
                </thead>
                
                  
<?php if($order_items) { ?>
                <tbody>
<?php
        foreach ($order_items as $order_item) { 
          if($order_item->custom) { ?>
                  <tr class="danger">
<?php
          }
          else { ?>
                  <tr>
<?php
          } ?>
                    <td><?php echo $order_item->id; ?></td>
                    <td><a href="<?php echo $this->config->base_url().'skus/sku_info/'.$order_item->sku_id; ?>"><?php echo $order_item->sku_code; ?></a></td>
                    <td><a href="<?php echo $this->config->base_url().'products/product_info/'.$order_item->product_id; ?>"><?php echo ucwords($products_list[$order_item->id]->name); ?></a></td>
<?php 
          if($order_item->custom) {
            if($order_item->custom_standard == 1) { ?>
                    <td><a href="#<?php echo $customizations_list[$order_item->id]->id; ?>orderCust"><span class="label label-danger">Customized - std</span></a></td>
<?php
            } else { ?>
                    <td><a href="#<?php echo $customizations_list[$order_item->id]->id; ?>orderCust"><span class="label label-danger">Customized</span></a></td>
<?php
            } ?>
            
            
<?php
          } else { ?>                    
                    <td></td>
<?php
          } ?>
 
<?php 
        if($skus_list[$order_item->id]->size != null) { ?>
                    <td><?php echo strtoupper($skus_list[$order_item->id]->size); ?></td>
<?php
        } else { ?>
                    <td><span class="label label-default">Unstitched</span></td>
<?php
        } ?>
                    <td align="right">
						<?php echo strtoupper($order_details->currency) . ' ' . money_format('%!.2n', $order_item->unit_price); ?>
						<?php
						if($order_item->gst > 0) {
							if($order_item->unit_price >= 1000) {
								echo "(12% GST)";
							} else {
								echo "(5% GST)";
							}
						} ?>
					</td>
                    <td align="center"><?php echo $order_item->discount_percentage; ?> %</td>
                    <td align="right"><?php echo $order_item->qty; ?></td>
                    <td align="right"><?php echo strtoupper($order_details->currency) . ' ' . money_format('%!.2n', $order_item->net_price); ?></td>
                  </tr>
<?php   } // end of foreach loop ?>
                </tbody>
<?php
      } //end of if 
      else {  ?>  
                <tfoot>                
                  <tr align='center'>
                    <td colspan="6">No Items</td>
                  </tr>
                </tfoot>
<?php } // end of else ?>                  
                
              </table>
            </div> <!-- /.table-responsive -->
          </div>
          
          
<style>
#customList tr:target {
    background-color: #FFFF66;
}
@-webkit-keyframes highlight {
    0% { background-color: #FFFF66; }
    100% { background-color: #FFFFFF; }
}
@keyframes highlight {
    0% { background-color: #FFFF66; }
    100% { background-color: #FFFFFF; }
}
</style>
          
          <div class="row margin-top-30">
            <div class="col-xs-12">
                <h2>Customizations</h2>
                
                <div class="table-responsive">
                <table class="table dataTableOverflow" id="customList">
                    
                    <thead>
                        <tr>
                            <th>Order Item ID</th>
                            <th>SKU Code</th>
                            <th>Product Name</th>
                            <th>top collar</th>
                            <th>top shoulder</th>
                            <th>top armhole</th>
                            <th>top sleeve length</th>
                            <th>top chest</th>
                            <th>top waist</th>
                            <th>top hip</th>
                            <th>top length</th>
                            <th>bottom waist</th>
                            <th>bottom thigh</th>
                            <th>bottom knee</th>
                            <th>bottom bottom</th>
                            <th>bottom seat</th>
                            <th>bottom length</th> 
                        </tr>
                    </thead>
                    
                    <tbody>
<?php
foreach($customizations_list as $customization) { ?>
                        <tr id="<?php echo $customization->id; ?>orderCust">
                            <td><?php echo $customization->order_item_id; ?></td>
                            <td><?php echo $skus_list[$customization->order_item_id]->sku_code; ?></td>
                            <td><?php echo ucwords($products_list[$customization->order_item_id]->name); ?></td>
                            <td align="left"><?php echo $customization->top_collar; ?></td>
                            <td align="left"><?php echo $customization->top_shoulder; ?></td>
                            <td align="left"><?php echo $customization->top_armhole; ?></td>
                            <td align="left"><?php echo $customization->top_sleevelength; ?></td>
                            <td align="left"><?php echo $customization->top_chest; ?></td>
                            <td align="left"><?php echo $customization->top_waist; ?></td>
                            <td align="left"><?php echo $customization->top_hip; ?></td>
                            <td align="left"><?php echo $customization->top_length; ?></td>
                            <td align="left"><?php echo $customization->bottom_waist; ?></td>
                            <td align="left"><?php echo $customization->bottom_thigh; ?></td>
                            <td align="left"><?php echo $customization->bottom_knee; ?></td>
                            <td align="left"><?php echo $customization->bottom_bottom; ?></td>
                            <td align="left"><?php echo $customization->bottom_seat; ?></td>
                            <td align="left"><?php echo $customization->bottom_length; ?></td>
                        </tr>
<?php
} ?>
                    </tbody>
                </table>
                </div> <!-- ./table-resposnive -->
            </div>
          </div>
          
          <div class="row margin-top-30">
            <div class="col-xs-12">
                <h2>Alterations</h2>
                
                <div class="table-responsive">
                <table class="table dataTableOverflow" id="customList">
                    
                    <thead>
                        <tr>
                            <th>Order Item ID</th>
                            <th>SKU Code</th>
                            <th>Product Name</th>
                            <th>Alteration details</th>
                        </tr>
                    </thead>
                    
                    <tbody>
<?php
foreach($order_items as $item) {
	if($item->alterations != '') { ?>
                        <tr>
							<td><?php echo $item->id; ?></td>
                            <td><?php echo $item->sku_code; ?></td>
                            <td><?php echo ucwords($products_list[$item->id]->name); ?></td>
                            <td><?php echo ucfirst($item->alterations); ?></td>
                        </tr>
<?php
	}
} ?>
                    </tbody>
                </table>
                </div> <!-- ./table-resposnive -->
            </div>
          </div>
          
        <div class="row margin-top-30">
          <div class="col-xs-12">
            <h2>Applied Coupons</h2>
            <div class="table-responsive">
              <table class="table dataTable">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Coupon ID</th>
                    <th>Coupon Code</th>
                    <th>Coupon Title</th>
                    <th>Coupon Type</th>
                    <th>Discounted Amount</th>
                  </tr>
                </thead>
<?php
if(count($order_coupon) > 0) { ?>
                <tbody>
                  <tr>
                    <td><?php echo $order_coupon->id; ?></td>
                    <td><?php echo $order_coupon->coupon_id; ?></td>
                    <td><?php echo $order_coupon->coupon_code; ?></td>
                    <td><?php echo ucfirst($order_coupon->title); ?></td>
                    <td><?php echo ucfirst($order_coupon->type); ?></td>
<?php
  if($order_coupon->type == 'shipping_off') { ?>                    
                    <td><?php echo money_format('%!.2n',$order_details->total_shipping_weight * $order_details->shipping_rate); ?></td>
<?php
  } else { ?>
                    <td><?php echo money_format('%!.2n', $order_coupon->discount_amount); ?></td>
<?php
  } ?>
                  </tr>
                </tbody>
<?php
} else { ?>
                <tfoot>
                  <tr>
                    <td colspan="6" align="center">No Cupon were applied</td>
                  </tr>

                </tfoot>
<?php
} ?>                
              </table>
            </div> <!-- ./table-responsive -->
          </div>  <!-- ./col-xs-12 -->
        </div>  <!-- ./row -->          
          
          
          
          
        </div> <!-- /.row -->
        
        

        
        
      </div> <!-- /#container-fluid -->
    </section>
  
    
</div>
<!-- /#main-content -->
