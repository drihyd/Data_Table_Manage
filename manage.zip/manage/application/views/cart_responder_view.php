<?php
	ob_start();
	setlocale(LC_MONETARY, 'en_IN');
	
	$item_num = count($cart_items);
	$item_phrase = 'items';
	if($item_num == 1) {
		$item_phrase = 'item';
	}
	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Checkout Your Cart</title>
</head>
<body style='font-family: Arial, sans-serif;background: #f4f4f4;color: #333;font-size: 12px;padding: 15px;'>
	<div class='container' style='padding: 0;padding-bottom: 15px;font-family: Arial, sans-serif;max-width:480px;margin: 30px auto; background: #fff;color: #333;box-shadow:1px 2px 5px #888'>
<?php
if($discount_mailer === TRUE) { ?>
		<!-- Visually Hidden Preheader Text : BEGIN -->
        <div style="display:none;font-size:1px;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;mso-hide:all;font-family: sans-serif;">
            Offer valid only for the next 24 hours. Hurry!
        </div>
        <!-- Visually Hidden Preheader Text : END -->
<?php
} else { ?>
		<!-- Visually Hidden Preheader Text : BEGIN -->
        <div style="display:none;font-size:1px;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;mso-hide:all;font-family: sans-serif;">
            Everything you’ve selected seems to be selling out. Hurry Up!
        </div>
        <!-- Visually Hidden Preheader Text : END -->
<?php
} ?>

<?php
if($discount_mailer === TRUE) { ?>
		<img src="http://taruni.in/assets/mailer/abandoned-cart-incentive/banner-week.jpg" width='100%'>
<?php
} else { ?>
		<img src="http://taruni.in/assets/mailer/abandoned-cart-incentive/banner.jpg" width='100%'>
<?php
} ?>
		<br><br>
		
		<p style="font-size: 12px;line-height: 140%;padding: 0 15px;margin-bottom: 0;">
			<span style="color: #333;font-weight:bold;">Hi <?php echo ucwords($cart_details_index[$cart_id]['name']); ?>,</span><br><br>
		</p>
<?php
if($discount_mailer === TRUE) { ?>
		
		<p style="font-size: 12px;line-height: 140%;padding: 0 15px;margin-top: 0;">
			Why wait to welcome something so beautiful? Redeem this fabulous discount on your abandoned cart now! Get all those fabulous outfits you wanted!
		</p>
		<p style="font-size: 12px;line-height: 140%;padding: 0 15px;margin-top: 0;">Please <a href="http://taruni.in/contact" style="text-decoration: none;font-size: 12px;">do tell us</a> what is keeping you from placing that order on your fine selection.</p>
		
		<div style="font-size: 12px;line-height: 140%;padding: 0 15px;margin: 0 15px;background: #484848;text-align:center;padding-top: 9px;padding-bottom: 3px;">
			<p style="font-size: 12px;margin: 3px 0 9px;color:#ababab;font-family:'Arial', sans-serif;">COUPON CODE</p>
			<p style="font-size: 24px;margin: 3px 0 6px;color: #ffffff;font-weight: bold;font-family:'Arial', sans-serif;"><?php echo $code; ?></p>
		</div>
		
		<div style="font-size: 12px;line-height: 140%;padding: 0 15px;margin: 0 15px 24px;background: #222222;text-align:center;padding-top: 3px;padding-bottom: 3px;">
			<p style="font-size: 12px;margin:3px 0;color:#fff;font-family:'Arial', sans-serif;"><?php echo $percent_off; ?>% discount if you Checkout within 24 Hrs.</p>
		</div>
		
		<p style="font-size: 12px;line-height: 140%;padding: 0 15px;">
			<b><a href="<?php echo 'http://taruni.in/cart/checkout'.$utms; ?>" target="_blank" style="text-decoration: none;font-size: 12px;">Checkout</a> within 24 Hrs.</b> using the above coupon code and get a <?php echo $percent_off; ?>% discount on the total order value for orders worth INR <?php echo $min_order_value; ?> and above.
			<br><br>
			<b>HURRY, the coupon expires today</b>

		</p>
		
		<hr style="border:none;border-top: 1px solid #ccc;">
<?php
} else { ?>

		<p style="font-size: 12px;line-height: 140%;padding: 0 15px;margin-top: 0;">
			Your cart full of amazing clothes awaits you! Grab them before they’re gone.<br>
			<a href="<?php echo 'http://taruni.in/cart/checkout'.$utms; ?>" target="_blank" style="text-decoration: none;font-size: 12px;">Checkout</a> now to add some fabulous ethnic wear to your wardrobe.
		</p>
		<p style="font-size: 12px;line-height: 140%;padding: 0 15px;margin-top: 0;">Please <a href="http://taruni.in/contact" style="text-decoration: none;font-size: 12px;">do tell us</a> what is keeping you from placing that order on your fine selection.</p>
<?php
} ?>
		<table style="margin-top: 15px;padding: 0 15px;">
<?php
foreach($final_products as $item) {
	$sku_id = $item->sku_id;
	$product_id = $sku_index[$item->sku_id]->product_id; ?>
	
			<tr>
				<td style="width:60px;background:#ddd;"><img src="<?php echo 'http://taruni.in/assets/uploads/'.$product_index[$product_id]->code.'_dp.jpg'; ?>" width="60"></td>
				<td>
					<p style="font-size: 12px;font-weight: bold;margin: 0;margin-bottom: 3px;padding-left: 3px;">
						<?php echo ucwords($product_index[$product_id]->name); ?>
					</p>
					<p style="font-size: 10px; margin: 0; margin-bottom: 5px; line-height: 160%; padding-left: 3px;">
						Rs. <?php echo money_format('%!.2n', $item->unit_price); ?><br>
						Size: <?php echo strtoupper($sku_index[$sku_id]->size); ?>
					</p>
				</td>
			</tr>
<?php
} ?>
		</table>
		<a href="<?php echo 'http://taruni.in/cart/checkout'.$utms; ?>" target="_blank" style="display: inline-block;margin: 15px 15px;"><img src="http://taruni.in/img/ab_email_checkout.jpg" width="120" alt="Checkout"></a>
		
		<div style="background:#eee;border: 1px solid #ddd;font-size: 12px;color: #888;padding: 0px;padding-bottom: 0px;margin: 15px 15px;">
			<p style="padding: 3px 9px;font-weight: bold;margin:0;margin-bottom:9px;background: lightgray;color:gray;">Having Trouble?</p>
			<p style="margin: 0;padding: 0 9px;">
				<a href="<?php echo 'http://taruni.in/contact'.$utms; ?>" target="_blank" style="text-decoration: none;font-size: 12px;margin:3px 0;">I'm unable to checkout</a><br>
				<a href="<?php echo 'http://taruni.in/contact'.$utms; ?>" target="_blank" style="text-decoration: none;font-size: 12px;margin: 3px 0;">I have some questions</a>
			</p>
			<p style="marign: 0;font-size: 10px;color: #aaa;padding: 0 9px;">Click on the above links and write to us. Our team will help you out.</p>
		</div>
		<p style="padding: 0 15px;margin-top:15px">
			Shop for other items here : <a href="<?php echo 'http://taruni.in/home'.$utms; ?>" target="_blank" style="text-decoration: none;font-size: 12px;margin:3px 0;">taruni.in</a>
		</p>
		<p style="line-height: 140%;padding: 0 15px;margin-bottom: 5px;">Happy Shopping!<br><b>Team Taruni</b></p>
	</div> <!-- ./container -->
</body>
</html>
<?php
	$message = ob_get_clean();
	echo $message;
	
	if($discount_mailer == TRUE) {
		$subject = 'Your discount coupon is expiring today. Last 24 hours left';
	} else {
		$subject = 'You have ' . $item_num . ' ' . $item_phrase .' in your cart';
	}
	
	if($justsee == null) {
		
		send_api_email('esales@taruni.in', 'Taruni', $cart_details_index[$cart_id]['email'], $cart_details_index[$cart_id]['name'], $subject, $message, '');
		//if($cart_details_index[$cart_id]['email'] == 'svsashank@gmail.com') {
			////send_email('esales@taruni.in', 'Taruni', $cart_details_index[$cart_id]['email'], $cart_details_index[$cart_id]['name'], 'Your Cart', $message);
			//send_email('esales@taruni.in', 'Taruni', 'nsathyendra1991@gmail.com', 'sathyendra', $subject, $message);
			//send_email('esales@taruni.in', 'Taruni', 'sathyendra@deepredink.com', 'sathyendra', $subject, $message);
		//}
		
		if($discount_mailer == FALSE) {
			$schedule_discount = date('Y-m-d H:i:s', strtotime('+7 days'));
			$abandon_coupon_id = 0;
			$last_discount_mailer = NULL;
		} else {
			$schedule_discount = NULL;
			$last_discount_mailer = date('Y-m-d H:i:s', time());
		}
		
		$new_data = array(
			'last_email' => date('Y-m-d H:i:s', strtotime('+1 day')),
			'schedule_discount' => $schedule_discount,
			'abandoned_coupon_id' => $abandon_coupon_id,
			'last_discount_mailer' => $last_discount_mailer,
		);
		$this->db->where('id', $cart_id);
		$this->db->update('carts', $new_data);
		
		//send_email('admin@taruni.in', 'Taruni Admin', 'sashank@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'nsathyendra1991@gmail.com', 'Taruni Weekly Report', $message, '');
		//send_email('esales@taruni.in', 'Taruni Admin', 'sathyendra@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'ranjith@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'nabeel@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'santhan@deepredink.com', 'Taruni Weekly Report', $message, '');
		//send_email('admin@taruni.in', 'Taruni Admin', 'priya@deepredink.com', 'Taruni Weekly Report', $message, '');
	}
?>
