<div class="sub-header">Wishlist Details</div>
<section class='stats-section'>
	<div class="container-fluid">
		
		<div class="row">
			<div class="col-xs-12">
				<div class="inline stat-card">
					<h1><?php echo count($wishlists); ?></h1>
					<p>Total Wishlists</p>
				</div>
				<div class="inline stat-card">
					<h1><?php echo count($wishlist_products); ?></h1>
					<p>Unique Products</p>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="sub-header">Top Products in Wishlist</div>
<section class='stats-section'>
	<div class="container-fluid">
		
		<div class="row">
			<div class="col-xs-12">
				<table class="table dataTable">
					<thead>
						<tr>
							<th width="32px" style="width:32px;padding:0;" class="noSort">&nbsp;</th>
							<th>Product Name</th>
							<th>Times Added</th>
						</tr>
					</thead>
					
					<tbody>
<?php
foreach($wishlist_products as $key => $value) {
	if($product != 'unknown') { ?>
						<tr>
							<?php
							if( ! file_exists('../assets/uploads/' . $product_index[$key]->code . '_dp.jpg')) { ?>
								<td width="32px" style="width:32px;padding:0;"><img src="<?php echo $this->config->base_url().'img/Not_Available.jpg'; ?>" width="100%"></td>
							<?php
							} else { ?>
								<td width="32px" style="width:32px;padding:0;"><img src="<?php echo $this->config->base_url().'../assets/uploads/'.$product_index[$key]->code.'_dp.jpg'; ?>" width="100%"></td>
							<?php
							} ?>
							<td><a href="<?php echo $this->config->base_url().'products/product_info/'.$product_index[$key]->id; ?>" target="_blank"><?php echo ucwords($product_index[$key]->name); ?></a></td>
							<td><?php echo $value; ?></td>
						</tr>
<?php
	} else { ?>
						<tr>
							<td colspan="3">Unknown Product</td>
						</tr>
<?php
	} ?>
<?php
} ?>
					</tbody>
					
				</table>
			</div>
		</div>
	</div>
</section>
