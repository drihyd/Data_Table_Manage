<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title><?php echo $seo_title; ?> </title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
  
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/simplelightbox.min.css">
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/style.css">

<?php if($page_name_new=="products_filter"){ ?>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs/jszip-2.5.0/dt-1.10.18/af-2.3.3/b-1.5.6/b-colvis-1.5.6/b-flash-1.5.6/b-html5-1.5.6/b-print-1.5.6/cr-1.5.0/fc-3.2.5/fh-3.1.4/kt-2.5.0/r-2.2.2/rg-1.1.0/rr-1.2.4/sc-2.0.0/sl-1.3.0/datatables.min.css"/>

<?php } else { ?>
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>js/jquery-ui/jquery-ui.min.css">
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>js/jquery-ui/dataTables.jqueryui.css">
<?php } ?>

  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/loading.css">

   
  
  <!--[if lt IE 9]>
  <script src="js/vendor/html5-3.6-respond-1.1.0.min.js"></script>
  <![endif]-->
</head>
<body>
  <!--[if lt IE 7]>
  <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
  <![endif]-->
  
  <!-- Sidebar -->
  <div id="sidebar-wrapper">
    <ul class="sidebar-nav">
      <li class="sidebar-brand">
        <a href="<?php echo $this->config->base_url(); ?>"><img src="<?php echo $this->config->base_url(); ?>img/logo.png" class="img-responsive" alt="Seating-world Logo" title="Seating-world"></a>
      </li>
      <!-- li><a href="<?php echo $this->config->base_url().'getting_started'; ?>">Getting Started</a></li -->
      
      <li id="side-dashboard"><a href="<?php echo $this->config->base_url().'dashboard'; ?>">Dashboard </a></li>
      
      <li id="side-orders">
        <a href="#" data-toggle="collapse" data-target="#side-orders-dropmenu">Orders</a>
        <ul class="nav nav-list collapse" id="side-orders-dropmenu">
          <li id="side-orders-view"><a href="<?php echo $this->config->base_url().'orders'; ?>">View All</a></li>
          <li id="side-foreign-orders"><a href="<?php echo $this->config->base_url().'foreign_orders'; ?>">Foreign Orders</a></li>
          <li id="side-abandoned-carts"><a href="<?php echo $this->config->base_url().'abandoned_carts'; ?>">Abandoned Carts</a></li>
          <li id="side-paypal-outbox"><a href="<?php echo $this->config->base_url().'paypal_outbox'; ?>">Paypal Outbox</a></li>
        </ul>
      </li>
      
      <li id="side-customers">
        <a href="#" data-toggle="collapse" data-target="#side-customers-dropmenu">Customers</a>
        <ul class="nav nav-list collapse" id="side-customers-dropmenu">
          <li id="side-customers-view"><a href="<?php echo $this->config->base_url().'customers'; ?>">View All</a></li>
          <li id="side-export-customers"><a href="<?php echo $this->config->base_url().'export_customers'; ?>">Export</a></li>
          <li id="side-loyal-customers"><a href="<?php echo $this->config->base_url().'loyal_customers'; ?>">Loyal Customers</a></li>
          <!-- li id="side-repeat-customers"><a href="<?php echo $this->config->base_url().'repeat_customers'; ?>">Repeat Customers</a></li -->
          <li id="side-wishlists"><a href="<?php echo $this->config->base_url().'wishlists'; ?>">Wishlists</a></li>
          <li id="side-clicks"><a href="<?php echo $this->config->base_url().'clicks'; ?>">Clicks</a></li>
        </ul>
      </li>
      
      <li id="side-products">
        <a href="#" data-toggle="collapse" data-target="#side-products-dropmenu">Products</a>
        <ul class="nav nav-list collapse" id="side-products-dropmenu">
          <!-- <li id="side-products-view"><a href="<?php echo $this->config->base_url().'product_reports'; ?>">View All</a></li>           -->
          <li id="side-products-view"><a href="<?php echo $this->config->base_url().'products'; ?>">View All</a></li>          
          <li id="side-products-filter"><a href="<?php echo $this->config->base_url().'product_viewer'; ?>">Filter</a></li>
          <li id="side-add-product"><a href="<?php echo $this->config->base_url().'products/add'; ?>">Add Product</a></li>
          <li id="side-attributes-view"><a href="<?php echo $this->config->base_url().'attributes'; ?>">Attributes</a></li>
          <li id="side-recommended"><a href="<?php echo $this->config->base_url().'recommend'; ?>">Recommended</a></li>
          <li id="side-recommended"><a href="<?php echo $this->config->base_url().'update_price'; ?>">Update $ Price</a></li>
          <!-- <li id="sid-product-report"><a href="<?php echo $this->config->base_url().'product_reports';?>">Product Reports</a></li> -->
        </ul>
      </li>
      	
      <li id="side-bulk-upload">
        <a href="#" data-toggle="collapse" data-target="#side-bulk-upload-dropmenu">Bulk Upload</a>
        <ul class="nav nav-list collapse" id="side-bulk-upload-dropmenu">
          <li id="side-bulk-upload-download"><a href="<?php echo $this->config->base_url().'bulk_upload/download'; ?>">Download XLSX File</a></li>
          <li id="side-bulk-upload-upload"><a href="<?php echo $this->config->base_url().'bulk_upload/upload'; ?>">Upload Bulk Data</a></li>
          <li id="side-bulk-images-upload"><a href="<?php echo $this->config->base_url().'bulk_images_upload'; ?>">Bulk Image Upload</a></li>
          <li id="side-postalcodes-upload"><a href="<?php echo $this->config->base_url().'upload_postalcodes'; ?>">Upload Postalcodes</a></li>
        </ul>
      </li>
      
      <li id="side-categories">
        <a href="#" data-toggle="collapse" data-target="#side-categories-dropmenu">Categories</a>
        <ul class="nav nav-list collapse" id="side-categories-dropmenu">
          <li id="side-categories-view"><a href="<?php echo $this->config->base_url().'categories'; ?>">View</a></li>
          <li id="side-add-parentcat"><a href="<?php echo $this->config->base_url().'categories/parentadd'; ?>">Add Parent Category</a></li>
          <li id="side-add-childcat"><a href="<?php echo $this->config->base_url().'categories/add'; ?>">Add Child Category</a></li>
          <li id="side-edit-reorder"><a href="<?php echo $this->config->base_url().'reorder'; ?>">Edit Re-order Values</a></li>
        </ul>
      </li>
      
      <li id="side-master-data">
        <a href="#" data-toggle="collapse" data-target="#side-master-data-dropmenu">Master Data</a>
		<ul class="nav nav-list collapse" id="side-master-data-dropmenu">
			<li id="side-tags-view"><a href="<?php echo $this->config->base_url().'tags/'; ?>">Tags</a></li>
			<li id="side-shipping-rates-view"><a href="<?php echo $this->config->base_url().'shipping_rates/'; ?>">Shipping Rates</a></li>
			<li id="side-shipping-times-view"><a href="<?php echo $this->config->base_url().'shipping_times/'; ?>">Shipping Times</a></li>
			<li id="side-countries-view"><a href="<?php echo $this->config->base_url().'countries/'; ?>">Countries</a></li>
			<li id="side-states"><a href="<?php echo $this->config->base_url().'states'; ?>">States</a></li>
            <li id="side-cities"><a href="<?php echo $this->config->base_url().'cities'; ?>">Cities</a></li>
		</ul>
	  </li>
	  
	  <li id="side-promos">
        <a href="#" data-toggle="collapse" data-target="#side-promos-dropmenu">Promotions</a>
		<ul class="nav nav-list collapse" id="side-promos-dropmenu">
			<li id="side-contest"><a href="<?php echo $this->config->base_url().'friendship_contest'; ?>">Contest</a></li>
			<li id="side-coupons-view"><a href="<?php echo $this->config->base_url().'coupons/'; ?>">Coupons</a></li>
			<li id="side-discounts-view"><a href="<?php echo $this->config->base_url().'discounts/'; ?>">Discounts</a></li>
		</ul>
	  </li>
	  
	  <li id="side-content">
        <a href="#" data-toggle="collapse" data-target="#side-content-dropmenu">Content &amp; Pages</a>
		<ul class="nav nav-list collapse" id="side-content-dropmenu">
			<li id="side-homepage-featured"><a href="<?php echo $this->config->base_url().'homepage_featured'; ?>">Homepage Featured</a></li>
			<li id="side-pages-view"><a href="<?php echo $this->config->base_url().'pages'; ?>">Pages</a></li>
			<li id="side-static-page-seo"><a href="<?php echo $this->config->base_url().'static_page_seo'; ?>">Static Pages Seo</a></li>
		</ul>
	  </li>
	  
	  <li id="side-monitor">
        <a href="#" data-toggle="collapse" data-target="#side-monitor-dropmenu">Reports &amp; Aanalytics</a>
		<ul class="nav nav-list collapse" id="side-monitor-dropmenu">
			<li id="side-analytics"><a href="<?php echo $this->config->base_url().'analytics'; ?>">Order Analytics</a></li>
			<li id="side-cart-analytics"><a href="<?php echo $this->config->base_url().'cart_analytics'; ?>">Cart Analytics</a></li>
			<li id="side-stock-reports"><a href="<?php echo $this->config->base_url().'stock_reports'; ?>">Stock Reports</a></li>
			<li id="side-product-report"><a href="<?php echo $this->config->base_url().'product_report'; ?>">Product Report</a></li>
			<!-- li id="side-reports-view"><a href="<?php echo $this->config->base_url().'reports'; ?>">Monthly Reports</a></li -->
			<li id="side-reports-view"><a href="<?php echo $this->config->base_url().'monthly_report'; ?>">Monthly Reports</a></li>
			<li id="side-monitor-stock"><a href="<?php echo $this->config->base_url().'monitor_stock'; ?>">Monitor Stock</a></li>
			<li id="side-color-report"><a href="<?php echo $this->config->base_url().'color_report'; ?>">Color Report</a></li>
			<li id="side-order-location-report"><a href="<?php echo $this->config->base_url().'order_location_report'; ?>">Order Location Report</a></li>
			<li id="side-stock-logs"><a href="<?php echo $this->config->base_url().'stock_logs'; ?>">Inventory Age</a></li>
		</ul>
	  </li>
	  
	  <li id="side-feedback"><a href="<?php echo $this->config->base_url().'feedback'; ?>">Feedback</a></li>
	  
    </ul>
  </div>
  <!-- /#sidebar-wrapper -->
  <div id="main-content">
    <header>
      <a href="#menu-toggle" class="btn btn-default btn-edit btn-xs" id="menu-toggle"><span class="glyphicon glyphicon-chevron-left"></span> Menu</a>
<?php
if(isset($page_title)) { ?>
      <div class="header-page-title"><?php echo ucwords($page_title); ?></div>
<?php
} else { ?>
      <div class="header-page-title"><?php echo ucfirst($user_type); ?></div>
<?php
} ?>
      <div class="dropdown pull-right header-user-dropdown" style="display: inline-block;">
        <button class="btn btn-brand dropdown-toggle" type="button" id="userDropMenu" data-toggle="dropdown">
          <?php echo $username; ?>
          <span class="caret"></span>
        </button>
        <ul class="dropdown-menu" role="menu" aria-labelledby="userDropMenu">
          <!-- li role="presentation"><a role="menuitem" tabindex="-1" href="#">Change Password</a></li -->
          <!-- li role="presentation"><a role="menuitem" tabindex="-1" href="#">Change Email</a></li -->
          <!-- li role="presentation" class="divider"></li -->
          <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo $this->config->base_url().'profile'; ?>">Profile</a></li>
          <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo $this->config->base_url().'dashboard/logout'; ?>">Logout</a></li>
        </ul>
      </div>
    </header>
    
