<div class="sub-header">Edit Testimonial</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open('testimonials/save/'.$testimonial_details['id']); ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="testimonialName" class="control-label">Customer's Name</label>
                <input type="text" class="form-control" id="testimonialName" name="testimonialName" value="<?php echo $testimonial_details['name']; ?>" required>
              </div>
              <div class="form-group inline">
                <label for="testimonialSlug" class="control-label">Slug</label>
                <input type="text" class="form-control" id="testimonialSlug" name="testimonialSlug" value="<?php echo $testimonial_details['slug']; ?>" required>
              </div>
              <div class="form-group">
                <label for="testimonialContent" class="control-label">Testimonial Content</label>
                <textarea class="form-control mce" id="testimonialContent" name="testimonialContent" required><?php echo $testimonial_details['testimonial_content']; ?></textarea>
              </div>
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
          
          <div class="col-sm-6">
            
            <?php echo validation_errors(); ?>
            <?php echo form_open('testimonials/seosave/'.$testimonial_details['id']); ?>
              <legend>SEO Tags</legend>
              <div class="form-group inline">
                <label for="testimonialSeoTitle" class="control-label">Page Title</label>
                <input type="text" class="form-control" id="testimonialSeoTitle" name="testimonialSeoTitle" value="<?php echo ucfirst($testimonial_details['seo_title']); ?>">
              </div>
              <div class="form-group inline">
                <label for="testimonialSeoDesc" class="control-label">Page Description</label>
                <input type="text" class="form-control" id="testimonialSeoDesc" name="testimonialSeoDesc" value="<?php echo ucfirst($testimonial_details['seo_desc']); ?>">
              </div>
              <div class="form-group inline">
                <label for="testimonialSeoKeys" class="control-label">Page Keywords</label>
                <input type="text" class="form-control" id="testimonialSeoKeys" name="testimonialSeoKeys" value="<?php echo ucfirst($testimonial_details['seo_keywords']); ?>">
              </div>
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
