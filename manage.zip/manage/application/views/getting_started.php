<style>
  article {
    margin: 30px 0;
    border-bottom: 1px dashed #888;
    padding-bottom: 15px;
  }
  article h3 {
    margin-bottom: 15px;
  }
  figure {
    display: inline-block;
    padding: 5px;
    margin: 15px 0;
    border: 1px solid #eee;
    background: #f2f2f2;
  }
  figure img {
    max-width: 100%;
    border: 1px solid #E0E0E0;
    border-radius: 3px;
  }
  figcaption {
    font-size: 12px;
    font-style: italic;
    margin-top: 5px;
    color: #B8B8B8;
    padding: 2px 0;
  }
  a {
    color: blue;
  }
</style>
<div class="sub-header">Getting Started</div>
    <section class="stats-section">
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-sm-12">
            <article id="before-products">
              <h3>Before Adding Products</h3>
              <p>Adding a product requires assigning it a brand and a category. Hence, before you can start adding products, you need to:</p>
              <ul>
                <li><a href="#add-parent-category">Add Parent Categories</a></li>
                <li><a href="#add-sub-category">Add Child/Sub-categories</a></li>
                <li><a href="#add-brand">Add Brands</a></li>
              </ul>
              <p>A category could be:</p>
              <ul>
                <li>A <em>Parent</em> category or</li>
                <li>A <em>Child</em> category</li>
              </ul>
              <p>Every product <strong><mark>must</mark></strong> be added under a <em>Child Category</em>.</p>
            </article>
            <article id="add-parent-category">
              <h3>Adding Parent Categories</h3>
              <p>Click on the Categories link in the Side-menu. You will be taken to the categories manager page.</p>
              <p>Click on the "Add Parent Category" button on top (as shown in <em>fig 1</em>)</p>
              <figure>
                <img src="<?php echo $this->config->base_url().'img/cms_doc/'.'parent-category-1.png'; ?>">
                <figcaption>fig.1 - Add Parent Category Button</figcaption>
              </figure>
              <p>You will be shown a form (refer fig.2), in which the parent category name needs to entered.</p>
              <figure>
                <img src="<?php echo $this->config->base_url().'img/cms_doc/'.'parent-category-2.png'; ?>">
                <figcaption>fig.2 - Basic category details form</figcaption>
              </figure>
              <p>A recommended slug will be auto-generated, based on the name. This auto-generated slug can be edited, but <a href="#slug-rules">certain rules</a> need to be followed.</p>
              <p>Save the details by clicking on the "Save Changes" button.</p>
            </article>
          </div>          
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
