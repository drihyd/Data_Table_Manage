<style>
    .numbers-section {
        padding: 30px 0 0;
        background: #fff;
    }
    table.dataTable tbody th, table.dataTable tbody td {padding:5px 10px;}
    .stat-card {
        display: inline-block;
        border: 1px dashed #cacaca;
        padding: 15px 15px 3px;
        margin: 10px;
        text-align: center;
    }
    .stat-card.small {
        padding: 5px 20px;
    }
    .stat-card.small h1 {
        font-size: 16px;
    }
    .text-align-center {
        text-align: center;
    }
    @media(max-width:767px) {
        .stat-card, .stat-card.small {
            width: 100%;
            padding: 5px;
            margin: 5px;
        }
        .stat-card.small h1 {
            margin: 5px;
            font-size: 14px;
        }
        .stat-card.small p {
            margin: 0;
        }
    }
</style>
<?php
//date_default_timezone_set("Asia/Kolkata");
setlocale(LC_MONETARY, 'en_IN');
?>
<div class="sub-header">Participants</div>  
    
    <section class="numbers-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12 text-align-center">
                    <div class="edit-form inline stat-card small">
                        <h1><?php echo count($participants); ?></h1>
                        <p>Total Participants</p>
                    </div>
                    <div class="edit-form inline stat-card small">
                        <h1><?php echo $completed.' / '.count($participants); ?></h1>
                        <p>Completed the Game</p>
                    </div>
                    <div class="edit-form inline stat-card small">
                        <h1><?php echo (count($participants) - $completed) .' / '.count($participants); ?></h1>
                        <p>Yet to Complete</p>
                    </div>
                    <div class="edit-form inline stat-card small">
                        <h1><?php echo $new_regs; ?></h1>
                        <p>Total New Registrations for the contest</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 text-align-center">
                    <div class="edit-form inline stat-card">
                        <h1><?php echo 'Rs. '.money_format('%!.0n', $winnings); ?></h1>
                        <p>Total Value of Coupons Won</p>
                    </div>
                     <div class="edit-form inline stat-card">
                        <h1><?php echo 'Rs. '.money_format('%!.0n', $claimed); ?></h1>
                        <p>Total Value of Coupons Claimed</p>
                    </div>
                    <div class="edit-form inline stat-card">
                        <h1><?php echo 'Rs. '.money_format('%!.0n', $spent); ?></h1>
                        <p>Revenue generated while claiming coupons</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="stats-section">
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table dataTable">
                <thead>
                  <tr>
                    <th>Customer</th>
                    <th>Sister Email</th>
                    <th>Brother Name</th>
                    <th>Brother Email</th>
                    <th>Brother Phone</th>
                    <th>Coupon</th>
                    <th>Winnings</th>
                    <th>Status</th>
                    <th>Played</th>
                  </tr>
                </thead>
                
                  
<?php if(count($participants) > 0) { ?>
                <tbody>
<?php
        foreach ($participants as $participant) { ?> 
                  <tr>
                    <td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$participant->cust_id; ?>"><?php echo $participant->cust_id; ?></a></td>
                    <td><?php echo $customer_index[$participant->cust_id]->email; ?></td>
                    <td><?php echo ucfirst($participant->partner_name); ?></td>
                    <td><?php echo $participant->partner_email; ?></td>
                    <td><?php echo $participant->partner_phone; ?></td>
<?php
$finished = "<span class='label label-danger'>Yet to Win</span>";
if($participant->coupon_id != 0) {
    $coupon_details = $this->db->get_where('coupons', array('id' => $participant->coupon_id));
    if($coupon_details->num_rows() > 0) {
        $coupon_details = $coupon_details->row();
        $coupon_code = $coupon_details->code;
        $claimed_order = '';
        if(isset($claimed_coupons[$coupon_details->id])) {
            $order_id = $claimed_coupons[$coupon_details->id];
            $claimed_order = " <a href='{$this->config->base_url()}orders/order_info/{$order_id}' target='_blank' class='label label-primary pull-right' style='margin-top:2px;'>claimed</a>";
        }
        $finished = "<span class='label label-success'>Won</span>";
    }
} else {
    $claimed_order = '';
    $coupon_code = " ";
} ?>
                    <td width="150" style="width:100px;"><a href="<?php echo $this->config->base_url().'coupons/coupon_info/'.$coupon_details->id; ?>"><?php echo $coupon_code; ?></a><?php echo $claimed_order; ?></td>
                    <td><?php echo $participant->score; ?></td>
                    <td><?php echo $finished; ?></td>
                    <td><?php echo date('d M', strtotime($participant->date_sent)); ?></td>
                  </tr>
<?php   } // end of foreach loop ?>
                </tbody>
<?php
      } //end of if 
      else {  ?>  
                <tfoot>                
                  <tr align='center'>
                    <td colspan="6">No coupons</td>
                  </tr>
                </tfoot>
<?php } // end of else ?>                  
                
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>
     
    
  </div>
  <!-- /#main-content -->
