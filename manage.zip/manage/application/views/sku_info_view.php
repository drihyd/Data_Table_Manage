<?php setlocale(LC_MONETARY, 'en_IN'); ?>
  
  <div class="sub-header">Actions</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12">
<?php
                      echo $this->session->flashdata('form-after-message');
?>              
            <a href="<?php echo $this->config->base_url().'products/product_info/'.$parent_product_details->id.'#sub-skus-section'; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Back to All SKU's</a>
            &nbsp;<a href="<?php echo $this->config->base_url().'skus/edit/'.$sku_details->id; ?>" class="btn btn-warning btn-xs"><span class="glyphicon glyphicon-edit"></span> Edit</a> 
            &nbsp;<a href="<?php echo $this->config->base_url().'skus/delete/'.$sku_details->id; ?>" class="btn btn-danger btn-xs delete-confirm"><span class="glyphicon glyphicon-trash"></span> Delete</a>
            
          </div>
        </div>
      </div> <!-- /#container-fluid -->
    </section>
  
  <div class="sub-header">SKU Info</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <p>Code: <?php echo $sku_details->sku_code; ?></p>
            <p>Parent Product: <a href="<?php echo $this->config->base_url().'products/product_info/'.$parent_product_details->id; ?>"><?php echo ucwords($parent_product_details->name); ?></a></p>
<?php
    if($sku_details->size == null) { ?>                    
            <p>Size: <span class="text-danger">Unstitched</span></p>
<?php
    } else { ?>
            <p>Size: <?php echo ucfirst($sku_details->size); ?></p>
<?php
    } ?>            
            <p>Price: Rs. <?php echo money_format('%!.2n',$sku_details->price); ?></p>
            <p>Striked Off Price: Rs. <?php echo money_format('%!.2n',$sku_details->striked_price); ?></p>
            <p>Stock: <?php echo $sku_details->stock; ?></p>            

            <a href="<?php echo $this->config->base_url().'skus/edit/'.$sku_details->id; ?>" class="btn btn-warning btn-xs"><span class="glyphicon glyphicon-edit"></span> Edit Details</a>

          </div>
          
          <div class="col-sm-6">
            <p><span class="stat-value">Size - <?php echo ucwords($sku_details->size); ?></span></p>            
          </div>
          
        </div>
      </div>
    </section> 
    
</div>
<!-- /#main-content -->
