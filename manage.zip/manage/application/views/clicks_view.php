<style>
    table.dataTable tbody th,
    table.dataTable tbody td {
		font-size: 12px;
		padding:5px 10px;
	}
</style>
<div class="sub-header">Taruni Clicks</div>
<section class="stats-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12">
				
				<?php echo $this->session->flashdata('form_errors'); ?>
				
				<table class="table dataTable">
					<thead>
						<tr>
							<!-- th style="width: 30px;">&nbsp;</th -->
							<th>Name</th>
							<th>Email</th>
							<th>Country</th>
							<!-- th style="width: 60px;">Frame</th -->
							<th style="width: 100px;">Date</th>
						</tr>
					</thead>
					
					<tbody>
						
<?php
if(count($clicks) > 0) {
	foreach($clicks as $click) { ?>
						<tr>
							<!-- td>
								<a href="<?php echo $this->config->base_url().'clicks/click_info/' . $click->click_user_id; ?>" target="_blank">
									<?php
									$images = $click->click_img_paths;
									$images = explode(',', $images);
									$images = array_filter($images);
									$image = $images[0]; ?>
									
									<img src="<?php echo $this->config->base_url() . '../taruni_clicks/' . $image; ?>" width="30" height="30">
								</a>
							</td -->
							<td>
								<a href="<?php echo $this->config->base_url().'clicks/click_info/' . $click->click_user_id; ?>" target="_blank">
									<?php echo ucwords($click->click_name); ?>
								</a>
							</td>
							<td><?php echo $click->click_email; ?></td>
							<td><?php echo ucwords($click->click_country); ?></td>
							<!-- td>
								<?php
								//$frame_status = '';
								//if($click->frame_sent == 1) {
								//	$frame_status = "<span class='label label-success'>Sent</span>";
								//}
								//echo $frame_status;
								?>
							</td -->
							<td><?php echo date('d M, Y', strtotime($click->click_date_captured)); ?></td>
						</tr>

<?php
	}
} else { ?>
						<tr align="center">
							<td colspan="4">Sorry! No Records</td>
						</tr>
<?php
} ?>
					</tbody>
					
				</table>
				
			</div>
		</div>
	</div>
</section>
