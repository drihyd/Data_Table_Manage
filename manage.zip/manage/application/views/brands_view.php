<div class="sub-header">Manage Brands</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'brands/add'; ?>" class="btn btn-brand btn-sm">New Brand +</a>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table table-sort table-sort-search table-sort-show-search-count">
                <thead>
                  <tr>
                    <th class="table-sort">Brand Name</th>
                    <th class="">Slug</th>
                    <th width="100px">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  
<?php if($brands) {
        foreach ($brands as $brand) { ?>
                  <tr>
                    <td><?php echo $brand['name']; ?></td>
                    <td><?php echo $brand['slug']; ?></td>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'brands/edit/'.$brand['id']; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'brands/delete/'.$brand['id']; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop
      } //end of if 
      else {  ?>                  
                  <tr align='center'>
                    <td colspan=7><a href="<?php echo $this->config->base_url().'brands/add'; ?>" class="btn btn-default btn-sm">Start adding brands +</a></td>
                  </tr
<?php } // end of else ?>                  
                </tbody>
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
