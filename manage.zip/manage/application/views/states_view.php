<div class="sub-header">Manage States</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <!-- a href="<?php echo $this->config->base_url().'states/add'; ?>" class="btn btn-default btn-sm">New State +</a --> 
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 margin-top-15">
            
<?php
    echo $this->session->flashdata('form-after-message');
?>  
              <table class="table dataTable">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Parent Country</th>
                    <th style="text-align:right;">Shipping Rate (per KG)</th>
                    <th>Shipping Time</th>
                    <th>Tax Percentage</th>
                    <th>COD Available</th>
                    <th width="100px">Actions</th>
                  </tr>
                </thead>
                
                  
<?php if( count($states) > 0 ) { ?>
                <tbody>
<?php
        foreach ($states as $state) { ?>
                  <tr>  
                    <td><?php echo $state->id; ?></td>
                    <td><?php echo ucwords($state->state_name); ?></td>
                    <td><?php echo ucwords($countries_info[$state->country_id]->country_name); ?></td>
                    <td align="right"><?php echo 'Rs. '.$shipping_rates_info[$state->shipping_rate_id]->inr_rate; ?></td>
<?php
          if( ((int) $shipping_times_info[$state->shipping_time_id]->min_days) == ( (int) $shipping_times_info[$state->shipping_time_id]->max_days) ) { ?>
                    <td><?php echo $shipping_times_info[$state->shipping_time_id]->min_days; ?> Day(s)</td>
<?php
          } else { ?>
                    <td><?php echo $shipping_times_info[$state->shipping_time_id]->min_days; ?> to <?php echo $shipping_times_info[$state->shipping_time_id]->max_days; ?> Days</td>
<?php
          } ?>
                    <td><?php echo $state->tax_percentage; ?> %</td> 
<?php
          if($state->cod_available == 1) { ?>
                    <td><strong class="text-success">Yes</strong></td>
<?php
          } else { ?>
                    <td>No</td>
<?php
          } ?>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'states/edit/'.$state->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'states/delete/'.$state->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop ?>
                </tbody>
<?php
      } //end of if 
      else {  ?>  
                <tfoot>                
                  <tr align='center'>
                    <td colspan="6"><a href="<?php echo $this->config->base_url().'states/add/'.$states->id; ?>" class="btn btn-default">Start adding States +</a></td>
                  </tr>
                </tfoot>
<?php } // end of else ?>                  
                
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
