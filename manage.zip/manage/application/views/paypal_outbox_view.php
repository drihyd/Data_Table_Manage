<?php
//date_default_timezone_set("Asia/Kolkata");
setlocale(LC_MONETARY, 'en_IN');
?>
    <section class="stats-section">
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table dataTable">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Cart ID</th>
                    <th>Customer ID</th>
                    <th>Customer Email</th>
                    <th>Grand Total INR</th>
                    <th>Grand Total USD</th>
                    <th>Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                
                  
<?php if(count($orders) > 0) { ?>
                <tbody>
<?php
        foreach ($orders as $order) { ?> 
                  <tr>
                    <td><?php echo $order->id; ?></td>
                    <td><a href="<?php echo $this->config->base_url().'carts/view/'. $order->cart_id; ?>"><?php echo $order->cart_id; ?></a></td>
                    <td><a href="<?php echo $this->config->base_url().'customers/customer_info/'. $order->customer_id; ?>"><?php echo $order->customer_id; ?></a></td>
                    <td><?php echo $order->customer_email; ?></td>
                    <td><?php echo money_format('%!.2n', $order->grand_total_inr); ?></td>
                    <td><?php echo $order->grand_total_usd; ?></td>
                    <td><?php echo date('d M, Y H:i:s', strtotime($order->date)); ?></td>
                    <td>
                      <a href="<?php echo $this->config->base_url().'paypal_outbox/order_snapshot/'.$order->id; ?>">View order snapshot</a>
                    </td>
                  </tr>
<?php   } // end of foreach loop ?>
                </tbody>
<?php
      } //end of if 
      else {  ?>  
                <tfoot>                
                  <tr align='center'>
                    <td colspan="6">No Orders</td>
                  </tr>
                </tfoot>
<?php } // end of else ?>                  
                
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>
    
  </div>
  <!-- /#main-content -->
