<div class="sub-header">Edit <?php echo ucwords($seo_details->page); ?> Meta Tags</div>
<section class="stats-section">
	<div class="container-fluid">
		<div class="row">
            <div class="col-sm-6">
<?php
	echo $this->session->flashdata('message');
?>
				<?php echo form_open("static_page_seo/save/{$seo_details->id}", array('class' => 'edit-form')); ?>
					<legend>Edit Meta Tags</legend>
					<div class="form-group inline">
						<label for="seo_title">Title</label>
						<input type="text" class="form-control input-sm" id="seo_title" name="seo_title" value="<?php echo $seo_details->seo_title; ?>">
					</div>
					<div class="form-group inline">
						<label for="seo_desc">Description</label>
						<input type="text" class="form-control input-sm" id="seo_desc" name="seo_desc" value="<?php echo $seo_details->seo_desc; ?>">
					</div>
					<div class="form-group inline">
						<label for="seo_keywords">Keywords</label>
						<input type="text" class="form-control input-sm" id="seo_keywords" name="seo_keywords" value="<?php echo $seo_details->seo_keywords; ?>">
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-brand btn-wide btn-sm">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>
