<?php
//date_default_timezone_set("Asia/Kolkata");
setlocale(LC_MONETARY, 'en_IN');
?>
<div class="sub-header">Coupons</div>  


    <section class="stats-section">
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'coupons/add'; ?>" class="btn btn-default btn-sm">New Coupon +</a>
          </div>
        </div>
        
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table dataTable">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Code</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Usage Limit</th>
                    <th>Times Used</th>
                    <th>Valid From</th>
                    <th>Valid Till</th>
                    <th>For Customer</th>
                    <th>Type</th>
                    <th>Value</th>
                    <th>Min Order</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                
                  
<?php if(count($coupons) > 0) { ?>
                <tbody>
<?php
        foreach ($coupons as $coupon) { ?> 
                  <tr>
                    <td><a href="<?php echo $this->config->base_url().'coupons/coupon_info/'.$coupon->id; ?>"><?php echo $coupon->id; ?></a></td>
                    <td><?php echo $coupon->code; ?></td>
                    <td><?php echo ucfirst($coupon->title); ?></td>
                    <td><?php echo ucfirst($coupon->desc); ?></td>
<?php
if($coupon->usage_limit == -1) { ?>                    
                    <td>Infinite</td>
<?php
} else { ?>
                    <td><?php echo $coupon->usage_limit; ?></td>
<?php
} ?>
                    <td><?php echo $coupon->times_used; ?></td>
                    <td><?php echo date('d F, Y', strtotime($coupon->valid_from)); ?></td>
                    <td><?php echo date('d F, Y', strtotime($coupon->valid_till)); ?></td>
<?php
if($coupon->owner_cust_id != 0) { ?>                    
                    <td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$coupon->owner_cust_id; ?>"><?php echo $coupon->owner_cust_id; ?></a></td>
<?php
} else { ?>
                    <td>&nbsp;</td>
<?php
} ?>

                    <td><?php echo ucwords($coupon->type); ?></td>
                    <td><?php echo ucwords($coupon->value); ?></td>
                    <td><?php echo ucwords($coupon->min_order_value); ?></td> 
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'coupons/edit/'.$coupon->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'coupons/delete/'.$coupon->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop ?>
                </tbody>
<?php
      } //end of if 
      else {  ?>  
                <tfoot>                
                  <tr align='center'>
                    <td colspan="6">No coupons</td>
                  </tr>
                </tfoot>
<?php } // end of else ?>                  
                
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>
     
    
  </div>
  <!-- /#main-content -->
