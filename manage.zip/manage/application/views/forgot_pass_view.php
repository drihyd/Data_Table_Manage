<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
  
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/style.css">

  <!--[if lt IE 9]>
  <script src="js/vendor/html5-3.6-respond-1.1.0.min.js"></script>
  <![endif]-->
</head>
<body style="padding-left: 0px;">
  <!--[if lt IE 7]>
  <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
  <![endif]-->
  
  <style>
    form.login {
      background: #fff;
      width: 80%;
      max-width: 480px;
      display: block;
      margin: 10% auto;
      border-radius: 6px;
      padding-bottom: 15px;
    }
    form.login h2 {
      font-size: 14px;
      display: block;
      background: #1b1834;
      margin-bottom: 15px;
      padding: 15px;
      color: #fbe113;
      border-top-right-radius: 6px;
      border-top-left-radius: 6px;
    }
    form.login .form-group {
      padding: 0 15px;
    }
    form.login .btn-action-link {
      font-style: italic;
      font-size: 12px;
      display: inline-block;
    }
  </style>
   <div class="container">
     <div class="col-sm-6 col-sm-offset-3">


      
      <?php echo form_open('profile/forgot_pass', array('class' => 'login ajaxform')); ?>
        <h2 class="form-signin-heading">Forgot Password</h2>
<?php
if(!isset($success)): ?>        
        <div class="form-group">
          <?php echo validation_errors(); ?>
          <label>Enter Your Email</label>
          <input type="email" id="email" name="email" class="form-control" placeholder="email" autofocus>
        </div>
<?php
endif;
if(isset($success)) : ?>
        <div class="form-group"> 
          <div class="label label-success"><?php echo $success; ?></div>
        </div>
<?php
endif; ?>        
      
        <div class="form-group">
<?php
if(!isset($success)): ?>
          <button class="btn btn-lg btn-brand btn-sm btn-wide" type="submit">Submit</button>
<?php
endif;
if(isset($success)): ?>
          <a href="<?php echo $this->config->base_url().'login'; ?>" class="btn btn-brand btn-sm btn-wide">Login</a>
<?php
endif; ?>
        </div>
      </form>
     </div>
   </div>
   
  
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="<?php echo $this->config->base_url(); ?>js/vendor/jquery-1.11.0.min.js"><\/script>')</script>
  
  <script src="<?php echo $this->config->base_url(); ?>js/vendor/bootstrap.min.js"></script>
  <script src="<?php echo $this->config->base_url(); ?>js/vendor/tablesort.js"></script>
  <script src="<?php echo $this->config->base_url(); ?>js/main.js"></script>
</body>
</html>
