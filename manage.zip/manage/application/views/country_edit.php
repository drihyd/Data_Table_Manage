    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
<?php
    echo $this->session->flashdata('form-after-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>
                <?php echo form_open('countries/save/'.$country_details->id, array('class' => 'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="countryName" class="control-label">Country Name</label>
                    <input type="text" class="form-control input-sm" id="countryName" name="countryName" value="<?php echo ucwords($country_details->country_name); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="countryCode" class="control-label">Country Code</label>
                    <input type="text" class="form-control input-sm" id="countryCode" name="countryCode" value="<?php echo $country_details->country_code; ?>">
                  </div>
                  
                  <div class="form-group inline">
                    <label for="countryShippingRateID" class="control-label">Shipping Rate</label>
                    <select class="form-control input-sm" id="countryShippingRateID" name="countryShippingRateID" required>
<?php
foreach($shipping_rates as $shipping_rate) {
  if($shipping_rate->id == $country_details->shipping_rate_id) { ?>
                      <option value="<?php echo $shipping_rate->id; ?>" selected><?php echo ucwords($shipping_rate->name); ?> (<?php echo $shipping_rate->inr_rate; ?> per KG)</option>
<?php
  } else { ?>
                      <option value="<?php echo $shipping_rate->id; ?>"><?php echo ucwords($shipping_rate->name); ?> (<?php echo $shipping_rate->inr_rate; ?> per KG)</option>
<?php
  } ?>
<?php
} ?>
                    </select>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="countryShippingTimeID" class="control-label">Shipping Time</label>
                    <select class="form-control input-sm" id="countryShippingTimeID" name="countryShippingTimeID" required>
<?php
foreach($shipping_times as $shipping_time) {
  if($shipping_time->min_days == $shipping_time->max_days) {
    if($shipping_time->id == $country_details->shipping_time_id) { ?>
                      <option value="<?php echo $shipping_time->id; ?>" selected><?php echo ucwords($shipping_time->name); ?> - <?php echo $shipping_time->min_days; ?> day(s)</option>
<?php
    } else { ?>
                      <option value="<?php echo $shipping_time->id; ?>"><?php echo ucwords($shipping_time->name); ?> - <?php echo $shipping_time->min_days; ?> day(s)</option>
<?php
    } ?>
<?php
  } 
  else { 
    if($shipping_time->id == $country_details->shipping_time_id) { ?>
                      <option value="<?php echo $shipping_time->id; ?>" selected><?php echo ucwords($shipping_time->name); ?> - <?php echo $shipping_time->min_days; ?> to <?php echo $shipping_time->max_days; ?> days</option>
<?php
    } else { ?>
                      <option value="<?php echo $shipping_time->id; ?>"><?php echo ucwords($shipping_time->name); ?> - <?php echo $shipping_time->min_days; ?> to <?php echo $shipping_time->max_days; ?> days</option>
<?php
    } ?>
    
<?php
  } ?>
  
<?php
} ?>
                    </select>
                  </div>
                  
                    
                  <div class="form-group inline">
                    <label for="countryTax" class="control-label">Tax Percentage</label>
                    <input type="text" class="form-control input-sm" id="countryTax" name="countryTax" value="<?php echo $country_details->tax_percentage; ?>">
                  </div>
                  
                  <div class="form-group inline">
                    <label for="countryCOD" class="control-label">Cash on Delivery Available</label>
                    <select class="form-control input-sm" id="countryCOD" name="countryCOD" required>
<?php
if($country_details->cod_available == 0) { ?>                      
                      <option value="0" selected>No</option>
<?php
} else { ?>
                      <option value="0">No</option>
<?php
}

if($country_details->cod_available == 1) { ?>
                      <option value="1" selected>Yes</option>
<?php
} else { ?>
                      <option value="1">Yes</option>
<?php
} ?>
                    </select>
                  </div>
                  
                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'countries'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#basicinfo tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
