<div class="sub-header">Add Homepage Slider</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open_multipart('homepage_sliders/save/', array('class' => 'margin-top-15')); ?>
              <legend>Basic Info</legend>
            
              <div class="form-group margin-top-15">
                <label for="homepage_sliderImage" class="control-label">Add Homepage Slider Image</label>
                <input type="file" class="form-control" id="homepage_sliderImage" name="homepage_sliderImage" value="">
              </div>
              <div class="form-group inline">
                <label for="homepage_sliderUrl" class="control-label">URL</label>
                <input type="text" class="form-control" id="homepage_sliderUrl" name="homepage_sliderUrl" value="">
              </div>
              <div class="form-group inline">
                <label for="homepage_sliderCaption" class="control-label">Caption</label>
                <input type="text" class="form-control" id="homepage_sliderCaption" name="homepage_sliderCaption" value="">
              </div>
                             
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
