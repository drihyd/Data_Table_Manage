<div class="sub-header">Add Product</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open('products/save', array('class' => 'edit-form')) ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="productName" class="control-label">Name</label>
                <input type="text" class="form-control input-sm nameForSlug" id="productName" name="productName" value="" required>
              </div>
              <div class="form-group inline">
                <label for="productCode" class="control-label">Code</label>
                <input type="text" class="form-control input-sm" id="productCode" name="productCode" value="" required>
              </div>
              <div class="form-group inline">
                <label for="productSlug" class="control-label">Slug</label>
                <input type="text" class="form-control input-sm slugForName" id="productSlug" name="productSlug" value="" required>
              </div>
              <div class="form-group inline">
                <label for="productCategory" class="control-label">Category</label>
<?php if($categories_list) { ?>
                <select class="form-control input-sm" id="productCategory" name="productCategory" required>
<?php   foreach($categories_list as $category) { ?>
                  <option value="<?php echo $category->id; ?>"><?php echo ucfirst($category->name); ?></option>
<?php   } // end of foreach ?>
                </select>
<?php }  // end of if 
      else {
        echo "<div><a href='#' class='text-danger'>Add some categories first</a></div>";
      } ?>
              </div>
              
              <div class="form-group inline">
                <label for="productPrice" class="control-label">Price (INR)</label>
                <input type="text" class="form-control input-sm" id="productPrice" name="productPrice" value="" required>
              </div>
              <br>
              <div class="form-group inline">
                <div class="checkbox">
                  <label>
                    <input type="checkbox" name="productUnstitched" value="1" autocomplete="off"> unstitched
                  </label>
                </div>
              </div>
              
              <div class="form-group">
                <label for="productPosScore" class="control-label">Position Score</label>
                <input type="number" min="0" max="1000" class="form-control input-sm" id="productPosScore" name="productPosScore" value="0">
                <div class="help-block"><small>Position Score is a number between 0 and 1000. Products are displayed in the descending order of their Position Score. Products with higher scores show up first.</small></div>
              </div>
              
              <div class="form-group">
                <label for="productDesc" class="control-label">Description</label>
                <textarea class="form-control input-sm" style="max-width: 100%; min-width: 100%; min-height: 100px;" id="productDesc" name="productDesc"></textarea>
              </div>
              
              <div class="form-group margin-top-30">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'products'; ?>" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
