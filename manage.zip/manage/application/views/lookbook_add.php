<div class="sub-header">Add Product</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open_multipart('lookbooks/save', array('class' => 'edit-form')) ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="lb_name" class="control-label">Name</label>
                <input type="text" class="form-control input-sm nameForSlug" id="lb_name" name="lb_name" value="" required>
              </div>
              <div class="form-group inline">
                <label for="lb_code" class="control-label">Code</label>
                <input type="text" class="form-control input-sm" id="lb_code" name="lb_code" value="" required>
              </div>
              <div class="form-group inline">
                <label for="lb_slug" class="control-label">Slug</label>
                <input type="text" class="form-control input-sm slugForName" id="lb_slug" name="lb_slug" value="" required>
              </div>
              <div class="form-group inline">
                <label for="productCategory" class="control-label">Description</label>
                <textarea name="lb_desc" id="lb_desc" cols="30" rows="10"></textarea>
              </div>
              
              <div class="form-group inline">
                <label for="productPrice" class="control-label">Image</label>
                <input type="file" class="form-control input-sm" id="image" name="image" required>
              </div>
              <br>

               <div class="form-group inline">
                <label for="productPrice" class="control-label">Details Image</label>
                <input type="file" class="form-control input-sm" id="image" name="image" required>
              </div>
              <br>             
              
              <div class="form-group margin-top-30">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save</button> <a href="<?php echo $this->config->base_url().'lookbooks'; ?>" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
