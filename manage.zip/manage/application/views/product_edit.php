    <?php $this->load->helper('encode_helper'); ?>
    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
        <li role="presentation"><a href="#productpics" aria-controls="productpics" role="tab" data-toggle="tab">Product Pictures</a></li>
        <li role="presentation"><a href="#seotags" aria-controls="seotags" role="tab" data-toggle="tab">SEO Tags</a></li>
      </ul>
    </div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
<?php
                      echo $this->session->flashdata('form-after-message');
?>              
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>
                <?php echo form_open('products/save/'.$product_details->id, array('class'=>'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="productName" class="control-label">Name</label>
                    <input type="text" class="form-control input-sm nameForSlug" id="productName" name="productName" value="<?php echo $product_details->name; ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="productCode" class="control-label">Code</label>
                    <input type="text" class="form-control input-sm" id="productCode" name="productCode" value="<?php echo $product_details->code; ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="productSlug" class="control-label">Slug</label>
                    <input type="text" class="form-control input-sm slugForName" id="productSlug" name="productSlug" value="<?php echo $product_details->slug; ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="productCategory" class="control-label">Category</label>
    <?php if($categories_list) { ?>
                    <select class="form-control input-sm" id="productCategory" name="productCategory">
    <?php   foreach($categories_list as $category) {
              
              if($category->id == $product_details->cat_id) { ?>
                      <option value="<?php echo $category->id; ?>" selected><?php echo ucfirst($category->name); ?></option>
    <?php     } // end of if 
              else { ?>
                      <option value="<?php echo $category->id; ?>"><?php echo ucfirst($category->name); ?></option>
    <?php     } // end of else ?>
    <?php   } // end of foreach ?>
                    </select>
    <?php }  // end of if 
          else {
            echo "<div><a href='#' class='text-danger'>Add some categories first</a></div>";
          } ?>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="productPriceINR" class="control-label">Price INR</label>
                    <input type="text" min="0" class="form-control input-sm" id="productPriceINR" name="productPriceINR" value="<?php echo $product_details->price_inr; ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="productPriceUSD" class="control-label">Price USD</label>
                    <input type="text" min="0" class="form-control input-sm" id="productPriceUSD" name="productPriceUSD" value="<?php echo $product_details->price_usd; ?>">
                  </div>
                  
                  <br>
                  
                  <div class="form-group inline">
                    <div class="checkbox">
                      <label>
<?php 
if($product_details->unstitched == 1) { ?>
                        <input type="checkbox" name="productUnstitched" value="1" checked> unstitched
<?php
} else { ?>
                        <input type="checkbox" name="productUnstitched" value="1" autocomplete="off"> unstitched
<?php
} ?>
                      </label>
                    </div>
                  </div>
                  <br>
                  
<?php
foreach($attribute_values_array as $key => $value) { ?>
                  <!-- div class="form-group inline">
                    <label><?php echo ucwords($attribute_names[$key]); ?></label>
                    <select name="productAttributes[]" class="form-control input-sm">
<?php
  foreach($value as $attribute_value) {
    if(in_array($attribute_value->id, $selected_attributes)) { ?>
                      <option value="<?php echo $attribute_value->id; ?>" selected><?php echo ucwords($attribute_value->attr_value); ?></option>
<?php
    } else { ?>
                      <option value="<?php echo $attribute_value->id; ?>"><?php echo ucwords($attribute_value->attr_value); ?></option>
        
<?php
    }
  } ?>
                    </select>
                  </div -->
<?php
} ?>
                  <div class="form-group">
                    <label for="productPosScore" class="control-label">Position Score</label>
                    <input type="number" min="0" max="1000" class="form-control input-sm" id="productPosScore" name="productPosScore" value="<?php echo $product_details->position_score; ?>">
                    <div class="help-block"><small>Position Score is a number between 0 and 1000. Products are displayed in the descending order of their Position Score. Products with higher scores show up first.</small></div>
                  </div>
                  
                  <div class="form-group">
                    <label for="productDesc" class="control-label">Description</label>
                    <textarea class="form-control input-sm" style="max-width: 100%; min-width: 100%; min-height: 100px;" id="productDesc" name="productDesc"><?php echo $product_details->desc; ?></textarea>
                  </div>
                  
                  <input type="hidden" name="productId" value="productId">
                  <div class="form-group margin-top-30">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'products/product_info/'.$product_details->id; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./end basicinfo tab -->
              
              <div role="tabpanel" class="tab-pane" id="productpics">

<?php
$product_code = implode('_', explode(' ',$product_details->code));
$product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
//foreach($product_images as $image) { ?>        
        <!-- a href="<?php echo $this->config->base_url().$image;?>" -->
          <!-- img src="<?php echo $this->config->base_url().$image;?>" -->
        <!-- /a -->
<?php
//} ?>
                  <?php echo validation_errors(); ?>
                  <?php echo form_open_multipart('products/imageSave/'.$product_details->id, array('class' => 'edit-form', 'style' => ' display: inline-block;')); ?>
                      <legend>Upload Image</legend>
                      <small class="text-danger">Must be 500 X 500 px</small><br>
                      <img src="<?php echo $this->config->base_url().'img/Not_Available.jpg'; ?>" width="210px"><br>
                      <label for="productImage" class="control-label">Change Picture</label>
                      <br>
                      <input type="file" class="form-control input-sm" id="productImage" name="productImage" style="display: inline-block;max-width: 210px;">
                      <div class="form-group margin-top-15">
                        <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'products/product_info/'.$product_details->id; ?>" class="btn btn-action-link">Cancel</a>
                      </div>
                  </form><br>
                  
<?php
if( (is_array($product_images)) && (count($product_images) > 0) ) {
  foreach($product_images as $image) { ?>
                  <?php echo validation_errors(); ?>
                  <?php echo form_open_multipart('products/imageDelete/'.$product_details->id, array('class' => 'edit-form', 'style' => ' display: inline-block;')); ?>
                      <img src="<?php echo $this->config->base_url().$image;?>" width="210px"><br>
                      <input type="hidden" name="filename" value="<?php echo filename_encode($image); ?>">
                      <div class="form-group margin-top-15">
                        <button type='submit' class='btn btn-danger btn-sm btn-wide delete-confirm'>Remove Image</button>
                      </div>
                  </form>
<?php 
  }
} ?>              
              </div>
                
              <div role="tabpanel" class="tab-pane" id="seotags">
                <?php echo validation_errors(); ?>
                <?php echo form_open('products/seosave/'.$product_details->id, array('class'=>'edit-form')); ?>
                  <legend>SEO Tags</legend>
                  <div class="form-group inline">
                    <label for="productSeoTitle" class="control-label">Page Title</label>
                    <input type="text" class="form-control input-sm" id="productSeoTitle" name="productSeoTitle" value="<?php echo ucfirst($product_details->seo_title); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="productSeoDesc" class="control-label">Page Description</label>
                    <input type="text" class="form-control input-sm" id="productSeoDesc" name="productSeoDesc" value="<?php echo ucfirst($product_details->seo_desc); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="productSeoKeys" class="control-label">Page Keywords</label>
                    <input type="text" class="form-control input-sm" id="productSeoKeys" name="productSeoKeys" value="<?php echo ucfirst($product_details->seo_keywords); ?>">
                  </div>
                  
                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'products/product_info/'.$product_details->id; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./end seotags tab -->
            
            </div> <!-- ./ end tab-content -->
            
          </div>
          <div class="col-sm-6">
            <div class="edit-form">
                <legend>Info</legend>
                <p>Name: <?php echo ucwords($product_details->name); ?></p>
                <p>Code: <?php echo $product_details->code; ?></p>
                <p>Parent Category: <a href="<?php echo $this->config->base_url().'categories/category_info/'.$parent_category_details->id; ?>"><?php echo ucwords($parent_category_details->name); ?></a></p>
                <p>Description: <?php echo ucfirst($product_details->desc); ?></p>
                <hr style="margin: 10px 0;">
                <p>Price INR: <?php echo money_format('%!.2n', $product_details->price_inr); ?></p>
            	<p>Price USD: <?php echo money_format('%!.2n', $product_details->price_usd); ?></p>
                <hr style="margin: 10px 0;">
                <p><strong>Attributes:</strong></p>
<?php
foreach($product_attributes as $attribute) { ?>
                  <p><?php echo ucwords($attribute->attribute_name); ?> : <?php echo ucwords($attribute->attribute_value); ?></p>
<?php
} ?>
                <hr style="margin: 10px 0;">
                <p>Images:
<?php
$product_code = implode('_', explode(' ',$product_details->code));
$product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
//foreach($images as $image) { ?>        
        <!-- a href="<?php echo $this->config->base_url().$image;?>" -->
          <!-- img src="<?php echo $this->config->base_url().$image;?>" -->
        <!-- /a -->
<?php
//} ?>
<?php
if( (is_array($product_images)) && (count($product_images) > 0) ) { 
  foreach($product_images as $image) { ?>
              <div style="display: inline-block">
                <img src="<?php echo $this->config->base_url().$image;?>" class="small-thumbnail tiny-thumbnail" style="display:inline-block;">
              </div>
<?php
  } 
} else { ?>
              <div style="display: inline-block">
                <img src="<?php echo $this->config->base_url().'img/Not_Available.jpg';?>" class="small-thumbnail tiny-thumbnail" style="display:inline-block;">
              </div>
<?php
} ?>
                </p>
                <hr style="margin: 10px 0;"> 
                <p>Position Score: <?php echo ucfirst($product_details->position_score); ?></p>
                <hr style="margin: 10px 0;">
                <p>Slug: <?php echo $product_details->slug; ?></p>
                <p>SEO Title: <?php echo $product_details->seo_title; ?></p>
                <p>SEO Description: <?php echo $product_details->seo_desc; ?></p>
                <p>SEO Keywords: <?php echo $product_details->seo_keywords; ?></p>
                <hr style="margin: 10px 0;">
                <a href="<?php echo $this->config->base_url().'products'; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Back to All Products</a>
                &nbsp;<a href="<?php echo $this->config->base_url().'products/delete/'.$product_details->id; ?>" class="btn btn-danger btn-xs delete-confirm"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                <small class="help-block">Deleting this Product will delete all the SKU's listed under it.</small>
            </div>
            
            
            
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
