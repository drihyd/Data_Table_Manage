<div class="sub-header">Edit Project</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open_multipart('projects/save/'.$project_details['id']); ?>
              <legend>Basic Info</legend>
              <div class="form-group inline">
                <label for="projectName" class="control-label">Name</label>
                <input type="text" class="form-control nameForSlug" id="projectName" name="projectName" value="<?php echo $project_details['name']; ?>">
              </div>
              <div class="form-group inline">
                <label for="projectSlug" class="control-label">Slug</label>
                <input type="text" class="form-control slugForName" id="projectSlug" name="projectSlug" value="<?php echo $project_details['slug']; ?>">
              </div>
              <div class="form-group">
                <label for="projectDesc" class="control-label">Description</label>
                <textarea class="form-control mce" id="projectDesc" name="projectDesc"><?php echo $project_details['desc']; ?></textarea>
              </div>
              <legend>Display Picture</legend>
<?php         if($project_details['main_img']) { ?>
              <img src="<?php echo $this->config->base_url().'../assets/uploads/files/'.$project_details['main_img']; ?>" class="img-responsive" alt="" title="">
                
              <div class="form-group margin-top-15">
                <label for="projectDPChange" class="control-label">Change Display Picture</label>
                <input type="file" class="form-control" id="projectDPChange" name="projectDPChange">
              </div>
              <input type="hidden" name="editType" value="update">
<?php         } // end of if 
              else { ?>
              <div class="form-group margin-top-15">
                <label for="projectDPChange" class="control-label">Add Display Image</label>
                <input type="file" class="form-control" id="projectDPChange" name="projectDPChange" required>
              </div>
              <input type="hidden" name="editType" value="create">
<?php         } ?>
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
            
          </div>
          
          <div class="col-sm-6">
            
            <?php echo validation_errors(); ?>
            <?php echo form_open('projects/seosave/'.$project_details['id']); ?>
              <legend>SEO Tags</legend>
              <div class="form-group inline">
                <label for="projectSeoTitle" class="control-label">Page Title</label>
                <input type="text" class="form-control" id="projectSeoTitle" name="projectSeoTitle" value="<?php echo ucfirst($project_details['seo_title']); ?>">
              </div>
              <div class="form-group inline">
                <label for="projectSeoDesc" class="control-label">Page Description</label>
                <input type="text" class="form-control" id="projectSeoDesc" name="projectSeoDesc" value="<?php echo ucfirst($project_details['seo_desc']); ?>">
              </div>
              <div class="form-group inline">
                <label for="projectSeoKeys" class="control-label">Page Keywords</label>
                <input type="text" class="form-control" id="projectSeoKeys" name="projectSeoKeys" value="<?php echo ucfirst($project_details['seo_keywords']); ?>">
              </div>
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
            
            <legend class="margin-top-30">Associated Gallery Images</legend>
<?php if($galleryimgs) {
        foreach($galleryimgs as $galleryimg) { ?>
            <a href="<?php echo $this->config->base_url().'galleryimgs/edit/'.$galleryimg['id']; ?>" class="btn btn-link slider-edit-link" style="padding:0;"><img src="<?php echo $this->config->base_url().'../assets/uploads/files/'.$galleryimg['image']; ?>" class="img-responsive" style="max-width: 150px;"></a>
<?php   } ?>
            <a href="<?php echo $this->config->base_url().'galleryimgs/add/'.$project_details['id']; ?>" class="btn btn-default btn-sm">Add a new Gallery Image +</a>
<?php } 
      else { ?>
           <a href="<?php echo $this->config->base_url().'galleryimgs/add/'.$project_details['id']; ?>" class="btn btn-default btn-sm">Add a Gallery Image +</a>
<?php } ?>
            
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
