    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#discountimage" aria-controls="discountimage" role="tab" data-toggle="tab">Upload Images</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
 <?php
    echo $this->session->flashdata('form-after-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="discountimage">
                <?php echo validation_errors(); ?>
                <?php echo form_open_multipart('bulk_images_upload/doupload', array('class' => 'edit-form')); ?>
                  <legend>Bulk Upload</legend>
                  
                  <div class="form-group">
                    <label for="userfile">Select Images (500px X 500px)</label>
                    <input name="userfile[]" class="form-control input-sm" id="userfile" type="file" multiple="" />
                    <!-- input type="file" name="userfile[]" id="userfile" class="form-control input-sm" multiple required -->
                  </div>
                  
                  <div class="form-group">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Import Images</button> <a href="<?php echo $this->config->base_url().'dashboard' ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#discountimage tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
