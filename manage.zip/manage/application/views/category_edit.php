    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
        <li role="presentation"><a href="#displaypic" aria-controls="displaypic" role="tab" data-toggle="tab">Display Picture</a></li>
        <li role="presentation"><a href="#designertip" aria-controls="designertip" role="tab" data-toggle="tab">Designer Tip</a></li>
        <li role="presentation"><a href="#seotags" aria-controls="seotags" role="tab" data-toggle="tab">SEO Tags</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
 <?php
    echo $this->session->flashdata('form-after-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>
                <?php echo form_open('categories/save/'.$category_details->id, array('class' => 'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="categoryName" class="control-label">Name</label>
                    <input type="text" class="form-control input-sm nameForSlug" id="categoryName" name="categoryName" value="<?php echo $category_details->name; ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="categorySlug" class="control-label">Slug</label>
                    <input type="text" class="form-control input-sm slugForName" id="categorySlug" name="categorySlug" value="<?php echo $category_details->slug; ?>">
                  </div>
    <?php if($parent_categories) { ?>
                  <div class="form-group inline">
                    <label for="categoryParent" class="control-label">Parent Category</label>
                    <select class="form-control input-sm" name="categoryParent" id="categoryParent">
    <?php foreach($parent_categories as $category) { 
            if($category->id == $category_details->parent_id) { ?>
                      <option value="<?php echo $category->id; ?>" selected><?php echo ucfirst($category->name); ?></option>
    <?php   }
            else { ?>
                      <option value="<?php echo $category->id; ?>"><?php echo ucfirst($category->name); ?></option>
    <?php   } 
          } ?>
                    </select>
                  </div>
                  
                  <div class="form-group">
                    <label for="applicableCats">Applicable Attributes</label><br>
<?php
foreach($attributes as $attribute) { ?>
                    <div class="checkbox"  style="display: inline-block;margin-left: 10px;">
                      <label for="<?php echo str_replace(' ', '', strtolower($attribute->attr_name)); ?>">
<?php
  if(in_array($attribute->id, $selected_attributes)) { ?>
                        <input type="checkbox" name="applicableAttributes[]" id="<?php echo str_replace(' ', '', strtolower($attribute->attr_name)); ?>" value="<?php echo $attribute->id; ?>" checked> <span style="color:#333;font-size: 0.9em;"><?php echo ucwords($attribute->attr_name); ?></span>
<?php
  }
  else {?>
                        <input type="checkbox" name="applicableAttributes[]" id="<?php echo str_replace(' ', '', strtolower($attribute->attr_name)); ?>" value="<?php echo $attribute->id; ?>"> <span style="color:#333;font-size: 0.9em;"><?php echo ucwords($attribute->attr_name); ?></span>
<?php                      
  } ?> 
                      </label>
                    </div>
<?php
} ?>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="categoryShippingWeight" class="control-label">Shipping Weight (in Kg)</label>                    
                    <input type="text" class="form-control input-sm" id="categoryShippingWeight" name="categoryShippingWeight" value="<?php echo $category_details->shipping_weight; ?>">
                  </div>
                  
                  <div class="form-group">
                    <label for="categoryPosScore" class="control-label">Position Score</label>
                    <input type="number" min="0" max="1000" class="form-control input-sm" id="categoryPosScore" name="categoryPosScore" value="<?php echo $category_details->position_score; ?>">
                    <div class="help-block"><small>Position Score is a number between 0 and 1000. Categories are displayed in the <strong>descending</strong> order of their Position Score. Categories with higher scores show up first.</small></div>
                  </div>
                  
                  <div class="form-group">
                    <label for="categoryDesc" class="control-label">Description</label>
                    <textarea id="categoryDesc" name="categoryDesc" style="max-width: 100%;min-width;100%;" class="form-control input-sm"><?php echo $category_details->desc; ?></textarea>
                  </div>
    <?php } 
          else { ?>
                    
                  <div class="form-group margin-top-0">
                    <a href="<?php echo $this->config->base_url().'categories/parentadd'; ?>" class="btn btn-default btn-sm">Add a parent category first</a>
                  </div>
    <?php } ?>

                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'categories/category_info/'.$category_details->id; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#basicinfo tab end-->
              
              <div role="tabpanel" class="tab-pane" id="displaypic">
                <?php echo validation_errors(); ?>
                <?php echo form_open_multipart('categories/DPimageSave'.'/'.$category_details->id, array('class' => 'edit-form')); ?>
                  <legend>Product Display Picture</legend>
                    
    <?php         if($category_details->cat_image) { ?>
                  <img src="<?php echo $this->config->base_url().'../assets/uploads/category_dps/'.$category_details->cat_image; ?>" class="img-responsive" alt="" title="">
                    
                  <div class="form-group margin-top-15">
                    <label for="categoryDPChange" class="control-label">Change Display Picture</label>
                    <small class="text-warning">Must be 500 X 300 px</small><br>
                    <input type="file" class="form-control input-sm" id="categoryDPChange" name="categoryDPChange">
                  </div>
                  <input type="hidden" name="editType" value="update">
    <?php         } // end of if 
                  else { ?>
                  <div class="form-group margin-top-15">
                    <label for="categoryDPChange" class="control-label">Add Display Image</label>
                    <input type="file" class="form-control input-sm" id="categoryDPChange" name="categoryDPChange">
                  </div>
                  <input type="hidden" name="editType" value="create">
    <?php         } ?>              
                  
                  <input type="hidden" name="categoryId" value="categoryId">
                  <input type="hidden" name="imageId" value="imageId">
                  <div class="form-group">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'categories/category_info/'.$category_details->id; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#displaypic tab end-->
              
              <div role="tabpanel" class="tab-pane" id="designertip">
                <?php echo validation_errors(); ?>
                <?php echo form_open('categories/designertip_save/'.$category_details->id, array('class' => 'edit-form')); ?>
                  <legend>Designer Tip</legend>
<?php
if(count($designerTip) > 0) { ?>
                  <div class="form-group inline">
                    <label for="designerName" class="control-label">Designer Name</label>
                    <input type="text" class="form-control input-sm" id="designerName" name="designerName" value="<?php echo ucwords($designerTip->designer_name); ?>" required>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="designerDesignation" class="control-label">Designer Designation</label>
                    <input type="text" class="form-control input-sm" id="designerDesignation" name="designerDesignation" value="<?php echo ucfirst($designerTip->designer_designation); ?>" required>
                  </div>
                  
                  <div class="form-group">
                    <label for="designerTip" class="control-label">Designer Tip</label>
                    <textarea class="form-control input-sm" style="max-width: 100%;min-height: 100px;" name="designerTip" required><?php echo ucfirst($designerTip->designer_tip); ?></textarea>
                  </div>
                  
<?php
} else { ?>
                  <div class="form-group inline">
                    <label for="designerName" class="control-label">Designer Name</label>
                    <input type="text" class="form-control input-sm" id="designerName" name="designerName" value="" required>
                  </div>
                  
                  <div class="form-group inline">
                    <label for="designerDesignation" class="control-label">Designer Designation</label>
                    <input type="text" class="form-control input-sm" id="designerDesignation" name="designerDesignation" value="" required>
                  </div>
                  
                  <div class="form-group">
                    <label for="designerTip" class="control-label">Designer Tip</label>
                    <textarea class="form-control input-sm" style="max-width: 100%;min-height: 100px;" name="designerTip" required></textarea>
                  </div>
<?php
} ?>

                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'categories/category_info/'.$category_details->id; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#designertip tab end -->
              
              <div role="tabpanel" class="tab-pane" id="seotags">
                <?php echo validation_errors(); ?>
                <?php echo form_open('categories/seosave/'.$category_details->id, array('class' => 'edit-form')); ?>
                  <legend>SEO Tags</legend>
                  <div class="form-group inline">
                    <label for="categorySeoTitle" class="control-label">Page Title</label>
                    <input type="text" class="form-control input-sm" id="categorySeoTitle" name="categorySeoTitle" value="<?php echo ucfirst($category_details->seo_title); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="categorySeoDesc" class="control-label">Page Description</label>
                    <input type="text" class="form-control input-sm" id="categorySeoDesc" name="categorySeoDesc" value="<?php echo ucfirst($category_details->seo_desc); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="categorySeoKeys" class="control-label">Page Keywords</label>
                    <input type="text" class="form-control input-sm" id="categorySeoKeys" name="categorySeoKeys" value="<?php echo ucfirst($category_details->seo_keywords); ?>">
                  </div>
                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'categories/category_info/'.$category_details->id; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#seotags tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
          <div class="col-sm-6">
            <div class="edit-form">
              
              <p>Name: <?php echo ucwords($category_details->name); ?></p>
              <p>Slug: <?php echo $category_details->slug; ?></p>
              <p>Parent Category: <a href="<?php echo $this->config->base_url().'categories/category_info/'.$parent_category_details->id; ?>"><?php echo ucwords($parent_category_details->name); ?></a></p>
  <?php
  if($category_details->cat_image != '') { ?>
              <p>Display Image: <img src="<?php echo $this->config->base_url().'../assets/uploads/category_dps/'.$category_details->cat_image; ?>" style="margin: 5px 0;max-width: 100px" class="small-thumbnail"></p>
  <?php
  } else { ?>
              <p>Display Image: <img src="<?php echo $this->config->base_url().'img/Not_Available.jpg'; ?>" class="small-thumbnail"></p>
  <?php
  } ?>
              <p>Description: <?php echo ucfirst($category_details->desc); ?></p>
              <p>Position Score: <?php echo ucfirst($category_details->position_score); ?></p>
              <p>SEO Title: <?php echo $category_details->seo_title; ?></p>
              <p>SEO Description: <?php echo $category_details->seo_desc; ?></p>
              <p>SEO Keywords: <?php echo $category_details->seo_keywords; ?></p>
              <br>
              <a href="<?php echo $this->config->base_url().'categories'; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Back to All Categories</a>
              &nbsp;<a href="<?php echo $this->config->base_url().'categories/delete/'.$category_details->id; ?>" class="btn btn-danger btn-xs delete-confirm"><span class="glyphicon glyphicon-trash"></span> Delete</a>
              <small class="help-block">Deleting this Category will delete all the products listed under it.</small>
            </div>
              
            </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
