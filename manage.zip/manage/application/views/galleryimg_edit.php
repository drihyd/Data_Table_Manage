<div class="sub-header">Edit Gallery Image</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <a href="<?php echo $this->config->base_url().'galleryimgs/delete/'.$galleryimg_details['id']; ?>" class="btn btn-danger btn-sm margin-top-15 delete-confirm"><b>Delete</b> this Gallery Image</a>
            <?php echo validation_errors(); ?>
            <?php echo form_open_multipart('galleryimgs/save/'.$galleryimg_details['id'], array('class' => 'margin-top-15')); ?>
              <legend>Basic Info</legend>
              <img src="<?php echo $this->config->base_url().'../assets/uploads/files/'.$galleryimg_details['image']; ?>" class="img-responsive" alt="<?php echo $galleryimg_details['caption']; ?>" title="<?php echo $galleryimg_details['caption']; ?>">
              <div class="form-group margin-top-15">
                <label for="galleryimgImage" class="control-label">Change Gallery Image</label>
                <input type="file" class="form-control" id="galleryimgImage" name="galleryimgImage" value="">
              </div>
              <div class="form-group inline">
                <label for="galleryimgCaption" class="control-label">Caption</label>
                <input type="text" class="form-control" id="galleryimgCaption" name="galleryimgCaption" value="<?php echo $galleryimg_details['caption']; ?>">
              </div>
              <div class="form-group inline">
                <label for="galleryimgParentProject" class="control-label">Parent Project</label>
                <select class="form-control" name="galleryimgParentProject" id="galleryimgParentProject" readonly>
                  <option value="<?php echo $project['id']; ?>" selected><?php echo ucfirst($project['name']); ?></option>
                </select>
              </div>
               
              <div class="form-group margin-top-0">
                <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="#" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
