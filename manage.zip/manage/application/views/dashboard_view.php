<script type="text/javascript" src="https://www.google.com/jsapi?autoload={'modules':[{'name':'visualization','version':'1.1','packages':['corechart', 'timeline', 'bar']}]}"></script>
<?php setlocale(LC_MONETARY, 'en_IN'); ?>
<div class="sub-header">Today's Updates</b></div>
<section class="stats-section">
	<div class="container-fluid">
		
		<div class="row">
			<div class="col-sm-12 text-align-center">
				<div class="inline stat-card">
					<h1><?php echo $todays_orders_num; ?></h1>
					<p>Today's Orders</p>
				</div>
				 <div class="inline stat-card">
					<h1>Rs. <?php echo money_format('%!.2n', $todays_order_worth); ?></h1>
					<p>Today's Order Worth</p>
				</div>
				<div class="inline stat-card">
					<h1><?php echo $todays_registrations; ?></h1>
					<p>Today's Registrations</p>
				</div>
			</div>
		</div> <!-- ./row -->
	</div>
</section>

<section class="stats-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12 text-align-center">
				<a href="<?php echo $this->config->base_url().'orders'; ?>" class="inline stat-card">
					<h1><span class="glyphicon glyphicon-list-alt" style="font-size:16px;"></span> View Orders</h1>
				</a>
				<a href="<?php echo $this->config->base_url().'monitor_stock'; ?>" class="inline stat-card">
					<h1><span class="glyphicon glyphicon-bell" style="font-size:16px;"></span> Stock Monitor</h1>
				</a>
				<a href="<?php echo $this->config->base_url().'analytics'; ?>" class="inline stat-card">
					<h1><span class="glyphicon glyphicon-stats" style="font-size:16px;"></span> Order Analytics</h1>
				</a>
				<a href="<?php echo $this->config->base_url().'cart_analytics'; ?>" class="inline stat-card">
					<h1><span class="glyphicon glyphicon-shopping-cart" style="font-size:16px;"></span> Cart Analytics</h1>
				</a>
			</div>
		</div>
	</div>
</section>


