    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
        <li role="presentation"><a href="#seotags" aria-controls="seotags" role="tab" data-toggle="tab">SEO Tags</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
<?php
    echo $this->session->flashdata('form-after-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>
                <?php echo form_open('pages/save/'.$page_details->id, array('class' => 'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="pageName" class="control-label">Name</label>
                    <input type="text" class="form-control input-sm nameForSlug" id="pageName" name="pageName" value="<?php echo $page_details->name; ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="pageSlug" class="control-label">Slug</label>
                    <input type="text" class="form-control input-sm slugForName" id="pageSlug" name="pageSlug" value="<?php echo $page_details->slug; ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="pageTitle" class="control-label">Title</label>
                    <input type="text" class="form-control input-sm" id="pageTitle" name="pageTitle" value="<?php echo $page_details->title; ?>">
                  </div>
                  <div class="form-group">
                    <label for="pageExcerpt" class="control-label">Excerpt</label>
                    <textarea class="form-control input-sm" id="pageExcerpt" name="pageExcerpt" style="max-width: 100%;min-width;100%;"><?php echo $page_details->excerpt; ?></textarea>
                  </div>
                  <div class="form-group">
                    <label for="pageKeywords" class="control-label">Keywords</label>
                    <textarea class="form-control input-sm" id="pageKeywords" name="pageKeywords" style="max-width: 100%;min-width;100%;"><?php echo $page_details->keywords; ?></textarea>
                  </div>
                  <div class="form-group">
                    <label for="pageContent" class="control-label">Content</label>
                    <textarea class="form-control input-sm mce" id="pageContent" name="pageContent"><?php echo $page_details->content; ?></textarea>
                  </div>
                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'pages'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#basicinfo tab end-->
              
              <div role="tabpanel" class="tab-pane" id="seotags">
                <?php echo validation_errors(); ?>
                <?php echo form_open('pages/seosave/'.$page_details->id, array('class' => 'edit-form')); ?>
                  <legend>SEO Tags</legend>
                  <div class="form-group inline">
                    <label for="pageSeoTitle" class="control-label">Page Title</label>
                    <input type="text" class="form-control input-sm" id="pageSeoTitle" name="pageSeoTitle" value="<?php echo ucfirst($page_details->seo_title); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="pageSeoDesc" class="control-label">Page Description</label>
                    <input type="text" class="form-control input-sm" id="pageSeoDesc" name="pageSeoDesc" value="<?php echo ucfirst($page_details->seo_desc); ?>">
                  </div>
                  <div class="form-group inline">
                    <label for="pageSeoKeys" class="control-label">Page Keywords</label>
                    <input type="text" class="form-control input-sm" id="pageSeoKeys" name="pageSeoKeys" value="<?php echo ucfirst($page_details->seo_keywords); ?>">
                  </div>
                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'pages'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#seotags tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
          <div class="col-sm-6">
            <p>Page Name: <?php echo ucwords($page_details->name); ?></p>
            <p>Slug: <?php echo $page_details->slug; ?></p>
            <p>Page Title: <?php echo $page_details->title; ?></p>
            <p>Excerpt: <?php echo $page_details->excerpt; ?></p>
            <p>Content: </p>
            <div>
              <?php echo $page_details->content; ?>
            </div>
            <br>
            <p>SEO Title: <?php echo $page_details->seo_title; ?></p>
            <p>SEO Description: <?php echo $page_details->seo_desc; ?></p>
            <p>SEO Keywords: <?php echo $page_details->seo_keywords; ?></p>
            <br>
            <a href="<?php echo $this->config->base_url().'pages'; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Back to All Pages</a>
            &nbsp;<a href="<?php echo $this->config->base_url().'pages/delete/'.$page_details->id; ?>" class="btn btn-danger btn-xs delete-confirm"><span class="glyphicon glyphicon-trash"></span> Delete</a>
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
