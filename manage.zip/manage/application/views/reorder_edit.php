    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
<?php
    echo $this->session->flashdata('form_errors');
?>             
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>
                <?php echo form_open('reorder/save/'.$reorder_values->id, array('class' => 'edit-form')); ?>
                  <legend><?php echo ucfirst($category_details->name); ?></legend>
                  
<?php
$sizes = array('s', 'm', 'l', 'xl', 'xxl', 'unstitched');
foreach($sizes as $size) { ?>
                  <div class="form-group inline">
                    <label for="<?php echo $size; ?>" class="control-label">Size <?php echo strtoupper($size); ?></label>
                    <input type="number" min="0" class="form-control input-sm" id="<?php echo $size; ?>" name="<?php echo $size; ?>" value="<?php echo ucwords($reorder_values->$size); ?>">
                  </div>
<?php
} ?>
                  
                  
                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'reorder'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#basicinfo tab end-->
              
            </div> <!-- ./tab-content -->
             
          </div>
          
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
