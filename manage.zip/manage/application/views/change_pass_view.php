<div class="sub-header">Change Password</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php echo form_open_multipart('profile/change_pass_save/'); ?>
              <div class="form-group inline">
                <label for="oldpass" class="control-label">Enter Current Password</label>
                <input type="password" class="form-control" id="oldpass" name="oldpass" value="" required>
              </div><br>
              <div class="form-group inline">
                <label for="newpass" class="control-label">Enter New Password</label>
                <input type="password" class="form-control toBeConfirmed" id="newpass" name="newpass" value="" required>
              </div><br>
              <div class="form-group inline">
                <label for="newpass_confirm" class="control-label">Confirm New Password</label>
                <input type="password" class="form-control confirmCheck" id="newpass_confirm" name="newpass_confirm" value="" required>
              </div>
              <div id="passConfirmMessage"></div><br>

              <div class="form-group margin-top-0">
                <button type="submit" id="changePassSubmit" class="btn btn-brand btn-wide btn-sm">Change Password</button> <a href="<?php echo $this->config->base_url().'dashboard'; ?>" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
