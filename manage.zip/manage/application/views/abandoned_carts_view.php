<style>
    .numbers-section {
        padding: 30px 0 0;
        background: #fff;
    }
    table.dataTable tbody th, table.dataTable tbody td {padding:5px 10px;}
    .stat-card {
        display: inline-block;
        border: 1px dashed #cacaca;
        padding: 15px 15px 3px;
        margin: 10px;
        text-align: center;
    }
    .stat-card.small {
        padding: 5px 20px;
    }
    .stat-card.small h1 {
        font-size: 16px;
    }
    .text-align-center {
        text-align: center;
    }
    @media(max-width:767px) {
        .stat-card, .stat-card.small {
            width: 100%;
            padding: 5px;
            margin: 5px;
        }
        .stat-card.small h1 {
            margin: 5px;
            font-size: 14px;
        }
        .stat-card.small p {
            margin: 0;
        }
    }
</style>
<?php
//date_default_timezone_set("Asia/Kolkata");
setlocale(LC_MONETARY, 'en_IN');
?>
<div class="sub-header">Abandoned Carts</div>  
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12 margin-top-15">
			  
				<?php echo $this->session->flashdata('form_errors'); ?>
				<?php echo form_open('abandoned_carts', array('method' => 'GET', 'class' => 'edit-form clearfix')) ?>
					<div class="form-group inline one-third">
					  <label for="from">From</label>
					  <input type="date" class="form-control input-sm" name="from" value="<?php echo $get_from; ?>">
					</div>
					
					<div class="form-group inline one-third">
					  <label for="from">To</label>
					  <input type="date" class="form-control input-sm" name="to" value="<?php echo $get_to; ?>">
					</div>
					  
					<div class='form-group inline'>
					  <input type="submit" class="btn btn-brand btn-wide" value="Filter">&nbsp; &nbsp; 
					  <a href="<?php echo $this->config->base_url().'abandoned_carts'; ?>">Reset Filters</a>
					</div>
				</form>
			  
              <table class="table dataTable">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Items</th>
                    <th>Total Amount</th>
                    <th>Customer ID</th>
                    <th>Customer Name</th>
                    <th>Customer Email</th>
                    <th>Guest</th>
                    <th>Created</th>
                    <th>Last Modified</th>
                  </tr>
                </thead>
                
                  
<?php if(count($ab_carts) > 0) { ?>
                <tbody>
<?php
        foreach ($ab_carts as $ab_cart) { ?> 
                  <tr>
                    <td><a href="<?php echo $this->config->base_url().'carts/view/'.$ab_cart->id; ?>" target="_blank"><?php echo $ab_cart->id; ?></a></td>
                    <td><?php echo $ab_cart->total_items; ?></td>
                    <td><?php echo money_format('%!.2n', $ab_cart->total_amount); ?></td>
<?php
if($ab_cart->user_id != 0) { ?>
                    <td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$ab_cart->user_id; ?>" target="_blank"><?php echo $ab_cart->user_id; ?></a></td>
                    <td><?php echo ucwords($customer_index[$ab_cart->user_id]->name); ?></td>
                    
<?php
	if($customer_index[$ab_cart->user_id]->is_guest != 0) { ?>
                    <td><?php echo $customer_index[$ab_cart->user_id]->guest_email; ?></td>
                    <td><span class="label label-danger">Guest</span></td>
                    
<?php
	} else { ?>
					<td><?php echo $customer_index[$ab_cart->user_id]->email; ?></td>
					<td></td>
<?php
	} ?>                    
                    <td><?php echo date('d M, Y', strtotime($ab_cart->date)); ?></td>
<?php
} else { ?>
					<td>-NA-</td>
					<td>-NA-</td>
					<td>-NA-</td>
					<td></td>
					<td><?php echo date('d M, Y', strtotime($ab_cart->date)); ?></td>
<?php
} ?>

<?php
if($ab_cart->last_modified != NULL) { ?>
                    <td><?php echo date('d M, Y', strtotime($ab_cart->last_modified)); ?></td>
<?php
} else { ?>
	
					<td><?php echo date('d M, Y', strtotime($ab_cart->date)); ?></td>
<?php
} ?>
					
<?php   } // end of foreach loop ?>
                </tbody>
<?php
      } //end of if 
      else {  ?>  
                <tfoot>                
                  <tr align='center'>
                    <td colspan="6">No Abondoned Carts</td>
                  </tr>
                </tfoot>
<?php } // end of else ?>                  
                
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>
     
    
  </div>
  <!-- /#main-content -->
