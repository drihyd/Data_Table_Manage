<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
  
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $this->config->base_url(); ?>css/style.css">

  <!--[if lt IE 9]>
  <script src="js/vendor/html5-3.6-respond-1.1.0.min.js"></script>
  <![endif]-->
</head>
<body style="padding-left: 0px;">
  <!--[if lt IE 7]>
  <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
  <![endif]-->
  
  <style>
    form.login {
      background: #fff;
      width: 80%;
      max-width: 480px;
      display: block;
      margin: 10% auto;
      border-radius: 6px;
      padding-bottom: 15px;
    }
    form.login h2 {
      font-size: 14px;
      display: block;
      background: #a54700;
      margin-bottom: 15px;
      padding: 15px;
      color: #fff;
      border-top-right-radius: 6px;
      border-top-left-radius: 6px;
    }
    form.login .form-group {
      padding: 0 15px;
    }
    form.login .btn-action-link {
      font-style: italic;
      font-size: 12px;
      display: inline-block;
    }
  </style>
   <div class="container">
     <div class="col-sm-6 col-sm-offset-3">
      
      <?php echo form_open('verifylogin', array('class' => 'login')); ?>
        <h2 class="form-signin-heading">Taruni Login</h2>
        <div class="form-group">
          <?php echo validation_errors(); ?>
          <input type="text" size="20" id="username" name="username" class="form-control" placeholder="username" autofocus>
        </div>
        <div class="form-group">
          <input type="password" size="20" id="username" name="password" placeholder="password" class="form-control">
        </div>
        <div class="form-group">
          <button class="btn btn-lg btn-brand btn-sm btn-wide" type="submit">Login</button> <a href="<?php echo $this->config->base_url().'profile/forgot_pass_page'; ?>" class="btn btn-action-link">forgot password?</a>
        </div>
      </form>
     </div>
   </div>
   
  
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="<?php echo $this->config->base_url(); ?>js/vendor/jquery-1.11.0.min.js"><\/script>')</script>
  
  <script src="<?php echo $this->config->base_url(); ?>js/vendor/bootstrap.min.js"></script>
  <script src="<?php echo $this->config->base_url(); ?>js/vendor/tablesort.js"></script>
  <script src="<?php echo $this->config->base_url(); ?>js/main.js"></script>
</body>
</html>
