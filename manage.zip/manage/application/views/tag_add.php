    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
        <li role="presentation"><a href="#displaypic" aria-controls="displaypic" role="tab" data-toggle="tab">Display Picture</a></li>
        <li role="presentation"><a href="#seotags" aria-controls="seotags" role="tab" data-toggle="tab">SEO Tags</a></li>
      </ul>
    </div>
    
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
 <?php
    echo $this->session->flashdata('form-after-message');
    echo $this->session->flashdata('tag-success-message');
    echo $this->session->flashdata('tag-error-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>
                <?php echo form_open('tags/save/', array('class' => 'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="tagName" class="control-label">Name</label>
                    <input type="text" class="form-control input-sm nameForSlug" id="tagName" name="tagName" value="">
                  </div>
                  <div class="form-group inline">
                    <label for="tagSlug" class="control-label">Slug</label>
                    <input type="text" class="form-control input-sm slugForName" id="tagSlug" name="tagSlug" value="">
                  </div>
                  <div class="form-group inline">
                    <label for="tagPosScore" class="control-label">Position Score</label>
                    <input type="number" min="0" max="1000" class="form-control input-sm" id="tagPosScore" name="tagPosScore" value="0">
                  </div><br>                  
                  <div class="form-group">
                    <label for="tagDesc" class="control-label">Description</label>
                    <textarea id="tagDesc" name="tagDesc" style="max-width: 100%;min-width;100%;" class="form-control input-sm"></textarea>
                  </div>

                  <div class="form-group margin-top-0">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'tags'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./#basicinfo tab end-->
              
              
              
            </div> <!-- ./tab-content -->
             
          </div>
          
          <div class="col-sm-6">
  
              
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
