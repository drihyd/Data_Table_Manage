    <div class="admin-tabs">
      <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active"><a href="#basicinfo" aria-controls="basicinfo" role="tab" data-toggle="tab">Basic Info</a></li>
      </ul>
    </div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <div class="tab-content">
<?php
                      echo $this->session->flashdata('form-after-message');
?>             
              <div role="tabpanel" class="tab-pane active" id="basicinfo">
                <?php echo validation_errors(); ?>
                <?php echo form_open('skus/save/', array('class'=>'edit-form')); ?>
                  <legend>Basic Info</legend>
                  <div class="form-group inline">
                    <label for="skuCode" class="control-label">SKU Code</label>
                    <input type="text" class="form-control input-sm" id="skuCode" name="skuCode" value="" required>
                  </div>
                  <div class="form-group inline">
                    <label for="skuSize" class="control-label">Size</label>
                    <select class="form-control input-sm" id="skuSize" name="skuSize" required>
<?php
  if($product_details->unstitched) { ?>
                        <option value="unstitched">Unstitched</option>
<?php
  } else { ?>
    
                        <option value="s">S</option>
                        <option value="m">M</option>
                        <option value="l">L</option>
                        <option value="xl">XL</option>
                        <option value="xxl">XXL</option>
<?php
  } ?>
                    </select>    
                  </div>
                  <div class="form-group">
                    <label for="skuPrice" class="control-label">SKU Price</label>
                    <input type="text" class="form-control input-sm" id="skuPrice" name="skuPrice" value="" required>
                  </div>
                  <div class="form-group inline">
                    <label for="skuStock" class="control-label">Stock</label>
                    <input type="number" min="0" class="form-control input-sm" id="skuStock" name="skuStock" value="0" required>
                  </div>
                  
                  <input type="hidden" name="productId" value="<?php echo $product_details->id; ?>">
                  <input type="hidden" name="catId" value="<?php echo $product_details->cat_id; ?>"> 
                  
                  <div class="form-group margin-top-30">
                    <button type="submit" class="btn btn-brand btn-wide btn-sm">Save Changes</button> <a href="<?php echo $this->config->base_url().'products/product_info/'.$product_details->id.'#sub-skus-section'; ?>" class="btn btn-action-link">Cancel</a>
                  </div>
                </form>
              </div> <!-- ./end basicinfo tab -->
            
            </div> <!-- ./ end tab-content -->
            
          </div>
          <div class="col-sm-6">
            
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
