<script type="text/javascript" src="https://www.google.com/jsapi?autoload={'modules':[{'name':'visualization','version':'1.1','packages':['corechart', 'timeline', 'bar']}]}"></script>
<?php setlocale(LC_MONETARY, 'en_IN'); ?>
<div class="sub-header">From: <b><?php echo date('d M, Y', strtotime($get_from_date)); ?></b> &nbsp;&nbsp;&nbsp;&nbsp;To: <b><?php echo date('d M, Y', strtotime($get_to_date)); ?></b> &nbsp;&nbsp;(<?php echo $total_carts; ?>)</div>
<section class="stats-section">
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
				
                <?php echo $this->session->flashdata('form_errors'); ?>
				<?php echo form_open('cart_analytics', array('method' => 'GET', 'class' => 'edit-form clearfix')) ?>
                    
                    <div class="form-group inline one-third">
						<label for="utm_source">Source</label>
						<select class="form-control input-sm" name="utm_source" id="utm_source">
							<option value="">All</option>
<?php
foreach($all_utm_sources as $key) {
	if(trim($key) == trim($get_utm_source)) { ?>
							<option value="<?php echo $key; ?>" selected><?php echo ucwords($key); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $key; ?>"><?php echo ucwords($key); ?></option>
<?php
	}
} ?>
						</select>
                    </div>
                    
					<div class="form-group inline one-third">
						<label for="utm_medium">Medium</label>
						<select class="form-control input-sm" name="utm_medium" id="utm_medium">
							<option value="">All</option>
<?php
foreach($all_utm_mediums as $key) {
	if(trim($key) == trim($get_utm_medium)) { ?>
							<option value="<?php echo $key; ?>" selected><?php echo ucwords($key); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $key; ?>"><?php echo ucwords($key); ?></option>
<?php
	}
} ?>
						</select>
                    </div>

					<div class="form-group inline one-third">
						<label for="utm_campaign">Campaign</label>
						<select class="form-control input-sm" name="utm_campaign" id="utm_campaign">
							<option value="">All</option>
<?php
foreach($all_utm_campaigns as $key) {
	if(trim($key) == trim($get_utm_campaign)) { ?>
							<option value="<?php echo $key; ?>" selected><?php echo ucwords($key); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $key; ?>"><?php echo ucwords($key); ?></option>
<?php
	}
} ?>
						</select>
                    </div>
                    
                    <div class="form-group inline one-third">
						<label for="utm_term">Term</label>
						<select class="form-control input-sm" name="utm_term" id="utm_term">
							<option value="">All</option>
<?php
foreach($all_utm_terms as $key) {
	if(trim($key) == trim($get_utm_term)) { ?>
							<option value="<?php echo $key; ?>" selected><?php echo ucwords($key); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $key; ?>"><?php echo ucwords($key); ?></option>
<?php
	}
} ?>
						</select>
                    </div>
                    
                    <div class="form-group inline one-third">
						<label for="utm_content">Content</label>
						<select class="form-control input-sm" name="utm_content" id="utm_content">
							<option value="">All</option>
<?php
foreach($all_utm_contents as $key) {
	if(trim($key) == trim($get_utm_content)) { ?>
							<option value="<?php echo $key; ?>" selected><?php echo ucwords($key); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $key; ?>"><?php echo ucwords($key); ?></option>
<?php
	}
} ?>
						</select>
                    </div>

                    <div class="form-group inline one-third">
                      <label for="from">From</label>
                      <input type="date" class="form-control input-sm" name="from" value="<?php echo $get_from_date; ?>">
                    </div>
                    
                    <div class="form-group inline one-third">
                      <label for="from">To</label>
                      <input type="date" class="form-control input-sm" name="to" value="<?php echo $get_to_date; ?>">
                    </div>
                      
                    <div class='form-group inline'>
                      <input type="submit" class="btn btn-brand btn-wide" value="Filter">&nbsp; &nbsp; 
                      <a href="<?php echo $this->config->base_url().'cart_analytics'; ?>">Reset Filters</a>
                    </div>
                </form>
                
            </div>
        </div>
        <!-- /.row -->
        
        <div class="row">
			<div class="col-sm-4 text-align-center">
				  <div class="graph-box inline">
					<div id="piechartSources" class="actual-graph" style="width: 100%;"></div>
				  </div>
			  </div>
			  <div class="col-sm-4 text-align-center">
				  <div class="graph-box inline">
					  <div id="piechartMediums" class="actual-graph" style="width: 100%;"></div>
				  </div>
			  </div>
			  <div class="col-sm-4 text-align-center">
				<div class="graph-box inline">
					<div id="piechartCampaigns" class="actual-graph" style="width: 100%;"></div>
				</div>
			  </div>
		</div>
        <br>
        <br>
        <div class="row">
			<div class="col-xs-12">
				
				<div class="graph-box inline half">
					<div id="carts" class="actual-graph"></div>
				</div>
				
				<div class="graph-box inline half">
					<div id="revenues"></div>
				</div>
				
				<div class="graph-box inline half">
					<div id="domesticForeign" class="actual-graph"></div>
				</div>
				
				<div class="graph-box inline half">
					<div id="domesticForeignRev"></div>
				</div>
				
				<script>
					google.load('visualization', '1', {
						packages: ['corechart']
					});
					google.setOnLoadCallback(drawChart);

					function drawChart() {

						var cartData = new google.visualization.DataTable();
						cartData.addColumn('date', 'Day');
						cartData.addColumn('number', 'Total carts');
						cartData.addColumn('number', 'Actionable');

						cartData.addRows([
<?php
$i = 0;
foreach($sorted as $key => $value) {
	if($i != 0) echo ','; ?>						
							[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo $value['cart_num']; ?>, <?php echo $value['actionable_num']; ?>]
<?php
		$i += 1;
} ?>
						]);
											
						
						
						var cartOptions = {
							left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0'
							},
							lineWidth: 1,
							pointSize: 1,
						};
						
						
						
						

						
						// carts
						var carts = new google.visualization.LineChart(document.getElementById('carts'));
						carts.draw(cartData, cartOptions);
						
						var revenueData = new google.visualization.DataTable();
						revenueData.addColumn('date', 'Day');
						revenueData.addColumn('number', 'Revenue (in Lakhs)');
						revenueData.addColumn('number', 'Actionable (in Lakhs)');

						revenueData.addRows([
<?php
$i = 0;
foreach($sorted as $key => $value) {
	if($i != 0) echo ','; ?>						
							[new Date(<?php echo implode(',', explode('-', $key)); ?>), <?php echo number_format(floor( (($value['cart_revenue']/100000) * 100))/100, 2); ?>, <?php echo number_format(floor( (($value['actionable_rev']/100000) * 100))/100, 2); ?>]
<?php
		$i += 1;
} ?>
						]);
						
						var revenuesOptions = {
							left: 0,
							'legend':'bottom',
							chartArea: {
								left: 50,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0L',
								minValue: 1
							},
							lineWidth: 1
						};
						
						// revenues
						var revenues = new google.visualization.LineChart(document.getElementById('revenues'));
						revenues.draw(revenueData, cartOptions);
					}
				</script>
				
<?php
if(count($carts) > 0) { ?>                  
                  <script type="text/javascript">
                      google.load("visualization", "1", {packages:["corechart"]});
                      google.setOnLoadCallback(drawChart);
                      function drawChart() {
// *********************************************************************
                        var dataSources = google.visualization.arrayToDataTable([
                          ['Source', 'No. of Leads'],
<?php
$i = 0;
foreach($utm_sources_index as $key => $value) { ?>                          
                        ['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
<?php
	$i += $value;
} 
	if($i != $total_carts) { ?>
						['Empty',     <?php echo abs($total_carts - $i); ?>]
<?php
	}
?>
                      ]);

                        var optionsSources = {
                          title: 'Utm_sources',
                          left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0',
								minValue: 10
							},
							lineWidth: 1
                        };
// *********************************************************************                        
                      var dataMediums = google.visualization.arrayToDataTable([
                        ['Medium', 'No. of Leads'],
<?php
$i = 0;
foreach($utm_mediums_index as $key => $value) { ?>                          
                        ['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
<?php
	$i += $value;
} 
	if($i != $total_carts) { ?>
						['Empty',     <?php echo abs($total_carts - $i); ?>]
<?php
	}
?>
                      ]);

                      var optionsMediums = {
                        title: 'Utm_mediums',
                        left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0',
								minValue: 10
							},
							lineWidth: 1
                      };  
// *********************************************************************
                      var dataCampaigns = google.visualization.arrayToDataTable([
                        ['Campaign', 'No. of Leads'],
<?php
$i = 0;
foreach($utm_campaigns_index as $key => $value) { ?>                          
                        ['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
<?php
	$i += $value;
} 
	if($i != $total_carts) { ?>
						['Empty',     <?php echo abs($total_carts - $i); ?>]
<?php
	}
?>
                      ]);

                      var optionsCampaigns = {
                        title: 'Utm_campaigns',
                        left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0',
								minValue: 10
							},
							lineWidth: 1
                      };
// *********************************************************************
                      var dataTerms = google.visualization.arrayToDataTable([
                        ['Term', 'No. of Leads'],
<?php
$i = 0;
foreach($utm_terms_index as $key => $value) { ?>                          
                        ['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
<?php
	$i += $value;
} 
	if($i != $total_carts) { ?>
						['Empty',     <?php echo abs($total_carts - $i); ?>]
<?php
	}
?>
                      ]);

                      var optionsTerms = {
                        title: 'Utm_terms',
                        left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0',
								minValue: 10
							},
							lineWidth: 1
                      };

// *********************************************************************
                      var dataContents = google.visualization.arrayToDataTable([
                        ['Content', 'No. of Leads'],
<?php
$i = 0;
foreach($utm_contents_index as $key => $value) { ?>                          
                        ['<?php echo ucwords($key); ?>',     <?php echo $value; ?>],
<?php
	$i += $value;
} 
	if($i != $total_carts) { ?>
						['Empty',     <?php echo abs($total_carts - $i); ?>]
<?php
	}
?>
                      ]);

                      var optionsContents = {
                        title: 'Utm_contents',
                        left: 0,
							'legend':'bottom',
							chartArea: {
								left: 20,
								top: 20,
								width: "100%"
							},
							backgroundColor: { fill:'transparent' },
							hAxis: {
								format: 'd MMM',
								gridlines: {count: 10}
							},
							
							vAxis: {
								gridlines: {
									color: 'none'
								},
								format: '0',
								minValue: 10
							},
							lineWidth: 1
                      };                        

                        var chartSources = new google.visualization.PieChart(document.getElementById('piechartSources'));
                        var chartMediums = new google.visualization.PieChart(document.getElementById('piechartMediums'));
                        var chartCampaigns = new google.visualization.PieChart(document.getElementById('piechartCampaigns'));
                        //var chartTerms = new google.visualization.PieChart(document.getElementById('piechartTerms'));
                        //var chartContents = new google.visualization.PieChart(document.getElementById('piechartContents'));
                     

                        chartSources.draw(dataSources, optionsSources);
                        chartMediums.draw(dataMediums, optionsMediums);
                        chartCampaigns.draw(dataCampaigns, optionsCampaigns);
                        //chartTerms.draw(dataTerms, optionsTerms);
                        //chartContents.draw(dataContents, optionsContents);
                      }
                    </script>
                  
                  
                  <!-- div class="col-sm-4 col-sm-offset-2 text-align-left">
                    <div id="piechartTerms" style="text-align:left;width: 100%;height:320px"></div>
                  </div>
                  <div class="col-sm-4 text-align-left">
                    <div id="piechartContents" style="text-align:left;width: 100%;height:320px"></div>
                  </div -->

<?php
} ?>				
				
				
			</div>
			
			
		</div>
		
	</div>
</section>

<div class="sub-header">Day Wise Volumetric Data</div>
<section class="white-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12">
				<table class="table">
					<thead style="font-size: 9px;">
						<tr>
							<th style="font-size: 9px;">Date</th>
							<th style="font-size: 9px;">Total Carts</th>
							<th style="font-size: 9px;">Total Amount</th>
							<th style="font-size: 9px;">S</th>
							<th style="font-size: 9px;">M</th>
							<th style="font-size: 9px;">L</th>
							<th style="font-size: 9px;">XL</th>
							<th style="font-size: 9px;">XXL</th>
							<th style="font-size: 9px;">XXXL</th>
							<th style="font-size: 9px;">Unstitched</th>
						</tr>
					</thead>
					<tbody>
<?php
$reversed_carts = array_reverse($sorted);
foreach($reversed_carts as $key => $value) { 
$key = explode('-', $key);
$key[1] = $key[1] + 1;
$key = implode('-', $key);?>
						<tr>
							<td><?php echo date('M d, Y', strtotime($key)); ?></td>
							<td><?php echo $value['cart_num']; ?></td>
							<td><?php echo $value['revenue']; ?></td>
							<td><?php echo $value['s']; ?></td>
							<td><?php echo $value['m']; ?></td>
							<td><?php echo $value['l']; ?></td>
							<td><?php echo $value['xl']; ?></td>
							<td><?php echo $value['xxl']; ?></td>
							<td><?php echo $value['xxxl']; ?></td>
							<td><?php echo $value['unstitched']; ?></td>
						</tr>
<?php
} ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</section>

<div class="sub-header">Actionable Emails</div>
<section class='stats-section'>
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12">
				<table class="table">
					<thead>
						<tr>
							<th>Name</th>
							<th>Email</th>
							<!-- th>Amount</th -->
						</tr>
					</thead>

					<tbody>

<?php
foreach($actionable_index as $cart) { ?>
						<tr>
							<td><?php echo ucwords($cart['name']); ?></td>
							<td><?php echo $cart['email']; ?></td>
							<!-- td><?php echo $cart['total_amount']; ?></td -->
						</tr>
<?php
} ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</section>
