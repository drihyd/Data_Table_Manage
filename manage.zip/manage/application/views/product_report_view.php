<?php
date_default_timezone_set("Asia/Kolkata");
setlocale(LC_MONETARY, 'en_IN');
?>
<div class="sub-header">Product Stats</div>
<section class="white-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6 ">
<?php echo $this->session->flashdata('form_message'); ?>
				<form class="form edit-form" method="POST" action="<?php $this->config->base_url().'product_report'; ?>">
					<div class="form-group">
						<label>Enter Product Code</label>
						<input type="text" class="form-control in[put-sm" id="product_code" name="product_code" value="<?php if(isset($product_code)) echo $product_code; ?>" required>
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-brand btn-sm btn-wide" value="Submit">
					</div>
				</form>
			</div>
		</div> <!-- ./row -->
		
<?php
if($has_data) { ?>
		
		<div class="row">
			<div class="col-xs-12">
				<h1><?php echo ucwords($product_details->name); ?></h1>
				<div class="text-align-left" style="margin-left: -10px; margin-right: -10px;">
					<div class="inline stat-card">
						<h1><?php echo count($orders); ?></h1>
						<p>Total Orders (Incl. Cancelled)</p>
					</div>
					<div class="inline stat-card">
						<h1><?php echo $pieces_sold; ?></h1>
						<p>Total Pieces (Incl. Cancelled)</p>
					</div>
					<div class="inline stat-card">
						<h1><?php echo 'INR ' . money_format('%!.2n',$revenue_generated); ?></h1>
						<p>Total Value (Incl. Cancelled)</p>
					</div>
					<div class="inline stat-card">
						<h1><?php echo $added_days; ?></h1>
						<p>Added (days ago)</p>
					</div>
					<div class="inline stat-card">
						<h1><?php echo $modified_days; ?></h1>
						<p>Last Modified (days ago)</p>
					</div>
					<div class="inline stat-card">
						<h1><?php echo $last_order_days; ?></h1>
						<p>Last Order (days ago)</p>
					</div>
				</div>	
			</div>
			<div class="col-sm-6 margin-top-30">
				<p><strong>Details:</strong></p>
				<p>Name: <a href="<?php echo $this->config->base_url().'products/product_info/'.$product_details->id; ?>" target="_blank"><?php echo ucwords($product_details->name); ?></a></p>
				<p>Code: <a href="<?php echo $this->config->base_url().'products/product_info/'.$product_details->id; ?>" target="_blank"><?php echo $product_details->code; ?></a></p>
				<p>Slug: <a href="<?php echo $this->config->base_url().'products/product_info/'.$product_details->id; ?>" target="_blank"><?php echo $product_details->slug; ?></a></p>
				<p>Parent Category: <a href="<?php echo $this->config->base_url().'categories/category_info/'.$parent_category_details->id; ?>" target="_blank"><?php echo ucwords($parent_category_details->name); ?></a></p>
<?php
if($product_details->unstitched == 1) { ?>
				<p><span class="label label-danger">Unstitched</span></p>
<?php
} ?>
				<hr style="margin: 10px 0;">
				<p><strong>Attributes:</strong></p>
<?php
foreach($product_attributes as $attribute) { ?>
				<p><?php echo ucwords($attribute->attribute_name); ?>: <?php echo ucwords($attribute->attribute_value); ?></p>
<?php
} ?>
				<hr style="margin: 10px 0;">
    
				
			</div>
			
			<div class="col-sm-6 margin-top-30">
				<p><strong>SKUs:</strong></p>
<?php
foreach($skus_list as $sku) { ?>
				<p><?php echo $sku->sku_code; ?> - Size: <?php echo strtoupper($sku->size); ?> - Stock: <?php echo $sku->stock; ?> - <?php echo 'INR ' . money_format('%!.2n', $sku->price_inr); ?></p>
<?php
} ?>
				<hr style="margin: 10px 0;">
				<p><strong>Images:</strong>
<?php
$product_code = implode('_', explode(' ',$product_details->code));
$product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
//foreach($images as $image) { ?>        
        <!-- a href="<?php echo $this->config->base_url().$image;?>" -->
          <!-- img src="<?php echo $this->config->base_url().$image;?>" -->
        <!-- /a -->
<?php
//} ?>
<?php
if((is_array($product_images)) && (count(array_filter($product_images)) > 0)) { 
  foreach($product_images as $image) { ?>
					<div style="display: inline-block">
						<img src="<?php echo $this->config->base_url().$image;?>" class="small-thumbnail" style="display:inline-block;">
					</div>
<?php
  } 
} else { ?>
					<div style="display: inline-block">
						<img src="<?php echo $this->config->base_url().'img/Not_Available.jpg';?>" class="small-thumbnail" style="display:inline-block;">
					</div>
<?php
} ?>

				</p>
				<hr style="margin: 10px 0;">
			</div>
		</div> <!-- ./row -->
<?php
} ?>

<?php
if($has_data) { ?>
		<div class="row">
			<div class="col-xs-12">
				<table class="table dataTable orders-table">
					<thead>
						<tr>
							<th>Order ID</th>
							<th>Grand Total</th>
							<th>Items</th>
							<th width="200">Customer</th>
							<th>Payment</th>
							<th>Date</th>
							<th>Ship To</th>
							<th>Status</th>
							<th>Action</th>
						</tr>
					</thead>					
					<tbody>
<?php
if($orders) {
	foreach($orders as $order) { ?>
						<tr class="<?php echo str_replace(' ', '-', $order->order_status); ?>">
							<td>
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank"><?php echo $order->id; ?></a>
							</td>
							<td width="100px"><?php echo strtoupper($order->currency); ?> <?php echo money_format('%!.0n', $order->grand_total); ?></td>
							<td><?php echo $order->total_items; ?></td>
							<td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order->customer_id; ?>" target="_blank"><?php echo ucwords($customer_index[$order->customer_id]->name); ?> (<?php echo $order->customer_id; ?>)</a></td>
							<td><?php echo $order->payment_status; ?> (<?php echo $payment_details_index[$order->id]; ?>)</td>
							<td><?php echo date('M d, Y', strtotime($order->ordered_on)); ?></td>
							<td>
<?php echo ucwords($order->ship_to_country); ?>
<?php
if ($shipping_index[$order->id] == 'foreign') {
	echo " <span class='' style='color: inherit;line-height: 0;font-size: 18px;position: relative; bottom: -2px;'>&#9992;</span>";
} ?>

<?php
if (isset($alterations_index[$order->id]) AND ($alterations_index[$order->id] == 1) ) {
	echo " <span class='alteration-ind' style='color: inherit;line-height: 0;font-size: 18px;position: relative; bottom: -2px;'>&#9986;</span>";
} ?>
							
							</td>
							<td>
<?php
if($order->order_status == 'cancelled-refund-pending') {
	echo 'Refund-pending';
} else {
	echo ucwords($order->order_status);
}
?>

							</td>
							<td class="edit-column">
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
							</td>
						</tr>
<?php
	}
} ?>
					</tbody>
				</table>
			</div>
		</div>
<?php
} ?>
	</div>
</section>
