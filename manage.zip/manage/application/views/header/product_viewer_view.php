
<?php setlocale(LC_MONETARY, 'en_IN'); ?>
<?php
$colors = array(
	'blue',
	'red',
	'yellow',
	'green',
	'violet',
	'orange',
	'gray',
	'cream',
	'black',
	'white',
	'pink',
	'brown',
	'multicolor',
	'silver',
	'gold',
	'peach',
	'maroon',
	'beige',
	'purple',
);

$time_frames = array(
	10,
	20,
	30,
	60,
);
?>

<div class="sub-header">Filtered Products</div>
<section class="stats-section">
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
				
                <?php echo $this->session->flashdata('form_errors'); ?>
                
				<?php echo form_open('product_viewer', array('method' => 'GET', 'class' => 'edit-form clearfix')) ?>
                    
                    <div class="form-group inline one-third">
						<label for="categories">Select Categories</label>
						<select class="form-control input-sm" name="categories" id="categories">
							<option value="">Select</option>
<?php
foreach($categories as $category) {
	if(in_array($category->id, $filters['categories'])) { ?>
							<option value="<?php echo $category->id; ?>" selected><?php echo ucwords($category->name); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $category->id; ?>"><?php echo ucwords($category->name); ?></option>
<?php
	}
} ?>
						</select>
                    </div>
                    
					<div class="form-group inline one-third">
						<label for="colors">Select Colors</label>
						<select class="form-control input-sm" name="colors" id="colors">
							<option value="">Select</option>
<?php
foreach($colors as $color) {
	if(in_array($color, $filters['colors'])) { ?>
							<option value="<?php echo $color; ?>" selected><?php echo ucwords($color); ?></option>
<?php
	} else { ?>
							<option value="<?php echo $color; ?>"><?php echo ucwords($color); ?></option>
<?php
	}
} ?>
						</select>
                    </div>

					<div class="form-group inline one-third">
						<label for="utm_campaign">Time Frame</label>
						<select class="form-control input-sm" name="time_frame" id="time_frame">
							<option value="">Select</option>
<?php
foreach($time_frames as $frame) {
	if($filters['time_frame'] == $frame) { ?>
							<option value="<?php echo $frame; ?>" selected> Added in last <?php echo ucwords($frame); ?> days</option>
<?php
	} else { ?>
							<option value="<?php echo $frame; ?>"> Added in last <?php echo ucwords($frame); ?> days</option>
<?php
	}
} ?>
						</select>
                    </div>
                    
					<div class='form-group inline'>
						<input type="submit" class="btn btn-brand btn-wide" value="Filter">&nbsp; &nbsp; 
						<a href="<?php echo $this->config->base_url().'product_viewer'; ?>">Reset Filters</a>
					</div>
                   
                </form>
                
            </div>
        </div>
        <!-- /.row -->
        

        <div class="row">
			
			<div class="col-xs-12">
				
				<label>Selected Products</label>
				<textarea id="selected-products-box" class="form-control" style="width: 100%; max-width: 100%; min-height: 100px;"></textarea>
				<br><br>
				<div id="product-viewer-grid">
<?php
if(count($products) > 0) {
	foreach($products as $product) {
		$product_code = implode('_', explode(' ',$product->code));
		$product_image = glob(APPPATH . '../../assets/uploads/'.$product_code.'*_dp.jpg');
		if( (is_array($product_image)) && (count($product_image) > 0) ) {
			$product_image = $product_image[0];
		} else {
			$product_image = $this->config->base_url().'img/Not_Available.jpg';
		} ?>
					<div class="product-box" id="<?php echo strtoupper($product->code); ?>">
						<div class="content">
							<img src="<?php echo $product_image; ?>" width="240">
							<p><?php echo ucwords($product->name); ?></p>
							<a href="<?php echo $this->config->base_url().'products/product_info/' . $product->id; ?>" target="_blank">View</a>
						</div>
					</div>
<?php
	}
} else {
	if( (count($filters['categories']) > 0) OR (count($filters['colors']) > 0) OR ($filters['time_frame'] > 0) ) { ?>
					<div class="alert alert-danger">Sorry! No products with this filter configuration.</div>
<?php
	}
} ?>
					
				</div>
				
			</div>
			
		</div>
	</div>
</section>
