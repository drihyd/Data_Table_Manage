<?php setlocale(LC_MONETARY, 'en_IN'); ?>
  
  <div class="sub-header">Actions</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12">
            
            <a href="<?php echo $this->config->base_url().'products'; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Back to All Products</a>
            &nbsp;<a href="<?php echo $this->config->base_url().'products/edit/'.$product_details->id; ?>" class="btn btn-warning btn-xs"><span class="glyphicon glyphicon-edit"></span> Edit</a> 
            &nbsp;<a href="<?php echo $this->config->base_url().'products/delete/'.$product_details->id; ?>" class="btn btn-danger btn-xs delete-confirm"><span class="glyphicon glyphicon-trash"></span> Delete</a>
            
          </div>
        </div>
      </div> <!-- /#container-fluid -->
    </section>
  
  <div class="sub-header">Product Info</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <p>Name: <?php echo ucwords($product_details->name); ?></p>
            <p>Code: <?php echo $product_details->code; ?></p>
            <p>Slug: <?php echo $product_details->slug; ?></p>
            
            <p>Parent Category: <a href="<?php echo $this->config->base_url().'categories/category_info/'.$parent_category_details->id; ?>"><?php echo ucwords($parent_category_details->name); ?></a></p>
            <!-- hr style="margin: 10px 0;">
            <p>Price INR: <?php echo money_format('%!.2n', $product_details->price_inr); ?></p>
            <p>Price USD: <?php echo money_format('%!.2n', $product_details->price_usd); ?></p -->
<?php
if($product_details->unstitched == 1) { ?>
            <p><span class="label label-danger">Unstitched</span></p>
<?php
} ?>
            <hr style="margin: 10px 0;">
            <p><strong>Attributes:</strong></p>
<?php
foreach($product_attributes as $attribute) { ?>
            <p><?php echo ucwords($attribute->attribute_name); ?>: <?php echo ucwords($attribute->attribute_value); ?></p>
<?php
} ?>
            <hr style="margin: 10px 0;">
    
            <p>Images:<br>
            	<div class="prod-photos">
<?php
$product_code = implode('_', explode(' ',$product_details->code));
$product_images = glob(APPPATH . '../../assets/uploads/'.$product_code.'_*.jpg');
//foreach($images as $image) { ?>        
        <!-- a href="<?php echo $this->config->base_url().$image;?>" -->
          <!-- img src="<?php echo $this->config->base_url().$image;?>" -->
        <!-- /a -->
<?php
//} ?>
<?php
if((is_array($product_images)) && (count(array_filter($product_images)) > 0)) { 
  foreach($product_images as $image) { ?>
              <a href="<?php echo $this->config->base_url().$image;?>" style="display: inline-block">
                <img src="<?php echo $this->config->base_url().$image;?>" class="small-thumbnail" style="display:inline-block;">
              </a>
<?php
  } 
} else { ?>
              <div style="display: inline-block">
                <img src="<?php echo $this->config->base_url().'img/Not_Available.jpg';?>" class="small-thumbnail" style="display:inline-block;">
              </div>
<?php
} ?>
				</div>
            </p>
            
            <p>Description: <?php echo ucfirst($product_details->desc); ?></p>
            <p>Position Score: <?php echo ucfirst($product_details->position_score); ?></p>
            <p>SEO Title: <?php echo $product_details->seo_title; ?></p>
            <p>SEO Description: <?php echo $product_details->seo_desc; ?></p>
            <p>SEO Keywords: <?php echo $product_details->seo_keywords; ?></p>
            <br>
            <a href="<?php echo $this->config->base_url().'products/edit/'.$product_details->id; ?>" class="btn btn-warning btn-xs"><span class="glyphicon glyphicon-edit"></span> Edit Details</a>

          </div>
          
          <div class="col-sm-6">        
            <p><a href='#sub-skus-section' class="stat-value"><?php echo count($skus_list); ?></a> SKU's</p>            
          </div>
        </div>
      </div>
    </section>

  <div class="sub-header" id="sub-skus-section">SKU's</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12">
            <a href="<?php echo $this->config->base_url().'skus/add_child/'.$product_details->id; ?>" class="btn btn-xs btn-default">+ Add an SKU</a><br><br>
<?php
if(count($skus_list) > 0) { ?>
            <div class="table-responsive">
              <table class="table table-condensed dataTableNoSort table-striped table-bordered">
                <thead>
                  <tr>
                    <th>SKU Code</th>
                    <th>Size</th>
                    <th>Price INR</th>
                    <th>Price USD</th>
                    <!-- th>Striked Off Price</th -->
                    <th>Stock</th>
                    <th>Actions</th>
                  </tr>                  
                </thead>
                <tbody>
<?php
  foreach($skus_list as $sku) { ?>
                  <tr>
                    <td><a href="<?php echo $this->config->base_url().'skus/sku_info/'.$sku->id; ?>"><?php echo $sku->sku_code; ?></a></td>
<?php
    if($sku->size == null) { ?>                    
                    <td><span class="text-danger">Unstitched</span></td>
<?php
    } else { ?>
                    <td><?php echo $sku->size; ?></td>
<?php
    } ?>
                    <td>INR. <?php echo money_format('%!.2n',$sku->price_inr); ?></td>
                    <td>USD. <?php echo money_format('%!.2n',$sku->price_usd); ?></td>
                    <!-- td>Rs. <?php echo money_format('%!.2n',$sku->striked_price); ?></td -->
                    <td>
                        <?php echo validation_errors(); ?>
                        <?php echo form_open('skus/update_stock/'.$sku->id); ?>
                            <input type="number" name="sku_stock" value="<?php echo $sku->stock; ?>">
                            <button type="submit" class="btn btn-xs btn-default">update</button>
                        </form>
                    </td>
                    <td class="edit-column tiny-col">
                      <a href="<?php echo $this->config->base_url().'skus/edit/'.$sku->id; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'skus/delete/'.$sku->id; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php
  } // end of foreach loop
} // end of IF
else { ?>
                  <tr>
                    <td colspan="3"><div class="alert alert-info">There are no Products Listed directly under this Category</div></td>
                  </tr>
<?php
} // end of else ?>
                </tbody>
              </table>
            </div> <!-- ./table-responsive -->
          </div>
        </div>
      </div>
    </section>  
  
    
</div>
<!-- /#main-content -->
