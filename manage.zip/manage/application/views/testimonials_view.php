<div class="sub-header">Manage Testimonials</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'testimonials/add'; ?>" class="btn btn-brand btn-sm">New Testimonial +</a>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table table-sort table-sort-search table-sort-show-search-count">
                <thead>
                  <tr>
                    <th class="table-sort">Testimonial</th>
                    <th>Customer Name</th>
                    <th class="table-sort">Slug</th>
                    <th width="100px">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  
<?php if($testimonials) {
        foreach ($testimonials as $testimonial) { ?>
                  <tr>
                    <td><?php echo substr(ucfirst($testimonial['testimonial_content']), 0, 50).'...' ; ?></td>
                    <td><?php echo ucfirst($testimonial['name']); ?></td>
                    <td><?php echo ucfirst($testimonial['slug']); ?></td>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'testimonials/edit/'.$testimonial['id']; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'testimonials/delete/'.$testimonial['id']; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop
      } //end of if 
      else {  ?>                  
                  <tr align='center'>
                    <td colspan=7><a href="<?php echo $this->config->base_url().'testimonials/add'; ?>" class="btn btn-default btn-sm">Start adding testimonials +</a></td>
                  </tr
<?php } // end of else ?>                  
                </tbody>
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
