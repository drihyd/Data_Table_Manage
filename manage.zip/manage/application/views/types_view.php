<div class="sub-header">Manage Types</div>
    <section class="stats-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <a href="<?php echo $this->config->base_url().'types/add'; ?>" class="btn btn-brand btn-sm">Add a new Type +</a>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              <table class="table table-sort table-sort-search table-sort-show-search-count">
                <thead>
                  <tr>
                    <th>Type Name</th>
                    <th>Parent Category</th>
                    <th width="100px">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  
<?php if($types) {
        foreach ($types as $type) { ?>
                  <tr>
                    <td><?php echo ucfirst($type['name']); ?></td>
                    <td><?php echo $type['cat_name']; ?></td>
                    <td class="edit-column">
                      <a href="<?php echo $this->config->base_url().'types/edit/'.$type['id']; ?>" class="btn btn-default btn-edit"><span class="glyphicon glyphicon-edit"></span></a>
                      <a href="<?php echo $this->config->base_url().'types/delete/'.$type['id']; ?>" class="btn btn-default btn-edit delete-confirm"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop
      } //end of if 
      else {  ?>                  
                  <tr align='center'>
                    <td colspan=7><a href="<?php echo $this->config->base_url().'types/add'; ?>" class="btn btn-default btn-sm">Start adding Types +</a></td>
                  </tr
<?php } // end of else ?>                  
                </tbody>
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->
