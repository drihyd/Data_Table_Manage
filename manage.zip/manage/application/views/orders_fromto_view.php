<?php
setlocale(LC_MONETARY, 'en_IN');
?>
<div class="admin-tabs">
  <ul class="nav nav-tabs" role="tablist">
    <li role="presentation"><a href="<?php echo $this->config->base_url().'orders/index'; ?>">Recent</a></li>
    <li role="presentation"><a href="<?php echo $this->config->base_url().'orders/today'; ?>">Today's Orders</a></li>
    <li role="presentation"><a href="<?php echo $this->config->base_url().'orders/month'; ?>">Monthly</a></li>
    <li role="presentation" class="active"><a href="<?php echo $this->config->base_url().'orders/from_to'; ?>">From - To</a></li>
  </ul>
</div>  


    <section class="stats-section">
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              
              <?php echo form_open("orders/from_to", array('class' => 'form form-inline')); ?>
                <div class="form-group">
                    <label for="from">Orders between </label>
                    <input type="date" name="from" class="form-control input-sm">
                </div>
                <div class="form-group">
                    <label for="to"> and </label>
                    <input type="date" name="to" class="form-control input-sm">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-default">Submit</button>
                </div>
              </form>
              <br>
              <h3><strong><?php echo $from_to_name; ?></strong> (<?php echo count($orders); ?>)</h3> <br>
              <p>Total shipping charges: INR <?php echo money_format('%!.2n', $total_shipping); ?></p><br>
              
              <table class="table dataTable orders-table">
                <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Grand Total</th>
                    <th>Items</th>
                    <th width="200">Customer</th>
                    <th>Ship Name</th>
                    <th>Payment</th>
                    <th>Date</th>
                    <th>Ship To</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                
                  
<?php if($orders) { ?>
                <tbody>
<?php
        foreach ($orders as $order) { ?>
			
				  <tr class="<?php echo str_replace(' ', '-', $order->order_status); ?>">
                  
                    <td>
						<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank"><?php echo $order->id; ?></a>
					</td>
                    <td width="100px"><?php echo strtoupper($order->currency) . ' ' . money_format('%!.2n', $order->grand_total); ?></td>
                    <td><?php echo $order->total_items; ?></td>
                    <td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order->customer_id; ?>" target="_blank"><?php echo ucwords($customer_index[$order->customer_id]->name); ?> (<?php echo $order->customer_id; ?>)</a></td>
                    <td><?php echo ucwords($order->ship_to_name); ?></td>
                    <td><?php echo $payment_details_index[$order->id]; ?> (<?php echo $order->payment_status; ?>)</td>
                    <td><?php echo date('M d, Y H:i:s', strtotime($order->ordered_on)); ?></td>
                    <td>
						<?php echo ucwords($order->ship_to_country); ?>
<?php if ($shipping_index[$order->id] == 'foreign') {
						echo " <span class='glyphicon glyphicon-plane' style='color:inherit;font-size: 10px;'></span>";
} else {
						echo "";
} ?>                    
                    </td>
                    <td>
<?php
			if($order->order_status == 'cancelled-refund-pending') {
				echo 'Refund-pending';
			} else {
				echo ucwords($order->order_status);
			}
?>

					</td>
					<td class="edit-column">
						<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
                    </td>
                  </tr>
<?php   } // end of foreach loop ?>
                </tbody>
<?php
      } //end of if 
      else {  ?>  
                <tfoot>                
                  <tr align='center'>
                    <td colspan="9">No Orders</td>
                  </tr>
                </tfoot>
<?php } // end of else ?>                  
                
              </table>
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>

    
    <div class="admin-tabs">
  <ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#placedOrders" aria-controls="placedOrders" role="tab" data-toggle="tab">Placed - <?php if(isset($orders_num['placed'])) { echo $orders_num['placed'];} else { echo 0;}?></a></li>
    <li role="presentation"><a href="#processingOrders" aria-controls="processingOrders" role="tab" data-toggle="tab">Processing - <?php if(isset($orders_num['processing'])) { echo $orders_num['processing'];} else { echo 0;}?></a></li>
    <li role="presentation"><a href="#dispatchedOrders" aria-controls="dispatchedOrders" role="tab" data-toggle="tab">Dispatched - <?php if(isset($orders_num['dispatched'])) { echo $orders_num['dispatched'];} else { echo 0;}?></a></li>
    <li role="presentation"><a href="#onholdOrders" aria-controls="onholdOrders" role="tab" data-toggle="tab">On Hold - <?php if(isset($orders_num['on-hold'])) { echo $orders_num['on-hold'];} else { echo 0;}?></a></li>
    <li role="presentation"><a href="#cancelledOrders" aria-controls="cancelledOrders" role="tab" data-toggle="tab">Cancelled - <?php if(isset($orders_num['cancelled'])) { echo $orders_num['cancelled'];} else { echo 0;}?></a></li>
    <li role="presentation"><a href="#deliveredOrders" aria-controls="deliveredOrders" role="tab" data-toggle="tab">Delivered - <?php if(isset($orders_num['delivered'])) { echo $orders_num['delivered'];} else { echo 0;}?></a></li>
    <li role="presentation"><a href="#cancelledrefundpendingOrders" aria-controls="cancelledrefundpendingOrders" role="tab" data-toggle="tab">Refund pending - <?php if(isset($orders_num['cancelled-refund-pending'])) { echo $orders_num['cancelled-refund-pending'];} else { echo 0;}?></a></li>
    <li role="presentation"><a href="#cancelledrefundedOrders" aria-controls="cancelledrefundedOrders" role="tab" data-toggle="tab">Refunded - <?php if(isset($orders_num['cancelled-refunded'])) { echo $orders_num['cancelled-refunded'];} else { echo 0;}?></a></li>
  </ul>
  </div> 


    <section class="stats-section">
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-xs-12 margin-top-15">
              
              <div class="tab-content">
                
                <div role="tabpanel" class="tab-pane active" id="placedOrders">
                    <table class="table dataTable orders-table">
                        <thead>
                          <tr>
							<th>Order ID</th>
							<th>Grand Total</th>
							<th>Items</th>
							<th width="200">Customer</th>
							<th>Payment</th>
							<th>Payment Mode</th>
							<th>Date</th>
							<th>Ship To</th>
							<th>Status</th>
							<th>Action</th>
						  </tr>
                        </thead>
                        
                          
        <?php if($orders) : ?>
                        <tbody>
        <?php
                foreach ($orders as $order) { 
                    if($order->order_status == 'placed') : ?>
                          <tr class="<?php echo str_replace(' ', '-', $order->order_status); ?>">
                  
							<td>
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank"><?php echo $order->id; ?></a>
							</td>
							<td width="100px"><?php echo strtoupper($order->currency) . ' ' . money_format('%!.2n', $order->grand_total); ?></td>
							<td><?php echo $order->total_items; ?></td>
							<td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order->customer_id; ?>" target="_blank"><?php echo ucwords($customer_index[$order->customer_id]->name); ?> (<?php echo $order->customer_id; ?>)</a></td>
							<td><?php echo $order->payment_status; ?></td>
							<td><?php echo $payment_details_index[$order->id]; ?></td>
							<td><?php echo date('M d, Y H:i:s', strtotime($order->ordered_on)); ?></td>
							<td>
								<?php echo ucwords($order->ship_to_country); ?>
		<?php if ($shipping_index[$order->id] == 'foreign') {
								echo " <span class='glyphicon glyphicon-plane' style='color:inherit;font-size: 10px;'></span>";
		} else {
								echo "";
		} ?>                    
							</td>
							<td>
		<?php
					if($order->order_status == 'cancelled-refund-pending') {
						echo 'Refund-pending';
					} else {
						echo ucwords($order->order_status);
					}
		?>

							</td>
							<td class="edit-column">
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
							</td>
						  </tr>
        <?php
                    endif;
                } // end of foreach loop ?>
                        </tbody>
        <?php
              endif; ?>
                        
                    </table>
                </div>
                
                <div role="tabpanel" class="tab-pane" id="processingOrders">
                    <table class="table dataTable orders-table">
                        <thead>
                          <tr>
							<th>Order ID</th>
							<th>Grand Total</th>
							<th>Items</th>
							<th width="200">Customer</th>
							<th>Payment</th>
							<th>Payment Mode</th>
							<th>Date</th>
							<th>Ship To</th>
							<th>Status</th>
							<th>Action</th>
						  </tr>
                        </thead>
                        
                          
        <?php if($orders) : ?>
                        <tbody>
        <?php
                foreach ($orders as $order) { 
                    if($order->order_status == 'processing') : ?>
                          <tr class="<?php echo str_replace(' ', '-', $order->order_status); ?>">
                  
							<td>
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank"><?php echo $order->id; ?></a>
							</td>
							<td width="100px"><?php echo strtoupper($order->currency) . ' ' . money_format('%!.2n', $order->grand_total); ?></td>
							<td><?php echo $order->total_items; ?></td>
							<td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order->customer_id; ?>" target="_blank"><?php echo ucwords($customer_index[$order->customer_id]->name); ?> (<?php echo $order->customer_id; ?>)</a></td>
							<td><?php echo $order->payment_status; ?></td>
							<td><?php echo $payment_details_index[$order->id]; ?></td>
							<td><?php echo date('M d, Y H:i:s', strtotime($order->ordered_on)); ?></td>
							<td>
								<?php echo ucwords($order->ship_to_country); ?>
		<?php if ($shipping_index[$order->id] == 'foreign') {
								echo " <span class='glyphicon glyphicon-plane' style='color:inherit;font-size: 10px;'></span>";
		} else {
								echo "";
		} ?>                    
							</td>
							<td>
		<?php
					if($order->order_status == 'cancelled-refund-pending') {
						echo 'Refund-pending';
					} else {
						echo ucwords($order->order_status);
					}
		?>

							</td>
							<td class="edit-column">
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
							</td>
						  </tr>
        <?php
                    endif;
                } // end of foreach loop ?>
                        </tbody>
        <?php
              endif; ?>
                        
                    </table>
                </div>
                
                <div role="tabpanel" class="tab-pane" id="dispatchedOrders">
                    <table class="table dataTable orders-table">
                        <thead>
                          <tr>
							<th>Order ID</th>
							<th>Grand Total</th>
							<th>Items</th>
							<th width="200">Customer</th>
							<th>Payment</th>
							<th>Payment Mode</th>
							<th>Date</th>
							<th>Ship To</th>
							<th>Status</th>
							<th>Action</th>
						  </tr>
                        </thead>
                        
                          
        <?php if($orders) : ?>
                        <tbody>
        <?php
                foreach ($orders as $order) { 
                    if($order->order_status == 'dispatched') : ?>
                          <tr class="<?php echo str_replace(' ', '-', $order->order_status); ?>">
                  
							<td>
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank"><?php echo $order->id; ?></a>
							</td>
							<td width="100px"><?php echo strtoupper($order->currency) . ' ' . money_format('%!.2n', $order->grand_total); ?></td>
							<td><?php echo $order->total_items; ?></td>
							<td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order->customer_id; ?>" target="_blank"><?php echo ucwords($customer_index[$order->customer_id]->name); ?> (<?php echo $order->customer_id; ?>)</a></td>
							<td><?php echo $order->payment_status; ?></td>
							<td><?php echo $payment_details_index[$order->id]; ?></td>
							<td><?php echo date('M d, Y H:i:s', strtotime($order->ordered_on)); ?></td>
							<td>
								<?php echo ucwords($order->ship_to_country); ?>
		<?php if ($shipping_index[$order->id] == 'foreign') {
								echo " <span class='glyphicon glyphicon-plane' style='color:inherit;font-size: 10px;'></span>";
		} else {
								echo "";
		} ?>                    
							</td>
							<td>
		<?php
					if($order->order_status == 'cancelled-refund-pending') {
						echo 'Refund-pending';
					} else {
						echo ucwords($order->order_status);
					}
		?>

							</td>
							<td class="edit-column">
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
							</td>
						  </tr>
        <?php
                    endif;
                } // end of foreach loop ?>
                        </tbody>
        <?php
              endif; ?>
                        
                    </table>
                </div>
                
                <div role="tabpanel" class="tab-pane" id="onholdOrders">
                    <table class="table dataTable orders-table">
                        <thead>
                          <tr>
							<th>Order ID</th>
							<th>Grand Total</th>
							<th>Items</th>
							<th width="200">Customer</th>
							<th>Payment</th>
							<th>Payment Mode</th>
							<th>Date</th>
							<th>Ship To</th>
							<th>Status</th>
							<th>Action</th>
						  </tr>
                        </thead>
                        
                          
        <?php if($orders) : ?>
                        <tbody>
        <?php
                foreach ($orders as $order) { 
                    if($order->order_status == 'on-hold') : ?>
                          <tr class="<?php echo str_replace(' ', '-', $order->order_status); ?>">
                  
							<td>
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank"><?php echo $order->id; ?></a>
							</td>
							<td width="100px"><?php echo strtoupper($order->currency) . ' ' . money_format('%!.2n', $order->grand_total); ?></td>
							<td><?php echo $order->total_items; ?></td>
							<td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order->customer_id; ?>" target="_blank"><?php echo ucwords($customer_index[$order->customer_id]->name); ?> (<?php echo $order->customer_id; ?>)</a></td>
							<td><?php echo $order->payment_status; ?></td>
							<td><?php echo $payment_details_index[$order->id]; ?></td>
							<td><?php echo date('M d, Y H:i:s', strtotime($order->ordered_on)); ?></td>
							<td>
								<?php echo ucwords($order->ship_to_country); ?>
		<?php if ($shipping_index[$order->id] == 'foreign') {
								echo " <span class='glyphicon glyphicon-plane' style='color:inherit;font-size: 10px;'></span>";
		} else {
								echo "";
		} ?>                    
							</td>
							<td>
		<?php
					if($order->order_status == 'cancelled-refund-pending') {
						echo 'Refund-pending';
					} else {
						echo ucwords($order->order_status);
					}
		?>

							</td>
							<td class="edit-column">
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
							</td>
						  </tr>
        <?php
                    endif;
                } // end of foreach loop ?>
                        </tbody>
        <?php
              endif; ?>
                        
                    </table>
                </div>
                
                <div role="tabpanel" class="tab-pane" id="cancelledOrders">
                    <table class="table dataTable orders-table">
                        <thead>
                          <tr>
							<th>Order ID</th>
							<th>Grand Total</th>
							<th>Items</th>
							<th width="200">Customer</th>
							<th>Payment</th>
							<th>Payment Mode</th>
							<th>Date</th>
							<th>Ship To</th>
							<th>Status</th>
							<th>Action</th>
						  </tr>
                        </thead>
                        
                          
        <?php if($orders) : ?>
                        <tbody>
        <?php
                foreach ($orders as $order) { 
                    if($order->order_status == 'cancelled') : ?>
                          <tr class="<?php echo str_replace(' ', '-', $order->order_status); ?>">
                  
							<td>
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank"><?php echo $order->id; ?></a>
							</td>
							<td width="100px"><?php echo strtoupper($order->currency) . ' ' . money_format('%!.2n', $order->grand_total); ?></td>
							<td><?php echo $order->total_items; ?></td>
							<td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order->customer_id; ?>" target="_blank"><?php echo ucwords($customer_index[$order->customer_id]->name); ?> (<?php echo $order->customer_id; ?>)</a></td>
							<td><?php echo $order->payment_status; ?></td>
							<td><?php echo $payment_details_index[$order->id]; ?></td>
							<td><?php echo date('M d, Y H:i:s', strtotime($order->ordered_on)); ?></td>
							<td>
								<?php echo ucwords($order->ship_to_country); ?>
		<?php if ($shipping_index[$order->id] == 'foreign') {
								echo " <span class='glyphicon glyphicon-plane' style='color:inherit;font-size: 10px;'></span>";
		} else {
								echo "";
		} ?>                    
							</td>
							<td>
		<?php
					if($order->order_status == 'cancelled-refund-pending') {
						echo 'Refund-pending';
					} else {
						echo ucwords($order->order_status);
					}
		?>

							</td>
							<td class="edit-column">
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
							</td>
						  </tr>
        <?php
                    endif;
                } // end of foreach loop ?>
                        </tbody>
        <?php
              endif; ?>
                        
                    </table>
                </div>
                
                <div role="tabpanel" class="tab-pane" id="deliveredOrders">
                    <table class="table dataTable orders-table">
                        <thead>
                          <tr>
							<th>Order ID</th>
							<th>Grand Total</th>
							<th>Items</th>
							<th width="200">Customer</th>
							<th>Payment</th>
							<th>Payment Mode</th>
							<th>Date</th>
							<th>Ship To</th>
							<th>Status</th>
							<th>Action</th>
						  </tr>
                        </thead>
                        
                          
        <?php if($orders) : ?>
                        <tbody>
        <?php
                foreach ($orders as $order) { 
                    if($order->order_status == 'delivered') : ?>
                          <tr class="<?php echo str_replace(' ', '-', $order->order_status); ?>">
                  
							<td>
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank"><?php echo $order->id; ?></a>
							</td>
							<td width="100px"><?php echo strtoupper($order->currency) . ' ' . money_format('%!.2n', $order->grand_total); ?></td>
							<td><?php echo $order->total_items; ?></td>
							<td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order->customer_id; ?>" target="_blank"><?php echo ucwords($customer_index[$order->customer_id]->name); ?> (<?php echo $order->customer_id; ?>)</a></td>
							<td><?php echo $order->payment_status; ?></td>
							<td><?php echo $payment_details_index[$order->id]; ?></td>
							<td><?php echo date('M d, Y H:i:s', strtotime($order->ordered_on)); ?></td>
							<td>
								<?php echo ucwords($order->ship_to_country); ?>
		<?php if ($shipping_index[$order->id] == 'foreign') {
								echo " <span class='glyphicon glyphicon-plane' style='color:inherit;font-size: 10px;'></span>";
		} else {
								echo "";
		} ?>                    
							</td>
							<td>
		<?php
					if($order->order_status == 'cancelled-refund-pending') {
						echo 'Refund-pending';
					} else {
						echo ucwords($order->order_status);
					}
		?>

							</td>
							<td class="edit-column">
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
							</td>
						  </tr>
        <?php
                    endif;
                } // end of foreach loop ?>
                        </tbody>
        <?php
              endif; ?>
                        
                    </table>
                </div>
                
                <div role="tabpanel" class="tab-pane" id="cancelledrefundpendingOrders">
                    <table class="table dataTable orders-table">
                        <thead>
                          <tr>
							<th>Order ID</th>
							<th>Grand Total</th>
							<th>Items</th>
							<th width="200">Customer</th>
							<th>Payment</th>
							<th>Payment Mode</th>
							<th>Date</th>
							<th>Ship To</th>
							<th>Status</th>
							<th>Action</th>
						  </tr>
                        </thead>
                        
                          
        <?php if($orders) : ?>
                        <tbody>
        <?php
                foreach ($orders as $order) { 
                    if($order->order_status == 'cancelled-refund-pending') : ?>
                          <tr class="<?php echo str_replace(' ', '-', $order->order_status); ?>">
                  
							<td>
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank"><?php echo $order->id; ?></a>
							</td>
							<td width="100px"><?php echo strtoupper($order->currency) . ' ' . money_format('%!.2n', $order->grand_total); ?></td>
							<td><?php echo $order->total_items; ?></td>
							<td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order->customer_id; ?>" target="_blank"><?php echo ucwords($customer_index[$order->customer_id]->name); ?> (<?php echo $order->customer_id; ?>)</a></td>
							<td><?php echo $order->payment_status; ?></td>
							<td><?php echo $payment_details_index[$order->id]; ?></td>
							<td><?php echo date('M d, Y H:i:s', strtotime($order->ordered_on)); ?></td>
							<td>
								<?php echo ucwords($order->ship_to_country); ?>
		<?php if ($shipping_index[$order->id] == 'foreign') {
								echo " <span class='glyphicon glyphicon-plane' style='color:inherit;font-size: 10px;'></span>";
		} else {
								echo "";
		} ?>                    
							</td>
							<td>
		<?php
					if($order->order_status == 'cancelled-refund-pending') {
						echo 'Refund-pending';
					} else {
						echo ucwords($order->order_status);
					}
		?>

							</td>
							<td class="edit-column">
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
							</td>
						  </tr>
        <?php
                    endif;
                } // end of foreach loop ?>
                        </tbody>
        <?php
              endif; ?>
                        
                    </table>
                </div>
                
                <div role="tabpanel" class="tab-pane" id="cancelledrefundedOrders">
                    <table class="table dataTable orders-table">
                        <thead>
                          <tr>
							<th>Order ID</th>
							<th>Grand Total</th>
							<th>Items</th>
							<th width="200">Customer</th>
							<th>Payment</th>
							<th>Payment Mode</th>
							<th>Date</th>
							<th>Ship To</th>
							<th>Status</th>
							<th>Action</th>
						  </tr>
                        </thead>
                        
                          
        <?php if($orders) : ?>
                        <tbody>
        <?php
                foreach ($orders as $order) { 
                    if($order->order_status == 'cancelled-refunded') : ?>
                          <tr class="<?php echo str_replace(' ', '-', $order->order_status); ?>">
                  
							<td>
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank"><?php echo $order->id; ?></a>
							</td>
							<td width="100px"><?php echo strtoupper($order->currency) . ' ' . money_format('%!.2n', $order->grand_total); ?></td>
							<td><?php echo $order->total_items; ?></td>
							<td><a href="<?php echo $this->config->base_url().'customers/customer_info/'.$order->customer_id; ?>" target="_blank"><?php echo ucwords($customer_index[$order->customer_id]->name); ?> (<?php echo $order->customer_id; ?>)</a></td>
							<td><?php echo $order->payment_status; ?></td>
							<td><?php echo $payment_details_index[$order->id]; ?></td>
							<td><?php echo date('M d, Y H:i:s', strtotime($order->ordered_on)); ?></td>
							<td>
								<?php echo ucwords($order->ship_to_country); ?>
		<?php if ($shipping_index[$order->id] == 'foreign') {
								echo " <span class='glyphicon glyphicon-plane' style='color:inherit;font-size: 10px;'></span>";
		} else {
								echo "";
		} ?>                    
							</td>
							<td>
		<?php
					if($order->order_status == 'cancelled-refund-pending') {
						echo 'Refund-pending';
					} else {
						echo ucwords($order->order_status);
					}
		?>

							</td>
							<td class="edit-column">
								<a href="<?php echo $this->config->base_url().'orders/order_info/'.$order->id; ?>" target="_blank" class="btn btn-sm btn-default btn-edit"><span class="glyphicon glyphicon-eye-open"></span></a>
							</td>
						  </tr>
        <?php
                    endif;
                } // end of foreach loop ?>
                        </tbody>
        <?php
              endif; ?>
                        
                    </table>
                </div>
              </div>
            
              
              
              
            </div> <!-- /.table-responsive -->
          </div>
        </div> <!-- /.row -->
      </div> <!-- /#container-fluid -->
    </section>
    
  </div>
  <!-- /#main-content -->
