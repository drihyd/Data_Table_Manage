<div class="sub-header">Update Dollar Price for all the Products</div>
    <section class="white-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <?php echo validation_errors(); ?>
            <?php 
            $attributes = array('id' => 'update_price_form');
             echo form_open('update_price/update/', $attributes); ?>
              <div class="form-group inline col-sm-6">
                <label for="price_factor" class="control-label">Enter Dollar Price in INR</label>
                <input type="text" class="form-control" id="price_factor" name="price_factor" value="" required>
              </div><br>              
              <div id="passConfirmMessage"></div><br>
              <div class="form-group margin-top-0">
                <button type="submit" id="update_price" class="btn btn-brand btn-wide btn-sm">Update Price</button> <a href="<?php echo $this->config->base_url().'dashboard'; ?>" class="btn btn-action-link">Cancel</a>
              </div>
            </form>
          </div>
        </div>
      </div> <!-- /.container-fluid -->
    </section>

  </div>
  <!-- /#main-content -->