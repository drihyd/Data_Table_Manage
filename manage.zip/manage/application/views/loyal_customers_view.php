<?php
setlocale(LC_MONETARY, 'en_IN');
?>
<style>
    table.dataTable tbody th,
    table.dataTable tbody td {
		font-size: 12px;
		padding:5px 10px;
	}
</style>
<div class="sub-header">Loyal Customers</div>
<section class="stats-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12">
				<a href="<?php echo $this->config->base_url().'loyal_customers?excel=1'; ?>" class="btn btn-brand btn-wide" style="display: block;margin:15px auto;width:175px;">Export to Excel</a>
				<table class="dataTable">
					
					<thead>
						<tr>
							<th>Name</th>
							<th>ID</th>
							<th>Email</th>
							<th>Orders</th>
							<th>Revenue</th>
							<th>Average</th>
							<th width="100px">Age (days)</th>
							<th width="150px">Last order (days)</th>
							<th>Cities</th>
							<th>Countries</th>
						</tr>
					</thead>
					
					<tbody>
						
<?php
if(count($customer_data) > 0) {
	foreach($customer_data as $customer) {
		if($customer['total_orders'] > 1) { ?>
						
						<tr>
							<td><a href="<?php echo $this->config->base_url().'customers/customer_info/' . $customer['id']; ?>" target="_blank"><?php echo ucwords($customer['name']); ?></a></td>
							<td><a href="<?php echo $this->config->base_url().'customers/customer_info/' . $customer['id']; ?>" target="_blank"><?php echo ucwords($customer['id']); ?></a></td>
							<td><?php echo $customer['email']; ?></td>
							<td><?php echo $customer['total_orders']; ?></td>
							<td><?php echo money_format('%!.2n',$customer['total_revenue']); ?></td>
							<td><?php echo money_format('%!.0n',$customer['avg_order_value']); ?></td>
							<td><?php echo $customer['num_days']; ?></td>
							<td><?php echo $customer['last_order_days']; ?></td>
							<td><?php echo ucwords($customer['cities']); ?></td>
							<td><?php echo ucwords($customer['countries']); ?></td>
						</tr>

<?php
		}
	}
} else { ?>
						<td>
							<td colspan="9">Sorry! No Records</td>
						</td>
<?php
} ?>
					</tbody>
					
				</table>
				
			</div>
		</div>
	</div>
</section>
